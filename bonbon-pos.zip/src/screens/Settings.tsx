import { type ReactNode, useMemo, useState } from 'react';
import { LuDatabaseZap, LuMoon, LuMonitorSmartphone, LuSave, LuSun, LuTrash2 } from 'react-icons/lu';
import { formatQty } from '../core/format';
import { DEMO_SKUS, seedDemo } from '../core/demo';
import { saveSettings } from '../core/services';
import type { PaymentMethod, RoundingMode, Settings, Transaction } from '../core/types';
import { METHOD_LABEL } from '../core/types';
import { useCart } from '../app/cart';
import { ReceiptPaper } from '../app/Receipt';
import { requestNotifyPermission, sendTestNotification } from '../app/notifications';
import { IS_ARTIFACT, IS_NATIVE } from '../app/runtime';
import { type ThemePref, getThemePref, setThemePref } from '../app/theme';
import { useAppState, useStore } from '../app/state';
import { ConfirmDialog, Field, NumberInput, PageHeader, cx, errorMessage, useToast } from '../app/ui';
import { BackupPanel } from './Backup';

const METHODS: PaymentMethod[] = ['cash', 'qris', 'transfer', 'ewallet', 'debit', 'credit'];

function Switch({ checked, onChange, label, hint }: { checked: boolean; onChange: (v: boolean) => void; label: string; hint?: string }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <div className="min-w-0">
        <p className="text-sm font-semibold">{label}</p>
        {hint && <p className="hint">{hint}</p>}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        onClick={() => onChange(!checked)}
        className={cx('relative mt-0.5 h-6 w-11 shrink-0 rounded-full transition-colors', checked ? 'bg-accent' : 'bg-line')}
      >
        <span className={cx('absolute top-0.5 left-0.5 size-5 rounded-full bg-white shadow transition-transform', checked && 'translate-x-5')} />
      </button>
    </div>
  );
}

function ThemeChoice() {
  const [pref, setPref] = useState<ThemePref>(getThemePref);
  const opts: { id: ThemePref; label: string; icon: ReactNode }[] = [
    { id: 'auto', label: 'Otomatis', icon: <LuMonitorSmartphone size={18} /> },
    { id: 'light', label: 'Terang', icon: <LuSun size={18} /> },
    { id: 'dark', label: 'Gelap', icon: <LuMoon size={18} /> },
  ];
  return (
    <div className="grid grid-cols-3 gap-2" role="group" aria-label="Tema tampilan">
      {opts.map((o) => (
        <button
          key={o.id}
          type="button"
          aria-pressed={pref === o.id}
          onClick={() => {
            setPref(o.id);
            setThemePref(o.id);
          }}
          className={cx('flex min-h-16 flex-col items-center justify-center gap-1 rounded-xl border text-[13px] font-semibold transition-colors', pref === o.id ? 'border-accent bg-accentsoft text-accent' : 'border-line bg-panel text-muted hover:text-ink')}
        >
          {o.icon}
          {o.label}
        </button>
      ))}
    </div>
  );
}

function Section({ title, subtitle, children }: { title: string; subtitle?: string; children: ReactNode }) {
  return (
    <section className="card p-5">
      <h2 className="text-base font-bold">{title}</h2>
      {subtitle && <p className="mb-4 text-sm text-muted">{subtitle}</p>}
      <div className={cx('grid gap-4', !subtitle && 'mt-4')}>{children}</div>
    </section>
  );
}

function sampleTx(s: Settings): Transaction {
  const now = new Date().toISOString();
  const total = 3500 * 2 + 15000;
  return {
    id: 'sample',
    receiptNo: 'INV-20261019-0001',
    dateKey: '2026-10-19',
    cashierId: 'kasir',
    cashierName: s.cashierName,
    items: [
      { productId: 'a', name: 'Indomie Goreng', unitName: 'pcs', unitQty: 2, conversion: 1, qty: 2, unitPrice: 3500, costPrice: 2800, discount: 0 },
      { productId: 'b', name: 'Roti Tawar Sari Roti', unitName: 'pcs', unitQty: 1, conversion: 1, qty: 1, unitPrice: 15000, costPrice: 12500, discount: 0 },
    ],
    subtotal: total,
    discount: 0,
    taxPercent: 0,
    tax: 0,
    rounding: 0,
    total,
    payments: [{ method: 'cash', amount: total, tendered: 50000, status: 'success' }],
    change: 50000 - total,
    status: 'completed',
    createdAt: now,
  };
}

/** lastBackupAt is written by the backup buttons, never by this form: keep it out of dirty checks and saves. */
function withoutBackupStamp(s: Settings): Omit<Settings, 'lastBackupAt'> {
  const { lastBackupAt: _ignored, ...rest } = s;
  return rest;
}

export function SettingsScreen() {
  const state = useAppState();
  const store = useStore();
  const toast = useToast();
  const { dispatch } = useCart();
  const [draft, setDraft] = useState<Settings>(state.settings);
  const [busy, setBusy] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [seeding, setSeeding] = useState(false);

  const dirty = useMemo(() => JSON.stringify(withoutBackupStamp(draft)) !== JSON.stringify(withoutBackupStamp(state.settings)), [draft, state.settings]);
  const set = <K extends keyof Settings>(k: K, v: Settings[K]) => setDraft((d) => ({ ...d, [k]: v }));
  const hasDemo = state.products.some((p) => DEMO_SKUS.includes(p.sku));
  const sample = useMemo(() => sampleTx(draft), [draft]);

  const save = async () => {
    setBusy(true);
    try {
      const saved = await saveSettings(store, withoutBackupStamp(draft));
      setDraft(saved);
      toast('Pengaturan disimpan.');
    } catch (e) {
      toast(errorMessage(e), 'err');
    } finally {
      setBusy(false);
    }
  };

  const toggleMethod = (m: PaymentMethod) =>
    set('enabledMethods', draft.enabledMethods.includes(m) ? draft.enabledMethods.filter((x) => x !== m) : METHODS.filter((x) => x === m || draft.enabledMethods.includes(x)));

  return (
    <>
      <PageHeader
        title="Pengaturan"
        subtitle="Profil toko, pajak, stok, struk, dan metode pembayaran."
        actions={
          <button type="button" className="btn btn-primary" disabled={!dirty || busy} onClick={save}>
            <LuSave size={17} /> {busy ? 'Menyimpan...' : dirty ? 'Simpan pengaturan' : 'Tersimpan'}
          </button>
        }
      />

      <div className="grid items-start gap-4 lg:grid-cols-2">
        <div className="grid gap-4">
          {!IS_ARTIFACT && (
            <Section title="Tampilan" subtitle="Otomatis mengikuti mode terang atau gelap di HP. Pilihan ini hanya berlaku di perangkat ini.">
              <ThemeChoice />
            </Section>
          )}
          <Section title="Profil toko" subtitle="Tampil di bagian atas struk.">
            <Field label="Nama toko">
              <input className="input" value={draft.storeName} onChange={(e) => set('storeName', e.target.value)} />
            </Field>
            <Field label="Alamat">
              <input className="input" value={draft.address} onChange={(e) => set('address', e.target.value)} />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Telepon (opsional)">
                <input className="input" inputMode="tel" value={draft.phone ?? ''} onChange={(e) => set('phone', e.target.value)} />
              </Field>
              <Field label="Nama kasir" hint="Dicatat di setiap transaksi.">
                <input className="input" value={draft.cashierName} onChange={(e) => set('cashierName', e.target.value)} />
              </Field>
            </div>
          </Section>

          <Section title="Pajak dan pembulatan" subtitle="Urutan hitung: subtotal, diskon, pajak, pembulatan.">
            <Switch checked={draft.taxEnabled} onChange={(v) => set('taxEnabled', v)} label="Tambahkan PPN ke transaksi" hint="Harga jual dianggap belum termasuk pajak. Konsultasikan aturan pajak usaha Anda dengan konsultan pajak." />
            {draft.taxEnabled && (
              <Field label="Persentase PPN (%)">
                <NumberInput value={draft.taxPercent} onChange={(n) => set('taxPercent', n ?? 0)} className="max-w-32" />
              </Field>
            )}
            <Field label="Pembulatan total">
              <select className="input" value={draft.roundingMode} onChange={(e) => set('roundingMode', e.target.value as RoundingMode)}>
                <option value="none">Tanpa pembulatan</option>
                <option value="100">Ke Rp 100 terdekat</option>
                <option value="500">Ke Rp 500 terdekat</option>
              </select>
            </Field>
          </Section>

          <Section title="Kas laci">
            <Switch checked={draft.requireShift} onChange={(v) => set('requireShift', v)} label="Wajib buka kas sebelum berjualan" hint="Jika aktif, Kasir menolak transaksi sampai kas laci dibuka di menu Kas Laci. Biarkan mati kalau kamu hanya ingin memakainya sesekali." />
          </Section>

          <Section title="Stok">
            <Switch checked={draft.allowNegativeStock} onChange={(v) => set('allowNegativeStock', v)} label="Izinkan stok minus" hint="Jika aktif, barang tetap bisa dijual saat stok di sistem 0 (mis. stok belum sempat dicatat)." />
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Stok minimum default" hint="Untuk produk baru.">
                <NumberInput value={draft.defaultMinStock} onChange={(n) => set('defaultMinStock', n ?? 0)} />
              </Field>
              <Field label="Metode HPP" className="sm:col-span-1">
                <select className="input" value={draft.costMethod} onChange={(e) => set('costMethod', e.target.value as Settings['costMethod'])}>
                  <option value="average">Rata-rata tertimbang</option>
                  <option value="last">Harga beli terakhir</option>
                </select>
              </Field>
              <Field label="Peringatan kadaluarsa (hari)">
                <NumberInput value={draft.expiryWarnDays} onChange={(n) => set('expiryWarnDays', Math.max(0, Math.round(n ?? 0)))} />
              </Field>
            </div>
            <p className="hint -mt-2">Stok minimum default saat ini {formatQty(state.settings.defaultMinStock)}. Produk lama tidak berubah.</p>
          </Section>

          {IS_NATIVE && (
            <Section title="Notifikasi stok" subtitle="Pengingat harian di HP untuk produk yang habis atau menipis. Isinya selalu mengikuti stok terakhir di aplikasi.">
              <Switch
                checked={draft.stockNotify}
                onChange={async (v) => {
                  if (v && !(await requestNotifyPermission())) {
                    toast('Izin notifikasi ditolak. Aktifkan lewat Pengaturan Android > Aplikasi > Warung Manop > Notifikasi.', 'err');
                    return;
                  }
                  set('stockNotify', v);
                }}
                label="Ingatkan stok setiap hari"
                hint="Tidak ada notifikasi kalau semua stok aman."
              />
              {draft.stockNotify && (
                <Field label="Jam pengingat">
                  <select className="input max-w-40" value={draft.stockNotifyHour} onChange={(e) => set('stockNotifyHour', Number(e.target.value))} aria-label="Jam pengingat">
                    {Array.from({ length: 24 }, (_, h) => (
                      <option key={h} value={h}>
                        {String(h).padStart(2, '0')}.00
                      </option>
                    ))}
                  </select>
                </Field>
              )}
              <div>
                <button
                  type="button"
                  className="btn btn-ghost"
                  onClick={async () => {
                    const sent = await sendTestNotification();
                    toast(sent ? 'Tes terkirim. Lihat bilah notifikasi HP.' : 'Notifikasi tidak bisa ditampilkan. Periksa izin notifikasi aplikasi di Android.', sent ? 'info' : 'err');
                  }}
                >
                  Kirim tes notifikasi
                </button>
              </div>
            </Section>
          )}

          <Section title="Metode pembayaran" subtitle="Metode yang muncul di layar pembayaran.">
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {METHODS.map((m) => {
                const on = draft.enabledMethods.includes(m);
                return (
                  <button
                    key={m}
                    type="button"
                    aria-pressed={on}
                    onClick={() => toggleMethod(m)}
                    className={cx('min-h-11 rounded-md border px-3 text-sm font-semibold transition-colors', on ? 'border-accent bg-accentsoft text-accent' : 'border-line bg-panel text-muted hover:text-ink')}
                  >
                    {METHOD_LABEL[m]}
                  </button>
                );
              })}
            </div>
            <Switch
              checked={draft.kasbonEnabled}
              onChange={(v) => set('kasbonEnabled', v)}
              label="Tawarkan Kasbon (bayar nanti) di kasir"
              hint="Pelanggan yang kasbon harus dipilih atau didaftarkan dulu. Utang dicatat di menu Kasbon dan bisa dicicil. Jika dimatikan, catatan kasbon yang sudah ada tetap tersimpan."
            />
          </Section>
        </div>

        <div className="grid gap-4 lg:sticky lg:top-4">
          <Section title="Struk" subtitle="Pratinjau langsung dengan contoh transaksi.">
            <Field label="Teks penutup">
              <input className="input" value={draft.receiptFooter} onChange={(e) => set('receiptFooter', e.target.value)} />
            </Field>
            <div>
              <span className="label">Lebar kertas</span>
              <div className="inline-flex overflow-hidden rounded-md border border-line" role="group" aria-label="Lebar kertas">
                {([58, 80] as const).map((w) => (
                  <button key={w} type="button" aria-pressed={draft.paperWidth === w} onClick={() => set('paperWidth', w)} className={cx('min-h-11 px-5 text-sm font-semibold', draft.paperWidth === w ? 'bg-accent text-onaccent' : 'bg-panel text-muted hover:bg-sunken')}>
                    {w} mm
                  </button>
                ))}
              </div>
            </div>
            <div className="rounded-lg bg-sunken px-3 py-5">
              <ReceiptPaper tx={sample} settings={draft} />
            </div>
          </Section>

          <Section title="Cadangan data" subtitle="Simpan salinan seluruh data (produk, stok, transaksi, kasbon) supaya bisa dipulihkan kapan saja.">
            <BackupPanel />
          </Section>

          <Section title="Data" subtitle="Semua data tersimpan di peramban ini (IndexedDB) dan tetap ada saat offline.">
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                className="btn btn-ghost"
                disabled={seeding || hasDemo}
                onClick={async () => {
                  setSeeding(true);
                  try {
                    const r = await seedDemo(store);
                    toast(`Data demo terisi: ${r.products} produk dan ${r.transactions} transaksi.`);
                  } catch (e) {
                    toast(errorMessage(e), 'err');
                  } finally {
                    setSeeding(false);
                  }
                }}
              >
                <LuDatabaseZap size={17} /> {seeding ? 'Mengisi...' : hasDemo ? 'Data demo sudah ada' : 'Isi data demo'}
              </button>
              <button type="button" className="btn btn-ghost text-bad" onClick={() => setConfirmReset(true)}>
                <LuTrash2 size={17} /> Hapus semua data
              </button>
            </div>
            {state.volatile && <p className="err">Penyimpanan peramban tidak tersedia, jadi data hilang saat halaman ditutup.</p>}
          </Section>
        </div>
      </div>

      {confirmReset && (
        <ConfirmDialog
          title="Hapus semua data?"
          message="Produk, stok, riwayat transaksi, dan pengaturan akan dihapus permanen dari peramban ini. Tindakan ini tidak bisa dibatalkan."
          confirmLabel="Hapus semua"
          danger
          onClose={() => setConfirmReset(false)}
          onConfirm={async () => {
            setConfirmReset(false);
            try {
              await store.resetAll();
              dispatch({ type: 'clear' });
              setDraft(store.getState().settings);
              toast('Semua data dihapus.');
            } catch (e) {
              toast(errorMessage(e), 'err');
            }
          }}
        />
      )}
    </>
  );
}
