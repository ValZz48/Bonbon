// Android notifications (APK only). Everything here is best effort and silent on failure: a missing
// permission or an old Android must never get in the way of selling.

import type { DailySummary } from '../core/stockNotify';
import { IS_NATIVE, nativePlugin } from './runtime';

const DAILY_ID = 7001;
const TEST_ID = 7002;
const CHANNEL = 'stok';

let chain: Promise<unknown> = Promise.resolve();
/** one plugin call at a time, in order, so a quick series of changes cannot interleave */
const queue = <T,>(fn: () => Promise<T>): Promise<T> => {
  const p = chain.then(fn, fn);
  chain = p.catch(() => undefined);
  return p;
};

async function ensureChannel(): Promise<void> {
  await nativePlugin('LocalNotifications').createChannel({ id: CHANNEL, name: 'Peringatan stok', description: 'Pengingat produk yang habis atau menipis', importance: 4, visibility: 1 });
}

/** Asks Android for permission to show notifications. true when allowed. */
export async function requestNotifyPermission(): Promise<boolean> {
  if (!IS_NATIVE) return false;
  try {
    const ln = nativePlugin('LocalNotifications');
    const have = await ln.checkPermissions();
    if (have?.display === 'granted') return true;
    const asked = await ln.requestPermissions();
    return asked?.display === 'granted';
  } catch {
    return false;
  }
}

/**
 * Makes the one daily reminder match the current stock: replaced whenever the text, hour or on/off changes,
 * removed when nothing needs attention or the switch is off. Repeats every day at `hour` until replaced.
 */
export function syncDailyNotification(opts: { enabled: boolean; hour: number; summary: DailySummary | null }): Promise<void> {
  if (!IS_NATIVE) return Promise.resolve();
  return queue(async () => {
    try {
      const ln = nativePlugin('LocalNotifications');
      await ln.cancel({ notifications: [{ id: DAILY_ID }] });
      if (!opts.enabled || !opts.summary) return;
      if ((await ln.checkPermissions())?.display !== 'granted') return;
      await ensureChannel();
      await ln.schedule({
        notifications: [
          {
            id: DAILY_ID,
            channelId: CHANNEL,
            title: opts.summary.title,
            body: opts.summary.body,
            largeBody: opts.summary.detail,
            schedule: { on: { hour: opts.hour, minute: 0 }, allowWhileIdle: true },
          },
        ],
      });
    } catch {
      /* best effort */
    }
  });
}

/** Shows a notification right now, so the user can check that notifications work on this phone. */
export function sendTestNotification(): Promise<boolean> {
  return queue(async () => {
    try {
      if (!(await requestNotifyPermission())) return false;
      await ensureChannel();
      await nativePlugin('LocalNotifications').schedule({
        notifications: [{ id: TEST_ID, channelId: CHANNEL, title: 'Tes notifikasi Bonbon', body: 'Kalau ini muncul, pengingat stok akan sampai ke HP ini.' }],
      });
      return true;
    } catch {
      return false;
    }
  });
}
