// Run in CI after `npx cap add android` (and before `npx cap sync`): makes the generated Android project
// match this app. No dependencies; every step is idempotent. Usage: node scripts/android-patch.mjs [androidDir]
//
//   - permissions: notifications (Android 13+), camera (barcode scan), vibrate (scan feedback)
//   - targetSdk 34, so the WebView is not drawn under the status bar (Android 15 forces edge-to-edge from 35)
//   - versionCode from the CI run number, so every build can be installed over the previous one
//   - fixed signing key (warung-manop.keystore): updates install over the old app and keep its data
//   - Bonbon launcher icon, notification icon, launch screen and brand colours (images from scripts/android-icons)

import { copyFileSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const android = resolve(process.argv[2] ?? join(root, 'android'));
const res = join(android, 'app/src/main/res');
console.log('Menyesuaikan proyek Android');
const warn = [];
const log = (m) => console.log(`  ${m}`);

function edit(file, fn, what, { required = false } = {}) {
  if (!existsSync(file)) {
    if (required) throw new Error(`File tidak ditemukan: ${file}`);
    warn.push(`${what}: ${file} tidak ada`);
    return;
  }
  const before = readFileSync(file, 'utf8');
  const after = fn(before);
  if (after === null) {
    if (required) throw new Error(`Pola tidak cocok untuk: ${what}`);
    warn.push(`${what}: pola tidak cocok`);
    return;
  }
  if (after !== before) writeFileSync(file, after);
  log(`${what}: ok`);
}

// ---- manifest -------------------------------------------------------------------------
edit(
  join(android, 'app/src/main/AndroidManifest.xml'),
  (s) => {
    const want = [
      '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
      '<uses-permission android:name="android.permission.CAMERA" />',
      '<uses-permission android:name="android.permission.VIBRATE" />',
      '<uses-feature android:name="android.hardware.camera" android:required="false" />',
    ].filter((line) => !s.includes(line.match(/"([^"]+)"/)[1]));
    if (!s.includes('<application')) return null;
    let out = want.length ? s.replace('<application', `${want.join('\n    ')}\n\n    <application`) : s;
    if (!/windowSoftInputMode/.test(out)) out = out.replace(/<activity\b/, '<activity\n            android:windowSoftInputMode="adjustResize"');
    return out;
  },
  'AndroidManifest (izin, keyboard)',
  { required: true },
);

// ---- gradle ---------------------------------------------------------------------------
edit(join(android, 'variables.gradle'), (s) => (/targetSdkVersion\s*=\s*\d+/.test(s) ? s.replace(/targetSdkVersion\s*=\s*\d+/, 'targetSdkVersion = 34') : null), 'targetSdk 34');

const run = Number(process.env.GITHUB_RUN_NUMBER ?? '1') || 1;
copyFileSync(join(root, 'warung-manop.keystore'), join(android, 'app/warung-manop.keystore'));
edit(
  join(android, 'app/build.gradle'),
  (s) => {
    if (!/versionCode\s+\d+/.test(s)) return null;
    let out = s.replace(/versionCode\s+\d+/, `versionCode ${run}`).replace(/versionName\s+"[^"]*"/, `versionName "1.${run}"`);
    if (!out.includes('warung-manop.keystore')) {
      out += `
android {
    signingConfigs {
        debug {
            storeFile file('warung-manop.keystore')
            storePassword 'warungmanop'
            keyAlias 'warungmanop'
            keyPassword 'warungmanop'
        }
    }
}
`;
    }
    return out;
  },
  `versionCode ${run}, kunci tanda tangan tetap`,
  { required: true },
);

// ---- icons ----------------------------------------------------------------------------
// The Bonbon images are pre-rendered by scripts/make-icons.mjs into scripts/android-icons/ (file name =
// <folder>-<name>.png, for example mipmap-hdpi-ic_launcher.png), so CI needs no image tooling.
const BRAND = '#4540D8';
const iconsDir = join(root, 'scripts/android-icons');

function write(path, data) {
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, data);
}

export function writeIcons(resDir) {
  let copied = 0;
  for (const name of readdirSync(iconsDir)) {
    const m = /^((?:mipmap|drawable)-[a-z]+)-(.+\.png)$/.exec(name);
    if (!m) continue; // preview files and the like
    write(join(resDir, m[1], m[2]), readFileSync(join(iconsDir, name)));
    copied++;
  }
  if (copied === 0) throw new Error('Tidak ada gambar ikon di scripts/android-icons');
  write(join(resDir, 'values/wm_colors.xml'), `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="wm_icon_bg">${BRAND}</color>\n</resources>\n`);
  const adaptive = `<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/wm_icon_bg"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n`;
  write(join(resDir, 'mipmap-anydpi-v26/ic_launcher.xml'), adaptive);
  write(join(resDir, 'mipmap-anydpi-v26/ic_launcher_round.xml'), adaptive);

  // launch screen: indigo with the candy in the middle. The template's own splash.png files (all densities and
  // orientations) go, and one drawable/splash.xml takes their place under the same name.
  for (const dir of readdirSync(resDir)) {
    if (dir.startsWith('drawable') && existsSync(join(resDir, dir, 'splash.png'))) rmSync(join(resDir, dir, 'splash.png'));
  }
  write(
    join(resDir, 'drawable/splash.xml'),
    `<?xml version="1.0" encoding="utf-8"?>\n<layer-list xmlns:android="http://schemas.android.com/apk/res/android">\n    <item android:drawable="@color/wm_icon_bg"/>\n    <item>\n        <bitmap android:gravity="center" android:src="@drawable/bonbon_splash_mark"/>\n    </item>\n</layer-list>\n`,
  );
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  writeIcons(res);
  log('ikon aplikasi, ikon notifikasi, layar pembuka: ok');
  // Android 12+ draws its own launch screen from the theme; give it the brand colour and the candy
  edit(
    join(res, 'values/styles.xml'),
    (s) => {
      if (s.includes('windowSplashScreenBackground')) return s;
      if (!/<style name="AppTheme\.NoActionBarLaunch"[^>]*parent="Theme\.SplashScreen"/.test(s)) return null;
      return s.replace(/(<style name="AppTheme\.NoActionBarLaunch"[^>]*>)/, '$1\n        <item name="windowSplashScreenBackground">@color/wm_icon_bg</item>\n        <item name="windowSplashScreenAnimatedIcon">@mipmap/ic_launcher_foreground</item>');
    },
    'layar pembuka Android 12+',
  );
  // status bar and system accent follow the brand
  edit(
    join(res, 'values/colors.xml'),
    (s) => {
      const out = s
        .replace(/(<color name="colorPrimary">)#[0-9A-Fa-f]{6,8}/, `$1${BRAND}`)
        .replace(/(<color name="colorPrimaryDark">)#[0-9A-Fa-f]{6,8}/, '$1#2F2BA8')
        .replace(/(<color name="colorAccent">)#[0-9A-Fa-f]{6,8}/, `$1${BRAND}`);
      return /colorPrimary/.test(s) ? out : null;
    },
    'warna tema',
  );
  if (warn.length) console.log(`\nPERINGATAN:\n${warn.map((w) => `  - ${w}`).join('\n')}`);
}
