// Makes a .y4m video for Chromium's fake camera (--use-file-for-fake-video-capture) showing real EAN-13 barcodes,
// so the e2e test can exercise the whole scanner: camera -> canvas -> decoder -> cart. No dependencies.

import { writeFileSync } from 'node:fs';

// Standard EAN-13 module tables (binary), the same ones printers use.
const L = ['0001101', '0011001', '0010011', '0111101', '0100011', '0110001', '0101111', '0111011', '0110111', '0001011'];
const G = ['0100111', '0110011', '0011011', '0100001', '0011101', '0111001', '0000101', '0010001', '0001001', '0010111'];
const R = ['1110010', '1100110', '1101100', '1000010', '1011100', '1001110', '1010000', '1000100', '1001000', '1110100'];
const PARITY = ['LLLLLL', 'LLGLGG', 'LLGGLG', 'LLGGGL', 'LGLLGG', 'LGGLLG', 'LGGGLL', 'LGLGLG', 'LGLGGL', 'LGGLGL'];

export function ean13Check(first12) {
  let sum = 0;
  for (let i = 0; i < 12; i++) sum += Number(first12[i]) * (i % 2 === 0 ? 1 : 3);
  return (10 - (sum % 10)) % 10;
}
export const withCheckDigit = (first12) => first12 + ean13Check(first12);

export function ean13Modules(code) {
  const d = [...code].map(Number);
  let s = '101';
  for (let i = 0; i < 6; i++) s += (PARITY[d[0]][i] === 'L' ? L : G)[d[1 + i]];
  s += '01010';
  for (let i = 0; i < 6; i++) s += R[d[7 + i]];
  return s + '101';
}

function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** One frame: paper with uneven light and noise, optional barcode, and some printed clutter below. */
function renderFrame(w, h, code, seed) {
  const rand = rng(seed);
  const y = new Uint8Array(w * h);
  const mod = code ? ean13Modules(code) : null;
  const px = 4.1;
  const x0 = mod ? Math.round((w - mod.length * px) / 2) : 0;
  for (let j = 0; j < h; j++) {
    for (let i = 0; i < w; i++) {
      let v = 214 - 22 * (i / w) + 8 * Math.sin(j / 60);
      if (mod && j >= 140 && j <= 290) {
        const m = Math.floor((i - x0) / px);
        if (m >= 0 && m < mod.length && mod[m] === '1') v = 38;
      }
      // printed clutter (text-like blocks) away from the barcode
      if (j >= 330 && j <= 372 && ((Math.floor(i / 9) * 7 + Math.floor(j / 6) * 3) % 5 < 2) && i > 60 && i < w - 60) v = Math.min(v, 70);
      y[j * w + i] = Math.max(0, Math.min(255, v + (rand() - 0.5) * 10));
    }
  }
  return y;
}

/**
 * sequence: [{ code: '8998866200301' | null, frames: 12 }, ...]. The camera plays the file in a loop.
 */
export function writeBarcodeVideo(file, sequence, { width = 640, height = 480, fps = 8 } = {}) {
  const header = Buffer.from(`YUV4MPEG2 W${width} H${height} F${fps}:1 Ip A1:1 C420jpeg\n`);
  const chroma = Buffer.alloc((width * height) / 2, 128); // U and V planes, neutral
  const parts = [header];
  const cache = new Map();
  let seed = 1;
  for (const { code, frames } of sequence) {
    for (let f = 0; f < frames; f++) {
      const key = `${code}:${f % 3}`; // three noise variants per code keep the sensor noise realistic but the file small to build
      let buf = cache.get(key);
      if (!buf) {
        buf = Buffer.concat([Buffer.from('FRAME\n'), Buffer.from(renderFrame(width, height, code, seed++)), chroma]);
        cache.set(key, buf);
      }
      parts.push(buf);
    }
  }
  writeFileSync(file, Buffer.concat(parts));
}
