// Renders the Android launcher / notification / splash images from the traced Bonbon symbol (src/app/brandPaths.ts).
// Needs Playwright with Chromium, so it runs on a computer, not in CI: the PNGs it writes to scripts/android-icons/
// are committed and copied into the Android project by scripts/android-patch.mjs.
//
//   node scripts/make-icons.mjs

import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const src = readFileSync(join(root, 'src/app/brandPaths.ts'), 'utf8');
const D = src.match(/SYMBOL_D =\s*'([^']+)'/)[1];
const W = Number(src.match(/SYMBOL_W = ([\d.]+)/)[1]);
const H = Number(src.match(/SYMBOL_H = ([\d.]+)/)[1]);
const INDIGO = '#4540d8';
const out = join(root, 'scripts/android-icons');
mkdirSync(out, { recursive: true });

/** One square image: `bg` is 'square' | 'round' | null (transparent), the symbol is `fraction` of the width, in `color`. */
function svg(size, { bg, fraction, color, offsetY = 0 }) {
  const w = size * fraction;
  const k = w / W;
  const h = H * k;
  const x = (size - w) / 2;
  const y = (size - h) / 2 + size * offsetY;
  const back = bg === 'round' ? `<circle cx="${size / 2}" cy="${size / 2}" r="${size / 2}" fill="${INDIGO}"/>` : bg === 'square' ? `<rect width="${size}" height="${size}" rx="${size * 0.22}" fill="${INDIGO}"/>` : '';
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">${back}<path transform="translate(${x} ${y}) scale(${k})" fill="${color}" fill-rule="evenodd" d="${D}"/></svg>`;
}

const browser = await chromium.launch();
const page = await browser.newPage();
async function render(file, size, opts, width = size, height = size) {
  await page.setViewportSize({ width, height });
  await page.setContent(`<style>html,body{margin:0;background:transparent}</style>${svg(size, opts).replace(`width="${size}" height="${size}"`, `width="${width}" height="${height}"`)}`);
  const buf = await page.screenshot({ omitBackground: true, clip: { x: 0, y: 0, width, height } });
  writeFileSync(join(out, file), buf);
}

// density -> [launcher px (48dp), adaptive foreground px (108dp), notification px (24dp)]
const dens = { mdpi: [48, 108, 24], hdpi: [72, 162, 36], xhdpi: [96, 216, 48], xxhdpi: [144, 324, 72], xxxhdpi: [192, 432, 96] };
for (const [d, [launcher, fg, stat]] of Object.entries(dens)) {
  await render(`mipmap-${d}-ic_launcher.png`, launcher, { bg: 'square', fraction: 0.64, color: '#ffffff' });
  await render(`mipmap-${d}-ic_launcher_round.png`, launcher, { bg: 'round', fraction: 0.6, color: '#ffffff' });
  await render(`mipmap-${d}-ic_launcher_foreground.png`, fg, { bg: null, fraction: 0.52, color: '#ffffff' });
  await render(`drawable-${d}-ic_stat_notify.png`, stat, { bg: null, fraction: 0.92, color: '#ffffff' });
}
// centre mark of the launch screen (the indigo background comes from the layer-list around it); 160dp wide at xxhdpi
await render('drawable-xxhdpi-bonbon_splash_mark.png', 480, { bg: null, fraction: 1, color: '#ffffff' }, 480, Math.ceil((480 * H) / W));
// a big preview, not used by the app
await render('preview-512.png', 512, { bg: 'square', fraction: 0.64, color: '#ffffff' });
await browser.close();
console.log('ikon ditulis ke scripts/android-icons');
