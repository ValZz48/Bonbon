create sequence if not exists public.sync_seq;

create table public.sync_rows (
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  tbl text not null check (tbl in ('products','productUnits','stockMovements','transactions','customers','debtEntries','shifts','cashMoves','returns','opnames','holds','settings')),
  id text not null,
  data jsonb,
  deleted boolean not null default false,
  client_ts timestamptz not null default now(),
  device_id text,
  seq bigint not null default nextval('public.sync_seq'),
  primary key (user_id, tbl, id)
);

create index sync_rows_pull_idx on public.sync_rows (user_id, seq);

create or replace function public.sync_rows_bump() returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.seq := nextval('public.sync_seq');
  new.user_id := coalesce(new.user_id, auth.uid());
  return new;
end;
$$;

create trigger sync_rows_bump_trg before insert or update on public.sync_rows
for each row execute function public.sync_rows_bump();

alter table public.sync_rows enable row level security;

create policy "own rows select" on public.sync_rows for select to authenticated using (user_id = (select auth.uid()));
create policy "own rows insert" on public.sync_rows for insert to authenticated with check (user_id = (select auth.uid()));
create policy "own rows update" on public.sync_rows for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "own rows delete" on public.sync_rows for delete to authenticated using (user_id = (select auth.uid()));

revoke all on public.sync_rows from anon;
grant select, insert, update, delete on public.sync_rows to authenticated;
grant usage, select on sequence public.sync_seq to authenticated;
