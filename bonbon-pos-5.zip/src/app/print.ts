// Ways to get a receipt onto paper: the browser's print dialog, a Bluetooth LE thermal printer, or the RawBT app.
// Everything here starts from the shared fixed-width layout (core/export.ts), so all three look the same.

import { chunkBytes, encodeEscPos, rawbtNativeUrl, rawbtUrl } from '../core/escpos';
import { IS_NATIVE } from './runtime';
import type { ReceiptLayout } from '../core/export';
import type { ReportTable } from '../core/reports';

export type Paper = 58 | 80;

// ---- browser print ------------------------------------------------------------------------------

/** 2.5 mm characters on 3.3 mm lines: the 12-dot "font A" of a 203 dpi thermal head, 32 characters in 48 mm. */
const LINE_MM = 3.3;
const PAD_TOP_MM = 3;
const PAD_BOTTOM_MM = 6;

/** Page height for a receipt of `lineCount` lines. A page must have an explicit height: `size: 58mm auto` is invalid CSS and browsers then fall back to a full A4/Letter sheet. */
export function receiptPageHeightMm(lineCount: number): number {
  return Math.ceil(lineCount * LINE_MM + PAD_TOP_MM + PAD_BOTTOM_MM + 1);
}

let printCleanup: (() => void) | null = null;

function cleanupPrint(): void {
  printCleanup?.();
  printCleanup = null;
}

/**
 * Opens the system print dialog with only the receipt on the page. Everything else in the app is `display: none`
 * while printing (see styles.css), so a roll printer gets one short page instead of blank paper.
 */
export function printInBrowser(layout: ReceiptLayout, paper: Paper): void {
  cleanupPrint();
  const root = document.createElement('div');
  root.id = 'print-root';
  root.setAttribute('data-paper', String(paper));
  const bold = new Set(layout.bold);
  layout.lines.forEach((line, i) => {
    const row = document.createElement('div');
    row.textContent = line === '' ? ' ' : line;
    if (bold.has(i)) row.className = 'b';
    root.appendChild(row);
  });
  const page = document.createElement('style');
  page.setAttribute('data-print-page', '');
  page.textContent = `@page { size: ${paper}mm ${receiptPageHeightMm(layout.lines.length)}mm; margin: 0; }`;
  document.head.appendChild(page);
  document.body.appendChild(root);
  document.body.classList.add('printing');

  const done = () => {
    window.removeEventListener('afterprint', done);
    document.body.classList.remove('printing');
    root.remove();
    page.remove();
    if (printCleanup === done) printCleanup = null;
  };
  printCleanup = done;
  window.addEventListener('afterprint', done);
  window.print();
}

// ---- report on A4 --------------------------------------------------------------------------------

/**
 * Prints report tables on A4. The browser's print dialog has "Save as PDF", which is how a PDF is made.
 * Like the receipt, only #print-report stays visible while printing (see styles.css).
 */
export function printReport(opts: { storeName: string; title: string; subtitle: string; tables: ReportTable[]; printedAt: string }): void {
  cleanupPrint();
  const root = document.createElement('div');
  root.id = 'print-report';
  const el = (tag: string, text?: string, cls?: string) => {
    const e = document.createElement(tag);
    if (text !== undefined) e.textContent = text;
    if (cls) e.className = cls;
    return e;
  };
  const head = el('header');
  head.append(el('p', opts.storeName, 'pr-store'), el('h1', opts.title), el('p', opts.subtitle, 'pr-sub'));
  root.appendChild(head);
  for (const t of opts.tables) {
    const sec = el('section');
    sec.appendChild(el('h2', t.title));
    const table = el('table');
    const thead = el('thead');
    const hr = el('tr');
    t.columns.forEach((c, i) => hr.appendChild(el('th', c, t.numeric.includes(i) ? 'n' : undefined)));
    thead.appendChild(hr);
    table.appendChild(thead);
    const tbody = el('tbody');
    for (const r of t.rows) {
      const tr = el('tr');
      r.forEach((c, i) => tr.appendChild(el('td', c, t.numeric.includes(i) ? 'n' : undefined)));
      tbody.appendChild(tr);
    }
    if (t.footer) {
      const tr = el('tr', undefined, 'f');
      t.footer.forEach((c, i) => tr.appendChild(el('td', c, t.numeric.includes(i) ? 'n' : undefined)));
      tbody.appendChild(tr);
    }
    table.appendChild(tbody);
    sec.appendChild(table);
    root.appendChild(sec);
  }
  root.appendChild(el('p', `Dicetak ${opts.printedAt}`, 'pr-foot'));

  const page = document.createElement('style');
  page.setAttribute('data-print-page', '');
  page.textContent = '@page { size: A4 portrait; margin: 14mm 12mm; }';
  document.head.appendChild(page);
  document.body.appendChild(root);
  document.body.classList.add('printing-report');

  const done = () => {
    window.removeEventListener('afterprint', done);
    document.body.classList.remove('printing-report');
    root.remove();
    page.remove();
    if (printCleanup === done) printCleanup = null;
  };
  printCleanup = done;
  window.addEventListener('afterprint', done);
  window.print();
}

// ---- Android / Bluetooth ------------------------------------------------------------------------

export function isAndroid(): boolean {
  return typeof navigator !== 'undefined' && /android/i.test(navigator.userAgent);
}

/** Opens RawBT (a free Android app that prints raw ESC/POS to Bluetooth and USB thermal printers). */
export function printViaRawBT(layout: ReceiptLayout, paper: Paper): void {
  const bytes = encodeEscPos(layout, { cut: paper === 80 });
  const url = IS_NATIVE ? rawbtNativeUrl(bytes) : rawbtUrl(bytes);
  const a = document.createElement('a');
  a.href = url;
  a.rel = 'noopener';
  document.body.appendChild(a);
  a.click();
  a.remove();
}

// Minimal Web Bluetooth surface (the DOM lib does not ship these types).
interface GattCharacteristic {
  properties: { write: boolean; writeWithoutResponse: boolean };
  writeValueWithResponse?(value: BufferSource): Promise<void>;
  writeValueWithoutResponse?(value: BufferSource): Promise<void>;
  writeValue(value: BufferSource): Promise<void>;
}
interface GattService {
  getCharacteristics(): Promise<GattCharacteristic[]>;
}
interface GattServer {
  connected: boolean;
  getPrimaryServices(): Promise<GattService[]>;
  disconnect(): void;
}
interface BluetoothDeviceLike {
  name?: string;
  gatt?: { connected: boolean; connect(): Promise<GattServer> };
}
interface BluetoothLike {
  requestDevice(options: { acceptAllDevices: true; optionalServices: string[] }): Promise<BluetoothDeviceLike>;
}

/** Services that cheap thermal printers use for their serial-over-BLE channel. Web Bluetooth only exposes services listed up front. */
const PRINTER_SERVICES = [
  '000018f0-0000-1000-8000-00805f9b34fb',
  '0000ff00-0000-1000-8000-00805f9b34fb',
  '0000ffe0-0000-1000-8000-00805f9b34fb',
  '0000ffe5-0000-1000-8000-00805f9b34fb',
  '0000fee7-0000-1000-8000-00805f9b34fb',
  '0000ae30-0000-1000-8000-00805f9b34fb',
  '0000a002-0000-1000-8000-00805f9b34fb',
  'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
  '49535343-fe7d-4ae5-8fa9-9fafd205e455',
  '38eb4a80-c570-11e3-9507-0002a5d5c51b',
  '00001101-0000-1000-8000-00805f9b34fb',
];

const bluetooth = (): BluetoothLike | undefined => (typeof navigator === 'undefined' ? undefined : (navigator as unknown as { bluetooth?: BluetoothLike }).bluetooth);

export function bluetoothSupported(): boolean {
  return !!bluetooth() && typeof window !== 'undefined' && window.isSecureContext;
}

export class PrintError extends Error {}

let lastDevice: BluetoothDeviceLike | null = null;
let lastChar: GattCharacteristic | null = null;

export function connectedPrinterName(): string | null {
  return lastDevice?.gatt?.connected && lastChar ? (lastDevice.name ?? 'Printer') : null;
}

export function forgetPrinter(): void {
  try {
    const gatt = lastDevice?.gatt as unknown as { connected: boolean; disconnect(): void } | undefined;
    if (gatt?.connected) gatt.disconnect();
  } catch {
    // already gone
  }
  lastDevice = null;
  lastChar = null;
}

async function findWritable(server: GattServer): Promise<GattCharacteristic> {
  const services = await server.getPrimaryServices();
  for (const s of services) {
    for (const c of await s.getCharacteristics()) {
      if (c.properties.write || c.properties.writeWithoutResponse) return c;
    }
  }
  throw new PrintError('Printer ini tidak membuka jalur cetak Bluetooth LE. Coba cetak lewat RawBT atau lewat peramban.');
}

async function connect(chooser: boolean): Promise<GattCharacteristic> {
  const bt = bluetooth();
  if (!bt) throw new PrintError('Peramban ini tidak mendukung Bluetooth.');
  if (!chooser && lastDevice?.gatt && lastChar) {
    try {
      if (!lastDevice.gatt.connected) {
        const server = await lastDevice.gatt.connect();
        lastChar = await findWritable(server);
      }
      return lastChar;
    } catch {
      // the printer was switched off or moved away: ask again below
    }
  }
  const device = await bt.requestDevice({ acceptAllDevices: true, optionalServices: PRINTER_SERVICES });
  if (!device.gatt) throw new PrintError('Perangkat yang dipilih tidak bisa dihubungkan.');
  const server = await device.gatt.connect();
  const characteristic = await findWritable(server);
  lastDevice = device;
  lastChar = characteristic;
  return characteristic;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** A permission prompt cancelled by the person is not an error worth shouting about. */
export function isChooserCancelled(e: unknown): boolean {
  return e instanceof Error && e.name === 'NotFoundError';
}

export function bluetoothErrorMessage(e: unknown): string {
  if (e instanceof PrintError) return e.message;
  if (e instanceof Error) {
    if (e.name === 'NotFoundError') return 'Tidak ada printer yang dipilih.';
    if (e.name === 'SecurityError' || e.name === 'NotAllowedError') return 'Izin Bluetooth ditolak. Izinkan Bluetooth (dan Lokasi di Android) untuk peramban ini, lalu coba lagi.';
    if (e.name === 'NetworkError') return 'Tidak bisa terhubung ke printer. Pastikan printer menyala dan dekat, lalu coba lagi.';
  }
  return 'Gagal mencetak lewat Bluetooth. Coba lagi, atau pakai RawBT atau cetak lewat peramban.';
}

/** Sends the receipt to a Bluetooth LE thermal printer, asking which one the first time. */
export async function printViaBluetooth(layout: ReceiptLayout, paper: Paper, onStatus?: (s: 'connecting' | 'printing') => void, chooser = false): Promise<string> {
  onStatus?.('connecting');
  const characteristic = await connect(chooser);
  const bytes = encodeEscPos(layout, { cut: paper === 80 });
  onStatus?.('printing');
  const noResponse = !characteristic.properties.write && characteristic.properties.writeWithoutResponse;
  const send = async (piece: Uint8Array) => {
    if (noResponse && characteristic.writeValueWithoutResponse) await characteristic.writeValueWithoutResponse(piece);
    else if (characteristic.writeValueWithResponse) await characteristic.writeValueWithResponse(piece);
    else await characteristic.writeValue(piece);
  };
  try {
    for (const piece of chunkBytes(bytes, 20)) {
      await send(piece);
      await sleep(20);
    }
  } catch (e) {
    // a stale connection: forget it so the next try asks for the printer again
    lastDevice = null;
    lastChar = null;
    throw e;
  }
  return lastDevice?.name ?? 'Printer';
}
