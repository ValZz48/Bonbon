import { useMemo, useState } from 'react';
import { LuCopy, LuSend } from 'react-icons/lu';
import { formatPhoneID, normalizePhoneID, waLink } from '../core/whatsapp';
import { IS_ARTIFACT } from './runtime';
import { Field, Modal, cx, useCopy } from './ui';

/**
 * "Kirim lewat WhatsApp": pick the number, edit the message, then open WhatsApp with the text typed.
 * Uses a wa.me link, so no WhatsApp account or API is needed; the person presses Send themselves.
 */
export function WaShareDialog({
  title,
  message,
  phone,
  onClose,
}: {
  title: string;
  message: string;
  /** known customer number (any format); empty = the person types one or picks a contact in WhatsApp */
  phone?: string;
  onClose: () => void;
}) {
  const copy = useCopy();
  const [number, setNumber] = useState(() => {
    const n = normalizePhoneID(phone);
    return n ? formatPhoneID(n) : '';
  });
  const [text, setText] = useState(message);

  const normalized = useMemo(() => normalizePhoneID(number), [number]);
  const invalid = number.trim() !== '' && !normalized;
  const href = invalid ? undefined : waLink(normalized, text);

  return (
    <Modal
      title={title}
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Tutup
          </button>
          <button type="button" className="btn btn-ghost" onClick={() => copy(text, 'Pesan disalin.')}>
            <LuCopy size={16} /> Salin pesan
          </button>
          {href ? (
            <a href={href} target="_blank" rel="noopener noreferrer" className="btn btn-primary">
              <LuSend size={16} /> Buka WhatsApp
            </a>
          ) : (
            <button type="button" className="btn btn-primary" disabled>
              <LuSend size={16} /> Buka WhatsApp
            </button>
          )}
        </>
      }
    >
      <Field
        label="Nomor WhatsApp"
        error={invalid ? 'Nomor tidak valid. Contoh: 0812 3456 7890 atau +62 812 3456 7890.' : null}
        hint={number.trim() === '' ? 'Kosongkan jika ingin memilih kontak langsung di WhatsApp.' : undefined}
      >
        <input
          className={cx('input', invalid && 'input-invalid')}
          inputMode="tel"
          autoComplete="off"
          placeholder="0812 3456 7890"
          value={number}
          onChange={(e) => setNumber(e.target.value)}
        />
      </Field>
      <Field label="Pesan (boleh diedit)" className="mt-4">
        <textarea className="input text-[13px] leading-relaxed" rows={12} value={text} onChange={(e) => setText(e.target.value)} />
      </Field>
      <p className="hint mt-2">
        Tombol Buka WhatsApp membuka aplikasi WhatsApp dengan pesan ini sudah terketik. Pesan baru terkirim setelah Anda menekan kirim di WhatsApp.
        {IS_ARTIFACT && ' Di halaman pratinjau ini WhatsApp bisa diblokir; jika tidak terbuka, pakai Salin pesan lalu tempel di chat.'}
      </p>
    </Modal>
  );
}
