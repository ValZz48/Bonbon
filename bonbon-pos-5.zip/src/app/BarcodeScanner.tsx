import { type FormEvent, useCallback, useEffect, useRef, useState } from 'react';
import { LuCamera, LuCameraOff, LuCircleCheck, LuFlashlight, LuKeyboard, LuRefreshCw, LuTriangleAlert } from 'react-icons/lu';
import { ScanGate, decodeFrame, rgbaToGray } from '../core/barcode';
import { IS_ARTIFACT } from './runtime';
import { Modal, cx } from './ui';

export interface ScanFeedback {
  tone: 'ok' | 'err';
  message: string;
}
/** Called for every new code. Return what to tell the person ("Indomie Goreng ditambahkan"); an 'err' tone keeps the scanner open. */
export type ScanHandler = (code: string) => ScanFeedback | void | Promise<ScanFeedback | void>;

interface DetectorLike {
  detect(source: CanvasImageSource): Promise<Array<{ rawValue: string }>>;
}
interface DetectorCtor {
  new (opts?: { formats?: string[] }): DetectorLike;
  getSupportedFormats?: () => Promise<string[]>;
}

/** The browser's own scanner (Chrome on Android and some desktops). Everything else uses our decoder in core/barcode. */
async function makeNativeDetector(): Promise<DetectorLike | null> {
  const Ctor = (window as unknown as { BarcodeDetector?: DetectorCtor }).BarcodeDetector;
  if (!Ctor) return null;
  try {
    const wanted = ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'code_39', 'itf', 'codabar'];
    const supported = (await Ctor.getSupportedFormats?.()) ?? [];
    const formats = supported.length ? wanted.filter((f) => supported.includes(f)) : wanted;
    return formats.length ? new Ctor({ formats }) : null;
  } catch {
    return null;
  }
}

function cameraProblem(e: unknown): string {
  const name = (e as { name?: string } | null)?.name;
  switch (name) {
    case 'NotAllowedError':
    case 'PermissionDeniedError':
    case 'SecurityError':
      return 'Izin kamera ditolak. Izinkan kamera untuk situs ini di pengaturan peramban, lalu coba lagi.';
    case 'NotFoundError':
    case 'DevicesNotFoundError':
      return 'Kamera tidak ditemukan di perangkat ini.';
    case 'NotReadableError':
    case 'TrackStartError':
      return 'Kamera sedang dipakai aplikasi lain. Tutup aplikasi itu, lalu coba lagi.';
    default:
      return 'Kamera tidak bisa dibuka.';
  }
}

let audio: AudioContext | undefined;
function signal(ok: boolean) {
  try {
    navigator.vibrate?.(ok ? 40 : [70, 50, 70]);
  } catch {
    /* not supported */
  }
  try {
    const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    audio ??= new Ctx();
    if (audio.state === 'suspended') void audio.resume();
    const osc = audio.createOscillator();
    const gain = audio.createGain();
    osc.type = 'square';
    osc.frequency.value = ok ? 1760 : 330;
    gain.gain.value = 0.035;
    osc.connect(gain);
    gain.connect(audio.destination);
    osc.start();
    osc.stop(audio.currentTime + (ok ? 0.09 : 0.22));
  } catch {
    /* sound is a nicety, never a blocker */
  }
}

type Phase = 'starting' | 'live' | 'error';

export function BarcodeScanner({
  title = 'Scan barcode',
  onCode,
  once = false,
  onClose,
  doneLabel = 'Selesai',
}: {
  title?: string;
  onCode: ScanHandler;
  /** close right after the first accepted code (single scan, e.g. filling a form field) */
  once?: boolean;
  onClose: () => void;
  doneLabel?: string;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const trackRef = useRef<MediaStreamTrack | null>(null);
  const gateRef = useRef(new ScanGate());
  const busyRef = useRef(false);
  const handlerRef = useRef(onCode);
  handlerRef.current = onCode;
  const closeRef = useRef(onClose);
  closeRef.current = onClose;

  const [phase, setPhase] = useState<Phase>('starting');
  const [problem, setProblem] = useState('');
  const [attempt, setAttempt] = useState(0);
  const [feedback, setFeedback] = useState<ScanFeedback | null>(null);
  const [count, setCount] = useState(0);
  const [torch, setTorch] = useState<'none' | 'off' | 'on'>('none');
  const [manual, setManual] = useState(false);
  const [manualText, setManualText] = useState('');

  const handleCode = useCallback(
    async (code: string) => {
      if (busyRef.current) return;
      busyRef.current = true;
      try {
        const fb = (await handlerRef.current(code)) ?? { tone: 'ok' as const, message: `Kode terbaca: ${code}` };
        setFeedback(fb);
        signal(fb.tone === 'ok');
        if (fb.tone === 'ok') {
          setCount((c) => c + 1);
          if (once) closeRef.current();
        }
      } finally {
        busyRef.current = false;
      }
    },
    [once],
  );

  useEffect(() => {
    let stopped = false;
    let timer = 0;
    let stream: MediaStream | null = null;
    const gate = gateRef.current;
    gate.reset();
    setPhase('starting');
    setProblem('');
    setTorch('none');

    const fail = (message: string) => {
      setProblem(message);
      setPhase('error');
      setManual(true);
    };

    const run = async () => {
      if (!navigator.mediaDevices?.getUserMedia) {
        fail('Peramban ini tidak mengizinkan kamera di halaman ini. Buka aplikasi lewat alamat https atau localhost.');
        return;
      }
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          audio: false,
          video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
        });
      } catch (e) {
        if (!stopped) fail(cameraProblem(e));
        return;
      }
      if (stopped) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      const video = videoRef.current;
      if (!video) return;
      video.srcObject = stream;
      try {
        await video.play();
      } catch {
        /* the loop below simply waits for frames */
      }
      if (stopped) return;

      const track = stream.getVideoTracks()[0];
      trackRef.current = track ?? null;
      try {
        const caps = (track?.getCapabilities?.() ?? {}) as { torch?: boolean };
        if (caps.torch) setTorch('off');
        await track?.applyConstraints({ advanced: [{ focusMode: 'continuous' } as unknown as MediaTrackConstraintSet] }).catch(() => undefined);
      } catch {
        /* optional capabilities */
      }
      setPhase('live');

      let detector = await makeNativeDetector();
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      let gray: Uint8Array | undefined;
      let pending: { code: string; t: number } | null = null;

      const tick = async () => {
        if (stopped) return;
        try {
          if (video.readyState >= 2 && video.videoWidth > 0 && !busyRef.current) {
            let code: string | null = null;
            if (detector) {
              try {
                const found = await detector.detect(video);
                code = found.find((f) => f.rawValue)?.rawValue ?? null;
              } catch {
                detector = null; // this device cannot actually scan natively: switch to our decoder
              }
            }
            if (!detector && ctx) {
              const scale = Math.min(1, 960 / video.videoWidth);
              const w = Math.round(video.videoWidth * scale);
              const h = Math.round(video.videoHeight * scale);
              if (canvas.width !== w || canvas.height !== h) {
                canvas.width = w;
                canvas.height = h;
                gray = undefined;
              }
              ctx.drawImage(video, 0, 0, w, h);
              gray = rgbaToGray(ctx.getImageData(0, 0, w, h).data, w * h, gray);
              const hit = decodeFrame(gray, w, h);
              if (hit) {
                // a read must be confirmed by a second scan line or the next frame before it counts
                const now = performance.now();
                if (hit.votes >= 2 || (pending && pending.code === hit.text && now - pending.t < 1000)) code = hit.text;
                else pending = { code: hit.text, t: now };
              }
            }
            if (code && gate.accept(code, performance.now())) void handleCode(code);
          }
        } catch {
          /* one bad frame must not stop the scanner */
        }
        if (!stopped) timer = window.setTimeout(tick, detector ? 90 : 120);
      };
      void tick();
    };
    void run();

    return () => {
      stopped = true;
      window.clearTimeout(timer);
      stream?.getTracks().forEach((t) => t.stop());
      trackRef.current = null;
      if (videoRef.current) videoRef.current.srcObject = null;
    };
  }, [attempt, handleCode]);

  const toggleTorch = async () => {
    const track = trackRef.current;
    if (!track) return;
    const next = torch !== 'on';
    try {
      await track.applyConstraints({ advanced: [{ torch: next } as unknown as MediaTrackConstraintSet] });
      setTorch(next ? 'on' : 'off');
    } catch {
      setTorch('none');
    }
  };

  const submitManual = (e: FormEvent) => {
    e.preventDefault();
    const code = manualText.trim();
    if (!code) return;
    setManualText('');
    void handleCode(code);
  };

  return (
    <Modal
      title={title}
      onClose={onClose}
      footer={
        <button type="button" className="btn btn-primary" onClick={onClose}>
          {doneLabel}
          {!once && count > 0 ? ` (${count} dipindai)` : ''}
        </button>
      }
    >
      <div className="grid gap-3">
        <div className="relative aspect-[4/3] w-full overflow-hidden rounded-lg bg-black">
          <video ref={videoRef} className="absolute inset-0 size-full object-cover" playsInline muted aria-label="Pratinjau kamera" />
          {phase === 'live' && (
            <div aria-hidden="true" className="pointer-events-none absolute inset-0">
              <div className="absolute inset-x-[8%] inset-y-[27%] rounded-lg border-2 border-white/90 shadow-[0_0_0_999px_rgb(0_0_0/0.4)]">
                <span className="scan-line" />
              </div>
            </div>
          )}
          {phase === 'starting' && (
            <div className="absolute inset-0 grid place-items-center text-white">
              <div className="flex flex-col items-center gap-2 text-sm font-medium">
                <LuCamera size={26} aria-hidden="true" />
                Membuka kamera...
              </div>
            </div>
          )}
          {phase === 'error' && (
            <div className="absolute inset-0 grid place-items-center p-5 text-center text-white">
              <div className="grid max-w-xs justify-items-center gap-3">
                <LuCameraOff size={28} aria-hidden="true" />
                <p role="alert" className="text-sm font-medium">
                  {problem}
                </p>
                {IS_ARTIFACT && (
                  <p className="text-xs text-white/75">Pratinjau di dalam Claude biasanya memblokir kamera. Buka aplikasi yang sudah di-deploy (misalnya di Vercel) lewat Chrome untuk memakai kamera.</p>
                )}
                <button type="button" className="btn btn-sm bg-white text-black hover:opacity-90" onClick={() => setAttempt((a) => a + 1)}>
                  <LuRefreshCw size={15} /> Coba lagi
                </button>
              </div>
            </div>
          )}
        </div>

        {phase !== 'error' && <p className="text-center text-sm text-muted">Arahkan kamera ke barcode di dalam kotak. Terbaca otomatis, tanpa menekan tombol.</p>}

        {feedback && (
          <div
            role={feedback.tone === 'err' ? 'alert' : 'status'}
            className={cx('flex items-start gap-2 rounded-md px-3 py-2.5 text-sm font-semibold', feedback.tone === 'ok' ? 'bg-goodsoft text-good' : 'bg-badsoft text-bad')}
          >
            {feedback.tone === 'ok' ? <LuCircleCheck className="mt-0.5 shrink-0" size={16} /> : <LuTriangleAlert className="mt-0.5 shrink-0" size={16} />}
            <span>{feedback.message}</span>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2">
          {torch !== 'none' && (
            <button type="button" className={cx('btn btn-ghost btn-sm', torch === 'on' && 'border-accent text-accent')} aria-pressed={torch === 'on'} onClick={toggleTorch}>
              <LuFlashlight size={15} /> Senter
            </button>
          )}
          <button type="button" className="btn btn-ghost btn-sm" aria-expanded={manual} onClick={() => setManual((v) => !v)}>
            <LuKeyboard size={15} /> Ketik kode
          </button>
        </div>

        {manual && (
          <form onSubmit={submitManual} className="flex gap-2">
            <input
              className="input min-w-0 flex-1"
              aria-label="Kode barcode atau SKU"
              placeholder="Ketik angka di bawah barcode"
              autoComplete="off"
              autoFocus={phase === 'error'}
              value={manualText}
              onChange={(e) => setManualText(e.target.value)}
            />
            <button type="submit" className="btn btn-primary shrink-0" disabled={!manualText.trim()}>
              OK
            </button>
          </form>
        )}
      </div>
    </Modal>
  );
}
