import { type ReactNode, createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

export type Route = 'beranda' | 'kasir' | 'produk' | 'stok' | 'belanja' | 'kasbon' | 'riwayat' | 'kas' | 'laporan' | 'pengaturan';
export const ROUTES: Route[] = ['beranda', 'kasir', 'produk', 'stok', 'belanja', 'kasbon', 'riwayat', 'kas', 'laporan', 'pengaturan'];

export interface NavParams {
  productId?: string; // pre-select a product on the Stok page
  tab?: 'masuk' | 'sesuaikan' | 'opname' | 'log';
  txId?: string; // open a transaction in Riwayat
}

interface NavValue {
  route: Route;
  params: NavParams;
  go: (route: Route, params?: NavParams) => void;
}

const NavCtx = createContext<NavValue>({ route: 'beranda', params: {}, go: () => undefined });
export const useNav = () => useContext(NavCtx);

function fromHash(): Route {
  try {
    const h = window.location.hash.replace(/^#/, '');
    return (ROUTES as string[]).includes(h) ? (h as Route) : 'beranda';
  } catch {
    return 'beranda';
  }
}

export function NavProvider({ children }: { children: ReactNode }) {
  const [route, setRoute] = useState<Route>(fromHash);
  const [params, setParams] = useState<NavParams>({});

  useEffect(() => {
    const onHash = () => {
      setRoute(fromHash());
      setParams({});
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  const go = useCallback((next: Route, p: NavParams = {}) => {
    setRoute(next);
    setParams(p);
    try {
      if (window.location.hash !== `#${next}`) window.location.hash = next;
    } catch {
      /* hash is only a convenience */
    }
    window.scrollTo({ top: 0 });
  }, []);

  const value = useMemo(() => ({ route, params, go }), [route, params, go]);
  return <NavCtx.Provider value={value}>{children}</NavCtx.Provider>;
}
