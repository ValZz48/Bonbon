import { type ReactNode, useState } from 'react';
import { LuCopy, LuMessageCircle, LuPrinter } from 'react-icons/lu';
import { receiptText } from '../core/export';
import { formatDateTime, formatNumber, formatQty, formatRupiah } from '../core/format';
import type { Settings, Transaction } from '../core/types';
import { METHOD_LABEL } from '../core/types';
import { receiptWhatsApp } from '../core/whatsapp';
import { CAN_PRINT } from './runtime';
import { useAppState } from './state';
import { PrintDialog } from './PrintDialog';
import { Modal, useCopy } from './ui';
import { WaShareDialog } from './WaShare';

function Row({ left, right, strong }: { left: ReactNode; right: ReactNode; strong?: boolean }) {
  return (
    <div className="row" style={strong ? { fontWeight: 700, fontSize: '1.08em' } : undefined}>
      <span>{left}</span>
      <span>{right}</span>
    </div>
  );
}

/** On-screen preview of the thermal receipt. Printing uses the fixed-width layout from core/export.ts instead. */
export function ReceiptPaper({ tx, settings, debtAfter }: { tx: Transaction; settings: Settings; debtAfter?: number }) {
  const signed = (n: number) => (n > 0 ? '+' : '-') + formatNumber(Math.abs(n));
  return (
    <div className="receipt-sheet mx-auto" data-paper={settings.paperWidth}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontWeight: 700, fontSize: '1.15em' }}>{settings.storeName}</div>
        <div>{settings.address}</div>
        {settings.phone ? <div>{settings.phone}</div> : null}
      </div>
      <hr className="rule" />
      <Row left="No" right={tx.receiptNo} />
      <Row left="Tanggal" right={formatDateTime(tx.createdAt)} />
      <Row left="Kasir" right={tx.cashierName} />
      {tx.customerName ? <Row left="Pelanggan" right={tx.customerName} /> : null}
      <hr className="rule" />
      {tx.items.map((i, idx) => (
        <div key={idx} style={{ marginBottom: 4 }}>
          <div>{i.name}</div>
          <Row left={`  ${formatQty(i.unitQty)} ${i.unitName} x ${formatNumber(i.unitPrice)}`} right={formatNumber(Math.round(i.unitQty * i.unitPrice))} />
          {i.discount > 0 && <Row left="  Diskon" right={`-${formatNumber(i.discount)}`} />}
          {i.note ? <div>{`  * ${i.note}`}</div> : null}
        </div>
      ))}
      <hr className="rule" />
      <Row left="Subtotal" right={formatNumber(tx.subtotal)} />
      {tx.discount > 0 && <Row left="Diskon" right={`-${formatNumber(tx.discount)}`} />}
      {tx.tax > 0 && <Row left={`PPN ${tx.taxPercent}%`} right={formatNumber(tx.tax)} />}
      {tx.rounding !== 0 && <Row left="Pembulatan" right={signed(tx.rounding)} />}
      <Row strong left="TOTAL" right={formatRupiah(tx.total)} />
      <hr className="rule" />
      {tx.payments.map((p, idx) => (
        <div key={idx}>
          <Row left={METHOD_LABEL[p.method] + (p.status === 'pending' ? ' (menunggu)' : '')} right={formatRupiah(p.amount)} />
          {p.method === 'cash' && (p.tendered ?? p.amount) > p.amount && <Row left="  Diterima" right={formatRupiah(p.tendered as number)} />}
          {p.reference ? <div>{`  Ref: ${p.reference}`}</div> : null}
        </div>
      ))}
      {tx.change > 0 && <Row left="Kembali" right={formatRupiah(tx.change)} />}
      {debtAfter !== undefined && tx.customerName ? <Row strong left="Total kasbon" right={formatRupiah(debtAfter)} /> : null}
      <hr className="rule" />
      <div style={{ textAlign: 'center' }}>{settings.receiptFooter}</div>
      {tx.status === 'voided' && (
        <div style={{ textAlign: 'center', marginTop: 10, fontWeight: 700 }}>
          *** DIBATALKAN ***
          {tx.voidReason ? <div style={{ fontWeight: 400 }}>{tx.voidReason}</div> : null}
        </div>
      )}
    </div>
  );
}

export function ReceiptModal({
  tx,
  settings,
  onClose,
  closeLabel = 'Tutup',
  extra,
  before,
}: {
  tx: Transaction;
  settings: Settings;
  onClose: () => void;
  closeLabel?: string;
  extra?: ReactNode;
  /** content shown above the paper (e.g. pending-payment actions) */
  before?: ReactNode;
}) {
  const copy = useCopy();
  const state = useAppState();
  const [sharing, setSharing] = useState(false);
  const [printing, setPrinting] = useState(false);
  // the customer's total kasbon right after this sale, read from the kasbon notebook
  const debtAfter = state.debtEntryByTx.get(tx.id)?.balanceAfter;
  const customerPhone = tx.customerId ? state.customersById.get(tx.customerId)?.phone : undefined;
  return (
    <>
    <Modal
      title={`Struk ${tx.receiptNo}`}
      onClose={onClose}
      size="md"
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={() => copy(receiptText(tx, settings, { debtAfter }), 'Teks struk disalin.')}>
            <LuCopy size={16} /> Salin teks
          </button>
          <button type="button" className="btn btn-ghost" onClick={() => setSharing(true)}>
            <LuMessageCircle size={16} /> Kirim WhatsApp
          </button>
          {CAN_PRINT && (
            <button type="button" className="btn btn-ghost" onClick={() => setPrinting(true)}>
              <LuPrinter size={16} /> Cetak
            </button>
          )}
          {extra}
          <button type="button" data-autofocus className="btn btn-primary" onClick={onClose}>
            {closeLabel}
          </button>
        </>
      }
    >
      {before}
      <div className="rounded-lg bg-sunken px-3 py-5">
        <ReceiptPaper tx={tx} settings={settings} debtAfter={debtAfter} />
      </div>
      {!CAN_PRINT && (
        <p className="hint mt-3 text-center">Tombol cetak ada di versi yang dijalankan langsung di peramban. Di halaman pratinjau ini cetak diblokir, gunakan Salin teks atau Kirim WhatsApp.</p>
      )}
    </Modal>
    {printing && <PrintDialog tx={tx} settings={settings} debtAfter={debtAfter} onClose={() => setPrinting(false)} />}
    {sharing && <WaShareDialog title={`Kirim struk ${tx.receiptNo}`} phone={customerPhone} message={receiptWhatsApp(tx, settings, { debtAfter })} onClose={() => setSharing(false)} />}
    </>
  );
}
