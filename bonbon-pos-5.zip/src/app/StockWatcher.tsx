import { useEffect, useMemo, useRef } from 'react';
import { stockAlerts } from '../core/queries';
import { dailySummary, levelMap, toastText, worsened, type Level } from '../core/stockNotify';
import { syncDailyNotification } from './notifications';
import { IS_NATIVE } from './runtime';
import { useAppState } from './state';
import { useToast } from './ui';

/**
 * Renders nothing. Two jobs:
 *  1. a toast when a product newly becomes low or out (after a sale, an adjustment, an opname, ...);
 *  2. in the Android app, keeps the daily reminder in step with the current stock.
 */
export function StockWatcher() {
  const state = useAppState();
  const toast = useToast();
  const items = useMemo(() => stockAlerts(state), [state]);
  const before = useRef<Map<string, Level> | null>(null);

  useEffect(() => {
    const prev = before.current;
    before.current = levelMap(items);
    if (!prev) return; // opening the app is not news
    const fresh = worsened(prev, items);
    if (fresh.length > 0) toast(toastText(fresh), 'info');
  }, [items, toast]);

  const enabled = IS_NATIVE && state.settings.stockNotify;
  const hour = state.settings.stockNotifyHour;
  const summary = useMemo(() => dailySummary(items), [items]);
  const key = JSON.stringify([enabled, hour, summary]);
  useEffect(() => {
    if (!IS_NATIVE) return;
    void syncDailyNotification({ enabled, hour, summary });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  return null;
}
