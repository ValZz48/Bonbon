import { type ReactNode, createContext, useContext, useSyncExternalStore } from 'react';
import type { State, Store } from '../core/store';

const StoreCtx = createContext<Store | null>(null);

export function StoreProvider({ store, children }: { store: Store; children: ReactNode }) {
  return <StoreCtx.Provider value={store}>{children}</StoreCtx.Provider>;
}

export function useStore(): Store {
  const s = useContext(StoreCtx);
  if (!s) throw new Error('StoreProvider tidak ditemukan');
  return s;
}

/** Re-renders whenever a committed operation changes the database. */
export function useAppState(): State {
  const store = useStore();
  return useSyncExternalStore(store.subscribe, store.getState, store.getState);
}
