import { type ReactNode, createContext, useContext, useSyncExternalStore } from 'react';
import type { SyncEngine, SyncStatus } from '../core/sync/engine';

const SyncCtx = createContext<SyncEngine | null>(null);

/** `engine` is null where sync cannot run (the sandboxed preview, which blocks network calls). */
export function SyncProvider({ engine, children }: { engine: SyncEngine | null; children: ReactNode }) {
  return <SyncCtx.Provider value={engine}>{children}</SyncCtx.Provider>;
}

export function useSyncEngine(): SyncEngine | null {
  return useContext(SyncCtx);
}

const NONE: SyncStatus = { phase: 'signedout', pending: 0 };
const noSub = () => () => {};

/** Live sync status; re-renders when it changes. */
export function useSyncStatus(): SyncStatus {
  const engine = useSyncEngine();
  return useSyncExternalStore(engine ? engine.subscribe : noSub, engine ? engine.getStatus : () => NONE, () => NONE);
}
