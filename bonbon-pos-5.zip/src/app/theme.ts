// Theme choice: follow the phone (auto), or force light / dark. Stored per device, not in the shop data.
// styles.css reads <html data-theme="light|dark">; with no attribute it follows prefers-color-scheme.
// The sandboxed preview (artifact) is themed by its viewer, so nothing here touches it.

import { IS_ARTIFACT } from './runtime';

export type ThemePref = 'auto' | 'light' | 'dark';
const KEY = 'bonbon-theme';

export function getThemePref(): ThemePref {
  try {
    const v = localStorage.getItem(KEY);
    return v === 'light' || v === 'dark' ? v : 'auto';
  } catch {
    return 'auto';
  }
}

function apply(pref: ThemePref) {
  if (IS_ARTIFACT) return;
  const root = document.documentElement;
  if (pref === 'auto') root.removeAttribute('data-theme');
  else root.setAttribute('data-theme', pref);
  const dark = pref === 'dark' || (pref === 'auto' && window.matchMedia?.('(prefers-color-scheme: dark)').matches);
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', dark ? '#0b0d1f' : '#4540d8');
}

export function setThemePref(pref: ThemePref) {
  try {
    if (pref === 'auto') localStorage.removeItem(KEY);
    else localStorage.setItem(KEY, pref);
  } catch {
    /* storage blocked: the choice lasts until the page closes */
  }
  apply(pref);
}

export function initTheme() {
  apply(getThemePref());
  try {
    // keep the status-bar colour right when the phone flips between light and dark while on "auto"
    window.matchMedia?.('(prefers-color-scheme: dark)').addEventListener?.('change', () => getThemePref() === 'auto' && apply('auto'));
  } catch {
    /* ignore */
  }
}
