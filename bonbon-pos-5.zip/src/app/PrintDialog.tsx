import { useMemo, useState } from 'react';
import { LuBluetooth, LuPrinter, LuSmartphone } from 'react-icons/lu';
import { receiptLayout } from '../core/export';
import type { Settings, Transaction } from '../core/types';
import {
  type Paper,
  bluetoothErrorMessage,
  bluetoothSupported,
  connectedPrinterName,
  forgetPrinter,
  isAndroid,
  isChooserCancelled,
  printInBrowser,
  printViaBluetooth,
  printViaRawBT,
} from './print';
import { CAN_BROWSER_PRINT } from './runtime';
import { Modal, cx } from './ui';

type Status = { tone: 'info' | 'ok' | 'err'; text: string } | null;

function Option({ icon, title, children, action }: { icon: React.ReactNode; title: string; children: React.ReactNode; action: React.ReactNode }) {
  return (
    <section className="rounded-lg border border-line bg-panel p-3">
      <div className="mb-2 flex items-start gap-3">
        <span className="mt-0.5 shrink-0 text-accent" aria-hidden="true">
          {icon}
        </span>
        <div className="min-w-0">
          <h3 className="text-sm font-bold">{title}</h3>
          <p className="mt-0.5 text-xs text-muted">{children}</p>
        </div>
      </div>
      <div className="flex flex-wrap gap-2">{action}</div>
    </section>
  );
}

/** Pick how to print: a small thermal printer over Bluetooth, the RawBT app, or the browser's print dialog. */
export function PrintDialog({ tx, settings, debtAfter, onClose }: { tx: Transaction; settings: Settings; debtAfter?: number; onClose: () => void }) {
  const [paper, setPaper] = useState<Paper>(settings.paperWidth);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<Status>(null);
  const [printerName, setPrinterName] = useState<string | null>(connectedPrinterName());
  const layout = useMemo(() => receiptLayout(tx, { ...settings, paperWidth: paper }, { debtAfter }), [tx, settings, paper, debtAfter]);
  const bt = bluetoothSupported();
  const android = isAndroid();

  const viaBluetooth = async (chooser: boolean) => {
    if (busy) return;
    setBusy(true);
    setStatus({ tone: 'info', text: 'Mencari printer...' });
    try {
      const name = await printViaBluetooth(layout, paper, (s) => setStatus({ tone: 'info', text: s === 'connecting' ? 'Menghubungkan ke printer...' : 'Mencetak...' }), chooser);
      setPrinterName(name);
      setStatus({ tone: 'ok', text: `Struk dikirim ke ${name}. Jika belum keluar, tunggu beberapa detik.` });
    } catch (e) {
      setPrinterName(connectedPrinterName());
      setStatus(isChooserCancelled(e) ? { tone: 'info', text: 'Tidak ada printer yang dipilih.' } : { tone: 'err', text: bluetoothErrorMessage(e) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal
      title="Cetak struk"
      size="sm"
      onClose={onClose}
      footer={
        <button type="button" data-autofocus className="btn btn-primary" onClick={onClose}>
          Tutup
        </button>
      }
    >
      <div className="mb-4">
        <span className="label">Lebar kertas printer</span>
        <div className="inline-flex overflow-hidden rounded-md border border-line" role="group" aria-label="Lebar kertas printer">
          {([58, 80] as const).map((w) => (
            <button key={w} type="button" aria-pressed={paper === w} onClick={() => setPaper(w)} className={cx('min-h-11 px-5 text-sm font-semibold', paper === w ? 'bg-accent text-onaccent' : 'bg-panel text-muted hover:bg-sunken')}>
              {w} mm
            </button>
          ))}
        </div>
        <p className="hint mt-1">Printer struk kecil biasanya 58 mm. Pilih 80 mm hanya bila kertasnya lebar.</p>
      </div>

      <div className="grid gap-3">
        {bt ? (
          <Option
            icon={<LuBluetooth size={18} />}
            title="Printer struk Bluetooth"
            action={
              <>
                <button type="button" className="btn btn-primary" disabled={busy} onClick={() => viaBluetooth(false)}>
                  <LuBluetooth size={16} /> {printerName ? `Cetak ke ${printerName}` : 'Pilih printer dan cetak'}
                </button>
                {printerName && (
                  <button
                    type="button"
                    className="btn btn-ghost"
                    disabled={busy}
                    onClick={() => {
                      forgetPrinter();
                      setPrinterName(null);
                      viaBluetooth(true);
                    }}
                  >
                    Ganti printer
                  </button>
                )}
              </>
            }
          >
            Langsung ke printer kecil lewat Bluetooth, tanpa aplikasi lain. Nyalakan printer, lalu pilih namanya di daftar. Cocok untuk printer yang mendukung Bluetooth LE.
          </Option>
        ) : null}

        {android && (
          <Option
            icon={<LuSmartphone size={18} />}
            title="Lewat aplikasi RawBT"
            action={
              <button type="button" className="btn btn-primary" onClick={() => printViaRawBT(layout, paper)}>
                <LuSmartphone size={16} /> Cetak lewat RawBT
              </button>
            }
          >
            Untuk printer Bluetooth atau USB yang tidak muncul di pilihan di atas. Pasang aplikasi RawBT (gratis di Play Store), pasangkan printer di aplikasi itu satu kali, lalu tekan tombol ini.
          </Option>
        )}

        {CAN_BROWSER_PRINT && (
          <Option
            icon={<LuPrinter size={18} />}
            title="Cetak lewat peramban"
            action={
              <button type="button" className={cx('btn', bt || android ? 'btn-ghost' : 'btn-primary')} onClick={() => printInBrowser(layout, paper)}>
                <LuPrinter size={16} /> Buka dialog cetak
              </button>
            }
          >
            Untuk printer yang sudah terpasang di komputer atau HP (termasuk printer kantor). Struk dicetak sebagai satu lembar sempit {paper} mm.
          </Option>
        )}
      </div>

      {!bt && !android && (
        <p className="hint mt-3">Peramban ini tidak punya Bluetooth langsung. Di Android pakai Chrome untuk cetak ke printer struk Bluetooth, atau pasang aplikasi RawBT.</p>
      )}
      {status && (
        <p role={status.tone === 'err' ? 'alert' : 'status'} className={cx('mt-3 text-sm', status.tone === 'err' && 'err', status.tone === 'ok' && 'text-good')}>
          {status.text}
        </p>
      )}
    </Modal>
  );
}
