// Backup as a short piece of text. The full JSON of a shop with a few weeks of sales is hundreds of KB, and chat apps
// cut long messages (WhatsApp stops at about 65,000 characters), which made pasted backups fail as "not complete".
// Gzip + base64 makes it about five times smaller and lets the paste check tell a cut-off text from a bad one.

export const PACK_PREFIX = 'BONBON1.';

const toBase64 = (bytes: Uint8Array): string => {
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(bin);
};

const fromBase64 = (b64: string): Uint8Array => {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
};

async function pipe(data: Uint8Array, stream: CompressionStream | DecompressionStream): Promise<Uint8Array> {
  const out = new Response(new Blob([data as BlobPart]).stream().pipeThrough(stream as unknown as ReadableWritablePair<Uint8Array, Uint8Array>));
  return new Uint8Array(await out.arrayBuffer());
}

export function canPack(): boolean {
  return typeof CompressionStream === 'function' && typeof DecompressionStream === 'function';
}

/** Compact one-line text for a backup. Falls back to the plain text where compression is not available. */
export async function packText(text: string): Promise<string> {
  if (!canPack()) return text;
  return PACK_PREFIX + toBase64(await pipe(new TextEncoder().encode(text), new CompressionStream('gzip')));
}

export const isPacked = (text: string): boolean => text.trimStart().startsWith(PACK_PREFIX);

/** Plain backup JSON from pasted text, whether it is packed or already plain. Throws a plain-language message. */
export async function unpackText(text: string): Promise<string> {
  const t = text.trim();
  if (!isPacked(t)) return text;
  const body = t.slice(PACK_PREFIX.length).replace(/\s+/g, '');
  try {
    if (!canPack()) throw new Error('no-gzip');
    return new TextDecoder().decode(await pipe(fromBase64(body), new DecompressionStream('gzip')));
  } catch {
    throw new Error(`Teks cadangan terputus atau rusak (terbaca ${body.length.toLocaleString('id-ID')} karakter). Salin ulang dari awal sampai akhir, atau pakai tombol "Simpan / kirim cadangan" lalu pilih berkasnya.`);
  }
}
