import { type Dispatch, type ReactNode, createContext, useContext, useMemo, useReducer, useRef } from 'react';
import type { DiscountSpec, Totals } from '../core/calc';
import { roundQty } from '../core/calc';
import type { CartLineInput, ResolvedLine } from '../core/services';
import { calcCart, resolveLine } from '../core/services';
import { useAppState } from './state';

export interface CartLine extends CartLineInput {
  key: string;
}
export interface CartState {
  lines: CartLine[];
  discount?: DiscountSpec;
}
export type CartAction =
  | { type: 'add'; key: string; productId: string; unitName: string }
  | { type: 'qty'; key: string; qty: number }
  | { type: 'remove'; key: string }
  | { type: 'unit'; key: string; unitName: string }
  | { type: 'lineDiscount'; key: string; discount?: DiscountSpec }
  | { type: 'note'; key: string; note: string }
  | { type: 'cartDiscount'; discount?: DiscountSpec }
  | { type: 'load'; lines: CartLine[]; discount?: DiscountSpec }
  | { type: 'clear' };

function reducer(state: CartState, a: CartAction): CartState {
  switch (a.type) {
    case 'add': {
      const same = state.lines.find((l) => l.productId === a.productId && l.unitName === a.unitName);
      if (same) {
        return { ...state, lines: state.lines.map((l) => (l === same ? { ...l, unitQty: roundQty(l.unitQty + 1) } : l)) };
      }
      return { ...state, lines: [...state.lines, { key: a.key, productId: a.productId, unitName: a.unitName, unitQty: 1 }] };
    }
    case 'qty':
      return { ...state, lines: state.lines.map((l) => (l.key === a.key ? { ...l, unitQty: a.qty } : l)) };
    case 'remove':
      return { ...state, lines: state.lines.filter((l) => l.key !== a.key) };
    case 'unit':
      return { ...state, lines: state.lines.map((l) => (l.key === a.key ? { ...l, unitName: a.unitName } : l)) };
    case 'lineDiscount':
      return { ...state, lines: state.lines.map((l) => (l.key === a.key ? { ...l, discount: a.discount } : l)) };
    case 'note':
      return { ...state, lines: state.lines.map((l) => (l.key === a.key ? { ...l, note: a.note } : l)) };
    case 'cartDiscount':
      return { ...state, discount: a.discount };
    case 'load':
      return { lines: a.lines, discount: a.discount };
    case 'clear':
      return { lines: [] };
  }
}

const CartCtx = createContext<{ cart: CartState; dispatch: Dispatch<CartAction>; nextKey: () => string } | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, dispatch] = useReducer(reducer, { lines: [] });
  const seq = useRef(0);
  const value = useMemo(() => ({ cart, dispatch, nextKey: () => `l${++seq.current}` }), [cart]);
  return <CartCtx.Provider value={value}>{children}</CartCtx.Provider>;
}

export function useCart() {
  const c = useContext(CartCtx);
  if (!c) throw new Error('CartProvider tidak ditemukan');
  return c;
}

export interface CartRow {
  line: CartLine;
  resolved: ResolvedLine;
  net: number;
  lineDiscount: number;
  gross: number;
  /** base units of this product needed by the whole cart */
  need: number;
  stock: number;
  overStock: boolean;
}

export interface CartView {
  rows: CartRow[];
  totals: Totals;
  itemCount: number;
  /** true when stock is insufficient and negative stock is not allowed */
  blocked: boolean;
  /** an unavailable (inactive / missing) product is in the cart */
  stale: boolean;
}

/** Cart lines joined with live product data, totals and stock problems. */
export function useCartView(): CartView {
  const state = useAppState();
  const { cart } = useCart();
  return useMemo(() => {
    const resolvedAll = cart.lines.map((line) => ({
      line,
      resolved: resolveLine(state.productsById.get(line.productId), state.unitsByProduct.get(line.productId) ?? [], line),
    }));
    const stale = resolvedAll.some((r) => !r.resolved || !r.resolved.product.active);
    const ok = resolvedAll.filter((r): r is { line: CartLine; resolved: ResolvedLine } => r.resolved !== null);
    const need = new Map<string, number>();
    for (const r of ok) need.set(r.resolved.product.id, roundQty((need.get(r.resolved.product.id) ?? 0) + r.resolved.baseQty));
    const totals = calcCart(
      ok.map((r) => r.resolved),
      cart.discount,
      state.settings,
    );
    const rows: CartRow[] = ok.map((r, i) => {
      const p = r.resolved.product;
      const n = need.get(p.id) ?? 0;
      return {
        line: r.line,
        resolved: r.resolved,
        net: totals.lines[i].net,
        lineDiscount: totals.lines[i].discount,
        gross: totals.lines[i].gross,
        need: n,
        stock: p.stock,
        overStock: n > p.stock,
      };
    });
    const blocked = !state.settings.allowNegativeStock && rows.some((r) => r.overStock);
    return { rows, totals, itemCount: rows.length, blocked, stale };
  }, [state, cart]);
}
