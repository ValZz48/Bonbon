import { LOCKUP, SYMBOL_D, SYMBOL_H, SYMBOL_W, WORDMARK_D, WORDMARK_H, WORDMARK_W } from './brandPaths';

/** The candy-shaped "b". Takes its colour from the surrounding text colour. */
export function BonbonMark({ className }: { className?: string }) {
  return (
    <svg viewBox={`0 0 ${SYMBOL_W} ${SYMBOL_H}`} className={className} role="img" aria-label="Bonbon" focusable="false">
      <path d={SYMBOL_D} fill="currentColor" fillRule="evenodd" />
    </svg>
  );
}

/** The rounded "Bonbon" lettering alone. */
export function BonbonWord({ className }: { className?: string }) {
  return (
    <svg viewBox={`0 0 ${WORDMARK_W} ${WORDMARK_H}`} className={className} role="img" aria-label="Bonbon" focusable="false">
      <path d={WORDMARK_D} fill="currentColor" fillRule="evenodd" />
    </svg>
  );
}

/** Symbol plus the "Bonbon" lettering, as in the brand banner. */
export function BonbonLogo({ className }: { className?: string }) {
  return (
    <svg viewBox={`0 0 ${LOCKUP.w} ${LOCKUP.h}`} className={className} role="img" aria-label="Bonbon" focusable="false">
      <path d={SYMBOL_D} fill="currentColor" fillRule="evenodd" />
      <path d={WORDMARK_D} fill="currentColor" fillRule="evenodd" transform={`translate(${LOCKUP.wx} ${LOCKUP.wy})`} />
    </svg>
  );
}

export const TAGLINE = 'Jualan Jalan, Bonbon Andalan!';
