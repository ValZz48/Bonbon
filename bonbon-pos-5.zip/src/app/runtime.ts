// Build-time and run-time capabilities.
//  - The sandboxed artifact build cannot open the print dialog or save files; the normal build can.
//    __ARTIFACT__ is replaced by esbuild (see scripts/build.mjs).
//  - The Android app (Capacitor) runs the same bundle inside a WebView. There window.print and
//    Web Bluetooth do not exist and downloads do not work, so files go through the Android share sheet.
//    Capacitor injects window.Capacitor at startup; nothing from @capacitor/* is bundled into the web build.

declare const __ARTIFACT__: boolean;

const artifact = typeof __ARTIFACT__ !== 'undefined' && __ARTIFACT__;

type PluginCall = (options?: unknown) => Promise<any>; // eslint-disable-line @typescript-eslint/no-explicit-any
interface CapacitorGlobal {
  isNativePlatform?: () => boolean;
  Plugins?: Record<string, Record<string, PluginCall> | undefined>;
  nativePromise?: (plugin: string, method: string, options?: unknown) => Promise<any>; // eslint-disable-line @typescript-eslint/no-explicit-any
}
const capacitor = (): CapacitorGlobal | undefined => (typeof window === 'undefined' ? undefined : (window as unknown as { Capacitor?: CapacitorGlobal }).Capacitor);

/** true when running inside the Android app */
export const IS_NATIVE = (() => {
  if (artifact) return false;
  try {
    return capacitor()?.isNativePlatform?.() === true;
  } catch {
    return false;
  }
})();

/** true when running as the sandboxed preview (popups, printing and downloads are blocked there) */
export const IS_ARTIFACT = artifact;
/** the printing dialog is offered (browser: print dialog and Bluetooth; Android app: RawBT) */
export const CAN_PRINT = !artifact;
/** window.print() works (not in the sandboxed preview, not inside the Android WebView) */
export const CAN_BROWSER_PRINT = !artifact && !IS_NATIVE;
/** files can be saved: as a download in the browser, through the share sheet in the app */
export const CAN_DOWNLOAD = !artifact;

/** Calls an Android plugin (LocalNotifications, Filesystem, Share). Only meaningful when IS_NATIVE. */
export function nativePlugin(name: string): Record<string, PluginCall> {
  return new Proxy({} as Record<string, PluginCall>, {
    get:
      (_t, method: string): PluginCall =>
      async (options?: unknown) => {
        const cap = capacitor();
        const direct = cap?.Plugins?.[name]?.[method];
        if (typeof direct === 'function') return direct.call(cap?.Plugins?.[name], options);
        if (typeof cap?.nativePromise === 'function') return cap.nativePromise(name, method, options);
        throw new Error(`Fitur ${name} tidak tersedia`);
      },
  });
}

/**
 * Saves text as a file. Browser: a download. Android app: written to the cache and handed to the share sheet
 * (save to Drive, send by WhatsApp, ...). Resolves false when the file could not be handed over.
 */
export async function downloadText(filename: string, text: string, mime = 'text/csv;charset=utf-8'): Promise<boolean> {
  // In the artifact build this whole body is removed at build time (the viewer never grants downloads).
  if (typeof __ARTIFACT__ !== 'undefined' && __ARTIFACT__) return false;
  // CSV gets a byte-order mark so Excel reads accents correctly; JSON must stay plain
  const data = (mime.startsWith('text/csv') ? '﻿' : '') + text;
  if (IS_NATIVE) {
    try {
      const written = await nativePlugin('Filesystem').writeFile({ path: filename, data, directory: 'CACHE', encoding: 'utf8' });
      await nativePlugin('Share').share({ title: filename, dialogTitle: 'Simpan atau kirim berkas', url: written?.uri });
      return true;
    } catch (e) {
      // closing the share sheet is not an error
      return /cancel/i.test(String((e as Error)?.message ?? e));
    }
  }
  const blob = new Blob([data], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  return true;
}

/** A short vibration on touch phones (the Android app and Chrome on Android); a no-op elsewhere. */
export function buzz(ms = 12): void {
  try {
    if (IS_NATIVE || (typeof navigator !== 'undefined' && /android/i.test(navigator.userAgent))) navigator.vibrate?.(ms);
  } catch {
    /* not supported */
  }
}
