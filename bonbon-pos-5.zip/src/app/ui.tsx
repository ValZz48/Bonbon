import { createPortal } from 'react-dom';
import {
  type ReactNode,
  createContext,
  useCallback,
  useContext,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
} from 'react';
import { LuCircleAlert, LuCircleCheck, LuCircleX, LuSearch, LuTriangleAlert, LuX } from 'react-icons/lu';
import type { StockStatus } from '../core/calc';
import { STATUS_LABEL, stockStatus } from '../core/calc';
import { formatNumber, formatQty } from '../core/format';
import type { Product } from '../core/types';
import { DomainError } from '../core/types';

/** A stable colour (1 to 8) for a category name, so the same category always has the same tile colour. */
export function catClass(category: string | undefined): string {
  const name = (category ?? '').trim().toLowerCase();
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return `cat-${(h % 8) + 1}`;
}

export const cx = (...a: (string | false | null | undefined)[]) => a.filter(Boolean).join(' ');

export function errorMessage(e: unknown): string {
  if (e instanceof DomainError) return e.message;
  if (e instanceof Error) return e.message || 'Terjadi kesalahan.';
  return 'Terjadi kesalahan.';
}

// ---- Toasts + text fallback dialog -------------------------------------------------

type ToastKind = 'ok' | 'err' | 'info';
interface Overlay {
  toast: (message: string, kind?: ToastKind) => void;
  copy: (text: string, okMessage?: string) => Promise<void>;
}
const OverlayCtx = createContext<Overlay>({ toast: () => undefined, copy: async () => undefined });
export const useToast = () => useContext(OverlayCtx).toast;
export const useCopy = () => useContext(OverlayCtx).copy;

let toastSeq = 0;

async function tryCopy(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    /* older desktop apps refuse the async clipboard API */
  }
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  } catch {
    return false;
  }
}

export function OverlayProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<{ id: number; message: string; kind: ToastKind }[]>([]);
  const [manual, setManual] = useState<string | null>(null);

  const toast = useCallback((message: string, kind: ToastKind = 'ok') => {
    const id = ++toastSeq;
    // the same message replaces the earlier one instead of stacking duplicates
    setToasts((l) => [...l.filter((t) => t.message !== message).slice(-2), { id, message, kind }]);
    window.setTimeout(() => setToasts((l) => l.filter((t) => t.id !== id)), kind === 'err' ? 6500 : 3200);
  }, []);

  const copy = useCallback(
    async (text: string, okMessage = 'Disalin ke clipboard.') => {
      if (await tryCopy(text)) toast(okMessage);
      else setManual(text);
    },
    [toast],
  );

  const value = useMemo(() => ({ toast, copy }), [toast, copy]);
  return (
    <OverlayCtx.Provider value={value}>
      {children}
      <div
        aria-live="polite"
        className="pointer-events-none fixed inset-x-0 bottom-[calc(env(safe-area-inset-bottom,0px)+104px)] z-[90] flex flex-col items-center gap-2 px-4 md:bottom-6"
      >
        {toasts.map((t) => (
          <div
            key={t.id}
            role={t.kind === 'err' ? 'alert' : 'status'}
            className={cx(
              'anim-toast pointer-events-auto flex max-w-md items-start gap-2.5 rounded-2xl px-4 py-2.5 text-sm font-medium shadow-[var(--lift)]',
              t.kind === 'err' ? 'bg-bad text-onbad' : 'glass-strong text-ink',
            )}
          >
            {t.kind === 'err' ? <LuTriangleAlert className="mt-0.5 shrink-0" size={16} /> : <LuCircleCheck className="mt-0.5 shrink-0" size={16} />}
            <span>{t.message}</span>
          </div>
        ))}
      </div>
      {manual !== null && (
        <Modal title="Salin manual" onClose={() => setManual(null)}>
          <p className="mb-3 text-sm text-muted">Peramban ini tidak mengizinkan penyalinan otomatis. Teks sudah terpilih, tekan Ctrl+C (atau tahan lalu pilih Salin).</p>
          <textarea
            readOnly
            autoFocus
            className="input font-mono text-xs"
            rows={12}
            value={manual}
            onFocus={(e) => e.currentTarget.select()}
          />
        </Modal>
      )}
    </OverlayCtx.Provider>
  );
}

// ---- Modal -------------------------------------------------------------------------

const modalStack: symbol[] = [];

// Page scroll is locked while any modal is open. The original value is remembered only when the
// first modal opens (stack 0 -> 1) and restored only when the last one closes, so stacked or
// simultaneously unmounting modals can never leave `overflow: hidden` behind.
let baseOverflow = '';
function lockScroll(): void {
  if (modalStack.length === 1) {
    const cur = document.body.style.overflow;
    baseOverflow = cur === 'hidden' ? '' : cur;
  }
  document.body.style.overflow = 'hidden';
}
function unlockScroll(): void {
  if (modalStack.length === 0) document.body.style.overflow = baseOverflow;
}

export function Modal({
  title,
  onClose,
  children,
  footer,
  size = 'md',
  flush = false,
  focusFirstField = true,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
  size?: 'sm' | 'md' | 'lg';
  /** No padding; the child lays itself out (e.g. a list that scrolls with a pinned footer). The body still scrolls as a last resort on very short screens. */
  flush?: boolean;
  /** false for sheets full of fields the person did not ask to edit (e.g. the cart): a phone would pop the keyboard up */
  focusFirstField?: boolean;
}) {
  const titleId = useId();
  const panel = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;

  useEffect(() => {
    const me = Symbol('modal');
    modalStack.push(me);
    lockScroll();
    const opener = document.activeElement as HTMLElement | null;
    // focus the first field, or the panel itself
    const auto = focusFirstField ? panel.current?.querySelector<HTMLElement>('[data-autofocus], input:not([type=hidden]), textarea, select') : null;
    (auto ?? panel.current)?.focus();
    const onKey = (e: KeyboardEvent) => {
      // only the top-most modal reacts, so Esc closes one layer at a time
      if (e.key === 'Escape' && modalStack[modalStack.length - 1] === me) {
        e.stopPropagation();
        closeRef.current();
      }
    };
    document.addEventListener('keydown', onKey, true);
    return () => {
      document.removeEventListener('keydown', onKey, true);
      const i = modalStack.indexOf(me);
      if (i >= 0) modalStack.splice(i, 1);
      unlockScroll();
      if (opener && document.contains(opener)) opener.focus?.();
    };
  }, []);

  const width = size === 'sm' ? 'sm:max-w-sm' : size === 'lg' ? 'sm:max-w-2xl' : 'sm:max-w-lg';
  // rendered into <body>: glass (backdrop-filter) ancestors would otherwise trap a `position: fixed` dialog inside them
  return createPortal(
    <div
      data-modal=""
      className="anim-overlay fixed inset-0 z-50 flex items-end justify-center bg-[#0d1130]/45 backdrop-blur-[6px] sm:items-center sm:p-4"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        ref={panel}
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        className={cx(
          'anim-sheet flex max-h-[94dvh] w-full flex-col glass-strong overflow-hidden rounded-t-3xl outline-none sm:max-h-[90dvh] sm:rounded-3xl',
          width,
        )}
      >
        <div className="mx-auto mt-2 h-1 w-10 shrink-0 rounded-full bg-line sm:hidden" aria-hidden="true" />
        <div className="flex items-center justify-between gap-3 border-b border-line px-5 py-3.5">
          <h2 id={titleId} className="text-[17px] font-bold tracking-tight">
            {title}
          </h2>
          <button type="button" className="btn-icon -mr-2 border-transparent" onClick={onClose} aria-label="Tutup">
            <LuX size={18} />
          </button>
        </div>
        <div className={cx('scroll-y min-h-0 flex-1', flush ? 'flex flex-col' : 'px-5 py-4')}>{children}</div>
        {footer && (
          <div className="flex flex-wrap items-center justify-end gap-2 border-t border-line bg-panel px-5 py-3 pb-[calc(0.75rem+env(safe-area-inset-bottom,0px))] sm:pb-3">
            {footer}
          </div>
        )}
      </div>
    </div>,
    document.body,
  );
}

export function ConfirmDialog({
  title,
  message,
  confirmLabel,
  danger,
  busy,
  onConfirm,
  onClose,
}: {
  title: string;
  message: ReactNode;
  confirmLabel: string;
  danger?: boolean;
  busy?: boolean;
  onConfirm: () => void;
  onClose: () => void;
}) {
  return (
    <Modal
      title={title}
      size="sm"
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Batal
          </button>
          <button type="button" data-autofocus className={cx('btn', danger ? 'btn-danger' : 'btn-primary')} disabled={busy} onClick={onConfirm}>
            {confirmLabel}
          </button>
        </>
      }
    >
      <div className="text-sm text-muted">{message}</div>
    </Modal>
  );
}

// ---- Form pieces -------------------------------------------------------------------

export function Field({
  label,
  hint,
  error,
  children,
  className,
}: {
  label: string;
  hint?: ReactNode;
  error?: string | null;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={cx('block min-w-0', className)}>
      <span className="label">{label}</span>
      {children}
      {error ? <span className="err block">{error}</span> : hint ? <span className="hint block">{hint}</span> : null}
    </label>
  );
}

export function parseDecimal(text: string): number | null {
  const t = text.trim().replace(/\s/g, '').replace(',', '.');
  if (t === '' || t === '.') return null;
  if (!/^\d*\.?\d*$/.test(t)) return null;
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
}

/** Whole-Rupiah input with thousand separators. */
export function MoneyInput({
  value,
  onChange,
  invalid,
  placeholder = '0',
  autoFocus,
  onEnter,
  id,
  className,
  'aria-label': ariaLabel,
}: {
  value: number | null;
  onChange: (n: number | null) => void;
  invalid?: boolean;
  placeholder?: string;
  autoFocus?: boolean;
  onEnter?: () => void;
  id?: string;
  className?: string;
  'aria-label'?: string;
}) {
  return (
    <div className={cx('relative', className)}>
      <span className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-sm text-muted">Rp</span>
      <input
        id={id}
        aria-label={ariaLabel}
        className={cx('input money pl-9 text-right', invalid && 'input-invalid')}
        inputMode="numeric"
        autoComplete="off"
        placeholder={placeholder}
        autoFocus={autoFocus}
        value={value === null ? '' : formatNumber(value)}
        onFocus={(e) => e.currentTarget.select()}
        onChange={(e) => {
          const digits = e.target.value.replace(/\D/g, '').slice(0, 11);
          onChange(digits === '' ? null : Number(digits));
        }}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && onEnter) {
            e.preventDefault();
            onEnter();
          }
        }}
      />
    </div>
  );
}

/** Decimal-friendly number input ("1,5" while typing). Emits null for empty/invalid text. */
export function NumberInput({
  value,
  onChange,
  invalid,
  placeholder,
  className,
  id,
  autoFocus,
  allowNegative,
  'aria-label': ariaLabel,
  onEnter,
}: {
  value: number | null;
  onChange: (n: number | null) => void;
  invalid?: boolean;
  placeholder?: string;
  className?: string;
  id?: string;
  autoFocus?: boolean;
  allowNegative?: boolean;
  'aria-label'?: string;
  onEnter?: () => void;
}) {
  const fmt = (n: number | null) => (n === null ? '' : formatQty(n).replace(/\./g, '')); // 1234,5 without thousand dots
  const [text, setText] = useState(fmt(value));
  const [prev, setPrev] = useState(value);
  const last = useRef<number | null | undefined>(undefined); // last value this field emitted itself
  // Adopt a value that changed from outside (e.g. the + button) in the same render, without a stale frame.
  // A value we emitted ourselves keeps the text as typed ("1," stays "1,").
  if (value !== prev) {
    setPrev(value);
    if (value !== last.current) setText(fmt(value));
  }
  return (
    <input
      id={id}
      aria-label={ariaLabel}
      className={cx('input money text-right', invalid && 'input-invalid', className)}
      inputMode={allowNegative ? 'text' : 'decimal'}
      autoComplete="off"
      autoFocus={autoFocus}
      placeholder={placeholder}
      value={text}
      onFocus={(e) => e.currentTarget.select()}
      onBlur={() => setText(fmt(value))}
      onChange={(e) => {
        let t = e.target.value;
        let neg = false;
        if (allowNegative && t.startsWith('-')) {
          neg = true;
          t = t.slice(1);
        }
        if (!/^[\d.,]*$/.test(t)) return;
        setText((neg ? '-' : '') + t);
        const n = parseDecimal(t);
        const out = n === null ? null : neg ? -n : n;
        last.current = out;
        onChange(out);
      }}
      onKeyDown={(e) => {
        if (e.key === 'Enter' && onEnter) {
          e.preventDefault();
          onEnter();
        }
      }}
    />
  );
}

// ---- Stock badges, empty states, headers --------------------------------------------

export function StatusPill({ status }: { status: StockStatus }) {
  const cls = status === 'ok' ? 'pill-good' : status === 'low' ? 'pill-warn' : 'pill-bad';
  const Icon = status === 'ok' ? LuCircleCheck : status === 'low' ? LuCircleAlert : LuCircleX;
  return (
    <span className={cx('pill', cls)}>
      <Icon size={13} aria-hidden="true" />
      {STATUS_LABEL[status]}
    </span>
  );
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-x-4 gap-y-3">
      <div className="min-w-0">
        <h1 className="text-[26px] leading-tight font-extrabold tracking-tight text-balance">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function EmptyState({ icon, title, children, action }: { icon: ReactNode; title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-2 px-6 py-10 text-center">
      <div className="anim-pop mb-1 flex size-14 items-center justify-center rounded-full bg-accentsoft text-accent">{icon}</div>
      <p className="text-[15px] font-bold">{title}</p>
      {children && <p className="max-w-sm text-sm text-muted">{children}</p>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

/** A card with a titled header: soft icon, title, and an optional action on the right. Lists inside use `divide-y divide-line`. */
export function Section({
  title,
  icon,
  action,
  children,
  className,
  label,
}: {
  title: string;
  icon?: ReactNode;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
  /** accessible name of the region, when it should differ from the title */
  label?: string;
}) {
  return (
    <section aria-label={label ?? title} className={cx('card overflow-hidden', className)}>
      <header className="flex items-center justify-between gap-3 px-4 pt-4 pb-3">
        <div className="flex min-w-0 items-center gap-2.5">
          {icon && <span className="icon-box size-9">{icon}</span>}
          <h2 className="card-title truncate">{title}</h2>
        </div>
        {action}
      </header>
      {children}
    </section>
  );
}

/** A thin progress bar. `value` out of `max`; the bar grows in once when it appears. */
export function Meter({ value, max, tone = 'accent', className }: { value: number; max: number; tone?: 'accent' | 'good' | 'warn' | 'bad'; className?: string }) {
  const pct = max > 0 ? Math.max(0, Math.min(100, (value / max) * 100)) : 0;
  const color = tone === 'bad' ? 'bg-bad' : tone === 'warn' ? 'bg-warn' : tone === 'good' ? 'bg-good' : 'bg-accent';
  return (
    <div className={cx('h-1.5 overflow-hidden rounded-full bg-sunken', className)} aria-hidden="true">
      <div className={cx('anim-bar h-full rounded-full', color)} style={{ width: `${pct}%` }} />
    </div>
  );
}

/** Round initials for a person (customers). */
export function Avatar({ name, className }: { name: string; className?: string }) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  const initials = ((parts[0]?.[0] ?? '?') + (parts.length > 1 ? (parts[parts.length - 1]?.[0] ?? '') : '')).toUpperCase();
  return (
    <span aria-hidden="true" className={cx('grid size-10 shrink-0 place-items-center rounded-full bg-accentsoft text-[13px] font-bold text-accent', className)}>
      {initials}
    </span>
  );
}

export function Tabs<T extends string>({
  tabs,
  value,
  onChange,
}: {
  tabs: { id: T; label: string }[];
  value: T;
  onChange: (id: T) => void;
}) {
  return (
    <div role="tablist" className="mb-4 flex gap-1 overflow-x-auto rounded-xl border border-line bg-sunken p-1">
      {tabs.map((t) => (
        <button
          key={t.id}
          type="button"
          role="tab"
          aria-selected={t.id === value}
          onClick={() => onChange(t.id)}
          className={cx(
            'min-h-9 flex-1 rounded-lg px-3 text-[13px] font-semibold whitespace-nowrap transition-[background-color,color,box-shadow] duration-150',
            t.id === value ? 'bg-panel text-accent shadow-sm' : 'text-muted hover:text-ink',
          )}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}

// ---- Product picker (inline list, no floating popover) --------------------------------

export function ProductPicker({
  products,
  value,
  onChange,
  label = 'Produk',
}: {
  products: Product[];
  value: string | null;
  onChange: (id: string | null) => void;
  label?: string;
}) {
  const [q, setQ] = useState('');
  const [category, setCategory] = useState('');
  const selected = value ? products.find((p) => p.id === value) : undefined;
  const categories = useMemo(() => [...new Set(products.map((p) => p.category).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'id')), [products]);
  // every match is listed and the list scrolls; nothing is cut off behind a "type to find more"
  const matches = useMemo(() => {
    const s = q.trim().toLowerCase();
    return products.filter((p) => (!category || p.category === category) && (!s || p.name.toLowerCase().includes(s) || p.sku.toLowerCase().includes(s) || (p.barcode ?? '').includes(s)));
  }, [products, q, category]);

  if (selected) {
    return (
      <div className="min-w-0">
        <span className="label">{label}</span>
        <div className="flex items-center justify-between gap-3 rounded-xl border border-line bg-sunken px-3 py-2.5">
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold">{selected.name}</p>
            <p className="text-xs text-muted">
              {selected.sku} · stok {formatQty(selected.stock)} {selected.baseUnit}
            </p>
          </div>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => onChange(null)}>
            Ganti
          </button>
        </div>
      </div>
    );
  }
  return (
    <div className="min-w-0">
      <span className="label">{label}</span>
      <div className="relative">
        <LuSearch className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-faint" size={16} />
        <input
          className="input pl-9"
          placeholder="Cari nama, SKU, atau barcode"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && matches.length > 0) {
              e.preventDefault();
              onChange(matches[0].id);
              setQ('');
            }
          }}
          aria-label={label}
        />
      </div>
      {categories.length > 1 && (
        <div className="scroll-x -mx-1 mt-2 flex max-w-[calc(100%+0.5rem)] gap-1.5 px-1 pb-1" role="group" aria-label="Kategori produk">
          {['', ...categories].map((c) => (
            <button key={c || 'all'} type="button" aria-pressed={category === c} onClick={() => setCategory(c)} className={cx('chip', category === c && 'chip-on')}>
              {c || 'Semua'}
            </button>
          ))}
        </div>
      )}
      <p className="mt-2 mb-1 text-xs text-muted" aria-live="polite">
        {matches.length} dari {products.length} produk
      </p>
      <ul className="scroll-y max-h-[19rem] divide-y divide-line rounded-xl border border-line" data-testid="picker-list">
        {matches.length === 0 && <li className="px-3 py-3 text-sm text-muted">Produk tidak ditemukan.</li>}
        {matches.map((p) => {
          const st = stockStatus(p.stock, p.minStock);
          return (
            <li key={p.id}>
              <button
                type="button"
                className="flex min-h-12 w-full items-center justify-between gap-3 bg-panel px-3 py-2 text-left hover:bg-sunken"
                onClick={() => {
                  onChange(p.id);
                  setQ('');
                }}
              >
                <span className="min-w-0">
                  <span className="block truncate text-sm font-semibold">{p.name}</span>
                  <span className="block text-xs text-muted">{p.sku}</span>
                </span>
                <span className={cx('num shrink-0 text-xs font-semibold', st === 'out' ? 'text-bad' : st === 'low' ? 'text-warn' : 'text-muted')}>
                  {formatQty(p.stock)} {p.baseUnit}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

/** Runs an async action, shows a toast on failure, and tracks the busy state. */
export function useAction() {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const run = useCallback(
    async <T,>(fn: () => Promise<T>, okMessage?: string): Promise<T | undefined> => {
      setBusy(true);
      try {
        const r = await fn();
        if (okMessage) toast(okMessage);
        return r;
      } catch (e) {
        toast(errorMessage(e), 'err');
        return undefined;
      } finally {
        setBusy(false);
      }
    },
    [toast],
  );
  return { busy, run };
}
