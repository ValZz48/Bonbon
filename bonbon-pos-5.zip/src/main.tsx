import { Component, type ReactNode, StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './app/App';
import { BonbonMark, BonbonWord, TAGLINE } from './app/brand';
import { StoreProvider } from './app/state';
import { initTheme } from './app/theme';
import { seedDemo } from './core/demo';
import { type Persistence, createPersistence } from './core/persistence';
import { saveSettings } from './core/services';
import { Store } from './core/store';
import { SyncApi } from './core/sync/api';
import { SyncEngine } from './core/sync/engine';
import { openOutbox } from './core/sync/outbox';
import { SyncedPersistence } from './core/sync/persistence';
import { IS_ARTIFACT } from './app/runtime';
import { SyncProvider } from './app/sync';
// Styles are compiled separately (Tailwind) and inlined by scripts/build.mjs.

function Splash({ text }: { text: string }) {
  return (
    <div className="flex min-h-[70dvh] flex-col items-center justify-center gap-4 text-center">
      <span className="anim-pop grid size-24 place-items-center rounded-[30px] bg-accent text-onaccent shadow-[0_12px_32px_rgb(69_64_216/0.4)]" aria-hidden="true">
        <BonbonMark className="anim-wobble h-12 w-auto" />
      </span>
      <BonbonWord className="h-9 w-auto text-accent" />
      <p className="text-base font-medium text-accentdeep">{TAGLINE}</p>
      <p role="status" className="mt-2 text-sm font-medium text-muted">
        {text}
      </p>
    </div>
  );
}

class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) {
    return { error };
  }
  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="mx-auto mt-16 max-w-md rounded-xl border border-line bg-panel p-6 text-center">
        <h1 className="text-lg font-bold">Aplikasi mengalami kendala</h1>
        <p className="mt-2 text-sm text-muted">{this.state.error.message}</p>
        <button type="button" className="btn btn-primary mt-4" onClick={() => window.location.reload()}>
          Muat ulang
        </button>
      </div>
    );
  }
}

initTheme();

async function boot() {
  const el = document.getElementById('root');
  if (!el) return;
  const root = createRoot(el);
  root.render(<Splash text="Menyiapkan Bonbon..." />);
  try {
    // Sync wraps the storage so every change is also queued for the cloud. It stays off in the sandboxed
    // preview (no network there) and when the browser could not give us real storage.
    const base: Persistence = await createPersistence();
    let engine: SyncEngine | null = null;
    let persistence: Persistence = base;
    let synced: SyncedPersistence | null = null;
    let outbox: Awaited<ReturnType<typeof openOutbox>> | null = null;
    if (!IS_ARTIFACT && !base.volatile) {
      outbox = await openOutbox();
      synced = new SyncedPersistence(base, outbox);
      persistence = synced;
    }
    const store = new Store(persistence);
    await store.init();

    // First run: offer sample data once so the app opens in a working state.
    const first = store.getState();
    if (!first.settings.demoOffered) {
      if (first.products.length === 0) {
        root.render(<Splash text="Mengisi data contoh..." />);
        try {
          await seedDemo(store);
        } catch {
          /* the app still works with an empty catalogue */
        }
      }
      await saveSettings(store, { demoOffered: true });
    }

    // ask the browser not to evict our data when storage runs low (ignored where unsupported or refused)
    try {
      void navigator.storage?.persist?.();
    } catch {
      /* optional */
    }

    if (synced && outbox) {
      try {
        const api = new SyncApi();
        // coming back from "continue with Google": the tokens are in the address
        if (/access_token=/.test(window.location.hash)) {
          try {
            await api.adoptHash(window.location.hash);
          } catch {
            /* the sync panel shows the sign-in again */
          }
          history.replaceState(null, '', window.location.pathname + window.location.search);
        }
        engine = new SyncEngine(store, outbox, synced, api);
        await engine.init();
      } catch {
        engine = null; // the app works fine without sync
      }
    }

    root.render(
      <StrictMode>
        <ErrorBoundary>
          <StoreProvider store={store}>
            <SyncProvider engine={engine}>
              <App />
            </SyncProvider>
          </StoreProvider>
        </ErrorBoundary>
      </StrictMode>,
    );
  } catch (e) {
    root.render(
      <ErrorBoundary>
        <Throw error={e instanceof Error ? e : new Error(String(e))} />
      </ErrorBoundary>,
    );
  }
}

function Throw({ error }: { error: Error }): never {
  throw error;
}

void boot();
