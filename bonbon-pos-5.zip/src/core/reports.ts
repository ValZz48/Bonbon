// Period reports. Everything is computed from the saved records, never from today's prices or HPP:
// every sold line keeps the price and HPP it had at the time (snapshot), so old reports never change.
//
// Returns count on the day they were made and reduce net sales and HPP of the period they fall in.

import { itemCost, lineAmounts } from './calc';
import { toCsv } from './export';
import { addDaysKey, daysBetweenKeys, formatDateKey, formatNumber, formatQty } from './format';
import { itemNet } from './returns';
import type { DaySummary } from './queries';
import { customerBalance, debtSince, summarizeDay } from './queries';
import type { State } from './store';
import type { MoneyMethod, PaymentMethod, Transaction } from './types';
import { METHOD_LABEL } from './types';
import { MONEY_METHODS } from './shifts';

// ---- periods ---------------------------------------------------------------------

export interface Period {
  from: string; // YYYY-MM-DD, inclusive
  to: string;
}

export type PeriodPreset = 'today' | 'yesterday' | 'week' | 'last7' | 'month' | 'lastMonth' | 'custom';

export const PERIOD_LABEL: Record<PeriodPreset, string> = {
  today: 'Hari ini',
  yesterday: 'Kemarin',
  week: 'Minggu ini',
  last7: '7 hari',
  month: 'Bulan ini',
  lastMonth: 'Bulan lalu',
  custom: 'Pilih tanggal',
};

/** 0 = Monday ... 6 = Sunday */
export function weekdayMon0(key: string): number {
  const [y, m, d] = key.split('-').map(Number);
  return (new Date(Date.UTC(y, m - 1, d)).getUTCDay() + 6) % 7;
}

export function presetPeriod(preset: Exclude<PeriodPreset, 'custom'>, today: string): Period {
  switch (preset) {
    case 'today':
      return { from: today, to: today };
    case 'yesterday': {
      const y = addDaysKey(today, -1);
      return { from: y, to: y };
    }
    case 'week':
      return { from: addDaysKey(today, -weekdayMon0(today)), to: today };
    case 'last7':
      return { from: addDaysKey(today, -6), to: today };
    case 'month':
      return { from: `${today.slice(0, 8)}01`, to: today };
    case 'lastMonth': {
      const end = addDaysKey(`${today.slice(0, 8)}01`, -1);
      return { from: `${end.slice(0, 8)}01`, to: end };
    }
  }
}

export const MAX_REPORT_DAYS = 366;

export function periodError(p: Period): string | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(p.from) || !/^\d{4}-\d{2}-\d{2}$/.test(p.to)) return 'Isi tanggal awal dan akhir.';
  if (p.from > p.to) return 'Tanggal awal tidak boleh setelah tanggal akhir.';
  if (daysBetweenKeys(p.from, p.to) + 1 > MAX_REPORT_DAYS) return 'Rentang laporan maksimal 366 hari.';
  return null;
}

export function periodLabel(p: Period): string {
  return p.from === p.to ? formatDateKey(p.from) : `${formatDateKey(p.from)} - ${formatDateKey(p.to)}`;
}

export function daysIn(p: Period): string[] {
  const out: string[] = [];
  for (let k = p.from; k <= p.to; k = addDaysKey(k, 1)) out.push(k);
  return out;
}

const within = (key: string, p: Period) => key >= p.from && key <= p.to;

// ---- sales summary ------------------------------------------------------------------

export interface SalesSummary {
  count: number; // sales that were not voided
  voidedCount: number;
  grossSales: number; // before any discount
  itemDiscounts: number;
  cartDiscounts: number;
  returnsRevenue: number; // net sales taken back by returns
  cartDiscountsKept: number; // cart discounts still standing after the part that went back with returns
  revenue: number; // net sales = gross - discounts - returns
  cogs: number;
  profit: number;
  marginPct: number; // profit / revenue, 0 when no revenue
  tax: number;
  rounding: number;
  billed: number; // what customers were charged (net sales + tax + rounding, before returns)
  refunds: number; // money paid back for returns
  returnCount: number;
  avgTicket: number;
}

function salesIn(state: State, p: Period): Transaction[] {
  return state.transactions.filter((t) => within(t.dateKey, p));
}

export function salesSummary(state: State, p: Period): SalesSummary {
  let count = 0;
  let voidedCount = 0;
  let gross = 0;
  let itemDiscounts = 0;
  let cartDiscounts = 0;
  let cogs = 0;
  let tax = 0;
  let rounding = 0;
  let billed = 0;
  for (const t of salesIn(state, p)) {
    if (t.status === 'voided') {
      voidedCount += 1;
      continue;
    }
    count += 1;
    for (const i of t.items) {
      const a = lineAmounts({ unitQty: i.unitQty, unitPrice: i.unitPrice });
      gross += a.gross;
      itemDiscounts += i.discount;
      cogs += itemCost(i);
    }
    cartDiscounts += t.discount;
    tax += t.tax;
    rounding += t.rounding;
    billed += t.total;
  }
  let returnsRevenue = 0;
  let returnsCogs = 0;
  let returnedDiscount = 0;
  let refunds = 0;
  let returnCount = 0;
  for (const r of state.returns) {
    if (!within(r.dateKey, p)) continue;
    returnsRevenue += r.revenue;
    returnedDiscount += r.lines.reduce((a, l) => a + l.value, 0) - r.revenue;
    returnsCogs += r.cogs;
    refunds += r.refund;
    returnCount += 1;
  }
  const revenue = gross - itemDiscounts - cartDiscounts - returnsRevenue;
  const netCogs = cogs - returnsCogs;
  const profit = revenue - netCogs;
  return {
    count,
    voidedCount,
    grossSales: gross,
    itemDiscounts,
    cartDiscounts,
    returnsRevenue,
    cartDiscountsKept: cartDiscounts - returnedDiscount,
    revenue,
    cogs: netCogs,
    profit,
    marginPct: revenue > 0 ? Math.round((profit / revenue) * 1000) / 10 : 0,
    tax,
    rounding,
    billed,
    refunds,
    returnCount,
    avgTicket: count > 0 ? Math.round(billed / count) : 0,
  };
}

export function dailyRows(state: State, p: Period): DaySummary[] {
  return daysIn(p).map((k) => summarizeDay(state, k));
}

// ---- per product and category -----------------------------------------------------------

export interface ProductRow {
  productId: string;
  name: string;
  category: string;
  unit: string; // base unit
  qty: number; // sold minus returned, in the base unit
  revenue: number; // line values after the line's own discount, minus returns (cart discounts are not spread over products)
  cogs: number;
  profit: number;
}

export function productRows(state: State, p: Period): ProductRow[] {
  const rows = new Map<string, ProductRow>();
  const rowFor = (productId: string, name: string): ProductRow => {
    let r = rows.get(productId);
    if (!r) {
      const prod = state.productsById.get(productId);
      r = { productId, name: prod?.name ?? name, category: prod?.category ?? 'Lainnya', unit: prod?.baseUnit ?? '', qty: 0, revenue: 0, cogs: 0, profit: 0 };
      rows.set(productId, r);
    }
    return r;
  };
  for (const t of salesIn(state, p)) {
    if (t.status === 'voided') continue;
    for (const i of t.items) {
      const r = rowFor(i.productId, i.name);
      r.qty += i.qty;
      r.revenue += itemNet(i);
      r.cogs += itemCost(i);
    }
  }
  for (const ret of state.returns) {
    if (!within(ret.dateKey, p)) continue;
    for (const l of ret.lines) {
      const r = rowFor(l.productId, l.name);
      r.qty -= l.qty;
      r.revenue -= l.value;
      r.cogs -= l.cost;
    }
  }
  const out = [...rows.values()].map((r) => ({ ...r, qty: Math.round(r.qty * 1000) / 1000, profit: r.revenue - r.cogs }));
  return out.filter((r) => r.qty !== 0 || r.revenue !== 0).sort((a, b) => b.revenue - a.revenue || a.name.localeCompare(b.name, 'id'));
}

export interface CategoryRow {
  category: string;
  products: number;
  revenue: number;
  cogs: number;
  profit: number;
}

export function categoryRows(products: ProductRow[]): CategoryRow[] {
  const map = new Map<string, CategoryRow>();
  for (const r of products) {
    const c = map.get(r.category) ?? { category: r.category, products: 0, revenue: 0, cogs: 0, profit: 0 };
    c.products += 1;
    c.revenue += r.revenue;
    c.cogs += r.cogs;
    c.profit += r.profit;
    map.set(r.category, c);
  }
  return [...map.values()].sort((a, b) => b.revenue - a.revenue || a.category.localeCompare(b.category, 'id'));
}

// ---- payment methods ------------------------------------------------------------------------

export interface MethodRow {
  method: PaymentMethod;
  label: string;
  sales: number; // received for sales
  debtPayments: number; // kasbon instalments received
  refunds: number; // paid back for returns
  net: number;
}

export interface MethodReport {
  rows: MethodRow[]; // money methods only
  kasbonNew: number; // sales put on kasbon (a receivable, not money)
  pending: number; // payments still waiting for confirmation
  received: number; // total net money received
}

export function methodReport(state: State, p: Period): MethodReport {
  const sales = new Map<MoneyMethod, number>();
  const debt = new Map<MoneyMethod, number>();
  const refunds = new Map<MoneyMethod, number>();
  const add = (m: Map<MoneyMethod, number>, k: MoneyMethod, v: number) => m.set(k, (m.get(k) ?? 0) + v);
  let kasbonNew = 0;
  let pending = 0;
  for (const t of salesIn(state, p)) {
    if (t.status === 'voided') continue;
    for (const pay of t.payments) {
      if (pay.method === 'kasbon') kasbonNew += pay.amount;
      else if (pay.status === 'pending') pending += pay.amount;
      else add(sales, pay.method, pay.amount);
    }
  }
  for (const r of state.returns) {
    if (within(r.dateKey, p) && r.refundMethod !== 'kasbon') add(refunds, r.refundMethod as MoneyMethod, r.refund);
  }
  for (const entries of state.debtByCustomer.values()) {
    for (const e of entries) {
      if (e.type === 'payment' && e.method && e.method !== 'kasbon' && within(e.dateKey, p)) add(debt, e.method as MoneyMethod, e.amount);
    }
  }
  const rows: MethodRow[] = MONEY_METHODS.map((method) => {
    const s = sales.get(method) ?? 0;
    const d = debt.get(method) ?? 0;
    const r = refunds.get(method) ?? 0;
    return { method, label: METHOD_LABEL[method], sales: s, debtPayments: d, refunds: r, net: s + d - r };
  }).filter((r) => r.sales !== 0 || r.debtPayments !== 0 || r.refunds !== 0);
  return { rows, kasbonNew, pending, received: rows.reduce((s, r) => s + r.net, 0) };
}

// ---- stock value (a snapshot of right now) ---------------------------------------------------------

export interface StockValueRow {
  productId: string;
  name: string;
  category: string;
  unit: string;
  stock: number;
  cost: number; // HPP per base unit
  value: number; // stock x HPP
  retail: number; // stock x selling price
}

export function stockValueRows(state: State): StockValueRow[] {
  return state.products
    .filter((p) => p.active && p.stock > 0)
    .map((p) => ({ productId: p.id, name: p.name, category: p.category, unit: p.baseUnit, stock: p.stock, cost: p.costPrice, value: Math.round(p.stock * p.costPrice), retail: Math.round(p.stock * p.sellPrice) }))
    .sort((a, b) => b.value - a.value || a.name.localeCompare(b.name, 'id'));
}

export interface StockValueCategory {
  category: string;
  products: number;
  value: number;
  retail: number;
}

export function stockValueByCategory(rows: StockValueRow[]): StockValueCategory[] {
  const map = new Map<string, StockValueCategory>();
  for (const r of rows) {
    const c = map.get(r.category) ?? { category: r.category, products: 0, value: 0, retail: 0 };
    c.products += 1;
    c.value += r.value;
    c.retail += r.retail;
    map.set(r.category, c);
  }
  return [...map.values()].sort((a, b) => b.value - a.value || a.category.localeCompare(b.category, 'id'));
}

// ---- kasbon recap ------------------------------------------------------------------------------------

export interface KasbonDebtor {
  name: string;
  balance: number;
  since: string | null;
  days: number;
}

export interface KasbonReport {
  outstanding: number;
  debtors: KasbonDebtor[];
  newDebt: number; // kasbon given in the period (sales and manual entries)
  paid: number; // instalments received in the period
  writtenOff: number; // debts cancelled in the period
  returnedAgainst: number; // taken off debt by returns in the period
}

export function kasbonReport(state: State, p: Period, today: string): KasbonReport {
  let outstanding = 0;
  const debtors: KasbonDebtor[] = [];
  for (const c of state.customers) {
    const balance = customerBalance(state, c.id);
    if (balance <= 0) continue;
    outstanding += balance;
    const since = debtSince(state.debtByCustomer.get(c.id) ?? []);
    debtors.push({ name: c.name, balance, since, days: since ? Math.max(0, daysBetweenKeys(since, today)) : 0 });
  }
  debtors.sort((a, b) => b.balance - a.balance || a.name.localeCompare(b.name, 'id'));
  let newDebt = 0;
  let paid = 0;
  let writtenOff = 0;
  let returnedAgainst = 0;
  for (const entries of state.debtByCustomer.values()) {
    for (const e of entries) {
      if (!within(e.dateKey, p)) continue;
      if (e.type === 'kasbon') newDebt += e.amount;
      else if (e.type === 'payment') paid += e.amount;
      else if (e.type === 'writeoff') writtenOff += e.amount;
      else if (e.type === 'return') returnedAgainst += e.amount;
    }
  }
  return { outstanding, debtors, newDebt, paid, writtenOff, returnedAgainst };
}

// ---- tables for screen, CSV and PDF ------------------------------------------------------------------------

export interface ReportTable {
  title: string;
  columns: string[];
  /** right-align these column indexes (numbers) */
  numeric: number[];
  rows: string[][];
  /** shown under the rows, same shape as a row */
  footer?: string[];
}

export function tableCsv(t: ReportTable): string {
  return toCsv([t.columns, ...t.rows, ...(t.footer ? [t.footer] : [])]);
}

export const rp = (n: number) => (n < 0 ? '-' : '') + 'Rp ' + formatNumber(Math.abs(n));

export function summaryTable(s: SalesSummary): ReportTable {
  const rows: string[][] = [
    ['Jumlah transaksi', String(s.count)],
    ['Penjualan kotor', rp(s.grossSales)],
    ['Diskon barang', rp(-s.itemDiscounts)],
    ['Diskon transaksi', rp(-s.cartDiscounts)],
    ['Retur', rp(-s.returnsRevenue)],
    ['Penjualan bersih', rp(s.revenue)],
    ['HPP (modal barang terjual)', rp(s.cogs)],
    ['Laba kotor', rp(s.profit)],
    ['Margin', `${String(s.marginPct).replace('.', ',')}%`],
    ['Pajak dipungut', rp(s.tax)],
    ['Pembulatan', rp(s.rounding)],
    ['Total ditagih ke pelanggan', rp(s.billed)],
    ['Uang dikembalikan (retur)', rp(s.refunds)],
    ['Rata-rata per transaksi', rp(s.avgTicket)],
    ['Transaksi dibatalkan (void)', String(s.voidedCount)],
  ];
  return { title: 'Ringkasan', columns: ['Keterangan', 'Nilai'], numeric: [1], rows };
}

export function dailyTable(days: DaySummary[]): ReportTable {
  const rows = days.map((d) => [formatDateKey(d.dateKey), String(d.count), rp(d.revenue), rp(d.cogs), rp(d.profit), rp(d.refunds)]);
  const tot = days.reduce((a, d) => ({ count: a.count + d.count, revenue: a.revenue + d.revenue, cogs: a.cogs + d.cogs, profit: a.profit + d.profit, refunds: a.refunds + d.refunds }), { count: 0, revenue: 0, cogs: 0, profit: 0, refunds: 0 });
  return {
    title: 'Per hari',
    columns: ['Tanggal', 'Transaksi', 'Penjualan bersih', 'HPP', 'Laba kotor', 'Retur'],
    numeric: [1, 2, 3, 4, 5],
    rows,
    footer: ['Total', String(tot.count), rp(tot.revenue), rp(tot.cogs), rp(tot.profit), rp(tot.refunds)],
  };
}

export function productTable(rows: ProductRow[], s: SalesSummary): ReportTable {
  const sum = rows.reduce((a, r) => ({ revenue: a.revenue + r.revenue, cogs: a.cogs + r.cogs, profit: a.profit + r.profit }), { revenue: 0, cogs: 0, profit: 0 });
  return {
    title: 'Per produk',
    columns: ['Produk', 'Kategori', 'Terjual', 'Penjualan', 'HPP', 'Laba'],
    numeric: [2, 3, 4, 5],
    rows: rows.map((r) => [r.name, r.category, `${formatQty(r.qty)} ${r.unit}`, rp(r.revenue), rp(r.cogs), rp(r.profit)]),
    footer: s.cartDiscountsKept > 0 ? ['Jumlah produk (sebelum diskon transaksi)', '', '', rp(sum.revenue), rp(sum.cogs), rp(sum.profit)] : ['Total', '', '', rp(sum.revenue), rp(sum.cogs), rp(sum.profit)],
  };
}

export function categoryTable(rows: CategoryRow[]): ReportTable {
  const sum = rows.reduce((a, r) => ({ products: a.products + r.products, revenue: a.revenue + r.revenue, cogs: a.cogs + r.cogs, profit: a.profit + r.profit }), { products: 0, revenue: 0, cogs: 0, profit: 0 });
  return {
    title: 'Per kategori',
    columns: ['Kategori', 'Produk', 'Penjualan', 'HPP', 'Laba'],
    numeric: [1, 2, 3, 4],
    rows: rows.map((r) => [r.category, String(r.products), rp(r.revenue), rp(r.cogs), rp(r.profit)]),
    footer: ['Total', String(sum.products), rp(sum.revenue), rp(sum.cogs), rp(sum.profit)],
  };
}

export function methodTable(m: MethodReport): ReportTable {
  const tot = m.rows.reduce((a, r) => ({ sales: a.sales + r.sales, debt: a.debt + r.debtPayments, refunds: a.refunds + r.refunds, net: a.net + r.net }), { sales: 0, debt: 0, refunds: 0, net: 0 });
  return {
    title: 'Per metode pembayaran',
    columns: ['Metode', 'Penjualan', 'Cicilan kasbon', 'Dikembalikan', 'Diterima bersih'],
    numeric: [1, 2, 3, 4],
    rows: m.rows.map((r) => [r.label, rp(r.sales), rp(r.debtPayments), rp(-r.refunds), rp(r.net)]),
    footer: ['Total uang diterima', rp(tot.sales), rp(tot.debt), rp(-tot.refunds), rp(tot.net)],
  };
}

export function stockValueTable(rows: StockValueRow[]): ReportTable {
  const value = rows.reduce((s, r) => s + r.value, 0);
  const retail = rows.reduce((s, r) => s + r.retail, 0);
  return {
    title: 'Nilai stok (per sekarang)',
    columns: ['Produk', 'Kategori', 'Stok', 'HPP', 'Nilai (HPP)', 'Nilai jual'],
    numeric: [2, 3, 4, 5],
    rows: rows.map((r) => [r.name, r.category, `${formatQty(r.stock)} ${r.unit}`, rp(r.cost), rp(r.value), rp(r.retail)]),
    footer: ['Total', '', '', '', rp(value), rp(retail)],
  };
}

export function stockCategoryTable(rows: StockValueCategory[]): ReportTable {
  return {
    title: 'Nilai stok per kategori',
    columns: ['Kategori', 'Produk', 'Nilai (HPP)', 'Nilai jual'],
    numeric: [1, 2, 3],
    rows: rows.map((r) => [r.category, String(r.products), rp(r.value), rp(r.retail)]),
    footer: ['Total', String(rows.reduce((s, r) => s + r.products, 0)), rp(rows.reduce((s, r) => s + r.value, 0)), rp(rows.reduce((s, r) => s + r.retail, 0))],
  };
}

export function kasbonTable(k: KasbonReport): ReportTable {
  return {
    title: 'Pelanggan yang masih berutang',
    columns: ['Pelanggan', 'Sejak', 'Lama', 'Kasbon'],
    numeric: [2, 3],
    rows: k.debtors.map((d) => [d.name, d.since ? formatDateKey(d.since) : '-', `${d.days} hari`, rp(d.balance)]),
    footer: ['Total kasbon belum dibayar', '', '', rp(k.outstanding)],
  };
}

export function kasbonFlowTable(k: KasbonReport): ReportTable {
  return {
    title: 'Pergerakan kasbon pada periode ini',
    columns: ['Keterangan', 'Nilai'],
    numeric: [1],
    rows: [
      ['Kasbon baru', rp(k.newDebt)],
      ['Cicilan diterima', rp(k.paid)],
      ['Dipotong retur', rp(k.returnedAgainst)],
      ['Utang dihapus', rp(k.writtenOff)],
    ],
  };
}
