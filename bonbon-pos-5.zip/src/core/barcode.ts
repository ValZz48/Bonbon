// Camera-free barcode decoding for the scanner fallback (browsers without the native BarcodeDetector,
// e.g. iPhone Safari). Pure functions over grayscale pixels so they can be unit-tested in Node.
//
// Supported: EAN-13, EAN-8, UPC-A (comes out as EAN-13 with a leading 0) and Code 128 (sets A, B, C).
// Every result passes the symbology's own check digit, so a wrong product is very unlikely to be added.

export type BarcodeFormat = 'ean_13' | 'ean_8' | 'code_128';

export interface DecodedBarcode {
  text: string;
  format: BarcodeFormat;
}

export interface FrameDecode extends DecodedBarcode {
  /** how many scan lines agreed on this code */
  votes: number;
}

type Gray = ArrayLike<number>;

// ---- run lengths -----------------------------------------------------------------

interface Runs {
  widths: number[];
  /** colour of widths[0] */
  firstBlack: boolean;
}

/**
 * Turns one row of gray pixels into alternating bar/space widths.
 * Uses a local mean threshold (robust to uneven light) and ignores tiny deviations so flat paper stays white.
 */
export function rowToRuns(row: Gray): Runs | null {
  const n = row.length;
  if (n < 40) return null;

  // light 1-2-1 smoothing against sensor noise
  const s = new Float64Array(n);
  let lo = Infinity;
  let hi = -Infinity;
  for (let i = 0; i < n; i++) {
    const a = row[i > 0 ? i - 1 : 0];
    const b = row[i];
    const c = row[i < n - 1 ? i + 1 : n - 1];
    const v = (a + 2 * b + c) / 4;
    s[i] = v;
    if (v < lo) lo = v;
    if (v > hi) hi = v;
  }
  const range = hi - lo;
  if (range < 24) return null; // no contrast, nothing to read

  // Local threshold = midpoint between the darkest and lightest pixel nearby (independent of how dense the bars are).
  // Blocks of `bs` pixels keep this O(n); a window that shows no real contrast is treated as paper.
  const half = Math.min(240, Math.max(14, Math.round(n / 9)));
  const bs = Math.max(4, Math.round(half / 4));
  const nb = Math.ceil(n / bs);
  const bmin = new Float64Array(nb).fill(Infinity);
  const bmax = new Float64Array(nb).fill(-Infinity);
  for (let i = 0; i < n; i++) {
    const k = (i / bs) | 0;
    if (s[i] < bmin[k]) bmin[k] = s[i];
    if (s[i] > bmax[k]) bmax[k] = s[i];
  }
  const reach = Math.ceil(half / bs);
  const minContrast = Math.max(20, range * 0.3);

  const widths: number[] = [];
  let firstBlack = false;
  let cur: boolean | null = null;
  let len = 0;
  for (let i = 0; i < n; i++) {
    const kc = (i / bs) | 0;
    let wmin = Infinity;
    let wmax = -Infinity;
    for (let k = Math.max(0, kc - reach); k <= Math.min(nb - 1, kc + reach); k++) {
      if (bmin[k] < wmin) wmin = bmin[k];
      if (bmax[k] > wmax) wmax = bmax[k];
    }
    const black = wmax - wmin >= minContrast && s[i] < (wmin + wmax) / 2;
    if (cur === null) {
      cur = black;
      firstBlack = black;
      len = 1;
    } else if (black === cur) {
      len++;
    } else {
      widths.push(len);
      cur = black;
      len = 1;
    }
  }
  widths.push(len);
  return widths.length >= 20 ? { widths, firstBlack } : null;
}

function reverseRuns(r: Runs): Runs {
  const lastBlack = (r.widths.length - 1) % 2 === 0 ? r.firstBlack : !r.firstBlack;
  return { widths: r.widths.slice().reverse(), firstBlack: lastBlack };
}

// ---- pattern matching (same scoring idea as ZXing) ------------------------------------

const MAX_AVG_VARIANCE = 0.48;
const MAX_INDIVIDUAL_VARIANCE = 0.7;

function variance(counters: number[], offset: number, pattern: readonly number[]): number {
  let total = 0;
  let patternLen = 0;
  for (let i = 0; i < pattern.length; i++) {
    total += counters[offset + i];
    patternLen += pattern[i];
  }
  if (total < patternLen) return Infinity;
  const unit = total / patternLen;
  const maxIndividual = MAX_INDIVIDUAL_VARIANCE * unit;
  let sum = 0;
  for (let i = 0; i < pattern.length; i++) {
    const d = Math.abs(counters[offset + i] - pattern[i] * unit);
    if (d > maxIndividual) return Infinity;
    sum += d;
  }
  return sum / total;
}

function bestMatch(counters: number[], offset: number, patterns: readonly (readonly number[])[]): number {
  let best = -1;
  let bestVar = MAX_AVG_VARIANCE;
  for (let i = 0; i < patterns.length; i++) {
    const v = variance(counters, offset, patterns[i]);
    if (v < bestVar) {
      bestVar = v;
      best = i;
    }
  }
  return best;
}

interface Hit {
  text: string;
  /** index just after the last run of the symbol */
  end: number;
  /** total modules the symbol spans (used to derive the module width) */
  modules: number;
  start: number;
}

/** Every group of runs must be about as wide as its module count says (rejects look-alike texture). */
function uniform(w: number[], start: number, groups: ReadonlyArray<readonly [offset: number, count: number, modules: number]>, modules: number): boolean {
  const last = groups[groups.length - 1];
  let total = 0;
  for (let k = start; k < start + last[0] + last[1]; k++) total += w[k];
  const unit = total / modules;
  for (const [off, count, mods] of groups) {
    let sum = 0;
    for (let k = 0; k < count; k++) sum += w[start + off + k];
    const ratio = sum / (mods * unit);
    if (ratio < 0.72 || ratio > 1.28) return false;
  }
  return true;
}

// ---- EAN / UPC ------------------------------------------------------------------------

const L_CODES = ['3211', '2221', '2122', '1411', '1132', '1231', '1114', '1312', '1213', '3112'].map((s) => [...s].map(Number));
const G_CODES = L_CODES.map((p) => p.slice().reverse());
const LG_CODES = [...L_CODES, ...G_CODES];
/** left-half parity (bit set = G code, most significant bit = first digit) -> leading digit of EAN-13 */
const FIRST_DIGIT = [0x00, 0x0b, 0x0d, 0x0e, 0x13, 0x19, 0x1c, 0x15, 0x16, 0x1a];
const GUARD = [1, 1, 1];
const MIDDLE = [1, 1, 1, 1, 1];

export function eanCheckDigit(withoutCheck: string): number {
  let sum = 0;
  for (let i = 0; i < withoutCheck.length; i++) {
    const d = withoutCheck.charCodeAt(i) - 48;
    // counting from the right of the payload, the last digit weighs 3
    sum += (withoutCheck.length - i) % 2 === 1 ? d * 3 : d;
  }
  return (10 - (sum % 10)) % 10;
}

export function isValidEan(code: string): boolean {
  return /^\d{8}$|^\d{13}$/.test(code) && eanCheckDigit(code.slice(0, -1)) === code.charCodeAt(code.length - 1) - 48;
}

function tryEan(w: number[], i: number, half: 6 | 4): Hit | null {
  const need = 3 + half * 4 + 5 + half * 4 + 3;
  if (i + need > w.length) return null;
  if (variance(w, i, GUARD) > MAX_AVG_VARIANCE) return null;
  let p = i + 3;
  const digits: number[] = [];
  let parity = 0;
  for (let k = 0; k < half; k++) {
    const d = bestMatch(w, p, half === 6 ? LG_CODES : L_CODES);
    if (d < 0) return null;
    if (d >= 10) parity |= 1 << (half - 1 - k);
    digits.push(d % 10);
    p += 4;
  }
  if (variance(w, p, MIDDLE) > MAX_AVG_VARIANCE) return null;
  p += 5;
  for (let k = 0; k < half; k++) {
    const d = bestMatch(w, p, L_CODES);
    if (d < 0) return null;
    digits.push(d);
    p += 4;
  }
  if (variance(w, p, GUARD) > MAX_AVG_VARIANCE) return null;
  if (half === 6) {
    const first = FIRST_DIGIT.indexOf(parity);
    if (first < 0) return null;
    digits.unshift(first);
  }
  const text = digits.join('');
  if (!isValidEan(text)) return null;
  const groups: Array<[number, number, number]> = [[0, 3, 3]];
  for (let k = 0; k < half; k++) groups.push([3 + 4 * k, 4, 7]);
  groups.push([3 + 4 * half, 5, 5]);
  for (let k = 0; k < half; k++) groups.push([8 + 4 * half + 4 * k, 4, 7]);
  groups.push([8 + 8 * half, 3, 3]);
  const modules = 11 + 14 * half;
  if (!uniform(w, i, groups, modules)) return null;
  return { text, end: i + need, modules, start: i };
}

// ---- Code 128 -------------------------------------------------------------------------

// Widths of bar,space,bar,space,bar,space for values 0..105 (start A/B/C = 103/104/105).
const C128 = (
  '212222 222122 222221 121223 121322 131222 122213 122312 132212 221213 ' +
  '221312 231212 112232 122132 122231 113222 123122 123221 223211 221132 ' +
  '221231 213212 223112 312131 311222 321122 321221 312212 322112 322211 ' +
  '212123 212321 232121 111323 131123 131321 112313 132113 132311 211313 ' +
  '231113 231311 112133 112331 132131 113123 113321 133121 313121 211331 ' +
  '231131 213113 213311 213131 311123 311321 331121 312113 312311 332111 ' +
  '314111 221411 431111 111224 111422 121124 121421 141122 141221 112214 ' +
  '112412 122114 122411 142112 142211 241211 221114 413111 241112 134111 ' +
  '111242 121142 121241 114212 124112 124211 411212 421112 421211 212141 ' +
  '214121 412121 111143 111341 131141 114113 114311 411113 411311 113141 ' +
  '114131 311141 411131 211412 211214 211232'
)
  .trim()
  .split(/\s+/)
  .map((s) => [...s].map(Number));
const C128_STOP = [2, 3, 3, 1, 1, 1, 2];

/** exposed for tests: the table must be internally consistent */
export const CODE128_TABLE = C128;

function code128Text(values: number[]): string | null {
  // values = [start, ...data] (checksum already removed)
  let set: 'A' | 'B' | 'C' = values[0] === 103 ? 'A' : values[0] === 104 ? 'B' : 'C';
  let shift = false;
  let out = '';
  for (let k = 1; k < values.length; k++) {
    const v = values[k];
    if (set === 'C') {
      if (v < 100) out += v < 10 ? `0${v}` : String(v);
      else if (v === 100) set = 'B';
      else if (v === 101) set = 'A';
      else if (v === 102) continue; // FNC1
      else return null;
      continue;
    }
    const cur: 'A' | 'B' = shift ? (set === 'A' ? 'B' : 'A') : set;
    shift = false;
    if (v < 96) {
      if (cur === 'B' || v < 64) out += String.fromCharCode(v + 32);
      else return null; // control characters are not product codes
    } else if (v === 98) {
      shift = true;
    } else if (v === 99) {
      set = 'C';
    } else if (v === 100) {
      if (cur === 'A') set = 'B'; // in set B this value is FNC4 (ignored)
    } else if (v === 101) {
      if (cur === 'B') set = 'A'; // in set A this value is FNC4 (ignored)
    }
    // 96, 97, 102 (FNC3, FNC2, FNC1): ignored
  }
  return out.length >= 4 ? out : null;
}

function tryCode128(w: number[], i: number): Hit | null {
  const start = bestMatch(w, i, C128.slice(103, 106));
  if (start < 0) return null;
  const values = [103 + start];
  let p = i + 6;
  for (let n = 0; n < 48; n++) {
    if (p + 7 <= w.length && variance(w, p, C128_STOP) <= MAX_AVG_VARIANCE) {
      if (values.length < 3) return null; // start + at least one data value + checksum
      const check = values[values.length - 1];
      let sum = values[0];
      for (let k = 1; k < values.length - 1; k++) sum += k * values[k];
      if (sum % 103 !== check) return null;
      const text = code128Text(values.slice(0, -1));
      if (!text) return null;
      const chars = values.length;
      const groups: Array<[number, number, number]> = [];
      for (let k = 0; k < chars; k++) groups.push([6 * k, 6, 11]);
      groups.push([6 * chars, 7, 13]);
      const modules = 11 * chars + 13;
      if (!uniform(w, i, groups, modules)) return null;
      return { text, end: p + 7, modules, start: i };
    }
    if (p + 6 > w.length) return null;
    const v = bestMatch(w, p, C128.slice(0, 103));
    if (v < 0) return null;
    values.push(v);
    p += 6;
  }
  return null;
}

// ---- row / frame ----------------------------------------------------------------------

function scanRuns(r: Runs): DecodedBarcode | null {
  const w = r.widths;
  // clear paper on both sides of the symbol (the standards ask for 7-10 modules; cameras crop, so be lenient)
  const framed = (h: Hit, minBefore: number, minAfter: number) => {
    const unit = (() => {
      let t = 0;
      for (let k = h.start; k < h.end; k++) t += w[k];
      return t / h.modules;
    })();
    return h.start >= 1 && h.end < w.length && w[h.start - 1] >= unit * minBefore && w[h.end] >= unit * minAfter;
  };
  for (let i = 1; i < w.length - 6; i++) {
    const black = (i % 2 === 0) === r.firstBlack;
    if (!black) continue;
    const e13 = tryEan(w, i, 6);
    if (e13 && framed(e13, 4, 3)) return { text: e13.text, format: 'ean_13' };
    const e8 = tryEan(w, i, 4);
    if (e8 && framed(e8, 4, 3)) return { text: e8.text, format: 'ean_8' };
    const c = tryCode128(w, i);
    if (c && framed(c, 5, 4)) return { text: c.text, format: 'code_128' };
  }
  return null;
}

/** Decodes a single row of gray pixels (either reading direction). */
export function decodeRow(row: Gray): DecodedBarcode | null {
  const runs = rowToRuns(row);
  if (!runs) return null;
  return scanRuns(runs) ?? scanRuns(reverseRuns(runs));
}

export interface FrameOptions {
  /** number of scan lines (default 15) */
  rows?: number;
  /** vertical band of the frame to scan, 0..1 (default 0.25 to 0.75) */
  from?: number;
  to?: number;
}

function tally(found: Map<string, FrameDecode>, d: DecodedBarcode | null) {
  if (!d) return;
  const prev = found.get(d.text);
  if (prev) prev.votes++;
  else found.set(d.text, { ...d, votes: 1 });
}

function best(found: Map<string, FrameDecode>): FrameDecode | null {
  let top: FrameDecode | null = null;
  for (const f of found.values()) if (!top || f.votes > top.votes) top = f;
  return top;
}

/**
 * Scans several horizontal lines (and, if nothing is found, vertical ones for a turned barcode)
 * of a gray image. Three neighbouring lines are averaged to calm sensor noise.
 */
export function decodeFrame(gray: Gray, width: number, height: number, opts: FrameOptions = {}): FrameDecode | null {
  const rows = opts.rows ?? 15;
  const from = opts.from ?? 0.25;
  const to = opts.to ?? 0.75;
  const found = new Map<string, FrameDecode>();

  const line = new Float64Array(Math.max(width, height));
  for (let k = 0; k < rows; k++) {
    const y = Math.round(height * (from + ((to - from) * (k + 0.5)) / rows));
    const y0 = Math.max(0, y - 1);
    const y1 = Math.min(height - 1, y + 1);
    const out = line.subarray(0, width);
    for (let x = 0; x < width; x++) out[x] = (gray[y0 * width + x] + gray[y * width + x] + gray[y1 * width + x]) / 3;
    tally(found, decodeRow(out));
  }
  const horizontal = best(found);
  if (horizontal) return horizontal;

  for (let k = 0; k < rows; k++) {
    const x = Math.round(width * (from + ((to - from) * (k + 0.5)) / rows));
    const x0 = Math.max(0, x - 1);
    const x1 = Math.min(width - 1, x + 1);
    const out = line.subarray(0, height);
    for (let y = 0; y < height; y++) out[y] = (gray[y * width + x0] + gray[y * width + x] + gray[y * width + x1]) / 3;
    tally(found, decodeRow(out));
  }
  return best(found);
}

/** RGBA (canvas ImageData) to one gray byte per pixel. */
export function rgbaToGray(rgba: ArrayLike<number>, pixels: number, into?: Uint8Array): Uint8Array {
  const out = into && into.length >= pixels ? into : new Uint8Array(pixels);
  for (let i = 0, j = 0; i < pixels; i++, j += 4) out[i] = (rgba[j] * 77 + rgba[j + 1] * 150 + rgba[j + 2] * 29) >> 8;
  return out;
}

// ---- scan gate ------------------------------------------------------------------------

/**
 * Stops one barcode held in front of the camera from being added over and over.
 * A new code counts at once; the same code counts again only after it left the view for a moment.
 */
export class ScanGate {
  private last = '';
  private lastAccepted = -Infinity;
  private lastSeen = -Infinity;

  constructor(
    private readonly minGapMs = 700,
    private readonly awayMs = 600,
  ) {}

  accept(code: string, now: number): boolean {
    const away = now - this.lastSeen;
    this.lastSeen = now; // every read, accepted or not, means "still in view"
    if (code === this.last && (away < this.awayMs || now - this.lastAccepted < this.minGapMs)) return false;
    this.last = code;
    this.lastAccepted = now;
    return true;
  }

  reset() {
    this.last = '';
    this.lastAccepted = -Infinity;
    this.lastSeen = -Infinity;
  }
}

// ---- matching scanned text to stored codes -------------------------------------------

/**
 * UPC-A (12 digits) is the same code as EAN-13 with a leading 0, and cameras report either form.
 * Compares numeric codes of 8+ digits ignoring leading zeros; everything else must match exactly (case-insensitive).
 */
export function sameCode(a: string, b: string): boolean {
  const x = a.trim().toLowerCase();
  const y = b.trim().toLowerCase();
  if (!x || !y) return false;
  if (x === y) return true;
  if (/^\d{8,}$/.test(x) && /^\d{8,}$/.test(y)) return x.replace(/^0+/, '') === y.replace(/^0+/, '');
  return false;
}
