// Formatting helpers. All calendar logic uses Asia/Jakarta (WIB, UTC+7, no DST).

export const TZ = 'Asia/Jakarta';

const dayFmt = new Intl.DateTimeFormat('en-CA', {
  timeZone: TZ,
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
});

const groupThousands = (s: string) => s.replace(/\B(?=(\d{3})+(?!\d))/g, '.');

/** 15000 -> "Rp 15.000" */
export function formatRupiah(n: number): string {
  const r = Math.round(n);
  return (r < 0 ? '-' : '') + 'Rp ' + groupThousands(Math.abs(r).toString());
}

/** Plain number with Indonesian separators, no currency prefix. */
export function formatNumber(n: number): string {
  const r = Math.round(n);
  return (r < 0 ? '-' : '') + groupThousands(Math.abs(r).toString());
}

/** Quantity with up to 3 decimals: 1.5 -> "1,5", 1234 -> "1.234". */
export function formatQty(n: number): string {
  const r = Math.round(n * 1000) / 1000;
  const [int, dec] = Math.abs(r).toString().split('.');
  return (r < 0 ? '-' : '') + groupThousands(int) + (dec ? ',' + dec : '');
}

/** Compact Rupiah for chart labels: 1250000 -> "1,25 jt", 162750 -> "162,8 rb". */
export function formatCompactRupiah(n: number): string {
  const abs = Math.abs(n);
  const trim = (v: number, digits: number) => {
    const f = 10 ** digits;
    return (Math.round(v * f) / f).toString().replace('.', ',');
  };
  if (abs >= 1_000_000_000) return trim(n / 1_000_000_000, 2) + ' M';
  if (abs >= 1_000_000) return trim(n / 1_000_000, 2) + ' jt';
  if (abs >= 1_000) return trim(n / 1_000, 1) + ' rb';
  return Math.round(n).toString();
}

/** "YYYY-MM-DD" of an instant, in WIB. */
export function dateKeyOf(d: Date): string {
  return dayFmt.format(d);
}

export function todayKey(now: Date = new Date()): string {
  return dateKeyOf(now);
}

/** Instant at 00:00 WIB of the given date key. */
export function startOfDayKey(key: string): Date {
  return new Date(`${key}T00:00:00+07:00`);
}

export function addDaysKey(key: string, days: number): string {
  // Indonesia has no DST, so adding whole days of milliseconds is exact.
  return dateKeyOf(new Date(startOfDayKey(key).getTime() + days * 86_400_000 + 12 * 3_600_000));
}

/** Whole days from key `a` to key `b` (b - a). */
export function daysBetweenKeys(a: string, b: string): number {
  return Math.round((startOfDayKey(b).getTime() - startOfDayKey(a).getTime()) / 86_400_000);
}

/** Build an instant from a WIB date key and clock time. */
export function atWib(key: string, hour: number, minute: number): Date {
  const hh = String(hour).padStart(2, '0');
  const mm = String(minute).padStart(2, '0');
  return new Date(`${key}T${hh}:${mm}:00+07:00`);
}

const dateTimeFmt = new Intl.DateTimeFormat('id-ID', {
  timeZone: TZ,
  day: '2-digit',
  month: 'short',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  hour12: false,
});
const dateFmt = new Intl.DateTimeFormat('id-ID', {
  timeZone: TZ,
  day: '2-digit',
  month: 'short',
  year: 'numeric',
});
const timeFmt = new Intl.DateTimeFormat('id-ID', {
  timeZone: TZ,
  hour: '2-digit',
  minute: '2-digit',
  hour12: false,
});
const longDateFmt = new Intl.DateTimeFormat('id-ID', {
  timeZone: TZ,
  weekday: 'long',
  day: 'numeric',
  month: 'long',
  year: 'numeric',
});
const weekdayShort = new Intl.DateTimeFormat('id-ID', { timeZone: TZ, weekday: 'short' });
const dayNum = new Intl.DateTimeFormat('id-ID', { timeZone: TZ, day: 'numeric' });

/** "19 Okt 2026, 17.01" */
export function formatDateTime(iso: string | Date): string {
  return dateTimeFmt.format(typeof iso === 'string' ? new Date(iso) : iso);
}
/** "19 Okt 2026" */
export function formatDate(iso: string | Date): string {
  return dateFmt.format(typeof iso === 'string' ? new Date(iso) : iso);
}
export function formatDateKey(key: string): string {
  return dateFmt.format(startOfDayKey(key));
}
/** "17.01" */
export function formatTime(iso: string | Date): string {
  return timeFmt.format(typeof iso === 'string' ? new Date(iso) : iso);
}
/** "Senin, 19 Oktober 2026" */
export function formatLongDate(d: Date = new Date()): string {
  return longDateFmt.format(d);
}
/** { weekday: "Sen", day: "19" } for a date key */
export function dayLabel(key: string): { weekday: string; day: string } {
  const d = new Date(startOfDayKey(key).getTime() + 12 * 3_600_000);
  return { weekday: weekdayShort.format(d).replace('.', ''), day: dayNum.format(d) };
}

export function newId(): string {
  const c = (globalThis as { crypto?: Crypto }).crypto;
  if (c && typeof c.randomUUID === 'function') return c.randomUUID();
  return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
}
