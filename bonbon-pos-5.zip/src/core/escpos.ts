// ESC/POS bytes for small thermal receipt printers (58 mm and 80 mm), built from the shared receipt layout.
// Pure functions only: the Bluetooth / RawBT plumbing lives in app/print.ts.

import type { ReceiptLayout } from './export';

const ESC = 0x1b;
const GS = 0x1d;
const LF = 0x0a;

const REPLACEMENTS: Record<string, string> = {
  '–': '-',
  '—': '-',
  '‘': "'",
  '’': "'",
  '“': '"',
  '”': '"',
  '…': '...',
  '×': 'x',
  '•': '*',
  '·': '*',
  ' ': ' ',
};

/** Thermal printers default to a 7-bit code page, so everything is reduced to plain ASCII ("é" becomes "e", unknown symbols "?"). */
export function toAscii(text: string): string {
  let out = '';
  for (const ch of text.normalize('NFD')) {
    const code = ch.codePointAt(0) as number;
    if (code >= 0x300 && code <= 0x36f) continue; // combining accents left over from NFD
    if (code >= 0x20 && code < 0x7f) out += ch;
    else if (REPLACEMENTS[ch] !== undefined) out += REPLACEMENTS[ch];
    else if (code === 0x09) out += ' ';
    else out += '?';
  }
  return out;
}

export interface EscPosOptions {
  /** blank lines after the receipt so the text clears the tear bar (default 4) */
  feed?: number;
  /** send a partial-cut command (only for printers that have a cutter, normally 80 mm models) */
  cut?: boolean;
}

/** ESC @ (reset), each line as ASCII with bold on the lines the layout marks, then paper feed (and optional cut). */
export function encodeEscPos(layout: ReceiptLayout, options: EscPosOptions = {}): Uint8Array {
  const bytes: number[] = [ESC, 0x40]; // initialize
  const bold = new Set(layout.bold);
  let boldOn = false;
  layout.lines.forEach((line, i) => {
    const wantBold = bold.has(i);
    if (wantBold !== boldOn) {
      bytes.push(ESC, 0x45, wantBold ? 1 : 0); // ESC E n
      boldOn = wantBold;
    }
    for (const ch of toAscii(line)) bytes.push(ch.charCodeAt(0));
    bytes.push(LF);
  });
  if (boldOn) bytes.push(ESC, 0x45, 0);
  const feed = Math.max(0, Math.min(10, options.feed ?? 4));
  if (options.cut) bytes.push(GS, 0x56, 0x42, 0x00); // GS V 66 0: feed to cutting position, then partial cut
  else if (feed > 0) bytes.push(ESC, 0x64, feed); // ESC d n: feed n lines
  return Uint8Array.from(bytes);
}

/** Splits bytes into pieces a Bluetooth LE characteristic accepts per write. */
export function chunkBytes(bytes: Uint8Array, size: number): Uint8Array[] {
  const n = Math.max(1, Math.floor(size));
  const out: Uint8Array[] = [];
  for (let i = 0; i < bytes.length; i += n) out.push(bytes.slice(i, i + n));
  return out;
}

export function bytesToBase64(bytes: Uint8Array): string {
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

/** Same job from inside the Android app's WebView, where Chrome-style intent: links are not understood: the plain rawbt: scheme. */
export function rawbtNativeUrl(bytes: Uint8Array): string {
  return `rawbt:base64,${bytesToBase64(bytes)}`;
}

/** Link that hands the bytes to the RawBT Android app, which drives Bluetooth and USB thermal printers. */
export function rawbtUrl(bytes: Uint8Array): string {
  return `intent:base64,${bytesToBase64(bytes)}#Intent;scheme=rawbt;launchFlags=0x10000000;package=ru.a402d.rawbtprinter;end;`;
}
