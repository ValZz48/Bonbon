// Shift and cash drawer: open with a starting float, see what the drawer should hold, close by counting.
//
// Cash that should be in the drawer =
//   opening float
//   + cash received for sales in this shift
//   + cash instalments of kasbon received in this shift
//   + cash put in by hand
//   - cash paid back for voids and returns done in this shift
//   - cash taken out by hand

import { dateKeyOf, formatDateTime, formatRupiah, newId } from './format';
import { currentShift } from './services';
import type { State, Store } from './store';
import type { CashMove, DebtEntry, MoneyMethod, ReturnRecord, Shift, ShiftMethodTotal, ShiftSummary, Transaction } from './types';
import { DomainError, METHOD_LABEL } from './types';

export const MONEY_METHODS: MoneyMethod[] = ['cash', 'qris', 'transfer', 'ewallet', 'debit', 'credit'];

export interface ShiftData {
  transactions: Transaction[];
  returns: ReturnRecord[];
  debtEntries: DebtEntry[];
  cashMoves: CashMove[];
}

/** The records a shift summary is computed from, taken straight from the app state. */
export function shiftDataOf(state: State): ShiftData {
  return { transactions: state.transactions, returns: state.returns, debtEntries: [...state.debtByCustomer.values()].flat(), cashMoves: state.cashMoves };
}

/** Money received by method for a sale: only payments that are confirmed, never kasbon. */
function receivedByMethod(t: Transaction): Map<MoneyMethod, number> {
  const out = new Map<MoneyMethod, number>();
  for (const p of t.payments) {
    if (p.method === 'kasbon' || p.status !== 'success') continue;
    out.set(p.method, (out.get(p.method) ?? 0) + p.amount);
  }
  return out;
}

/** Everything the shift did, computed from the records. Used live (open shift) and to freeze a closed one. */
export function summarizeShift(shift: Pick<Shift, 'id' | 'openingCash'>, data: ShiftData): ShiftSummary {
  const sales = new Map<MoneyMethod, number>();
  const debt = new Map<MoneyMethod, number>();
  const refunds = new Map<MoneyMethod, number>();
  const add = (m: Map<MoneyMethod, number>, k: MoneyMethod, v: number) => m.set(k, (m.get(k) ?? 0) + v);

  let salesCount = 0;
  let salesTotal = 0;
  let kasbonSales = 0;
  let pending = 0;
  let voidCount = 0;
  for (const t of data.transactions) {
    if (t.shiftId === shift.id) {
      for (const [m, v] of receivedByMethod(t)) add(sales, m, v);
      for (const p of t.payments) if (p.status === 'pending') pending += p.amount;
      if (t.status !== 'voided') {
        salesCount += 1;
        salesTotal += t.total;
        kasbonSales += t.payments.filter((p) => p.method === 'kasbon').reduce((s, p) => s + p.amount, 0);
      }
    }
    if (t.status === 'voided' && t.voidShiftId === shift.id) {
      voidCount += 1;
      for (const [m, v] of receivedByMethod(t)) add(refunds, m, v);
    }
  }
  let returnCount = 0;
  for (const r of data.returns) {
    if (r.shiftId !== shift.id) continue;
    returnCount += 1;
    if (r.refundMethod !== 'kasbon') add(refunds, r.refundMethod as MoneyMethod, r.refund);
  }
  for (const e of data.debtEntries) {
    if (e.shiftId === shift.id && e.type === 'payment' && e.method && e.method !== 'kasbon') add(debt, e.method as MoneyMethod, e.amount);
  }
  let moneyIn = 0;
  let moneyOut = 0;
  for (const m of data.cashMoves) {
    if (m.shiftId !== shift.id) continue;
    if (m.type === 'in') moneyIn += m.amount;
    else moneyOut += m.amount;
  }

  const methods: ShiftMethodTotal[] = MONEY_METHODS.map((method) => {
    const s = sales.get(method) ?? 0;
    const d = debt.get(method) ?? 0;
    const r = refunds.get(method) ?? 0;
    return { method, sales: s, debtPayments: d, refunds: r, net: s + d - r };
  }).filter((m) => m.sales !== 0 || m.debtPayments !== 0 || m.refunds !== 0);

  const cash = {
    opening: shift.openingCash,
    sales: sales.get('cash') ?? 0,
    debtPayments: debt.get('cash') ?? 0,
    moneyIn,
    refunds: refunds.get('cash') ?? 0,
    moneyOut,
    expected: 0,
  };
  cash.expected = cash.opening + cash.sales + cash.debtPayments + cash.moneyIn - cash.refunds - cash.moneyOut;
  return { salesCount, salesTotal, kasbonSales, pending, voidCount, returnCount, methods, cash };
}

/** The summary to show for a shift: frozen when closed, live when open. */
export function shiftSummaryOf(shift: Shift, data: ShiftData): ShiftSummary {
  return shift.summary ?? summarizeShift(shift, data);
}

export function openShift(store: Store, input: { openingCash: number; note?: string }, now: Date = new Date()): Promise<Shift> {
  return store.mutate((tx) => {
    if (currentShift(tx)) throw new DomainError('Masih ada shift yang berjalan. Tutup dulu sebelum membuka yang baru.');
    const cash = input.openingCash;
    if (!Number.isFinite(cash) || cash < 0 || !Number.isInteger(cash)) throw new DomainError('Uang awal di laci harus rupiah utuh, 0 atau lebih.');
    const shift: Shift = {
      id: newId(),
      status: 'open',
      openedAt: now.toISOString(),
      openingCash: cash,
      cashierName: tx.settings.cashierName,
      note: input.note?.trim() || undefined,
    };
    tx.put('shifts', shift);
    return shift;
  });
}

export function addCashMove(store: Store, input: { type: 'in' | 'out'; amount: number; note: string }, now: Date = new Date()): Promise<CashMove> {
  return store.mutate((tx) => {
    const shift = currentShift(tx);
    if (!shift) throw new DomainError('Buka shift dulu sebelum mencatat uang masuk atau keluar laci.');
    if (input.type !== 'in' && input.type !== 'out') throw new DomainError('Pilih uang masuk atau uang keluar.');
    if (!Number.isFinite(input.amount) || input.amount <= 0 || !Number.isInteger(input.amount)) throw new DomainError('Jumlah harus rupiah utuh lebih dari 0.');
    const note = input.note.trim();
    if (!note) throw new DomainError('Keterangan wajib diisi, mis. "Bayar supplier galon".');
    const move: CashMove = { id: newId(), shiftId: shift.id, type: input.type, amount: input.amount, note, createdAt: now.toISOString() };
    tx.put('cashMoves', move);
    return move;
  });
}

export interface CloseInput {
  countedCash: number;
  note?: string;
}

export function closeShift(store: Store, input: CloseInput, now: Date = new Date()): Promise<Shift> {
  return store.mutate((tx) => {
    const shift = currentShift(tx);
    if (!shift) throw new DomainError('Tidak ada shift yang berjalan.');
    if (!Number.isFinite(input.countedCash) || input.countedCash < 0 || !Number.isInteger(input.countedCash)) {
      throw new DomainError('Uang yang dihitung harus rupiah utuh, 0 atau lebih.');
    }
    const transactions = tx.list('transactions');
    const waiting = transactions.filter((t) => t.shiftId === shift.id && t.status === 'completed' && t.payments.some((p) => p.status === 'pending'));
    if (waiting.length > 0) {
      throw new DomainError(`Masih ada ${waiting.length} transaksi yang pembayarannya menunggu konfirmasi. Konfirmasi dulu di Riwayat sebelum menutup shift.`);
    }
    const summary = summarizeShift(shift, { transactions, returns: tx.list('returns'), debtEntries: tx.list('debtEntries'), cashMoves: tx.list('cashMoves') });
    const closed: Shift = {
      ...shift,
      status: 'closed',
      closedAt: now.toISOString(),
      countedCash: input.countedCash,
      expectedCash: summary.cash.expected,
      difference: input.countedCash - summary.cash.expected,
      closeNote: input.note?.trim() || undefined,
      summary,
    };
    tx.put('shifts', closed);
    return closed;
  });
}

/** Plain-text recap of a shift, for copying into a note or a chat. */
export function shiftText(shift: Shift, summary: ShiftSummary, storeName: string): string {
  const rp = formatRupiah;
  const lines = [
    `Rekap shift - ${storeName}`,
    `Buka: ${formatDateTime(shift.openedAt)}`,
    shift.closedAt ? `Tutup: ${formatDateTime(shift.closedAt)}` : 'Masih berjalan',
    '',
    `Penjualan: ${summary.salesCount} transaksi, ${rp(summary.salesTotal)}`,
  ];
  if (summary.kasbonSales > 0) lines.push(`  termasuk kasbon ${rp(summary.kasbonSales)} (belum diterima)`);
  lines.push('', 'Uang diterima per metode:');
  for (const m of summary.methods) lines.push(`  ${METHOD_LABEL[m.method]}: ${rp(m.net)}`);
  const c = summary.cash;
  lines.push('', 'Uang tunai di laci:', `  Uang awal: ${rp(c.opening)}`, `  Penjualan tunai: ${rp(c.sales)}`);
  if (c.debtPayments) lines.push(`  Cicilan kasbon tunai: ${rp(c.debtPayments)}`);
  if (c.moneyIn) lines.push(`  Uang masuk: ${rp(c.moneyIn)}`);
  if (c.refunds) lines.push(`  Void dan retur tunai: -${rp(c.refunds)}`);
  if (c.moneyOut) lines.push(`  Uang keluar: -${rp(c.moneyOut)}`);
  lines.push(`  Seharusnya: ${rp(c.expected)}`);
  if (shift.countedCash !== undefined) {
    const d = shift.difference ?? 0;
    lines.push(`  Dihitung: ${rp(shift.countedCash)}`, `  Selisih: ${d === 0 ? 'pas' : d > 0 ? `lebih ${rp(d)}` : `kurang ${rp(-d)}`}`);
  }
  if (shift.closeNote) lines.push('', `Catatan: ${shift.closeNote}`);
  return lines.join('\n');
}

/** Date key a shift started on (WIB). */
export function shiftDateKey(shift: Shift): string {
  return dateKeyOf(new Date(shift.openedAt));
}
