// Demo data: 20 products (food & drinks), a week of sales, and a few stock alerts.

import { isDecimalUnit, roundQty } from './calc';
import { addDaysKey, atWib, dateKeyOf } from './format';
import type { CartLineInput, PaymentInput } from './services';
import { addManualDebt, adjustStock, calcCart, checkout, receiveDebtPayment, receiveStock, resolveLine, saveCustomer, saveProduct } from './services';
import { holdCart } from './holds';
import { finishOpname, saveOpnameCount, startOpname } from './opname';
import { returnItems } from './returns';
import { closeShift, openShift, shiftDataOf, summarizeShift } from './shifts';
import type { Store } from './store';
import { DomainError } from './types';

interface DemoProduct {
  sku: string;
  barcode?: string;
  name: string;
  category: string;
  baseUnit: string;
  cost: number;
  sell: number;
  min: number;
  stock: number;
  units?: [string, number, number][]; // [name, conversion, price]
  target?: number; // final stock after the simulated week (to show alerts)
  expiryInDays?: number;
}

const PRODUCTS: DemoProduct[] = [
  { sku: 'MKN-001', barcode: '8998866200301', name: 'Indomie Goreng', category: 'Mi Instan', baseUnit: 'pcs', cost: 2800, sell: 3500, min: 20, stock: 140, units: [['dus', 40, 135000]], target: 15 },
  { sku: 'MKN-002', barcode: '8998866200318', name: 'Indomie Soto', category: 'Mi Instan', baseUnit: 'pcs', cost: 2700, sell: 3400, min: 20, stock: 120, units: [['dus', 40, 130000]] },
  { sku: 'MKN-003', barcode: '8998866200325', name: 'Mie Sedaap Goreng', category: 'Mi Instan', baseUnit: 'pcs', cost: 2750, sell: 3500, min: 15, stock: 90 },
  { sku: 'RTS-001', name: 'Roti Tawar Sari Roti', category: 'Roti & Snack', baseUnit: 'pcs', cost: 12500, sell: 15000, min: 5, stock: 24, target: 3, expiryInDays: 3 },
  { sku: 'RTS-002', barcode: '8992775001219', name: 'Biskuit Roma Kelapa', category: 'Roti & Snack', baseUnit: 'pcs', cost: 8500, sell: 10000, min: 8, stock: 40 },
  { sku: 'RTS-003', name: 'Wafer Tango Coklat', category: 'Roti & Snack', baseUnit: 'pcs', cost: 9000, sell: 11000, min: 8, stock: 36 },
  { sku: 'RTS-004', name: 'Chitato Sapi Panggang', category: 'Roti & Snack', baseUnit: 'pcs', cost: 9500, sell: 11500, min: 8, stock: 30 },
  { sku: 'SMB-001', name: 'Telur Ayam', category: 'Sembako', baseUnit: 'kg', cost: 26000, sell: 29000, min: 5, stock: 30, target: 0 },
  { sku: 'SMB-002', name: 'Beras Premium', category: 'Sembako', baseUnit: 'kg', cost: 13500, sell: 15500, min: 15, stock: 80 },
  { sku: 'SMB-003', name: 'Gula Pasir', category: 'Sembako', baseUnit: 'kg', cost: 16000, sell: 18000, min: 6, stock: 25, target: 5.5 },
  { sku: 'SMB-004', barcode: '8992000100014', name: 'Minyak Goreng 1 L', category: 'Sembako', baseUnit: 'botol', cost: 17500, sell: 19500, min: 6, stock: 30, units: [['dus', 12, 225000]], target: 4 },
  { sku: 'MNM-001', barcode: '8993000600016', name: 'Air Mineral 600 ml', category: 'Minuman', baseUnit: 'botol', cost: 2000, sell: 3000, min: 24, stock: 150, units: [['dus', 24, 45000]], target: 18 },
  { sku: 'MNM-002', barcode: '8996001600146', name: 'Teh Botol 450 ml', category: 'Minuman', baseUnit: 'botol', cost: 4500, sell: 6000, min: 12, stock: 60, units: [['dus', 12, 68000]], target: 0 },
  { sku: 'MNM-003', name: 'Kopi Kapal Api Sachet', category: 'Kopi & Susu', baseUnit: 'sachet', cost: 1100, sell: 1500, min: 25, stock: 160, units: [['renceng', 10, 14000]], target: 22 },
  { sku: 'MNM-004', name: 'Good Day Cappuccino', category: 'Kopi & Susu', baseUnit: 'sachet', cost: 1600, sell: 2000, min: 20, stock: 100, units: [['renceng', 10, 19000]] },
  { sku: 'MNM-005', name: 'Susu Coklat 200 ml', category: 'Kopi & Susu', baseUnit: 'kotak', cost: 4500, sell: 6000, min: 12, stock: 48, units: [['dus', 24, 138000]], expiryInDays: 120 },
  { sku: 'MNM-006', name: 'Sprite 390 ml', category: 'Minuman', baseUnit: 'botol', cost: 4000, sell: 5500, min: 12, stock: 48 },
  { sku: 'MNM-007', name: 'Pocari Sweat 500 ml', category: 'Minuman', baseUnit: 'botol', cost: 6500, sell: 8500, min: 10, stock: 40 },
  { sku: 'KRT-001', name: 'Sabun Mandi Batang', category: 'Kebutuhan Rumah', baseUnit: 'pcs', cost: 3200, sell: 4000, min: 10, stock: 36 },
  { sku: 'KRT-002', name: 'Deterjen Sachet', category: 'Kebutuhan Rumah', baseUnit: 'pcs', cost: 1000, sell: 1500, min: 20, stock: 90 },
];

const CUSTOMERS = [
  { name: 'Pak Budi', phone: '0812 3456 7890', limit: 200_000, note: 'Tetangga RT 3' },
  { name: 'Bu Siti', phone: '0857 1122 3344', limit: 150_000, note: 'Langganan sembako' },
  { name: 'Mas Andi', phone: '0821 9988 7766', limit: 100_000, note: undefined },
  { name: 'Bu Rina', phone: '0813 5555 0101', limit: undefined, note: undefined },
];

function mulberry32(seed: number): () => number {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const DEMO_SKUS = PRODUCTS.map((p) => p.sku);

export async function seedDemo(store: Store, now: Date = new Date()): Promise<{ products: number; transactions: number; customers: number }> {
  const existing = store.getState().products;
  if (existing.some((p) => DEMO_SKUS.includes(p.sku))) {
    throw new DomainError('Data demo sudah ada. Hapus semua data dulu jika ingin mengisi ulang.');
  }
  const rng = mulberry32(20261019);
  const today = dateKeyOf(now);
  const weekAgo = new Date(now.getTime() - 7 * 86_400_000);

  // 1) products + opening stock (a week ago)
  for (const p of PRODUCTS) {
    const saved = await saveProduct(
      store,
      {
        name: p.name,
        sku: p.sku,
        barcode: p.barcode,
        category: p.category,
        baseUnit: p.baseUnit,
        costPrice: p.cost,
        sellPrice: p.sell,
        minStock: p.min,
        expiryDate: p.expiryInDays ? addDaysKey(today, p.expiryInDays) : undefined,
        units: (p.units ?? []).map(([unitName, conversion, sellPrice]) => ({ unitName, conversion, sellPrice })),
      },
      weekAgo,
    );
    await receiveStock(store, { productId: saved.id, unitQty: p.stock, unitCost: p.cost, note: 'Stok awal demo' }, weekAgo);
  }

  // 1b) a few regulars who buy on kasbon
  const customerIds: Record<string, string> = {};
  for (const c of CUSTOMERS) {
    const saved = await saveCustomer(store, { name: c.name, phone: c.phone, creditLimit: c.limit, note: c.note }, weekAgo);
    customerIds[c.name] = saved.id;
  }

  // 2) a week of sales, oldest first so receipt numbers follow time
  const state = store.getState();
  const products = state.products.filter((p) => DEMO_SKUS.includes(p.sku));
  const byName = [...products].sort((a, b) => DEMO_SKUS.indexOf(a.sku) - DEMO_SKUS.indexOf(b.sku));
  const settings = state.settings;

  interface Plan {
    at: Date;
    lines: CartLineInput[];
    /** kasbon sale: the whole bill, or what is left after a cash down payment */
    kasbon?: { who: string; downPayment?: number };
    /** a kasbon notebook entry that is not a sale (old debt, instalment) */
    debtOp?: () => Promise<unknown>;
  }
  const plans: Plan[] = [];
  for (let d = 6; d >= 0; d--) {
    const key = addDaysKey(today, -d);
    const n = d === 0 ? 5 : 5 + Math.floor(rng() * 5);
    for (let i = 0; i < n; i++) {
      let at: Date;
      if (d === 0) {
        const earliest = atWib(key, 0, 1).getTime();
        at = new Date(Math.max(earliest, now.getTime() - (15 + Math.floor(rng() * 570)) * 60_000));
      } else {
        at = atWib(key, 8 + Math.floor(rng() * 12), Math.floor(rng() * 60));
      }
      const roll = rng();
      const lineCount = roll < 0.4 ? 1 : roll < 0.7 ? 2 : roll < 0.9 ? 3 : 4;
      const picked = new Set<number>();
      const lines: CartLineInput[] = [];
      while (lines.length < lineCount && picked.size < byName.length) {
        const idx = Math.floor(Math.pow(rng(), 1.5) * byName.length);
        if (picked.has(idx)) continue;
        picked.add(idx);
        const p = byName[idx];
        const units = state.unitsByProduct.get(p.id) ?? [];
        if (units.length > 0 && rng() < 0.07) {
          lines.push({ productId: p.id, unitName: units[0].unitName, unitQty: 1 });
        } else if (isDecimalUnit(p.baseUnit)) {
          lines.push({ productId: p.id, unitName: p.baseUnit, unitQty: [0.5, 1, 1.5, 2][Math.floor(rng() * 4)] });
        } else {
          const max = p.sellPrice < 5000 ? 5 : 2;
          lines.push({ productId: p.id, unitName: p.baseUnit, unitQty: 1 + Math.floor(rng() * max) });
        }
      }
      plans.push({ at, lines });
    }
  }

  // Kasbon scenario. These plans do not touch the random generator, so the regular sample is unchanged.
  const sku = (code: string) => {
    const p = products.find((x) => x.sku === code);
    if (!p) throw new Error(`Produk demo ${code} tidak ada`);
    return p;
  };
  const sale = (code: string, unitQty: number, unitName?: string): CartLineInput => ({ productId: sku(code).id, unitName: unitName ?? sku(code).baseUnit, unitQty });
  const when = (daysAgo: number, hour: number, minute: number) => atWib(addDaysKey(today, -daysAgo), hour, minute);
  const todayAt = new Date(Math.max(atWib(today, 0, 1).getTime(), now.getTime() - 25 * 60_000));
  const budi = customerIds['Pak Budi'];
  const rina = customerIds['Bu Rina'];
  plans.push(
    { at: when(7, 9, 5), lines: [], debtOp: () => addManualDebt(store, { customerId: budi, amount: 85_000, note: 'Utang lama dari buku catatan' }, when(7, 9, 5)) },
    { at: when(5, 11, 20), lines: [sale('SMB-002', 5), sale('MKN-001', 10)], kasbon: { who: 'Pak Budi' } },
    { at: when(4, 15, 30), lines: [sale('MKN-002', 6), sale('MNM-004', 5)], kasbon: { who: 'Bu Rina' } },
    { at: when(3, 9, 40), lines: [sale('MNM-001', 1, 'dus'), sale('RTS-002', 2)], kasbon: { who: 'Pak Budi', downPayment: 20_000 } },
    { at: when(2, 14, 0), lines: [], debtOp: () => receiveDebtPayment(store, { customerId: budi, amount: 50_000, method: 'cash', note: 'Cicilan pertama' }, when(2, 14, 0)) },
    { at: when(2, 17, 10), lines: [], debtOp: async () => {
        const owed = store.getState().balanceByCustomer.get(rina) ?? 0;
        if (owed > 0) await receiveDebtPayment(store, { customerId: rina, amount: owed, method: 'qris', reference: 'QR-LUNAS-01' }, when(2, 17, 10));
      } },
    { at: when(1, 16, 5), lines: [sale('SMB-004', 2), sale('SMB-003', 2)], kasbon: { who: 'Bu Siti' } },
    { at: todayAt, lines: [sale('RTS-004', 2), sale('MNM-006', 2)], kasbon: { who: 'Mas Andi', downPayment: 10_000 } },
  );

  // Phase 2 scenario: one stock count, yesterday's drawer (closed with a small shortfall, one return inside it)
  // and today's drawer left open. Again no random numbers are drawn.
  const ignoreDomain = async (fn: () => Promise<unknown>) => {
    try {
      await fn();
    } catch (e) {
      if (!(e instanceof DomainError)) throw e;
    }
  };
  plans.push(
    {
      at: when(3, 19, 0),
      lines: [],
      debtOp: () =>
        ignoreDomain(async () => {
          const s = await startOpname(store, { scope: 'Minuman', note: 'Hitung rak minuman' }, when(3, 19, 0));
          const rows = s.lines.filter((l) => l.systemQty >= 3).slice(0, 3);
          for (const [i, l] of rows.entries()) {
            await saveOpnameCount(store, { sessionId: s.id, productId: l.productId, countedQty: i === 0 ? l.systemQty - 2 : l.systemQty }, when(3, 19, 10));
          }
          await finishOpname(store, s.id, when(3, 19, 30));
        }),
    },
    { at: when(1, 7, 30), lines: [], debtOp: () => ignoreDomain(() => openShift(store, { openingCash: 100_000, note: 'Shift pagi' }, when(1, 7, 30))) },
    {
      at: when(1, 20, 0),
      lines: [],
      debtOp: () =>
        ignoreDomain(async () => {
          const cashSale = store.getState().transactions.find((t) => t.dateKey === addDaysKey(today, -1) && t.status === 'completed' && t.payments.length === 1 && t.payments[0].method === 'cash');
          if (!cashSale) return;
          const item = cashSale.items[0];
          await returnItems(store, { txId: cashSale.id, lines: [{ itemIndex: 0, unitQty: Math.min(1, item.unitQty) }], refundMethod: 'cash', restock: true, reason: 'Salah beli' }, when(1, 20, 0));
        }),
    },
    {
      at: when(1, 21, 0),
      lines: [],
      debtOp: () =>
        ignoreDomain(async () => {
          const open = store.getState().openShift;
          if (!open) return;
          const expected = summarizeShift(open, shiftDataOf(store.getState())).cash.expected;
          await closeShift(store, { countedCash: Math.max(0, expected - 2_000), note: 'Kurang receh' }, when(1, 21, 0));
        }),
    },
    { at: atWib(today, 0, 0), lines: [], debtOp: () => ignoreDomain(() => openShift(store, { openingCash: 150_000, note: 'Shift hari ini' }, atWib(today, 0, 0))) },
  );
  plans.sort((a, b) => a.at.getTime() - b.at.getTime());

  let pendingGiven = false;
  let done = 0;
  for (const plan of plans) {
    if (plan.debtOp) {
      await plan.debtOp();
      continue;
    }
    const resolved = plan.lines
      .map((l) => resolveLine(state.productsById.get(l.productId), state.unitsByProduct.get(l.productId) ?? [], l))
      .filter((r): r is NonNullable<typeof r> => r !== null);
    const total = calcCart(resolved, undefined, settings).total;
    let payments: PaymentInput[];
    if (plan.kasbon) {
      const dp = plan.kasbon.downPayment ?? 0;
      const customerId = customerIds[plan.kasbon.who];
      payments = dp > 0 ? [{ method: 'cash', amount: dp, tendered: dp }, { method: 'kasbon', amount: total - dp, customerId }] : [{ method: 'kasbon', amount: total, customerId }];
    } else {
      payments = pickPayments(total, rng, plan.at, today, () => {
        if (pendingGiven) return false;
        pendingGiven = true;
        return true;
      });
    }
    try {
      await checkout(store, { lines: plan.lines, payments }, plan.at);
      done += 1;
    } catch (e) {
      if (!(e instanceof DomainError)) throw e; // out of stock in the simulation: skip it
    }
  }

  // 2b) one cart left on hold, to show the Tahan list
  const heldProducts = byName.filter((p) => p.stock > 3).slice(0, 2);
  if (heldProducts.length === 2) {
    await holdCart(store, { label: 'Bu Ani', lines: heldProducts.map((p) => ({ productId: p.id, unitName: p.baseUnit, unitQty: 1 })) }, new Date(now.getTime() - 10 * 60_000));
  }

  // 3) leave a few products low / out of stock so the alerts have something to show
  for (const p of PRODUCTS) {
    if (p.target === undefined) continue;
    const cur = store.getState().products.find((x) => x.sku === p.sku);
    if (!cur) continue;
    const diff = roundQty(p.target - cur.stock);
    if (diff !== 0) await adjustStock(store, { productId: cur.id, qtyChange: diff, reason: 'Penyesuaian awal demo' }, now);
  }
  return { products: PRODUCTS.length, transactions: done, customers: CUSTOMERS.length };
}

function pickPayments(
  total: number,
  rng: () => number,
  at: Date,
  today: string,
  claimPending: () => boolean,
): PaymentInput[] {
  if (total <= 0) return [];
  const ref = () => String(10_000_000 + Math.floor(rng() * 89_999_999));
  const cash = (amount: number): PaymentInput => {
    const steps = [1000, 5000, 10000, 50000];
    const step = steps[Math.floor(rng() * steps.length)];
    return { method: 'cash', amount, tendered: Math.max(amount, Math.ceil(amount / step) * step) };
  };
  const r = rng();
  if (r < 0.52) return [cash(total)];
  if (r < 0.77) return [{ method: 'qris', amount: total, reference: ref(), status: 'success' }];
  if (r < 0.85) return [{ method: 'ewallet', amount: total, reference: ref(), status: 'success' }];
  if (r < 0.91) {
    const pending = dateKeyOf(at) === today && claimPending();
    return [{ method: 'transfer', amount: total, reference: ref(), status: pending ? 'pending' : 'success' }];
  }
  if (r < 0.95) return [{ method: 'debit', amount: total, reference: ref(), status: 'success' }];
  if (total >= 4000) {
    const part = Math.max(1000, Math.round(total / 2 / 1000) * 1000);
    if (part < total) return [cash(part), { method: 'qris', amount: total - part, reference: ref(), status: 'success' }];
  }
  return [cash(total)];
}

