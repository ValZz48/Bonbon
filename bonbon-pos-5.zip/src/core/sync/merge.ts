// Pure merge rules for sync (no network, no storage), so they can be tested on their own.
//
// 1. Row by row, the most recent edit wins (compared by the time the editing phone saved it).
// 2. Stock and kasbon balances are NEVER taken from the other phone as a number. They are rebuilt from
//    the history lines (stock movements, kasbon notebook), which only ever grow. That is why two phones
//    selling the same product at once end up with the right stock.

import { roundQty } from '../calc';
import type { Changes, Snapshot, TableName } from '../persistence';
import { TABLES, emptySnapshot } from '../persistence';
import type { DebtEntry, Product, Settings, StockMovement } from '../types';
import { DEFAULT_SETTINGS, debtDelta } from '../types';
import { type OutboxEntry, outboxKey } from './outbox';

export interface RemoteRow {
  tbl: string;
  id: string;
  data: unknown;
  deleted: boolean;
  client_ts: string;
  device_id: string | null;
  seq: number;
}

/** Settings that belong to one phone (printer, notification, backup reminder), never shared. */
export const DEVICE_ONLY_SETTINGS = ['stockNotify', 'stockNotifyHour', 'paperWidth', 'lastBackupAt', 'demoOffered'] as const;

export function stripDeviceOnly(s: Settings): Partial<Settings> {
  const out: Record<string, unknown> = { ...s };
  for (const k of DEVICE_ONLY_SETTINGS) delete out[k];
  return out as Partial<Settings>;
}

const isTable = (t: string): t is TableName => (TABLES as string[]).includes(t);
const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v);

export interface RemotePlan {
  changes: Changes;
  /** tables that received something, to decide what to rebuild */
  touched: Set<TableName>;
  /** outbox keys whose pending local edit lost to the cloud version */
  dropped: string[];
  applied: number;
}

/**
 * Decides what to do with rows pulled from the cloud.
 * `local` looks up a row on this phone; `dirty` holds the edits not sent yet.
 */
export function planRemote(rows: RemoteRow[], local: (t: TableName, id: string) => unknown, dirty: Map<string, OutboxEntry>, ownDevice: string): RemotePlan {
  const plan: RemotePlan = { changes: { put: {}, del: {} }, touched: new Set(), dropped: [], applied: 0 };
  // rows arrive oldest first; if one id shows up twice in a page, the later one wins
  const latest = new Map<string, RemoteRow>();
  for (const r of rows) latest.set(outboxKey(r.tbl, r.id), r);

  for (const [key, r] of latest) {
    if (!isTable(r.tbl)) continue;
    if (r.device_id && r.device_id === ownDevice) continue; // our own write coming back
    const mine = dirty.get(key);
    if (mine && mine.ts >= r.client_ts) continue; // our unsent edit is newer: keep it, it will be sent
    const t = r.tbl;
    if (r.deleted) {
      (plan.changes.del[t] ??= []).push(r.id);
    } else {
      if (!isObj(r.data) || r.data.id !== r.id) continue; // malformed row: ignore it
      let row: unknown = r.data;
      if (t === 'settings') {
        const cur = (local('settings', r.id) ?? {}) as Partial<Settings>;
        const keep: Record<string, unknown> = {};
        for (const k of DEVICE_ONLY_SETTINGS) if (cur[k] !== undefined) keep[k] = cur[k];
        row = { ...DEFAULT_SETTINGS, ...(r.data as object), ...keep, id: 'main' };
      }
      ((plan.changes.put[t] ??= []) as unknown[]).push(row);
    }
    plan.touched.add(t);
    plan.applied += 1;
    if (mine) plan.dropped.push(key);
  }
  return plan;
}

const byTimeThenId = <T extends { createdAt: string; id: string }>(a: T, b: T) => (a.createdAt < b.createdAt ? -1 : a.createdAt > b.createdAt ? 1 : a.id < b.id ? -1 : a.id > b.id ? 1 : 0);

/**
 * Rebuilds what is derived from history lines: stock of each product, the running balance printed on each
 * stock line, and the numbering and running balance of each customer's kasbon notebook.
 * Returns only the rows that actually change, so a second run returns nothing (it converges).
 */
export function reconcile(snap: Snapshot): Changes {
  const out: Changes = { put: {}, del: {} };

  const byProduct = new Map<string, StockMovement[]>();
  for (const m of snap.stockMovements) {
    const a = byProduct.get(m.productId);
    if (a) a.push(m);
    else byProduct.set(m.productId, [m]);
  }
  const movePuts: StockMovement[] = [];
  const productPuts: Product[] = [];
  const products = new Map(snap.products.map((p) => [p.id, p]));
  for (const [pid, list] of byProduct) {
    list.sort(byTimeThenId);
    let run = 0;
    for (const m of list) {
      run = roundQty(run + m.qtyChange);
      if (m.balanceAfter !== run) movePuts.push({ ...m, balanceAfter: run });
    }
    const p = products.get(pid);
    // products without any history line keep the stock they have: there is nothing to rebuild it from
    if (p && p.stock !== run) productPuts.push({ ...p, stock: run });
  }
  if (movePuts.length) out.put.stockMovements = movePuts;
  if (productPuts.length) out.put.products = productPuts;

  const byCustomer = new Map<string, DebtEntry[]>();
  for (const e of snap.debtEntries) {
    const a = byCustomer.get(e.customerId);
    if (a) a.push(e);
    else byCustomer.set(e.customerId, [e]);
  }
  const debtPuts: DebtEntry[] = [];
  for (const list of byCustomer.values()) {
    list.sort((a, b) => (a.createdAt < b.createdAt ? -1 : a.createdAt > b.createdAt ? 1 : a.seq - b.seq || (a.id < b.id ? -1 : 1)));
    let bal = 0;
    list.forEach((e, i) => {
      bal += debtDelta(e);
      if (e.seq !== i + 1 || e.balanceAfter !== bal) debtPuts.push({ ...e, seq: i + 1, balanceAfter: bal });
    });
  }
  if (debtPuts.length) out.put.debtEntries = debtPuts;
  return out;
}

export const isEmptyChanges = (c: Changes): boolean => TABLES.every((t) => !(c.put[t]?.length ?? 0) && !(c.del[t]?.length ?? 0));

/**
 * Makes stock equal the sum of its history lines on a phone that already had data before sync was switched on.
 * Without this, rebuilding stock from history would change numbers the owner typed in directly.
 */
export function openingBalances(snap: Snapshot, at: string, newId: () => string, userId: string): StockMovement[] {
  const sums = new Map<string, number>();
  for (const m of snap.stockMovements) sums.set(m.productId, roundQty((sums.get(m.productId) ?? 0) + m.qtyChange));
  const out: StockMovement[] = [];
  for (const p of snap.products) {
    const have = sums.get(p.id) ?? 0;
    const diff = roundQty(p.stock - have);
    if (diff !== 0) {
      out.push({ id: newId(), productId: p.id, type: 'adjustment', qtyChange: diff, balanceAfter: p.stock, reason: 'Saldo awal sinkron', userId, createdAt: at });
    }
  }
  return out;
}

export { emptySnapshot };
