// The sync outbox: a list of rows that changed on this phone and still have to be sent to the cloud.
// It lives in its OWN small database, so the main data database (and its upgrade path) stays untouched.
//
// An entry only says "this row is dirty". What gets sent is the row's CURRENT value at push time, so
// writing the entry BEFORE the data commit is safe: the worst case is one harmless extra push.

import type { TableName } from '../persistence';

export interface OutboxEntry {
  tbl: TableName;
  id: string;
  /** when this phone last changed the row (ISO); decides who wins if another phone edited it too */
  ts: string;
}

export const outboxKey = (tbl: string, id: string): string => `${tbl}:${id}`;

export interface SyncMeta {
  /** which signed-in account this phone's data was last synced with */
  boundUser?: string;
  /** highest cloud sequence number already applied here */
  cursor?: number;
  deviceId?: string;
  /** two characters used in receipt numbers */
  tag?: string;
  lastSyncAt?: string;
}

export interface Outbox {
  put(entries: OutboxEntry[]): Promise<void>;
  /** Removes entries, but only those whose `ts` still matches (a newer edit keeps its entry). */
  ack(entries: OutboxEntry[]): Promise<void>;
  /** Removes entries unconditionally (the cloud version won). */
  drop(keys: string[]): Promise<void>;
  all(): Promise<OutboxEntry[]>;
  clear(): Promise<void>;
  getMeta(): Promise<SyncMeta>;
  setMeta(patch: Partial<SyncMeta>): Promise<void>;
}

export class MemoryOutbox implements Outbox {
  private map = new Map<string, OutboxEntry>();
  private meta: SyncMeta = {};
  async put(entries: OutboxEntry[]): Promise<void> {
    for (const e of entries) this.map.set(outboxKey(e.tbl, e.id), { ...e });
  }
  async ack(entries: OutboxEntry[]): Promise<void> {
    for (const e of entries) {
      const k = outboxKey(e.tbl, e.id);
      if (this.map.get(k)?.ts === e.ts) this.map.delete(k);
    }
  }
  async drop(keys: string[]): Promise<void> {
    for (const k of keys) this.map.delete(k);
  }
  async all(): Promise<OutboxEntry[]> {
    return [...this.map.values()].sort((a, b) => (a.ts < b.ts ? -1 : a.ts > b.ts ? 1 : 0));
  }
  async clear(): Promise<void> {
    this.map.clear();
  }
  async getMeta(): Promise<SyncMeta> {
    return { ...this.meta };
  }
  async setMeta(patch: Partial<SyncMeta>): Promise<void> {
    this.meta = { ...this.meta, ...patch };
  }
}

function done<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error('Antrean sinkron gagal'));
    tx.onabort = () => reject(tx.error ?? new Error('Antrean sinkron dibatalkan'));
  });
}

export class IndexedDbOutbox implements Outbox {
  private constructor(private db: IDBDatabase) {}

  static async open(name = 'bonbon-sync'): Promise<IndexedDbOutbox> {
    if (typeof indexedDB === 'undefined') throw new Error('IndexedDB tidak tersedia');
    const req = indexedDB.open(name, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('outbox')) db.createObjectStore('outbox', { keyPath: 'k' });
      if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta');
    };
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
      req.onblocked = () => reject(new Error('Antrean sinkron terblokir'));
    });
    db.onversionchange = () => db.close();
    return new IndexedDbOutbox(db);
  }

  async put(entries: OutboxEntry[]): Promise<void> {
    if (!entries.length) return;
    const tx = this.db.transaction('outbox', 'readwrite');
    const st = tx.objectStore('outbox');
    for (const e of entries) st.put({ k: outboxKey(e.tbl, e.id), ...e });
    await txDone(tx);
  }

  async ack(entries: OutboxEntry[]): Promise<void> {
    if (!entries.length) return;
    const tx = this.db.transaction('outbox', 'readwrite');
    const st = tx.objectStore('outbox');
    const finished = txDone(tx);
    for (const e of entries) {
      const k = outboxKey(e.tbl, e.id);
      const cur = (await done(st.get(k))) as { ts: string } | undefined;
      if (cur && cur.ts === e.ts) st.delete(k);
    }
    await finished;
  }

  async drop(keys: string[]): Promise<void> {
    if (!keys.length) return;
    const tx = this.db.transaction('outbox', 'readwrite');
    const st = tx.objectStore('outbox');
    for (const k of keys) st.delete(k);
    await txDone(tx);
  }

  async all(): Promise<OutboxEntry[]> {
    const tx = this.db.transaction('outbox', 'readonly');
    const rows = (await done(tx.objectStore('outbox').getAll())) as ({ k: string } & OutboxEntry)[];
    return rows.map(({ tbl, id, ts }) => ({ tbl, id, ts })).sort((a, b) => (a.ts < b.ts ? -1 : a.ts > b.ts ? 1 : 0));
  }

  async clear(): Promise<void> {
    const tx = this.db.transaction('outbox', 'readwrite');
    tx.objectStore('outbox').clear();
    await txDone(tx);
  }

  async getMeta(): Promise<SyncMeta> {
    const tx = this.db.transaction('meta', 'readonly');
    const v = await done(tx.objectStore('meta').get('main'));
    return (v as SyncMeta | undefined) ?? {};
  }

  async setMeta(patch: Partial<SyncMeta>): Promise<void> {
    const cur = await this.getMeta();
    const tx = this.db.transaction('meta', 'readwrite');
    tx.objectStore('meta').put({ ...cur, ...patch }, 'main');
    await txDone(tx);
  }
}

export async function openOutbox(): Promise<Outbox> {
  try {
    return await IndexedDbOutbox.open();
  } catch {
    return new MemoryOutbox();
  }
}
