// Wraps the real storage and remembers every change in the sync outbox.
// The store does not know sync exists: it still calls commit / replaceAll / clear as before.

import type { Changes, Persistence, Snapshot, TableName } from '../persistence';
import { TABLES } from '../persistence';
import type { Outbox, OutboxEntry } from './outbox';

export class SyncedPersistence implements Persistence {
  /** called after a change was queued, so the engine can send it soon */
  onQueued: (() => void) | null = null;
  /** Changes are only queued once this phone is connected to an account (before that, nothing is ever sent). */
  enabled = false;

  constructor(
    private readonly inner: Persistence,
    private readonly outbox: Outbox,
  ) {}

  get volatile(): boolean {
    return this.inner.volatile;
  }

  load(): Promise<Snapshot> {
    return this.inner.load();
  }

  private async queue(entries: OutboxEntry[]): Promise<void> {
    if (!this.enabled || !entries.length) return;
    try {
      await this.outbox.put(entries);
    } catch {
      /* the data is still saved; the next full reconcile will pick the row up */
    }
  }

  async commit(changes: Changes): Promise<void> {
    const ts = new Date().toISOString();
    const entries: OutboxEntry[] = [];
    for (const t of TABLES) {
      for (const row of (changes.put[t] ?? []) as { id: string }[]) entries.push({ tbl: t, id: row.id, ts });
      for (const id of changes.del[t] ?? []) entries.push({ tbl: t, id, ts });
    }
    await this.queue(entries); // queued first: an extra entry is harmless, a missing one would lose a change
    await this.inner.commit(changes);
    if (this.enabled && entries.length) this.onQueued?.();
  }

  async commitSilent(changes: Changes): Promise<void> {
    await this.inner.commit(changes);
  }

  async clear(): Promise<void> {
    const before = await this.inner.load();
    const ts = new Date().toISOString();
    const entries: OutboxEntry[] = [];
    for (const t of TABLES) for (const row of before[t] as { id: string }[]) entries.push({ tbl: t, id: row.id, ts });
    await this.queue(entries);
    await this.inner.clear();
    if (this.enabled && entries.length) this.onQueued?.();
  }

  async replaceAll(snap: Snapshot): Promise<void> {
    const before = await this.inner.load();
    const ts = new Date().toISOString();
    const entries: OutboxEntry[] = [];
    for (const t of TABLES as TableName[]) {
      const keep = new Set((snap[t] as { id: string }[]).map((r) => r.id));
      for (const r of snap[t] as { id: string }[]) entries.push({ tbl: t, id: r.id, ts });
      for (const r of before[t] as { id: string }[]) if (!keep.has(r.id)) entries.push({ tbl: t, id: r.id, ts });
    }
    await this.queue(entries);
    await this.inner.replaceAll(snap);
    if (this.enabled && entries.length) this.onQueued?.();
  }
}
