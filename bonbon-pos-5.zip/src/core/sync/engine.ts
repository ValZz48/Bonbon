// The sync engine: keeps this phone and the cloud in step, without ever blocking the shop.
// The phone stays the main copy. Every sale is saved locally first (works offline); this engine sends the
// changes when there is internet and brings in what the other phones did.

import { DEMO_SKUS } from '../demo';
import { newId } from '../format';
import type { Changes, Snapshot, TableName } from '../persistence';
import { TABLES } from '../persistence';
import type { Store } from '../store';
import type { Settings } from '../types';
import { LOCAL_USER } from '../services';
import { type RemoteRowOut, type Session, SyncApi, SyncError } from './api';
import { isEmptyChanges, openingBalances, planRemote, reconcile, stripDeviceOnly } from './merge';
import { type Outbox, type OutboxEntry, outboxKey } from './outbox';
import type { SyncedPersistence } from './persistence';

export type SyncPhase = 'signedout' | 'idle' | 'syncing' | 'offline' | 'error' | 'choice';

export interface SyncStatus {
  phase: SyncPhase;
  email?: string;
  /** changes saved on this phone and not yet sent */
  pending: number;
  lastSyncAt?: string;
  error?: string;
  /** set while the first connection waits for the owner to choose what to do with two sets of data */
  choice?: { local: number; remote: number };
}

export type FirstSyncChoice = 'merge' | 'cloud' | 'local';

const PAGE = 1000;
const BATCH = 200;

function countRows(snap: Snapshot): number {
  return TABLES.reduce((n, t) => n + (t === 'settings' ? 0 : snap[t].length), 0);
}

/** Nothing the owner made yet: no sales, no customers, and only the sample products (or none). */
export function isPristine(snap: Snapshot): boolean {
  if (snap.transactions.length || snap.customers.length) return false;
  return snap.products.every((p) => DEMO_SKUS.includes(p.sku));
}

export class SyncEngine {
  private status: SyncStatus = { phase: 'signedout', pending: 0 };
  private listeners = new Set<() => void>();
  private running = false;
  private again = false;
  private timer: ReturnType<typeof setInterval> | null = null;
  private debounce: ReturnType<typeof setTimeout> | null = null;
  private started = false;
  private deviceId = '';
  private pendingChoice = false;

  constructor(
    private readonly store: Store,
    private readonly outbox: Outbox,
    private readonly persistence: SyncedPersistence,
    readonly api: SyncApi,
  ) {}

  // ---- status ------------------------------------------------------------------------------------

  subscribe = (fn: () => void): (() => void) => {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  };
  getStatus = (): SyncStatus => this.status;
  private set(patch: Partial<SyncStatus>): void {
    this.status = { ...this.status, ...patch };
    for (const fn of this.listeners) fn();
  }

  private async refreshPending(): Promise<void> {
    try {
      this.set({ pending: (await this.outbox.all()).length });
    } catch {
      /* the count is informational */
    }
  }

  // ---- lifecycle ---------------------------------------------------------------------------------

  /** Call once at startup, after the store is ready. */
  async init(): Promise<void> {
    const meta = await this.outbox.getMeta();
    this.deviceId = meta.deviceId ?? newId();
    if (!meta.deviceId) await this.outbox.setMeta({ deviceId: this.deviceId });
    if (meta.tag) this.store.setReceiptTag(meta.tag);
    this.persistence.enabled = !!meta.boundUser;
    this.persistence.onQueued = () => {
      void this.refreshPending();
      this.schedule(2500);
    };
    const s = this.api.session();
    if (s) {
      this.set({ phase: 'idle', email: s.user.email, lastSyncAt: meta.lastSyncAt });
      await this.refreshPending();
      this.begin();
      if (meta.boundUser === s.user.id) this.schedule(300);
      else void this.connect();
    } else {
      this.set({ phase: 'signedout', email: undefined, lastSyncAt: meta.lastSyncAt });
      await this.refreshPending();
    }
  }

  /** Call right after a successful sign-in (password, code or Google). */
  async afterSignIn(session: Session): Promise<void> {
    this.set({ phase: 'idle', email: session.user.email, error: undefined });
    this.begin();
    await this.connect();
  }

  async signOut(): Promise<void> {
    this.end();
    await this.api.signOut();
    this.set({ phase: 'signedout', email: undefined, error: undefined, choice: undefined });
  }

  private begin(): void {
    if (this.started) return;
    this.started = true;
    this.timer = setInterval(() => void this.sync(), 30_000);
    (this.timer as { unref?: () => void }).unref?.(); // never keeps a test process (or Node) alive
    if (typeof window !== 'undefined') {
      window.addEventListener('online', this.onWake);
      document.addEventListener('visibilitychange', this.onWake);
    }
  }

  private end(): void {
    this.started = false;
    if (this.timer) clearInterval(this.timer);
    if (this.debounce) clearTimeout(this.debounce);
    this.timer = null;
    this.debounce = null;
    if (typeof window !== 'undefined') {
      window.removeEventListener('online', this.onWake);
      document.removeEventListener('visibilitychange', this.onWake);
    }
  }

  private onWake = (): void => {
    if (typeof document !== 'undefined' && document.visibilityState === 'hidden') return;
    this.schedule(500);
  };

  private schedule(ms: number): void {
    if (!this.started || this.pendingChoice) return;
    if (this.debounce) clearTimeout(this.debounce);
    this.debounce = setTimeout(() => void this.sync(), ms);
    (this.debounce as { unref?: () => void }).unref?.();
  }

  // ---- first connection --------------------------------------------------------------------------

  private async connect(): Promise<void> {
    const session = this.api.session();
    if (!session) return;
    try {
      this.set({ phase: 'syncing', error: undefined });
      const meta = await this.outbox.getMeta();
      if (meta.boundUser === session.user.id) return void (await this.sync());

      const remote = await this.api.count();
      const local = this.store.snapshot();
      if (remote === 0) {
        await this.prepareUpload(session.user.id);
      } else if (isPristine(local)) {
        await this.adoptCloud(session.user.id);
      } else {
        this.pendingChoice = true;
        this.set({ phase: 'choice', choice: { local: countRows(local), remote } });
        return;
      }
      await this.sync();
    } catch (e) {
      this.fail(e);
    }
  }

  /** The owner's answer when this phone and the cloud both already hold data. */
  async resolveFirstSync(choice: FirstSyncChoice): Promise<void> {
    const session = this.api.session();
    if (!session) return;
    try {
      this.set({ phase: 'syncing', choice: undefined, error: undefined });
      if (choice === 'cloud') await this.adoptCloud(session.user.id);
      else {
        await this.prepareUpload(session.user.id);
        if (choice === 'local') await this.tombstoneCloudOnlyRows();
      }
      this.pendingChoice = false;
      await this.sync();
    } catch (e) {
      this.pendingChoice = false;
      this.fail(e);
    }
  }

  private async bind(userId: string): Promise<void> {
    const meta = await this.outbox.getMeta();
    const tag = meta.tag ?? Array.from({ length: 2 }, () => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 32)]).join('');
    await this.outbox.setMeta({ boundUser: userId, tag, cursor: 0 });
    this.store.setReceiptTag(tag);
    this.persistence.enabled = true;
  }

  /** Makes this phone's data the one that goes up: stock becomes rebuildable, then every row is queued. */
  private async prepareUpload(userId: string): Promise<void> {
    await this.outbox.clear();
    await this.bind(userId);
    const snap = this.store.snapshot();
    const opening = openingBalances(snap, new Date().toISOString(), newId, LOCAL_USER);
    if (opening.length) {
      await this.store.mutate((tx) => {
        for (const m of opening) tx.put('stockMovements', m);
      });
    }
    const ts = new Date().toISOString();
    const all: OutboxEntry[] = [];
    const now = this.store.snapshot();
    for (const t of TABLES) for (const r of now[t] as { id: string }[]) all.push({ tbl: t, id: r.id, ts });
    await this.outbox.put(all);
    await this.refreshPending();
  }

  /** Throws away what is on this phone and takes the cloud copy (rows arrive in the next pull). */
  private async adoptCloud(userId: string): Promise<void> {
    await this.outbox.clear();
    await this.bind(userId);
    const snap = this.store.snapshot();
    const del: Changes['del'] = {};
    for (const t of TABLES) {
      if (t === 'settings') continue;
      const ids = (snap[t] as { id: string }[]).map((r) => r.id);
      if (ids.length) del[t] = ids;
    }
    await this.store.applyExternal({ put: {}, del });
    await this.refreshPending();
  }

  /** "Use this phone": cloud rows this phone does not have are marked deleted so other phones drop them too. */
  private async tombstoneCloudOnlyRows(): Promise<void> {
    const have = new Set<string>();
    const snap = this.store.snapshot();
    for (const t of TABLES) for (const r of snap[t] as { id: string }[]) have.add(outboxKey(t, r.id));
    const ts = new Date().toISOString();
    const out: OutboxEntry[] = [];
    let after = 0;
    for (;;) {
      const rows = await this.api.pull(after, PAGE);
      for (const r of rows) {
        after = Math.max(after, r.seq);
        if (!r.deleted && (TABLES as string[]).includes(r.tbl) && !have.has(outboxKey(r.tbl, r.id))) out.push({ tbl: r.tbl as TableName, id: r.id, ts });
      }
      if (rows.length < PAGE) break;
    }
    await this.outbox.put(out);
  }

  // ---- the sync itself ---------------------------------------------------------------------------

  private fail(e: unknown): void {
    if (e instanceof SyncError) {
      if (e.kind === 'network') return void this.set({ phase: 'offline', error: undefined });
      if (e.kind === 'auth') {
        this.end();
        return void this.set({ phase: 'signedout', email: undefined, error: e.message });
      }
      return void this.set({ phase: 'error', error: e.message });
    }
    this.set({ phase: 'error', error: e instanceof Error ? e.message : 'Sinkron gagal.' });
  }

  /** One round: bring in what changed in the cloud, then send what changed here. Safe to call any time. */
  async sync(): Promise<void> {
    if (this.pendingChoice) return;
    if (this.running) {
      this.again = true;
      return;
    }
    const session = this.api.session();
    if (!session) return;
    this.running = true;
    try {
      do {
        this.again = false;
        this.set({ phase: 'syncing', error: undefined });
        await this.pullAll();
        await this.pushAll();
      } while (this.again);
      const at = new Date().toISOString();
      await this.outbox.setMeta({ lastSyncAt: at });
      await this.refreshPending();
      this.set({ phase: 'idle', lastSyncAt: at, error: undefined });
    } catch (e) {
      this.fail(e);
    } finally {
      this.running = false;
    }
  }

  private async pullAll(): Promise<void> {
    const touched = new Set<TableName>();
    let { cursor = 0 } = await this.outbox.getMeta();
    for (;;) {
      const rows = await this.api.pull(cursor, PAGE);
      if (!rows.length) break;
      const dirty = new Map<string, OutboxEntry>();
      for (const e of await this.outbox.all()) dirty.set(outboxKey(e.tbl, e.id), e);
      const plan = planRemote(rows, (t, id) => this.store.row(t, id), dirty, this.deviceId);
      await this.store.applyExternal(plan.changes);
      await this.outbox.drop(plan.dropped);
      for (const t of plan.touched) touched.add(t);
      cursor = rows.reduce((m, r) => Math.max(m, r.seq), cursor);
      await this.outbox.setMeta({ cursor });
      if (rows.length < PAGE) break;
    }
    if (touched.has('stockMovements') || touched.has('products') || touched.has('debtEntries')) {
      const fix = reconcile(this.store.snapshot());
      if (!isEmptyChanges(fix)) {
        await this.store.mutate((tx) => {
          for (const t of TABLES) for (const row of (fix.put[t] ?? []) as never[]) tx.put(t, row);
        });
      }
    }
  }

  private async pushAll(): Promise<void> {
    for (;;) {
      const entries = (await this.outbox.all()).slice(0, BATCH);
      if (!entries.length) return;
      const rows: RemoteRowOut[] = entries.map((e) => {
        const row = this.store.row(e.tbl, e.id);
        const data = row === undefined ? null : e.tbl === 'settings' ? stripDeviceOnly(row as Settings) : row;
        return { tbl: e.tbl, id: e.id, data, deleted: row === undefined, client_ts: e.ts, device_id: this.deviceId };
      });
      await this.api.push(rows);
      await this.outbox.ack(entries);
      this.set({ pending: Math.max(0, this.status.pending - entries.length) });
    }
  }
}
