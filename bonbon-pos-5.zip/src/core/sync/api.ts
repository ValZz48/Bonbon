// A small Supabase client written with plain fetch (no library): sign in, keep the session fresh, pull and push rows.
// Only the PUBLISHABLE key lives here. It is safe to ship: what each account can read or write is decided by
// row level security in the database (a signed-in account only ever sees its own rows).

export const SUPABASE_URL = 'https://mxdoanrtehmwwswkamod.supabase.co';
export const SUPABASE_KEY = 'sb_publishable_Cni4grUpiasDKjbXJ2_IBQ_85gZOjlZ';

export interface Session {
  access_token: string;
  refresh_token: string;
  /** unix seconds */
  expires_at: number;
  user: { id: string; email: string };
}

export type SyncErrorKind = 'auth' | 'network' | 'server' | 'confirm';
export class SyncError extends Error {
  constructor(
    message: string,
    readonly kind: SyncErrorKind,
  ) {
    super(message);
    this.name = 'SyncError';
  }
}

export interface RemoteRowOut {
  tbl: string;
  id: string;
  data: unknown;
  deleted: boolean;
  client_ts: string;
  device_id: string | null;
}
export interface RemoteRowIn extends RemoteRowOut {
  seq: number;
}

export interface SessionStorageLike {
  get(): string | null;
  set(v: string | null): void;
}

export function browserSessionStorage(key = 'bonbon-session'): SessionStorageLike {
  let mem: string | null = null;
  return {
    get() {
      try {
        return localStorage.getItem(key) ?? mem;
      } catch {
        return mem;
      }
    },
    set(v) {
      mem = v;
      try {
        if (v === null) localStorage.removeItem(key);
        else localStorage.setItem(key, v);
      } catch {
        /* session then lives only until the app closes */
      }
    },
  };
}

const MESSAGES: Record<string, string> = {
  invalid_credentials: 'Email atau kata sandi salah.',
  email_not_confirmed: 'Email belum dikonfirmasi. Buka email kiriman Supabase dan ketuk tautannya, lalu masuk lagi.',
  user_already_exists: 'Email ini sudah terdaftar. Silakan masuk.',
  weak_password: 'Kata sandi terlalu lemah. Pakai minimal 6 karakter.',
  over_email_send_rate_limit: 'Terlalu sering meminta kode. Tunggu sebentar lalu coba lagi.',
  over_request_rate_limit: 'Terlalu banyak percobaan. Tunggu sebentar lalu coba lagi.',
  otp_expired: 'Kode salah atau sudah kedaluwarsa. Minta kode baru.',
  validation_failed: 'Format email tidak valid.',
  signup_disabled: 'Pendaftaran sedang dimatikan di server.',
  email_address_invalid: 'Alamat email tidak valid.',
};

interface Body {
  error_code?: string;
  code?: string | number;
  msg?: string;
  message?: string;
  error_description?: string;
  error?: string;
}

function messageOf(status: number, b: Body | null): string {
  const code = b?.error_code ?? (typeof b?.code === 'string' ? b.code : undefined);
  if (code && MESSAGES[code]) return MESSAGES[code];
  return b?.msg ?? b?.message ?? b?.error_description ?? b?.error ?? `Server membalas ${status}.`;
}

const nowSec = () => Math.floor(Date.now() / 1000);

export class SyncApi {
  constructor(
    private readonly storage: SessionStorageLike = browserSessionStorage(),
    private readonly doFetch: typeof fetch = (...a) => fetch(...a),
    private readonly base = SUPABASE_URL,
    private readonly key = SUPABASE_KEY,
  ) {}

  // ---- session --------------------------------------------------------------------------------

  session(): Session | null {
    const raw = this.storage.get();
    if (!raw) return null;
    try {
      const s = JSON.parse(raw) as Session;
      return s && typeof s.access_token === 'string' && typeof s.refresh_token === 'string' && s.user?.id ? s : null;
    } catch {
      return null;
    }
  }

  private save(s: Session | null): void {
    this.storage.set(s ? JSON.stringify(s) : null);
  }

  private toSession(b: Record<string, unknown>): Session {
    const user = (b.user ?? {}) as { id?: string; email?: string };
    const token = b.access_token;
    const refresh = b.refresh_token;
    if (typeof token !== 'string' || typeof refresh !== 'string' || !user.id) throw new SyncError('Balasan login tidak lengkap.', 'server');
    const expiresIn = typeof b.expires_in === 'number' ? b.expires_in : 3600;
    const at = typeof b.expires_at === 'number' ? b.expires_at : nowSec() + expiresIn;
    return { access_token: token, refresh_token: refresh, expires_at: at, user: { id: user.id, email: user.email ?? '' } };
  }

  private async raw(path: string, init: RequestInit & { token?: string } = {}): Promise<Response> {
    const headers = new Headers(init.headers);
    headers.set('apikey', this.key);
    headers.set('Authorization', `Bearer ${init.token ?? this.key}`);
    if (init.body && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
    try {
      return await this.doFetch(this.base + path, { ...init, headers });
    } catch {
      throw new SyncError('Tidak ada koneksi internet.', 'network');
    }
  }

  private async json(res: Response): Promise<Body & Record<string, unknown>> {
    try {
      return (await res.json()) as Body & Record<string, unknown>;
    } catch {
      return {};
    }
  }

  // ---- sign in ---------------------------------------------------------------------------------

  async signUp(email: string, password: string): Promise<Session> {
    const res = await this.raw('/auth/v1/signup', { method: 'POST', body: JSON.stringify({ email: email.trim(), password }) });
    const b = await this.json(res);
    if (!res.ok) throw new SyncError(messageOf(res.status, b), 'auth');
    if (typeof b.access_token !== 'string') {
      throw new SyncError('Akun dibuat. Buka email kiriman Supabase, ketuk tautan konfirmasinya, lalu masuk.', 'confirm');
    }
    const s = this.toSession(b);
    this.save(s);
    return s;
  }

  async signIn(email: string, password: string): Promise<Session> {
    const res = await this.raw('/auth/v1/token?grant_type=password', { method: 'POST', body: JSON.stringify({ email: email.trim(), password }) });
    const b = await this.json(res);
    if (!res.ok) throw new SyncError(messageOf(res.status, b), 'auth');
    const s = this.toSession(b);
    this.save(s);
    return s;
  }

  /** Emails a one-time code (and a link). The code is typed into the app, so no web link has to open the app. */
  async sendCode(email: string): Promise<void> {
    const res = await this.raw('/auth/v1/otp', { method: 'POST', body: JSON.stringify({ email: email.trim(), create_user: true }) });
    if (!res.ok) throw new SyncError(messageOf(res.status, await this.json(res)), 'auth');
  }

  async verifyCode(email: string, token: string): Promise<Session> {
    const res = await this.raw('/auth/v1/verify', { method: 'POST', body: JSON.stringify({ type: 'email', email: email.trim(), token: token.trim() }) });
    const b = await this.json(res);
    if (!res.ok) throw new SyncError(messageOf(res.status, b), 'auth');
    const s = this.toSession(b);
    this.save(s);
    return s;
  }

  googleUrl(redirectTo: string): string {
    return `${this.base}/auth/v1/authorize?provider=google&redirect_to=${encodeURIComponent(redirectTo)}`;
  }

  /** After a Google sign-in the browser comes back with the tokens in the address (#access_token=...). */
  async adoptHash(hash: string): Promise<Session | null> {
    const p = new URLSearchParams(hash.replace(/^#/, ''));
    const access = p.get('access_token');
    const refresh = p.get('refresh_token');
    if (!access || !refresh) return null;
    const res = await this.raw('/auth/v1/user', { token: access });
    const user = await this.json(res);
    if (!res.ok || typeof user.id !== 'string') throw new SyncError('Login Google gagal diverifikasi.', 'auth');
    const expiresIn = Number(p.get('expires_in') ?? '3600');
    const s: Session = { access_token: access, refresh_token: refresh, expires_at: nowSec() + (Number.isFinite(expiresIn) ? expiresIn : 3600), user: { id: user.id, email: typeof user.email === 'string' ? user.email : '' } };
    this.save(s);
    return s;
  }

  async signOut(): Promise<void> {
    const s = this.session();
    this.save(null);
    if (s) {
      try {
        await this.raw('/auth/v1/logout', { method: 'POST', token: s.access_token });
      } catch {
        /* signed out here anyway */
      }
    }
  }

  /** A valid access token, refreshed when it is about to expire. Null when nobody is signed in. */
  async token(): Promise<string | null> {
    const s = this.session();
    if (!s) return null;
    if (s.expires_at - nowSec() > 60) return s.access_token;
    const res = await this.raw('/auth/v1/token?grant_type=refresh_token', { method: 'POST', body: JSON.stringify({ refresh_token: s.refresh_token }) });
    const b = await this.json(res);
    if (!res.ok) {
      if (res.status >= 500) throw new SyncError('Server sedang bermasalah.', 'server');
      this.save(null); // refresh token rejected: the login is over
      throw new SyncError('Sesi login berakhir. Masuk lagi.', 'auth');
    }
    const next = this.toSession(b);
    this.save(next);
    return next.access_token;
  }

  // ---- rows ------------------------------------------------------------------------------------

  private async authed(path: string, init: RequestInit = {}): Promise<Response> {
    const token = await this.token();
    if (!token) throw new SyncError('Belum masuk.', 'auth');
    const res = await this.raw(path, { ...init, token });
    if (res.status === 401) throw new SyncError('Sesi login tidak valid. Masuk lagi.', 'auth');
    return res;
  }

  /** Rows with a sequence number above `after`, oldest first. */
  async pull(after: number, limit = 1000): Promise<RemoteRowIn[]> {
    const q = `/rest/v1/sync_rows?select=tbl,id,data,deleted,client_ts,device_id,seq&seq=gt.${after}&order=seq.asc&limit=${limit}`;
    const res = await this.authed(q);
    if (!res.ok) throw new SyncError(messageOf(res.status, await this.json(res)), 'server');
    return (await res.json()) as RemoteRowIn[];
  }

  /** How many rows the account has in the cloud. */
  async count(): Promise<number> {
    const res = await this.authed('/rest/v1/sync_rows?select=id&limit=1', { headers: { Prefer: 'count=exact' } });
    if (!res.ok) throw new SyncError(messageOf(res.status, await this.json(res)), 'server');
    const range = res.headers.get('content-range') ?? '';
    const n = Number(range.split('/')[1]);
    return Number.isFinite(n) ? n : 0;
  }

  async push(rows: RemoteRowOut[]): Promise<void> {
    if (!rows.length) return;
    const uid = this.session()?.user.id;
    const body = rows.map((r) => ({ ...r, user_id: uid }));
    const res = await this.authed('/rest/v1/sync_rows?on_conflict=user_id,tbl,id', {
      method: 'POST',
      headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
      body: JSON.stringify(body),
    });
    if (!res.ok) throw new SyncError(messageOf(res.status, await this.json(res)), 'server');
  }
}
