// Storage backends. The Store keeps everything in memory and writes each business
// operation to the backend as ONE atomic commit (a single IndexedDB transaction).

import type { CashMove, Customer, DebtEntry, HeldCart, OpnameSession, Product, ProductUnit, ReturnRecord, Settings, Shift, StockMovement, Transaction } from './types';

export interface Rows {
  products: Product;
  productUnits: ProductUnit;
  stockMovements: StockMovement;
  transactions: Transaction;
  customers: Customer;
  debtEntries: DebtEntry;
  shifts: Shift;
  cashMoves: CashMove;
  returns: ReturnRecord;
  opnames: OpnameSession;
  holds: HeldCart;
  settings: Settings;
}
export type TableName = keyof Rows;
export type TableRow<K extends TableName> = Rows[K];

export const TABLES: TableName[] = ['products', 'productUnits', 'stockMovements', 'transactions', 'customers', 'debtEntries', 'shifts', 'cashMoves', 'returns', 'opnames', 'holds', 'settings'];

export type Snapshot = { [K in TableName]: Rows[K][] };
export interface Changes {
  put: { [K in TableName]?: Rows[K][] };
  del: { [K in TableName]?: string[] };
}

export function emptySnapshot(): Snapshot {
  return { products: [], productUnits: [], stockMovements: [], transactions: [], customers: [], debtEntries: [], shifts: [], cashMoves: [], returns: [], opnames: [], holds: [], settings: [] };
}

export interface Persistence {
  /** true when data is only kept in memory and will be lost on reload */
  readonly volatile: boolean;
  load(): Promise<Snapshot>;
  commit(changes: Changes): Promise<void>;
  clear(): Promise<void>;
  /** Replaces every table with `snap` in ONE atomic step: either all of it is applied or the old data stays untouched. */
  replaceAll(snap: Snapshot): Promise<void>;
  /** Sync only: writes changes that came FROM the cloud, so they are not queued to be sent back. */
  commitSilent?(changes: Changes): Promise<void>;
}

/** In-memory backend. Used by tests and as a fallback when IndexedDB is unavailable. */
export class MemoryPersistence implements Persistence {
  readonly volatile = true;
  private data: { [K in TableName]: Map<string, Rows[K]> } = {
    products: new Map(),
    productUnits: new Map(),
    stockMovements: new Map(),
    transactions: new Map(),
    customers: new Map(),
    debtEntries: new Map(),
    shifts: new Map(),
    cashMoves: new Map(),
    returns: new Map(),
    opnames: new Map(),
    holds: new Map(),
    settings: new Map(),
  };
  /** Test hook: make the next commit fail. */
  failNextCommit = false;

  async load(): Promise<Snapshot> {
    const snap = emptySnapshot();
    for (const t of TABLES) (snap[t] as unknown[]) = [...this.data[t].values()].map((r) => structuredClone(r));
    return snap;
  }

  async commit(changes: Changes): Promise<void> {
    if (this.failNextCommit) {
      this.failNextCommit = false;
      throw new Error('Penyimpanan gagal (simulasi).');
    }
    for (const t of TABLES) {
      const puts = changes.put[t] as { id: string }[] | undefined;
      for (const row of puts ?? []) (this.data[t] as Map<string, unknown>).set(row.id, structuredClone(row));
      for (const id of changes.del[t] ?? []) this.data[t].delete(id);
    }
  }

  async clear(): Promise<void> {
    for (const t of TABLES) this.data[t].clear();
  }

  async replaceAll(snap: Snapshot): Promise<void> {
    if (this.failNextCommit) {
      this.failNextCommit = false;
      throw new Error('Penyimpanan gagal (simulasi).');
    }
    for (const t of TABLES) {
      this.data[t].clear();
      for (const row of snap[t] as { id: string }[]) (this.data[t] as Map<string, unknown>).set(row.id, structuredClone(row));
    }
  }
}

// v2 added customers and debtEntries; v3 adds shifts, cashMoves, returns, opnames and holds.
// onupgradeneeded creates any store that is missing, so every older database upgrades in place.
const DB_VERSION = 3;

function reqDone<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error('Transaksi IndexedDB gagal'));
    tx.onabort = () => reject(tx.error ?? new Error('Transaksi IndexedDB dibatalkan'));
  });
}

/** The database upgrade is waiting for another open tab of the app (an older version) to let go. */
export class StorageBlockedError extends Error {
  constructor() {
    super('Tutup tab Bonbon lain yang masih terbuka, lalu muat ulang halaman ini. Data Anda aman.');
    this.name = 'StorageBlockedError';
  }
}

/** IndexedDB backend: one object store per table, keyed by `id`. */
export class IndexedDbPersistence implements Persistence {
  readonly volatile = false;
  private constructor(private db: IDBDatabase) {}

  // the database name stays 'kasirku-pos' (internal id from before the rename) so saved data is kept
  static async open(name = 'kasirku-pos'): Promise<IndexedDbPersistence> {
    if (typeof indexedDB === 'undefined') throw new Error('IndexedDB tidak tersedia');
    const req = indexedDB.open(name, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const t of TABLES) if (!db.objectStoreNames.contains(t)) db.createObjectStore(t, { keyPath: 'id' });
    };
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
      // An older tab that never closes its connection blocks the upgrade; say so instead of hanging.
      req.onblocked = () => reject(new StorageBlockedError());
    });
    // let a newer version of the app upgrade the database while this tab is still open
    db.onversionchange = () => db.close();
    return new IndexedDbPersistence(db);
  }

  async load(): Promise<Snapshot> {
    const tx = this.db.transaction(TABLES, 'readonly');
    const snap = emptySnapshot();
    const pending = TABLES.map(async (t) => {
      (snap[t] as unknown[]) = await reqDone(tx.objectStore(t).getAll());
    });
    await Promise.all(pending);
    await txDone(tx);
    return snap;
  }

  async commit(changes: Changes): Promise<void> {
    const touched = TABLES.filter((t) => (changes.put[t]?.length ?? 0) > 0 || (changes.del[t]?.length ?? 0) > 0);
    if (touched.length === 0) return;
    const tx = this.db.transaction(touched, 'readwrite');
    for (const t of touched) {
      const store = tx.objectStore(t);
      for (const row of (changes.put[t] ?? []) as unknown[]) store.put(row);
      for (const id of changes.del[t] ?? []) store.delete(id);
    }
    await txDone(tx);
  }

  async clear(): Promise<void> {
    const tx = this.db.transaction(TABLES, 'readwrite');
    for (const t of TABLES) tx.objectStore(t).clear();
    await txDone(tx);
  }

  async replaceAll(snap: Snapshot): Promise<void> {
    // one readwrite transaction: if any write fails the whole thing aborts and the old data stays
    const tx = this.db.transaction(TABLES, 'readwrite');
    const done = txDone(tx);
    for (const t of TABLES) {
      const store = tx.objectStore(t);
      store.clear();
      for (const row of snap[t] as unknown[]) store.put(row);
    }
    await done;
  }
}

/** Opens IndexedDB, or falls back to memory (flagged as volatile) when it is blocked. */
export async function createPersistence(): Promise<Persistence> {
  try {
    return await IndexedDbPersistence.open();
  } catch (e) {
    if (e instanceof StorageBlockedError) throw e; // not "storage unavailable": the saved data exists
    return new MemoryPersistence();
  }
}
