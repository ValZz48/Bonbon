// Pure business calculations. No storage, no UI. Everything here is unit tested.

import type { Payment, RoundingMode, TransactionItem } from './types';
import { METHOD_LABEL } from './types';

export type DiscountType = 'nominal' | 'percent';
export interface DiscountSpec {
  type: DiscountType;
  value: number;
}

/** Quantities keep at most 3 decimals (kg). */
export function roundQty(n: number): number {
  return Math.round(n * 1000) / 1000;
}

export function isDecimalUnit(unit: string): boolean {
  return /^(kg|gram|g|ons|liter|ltr|l|meter|m)$/i.test(unit.trim());
}

/** 2 dus x 24 = 48 base units. */
export function toBaseQty(unitQty: number, conversion: number): number {
  return roundQty(unitQty * conversion);
}

/** Cost per base unit when buying in a larger unit: Rp 24.000 per dus of 24 = Rp 1.000. */
export function costPerBase(unitCost: number, conversion: number): number {
  return Math.round(unitCost / conversion);
}

function clamp(n: number, min: number, max: number): number {
  return Math.min(Math.max(n, min), max);
}

/** Discount in Rupiah for a base amount. Never negative, never above the base. */
export function discountAmount(base: number, d?: DiscountSpec): number {
  if (!d || !(d.value > 0) || base <= 0) return 0;
  const raw = d.type === 'percent' ? Math.round((base * Math.min(d.value, 100)) / 100) : Math.round(d.value);
  return clamp(raw, 0, base);
}

export interface LineInput {
  unitQty: number;
  unitPrice: number;
  discount?: DiscountSpec;
}
export interface LineAmounts {
  gross: number;
  discount: number;
  net: number;
}

export function lineAmounts(l: LineInput): LineAmounts {
  const gross = Math.round(l.unitQty * l.unitPrice);
  const discount = discountAmount(gross, l.discount);
  return { gross, discount, net: gross - discount };
}

export function roundToStep(amount: number, mode: RoundingMode): number {
  if (mode === 'none') return amount;
  const step = Number(mode);
  return Math.round(amount / step) * step;
}

export interface TotalsOptions {
  taxEnabled: boolean;
  taxPercent: number;
  roundingMode: RoundingMode;
}
export interface Totals {
  lines: LineAmounts[];
  subtotal: number; // after item discounts
  discount: number; // cart-level discount
  tax: number;
  rounding: number;
  total: number;
}

/** Order of operations: subtotal -> discount -> tax -> rounding -> total. */
export function calcTotals(lines: LineInput[], cartDiscount: DiscountSpec | undefined, opts: TotalsOptions): Totals {
  const amounts = lines.map(lineAmounts);
  const subtotal = amounts.reduce((s, a) => s + a.net, 0);
  const discount = discountAmount(subtotal, cartDiscount);
  const taxable = subtotal - discount;
  const tax = opts.taxEnabled ? Math.round((taxable * opts.taxPercent) / 100) : 0;
  const beforeRounding = taxable + tax;
  const rounded = roundToStep(beforeRounding, opts.roundingMode);
  return {
    lines: amounts,
    subtotal,
    discount,
    tax,
    rounding: rounded - beforeRounding,
    total: Math.max(0, rounded),
  };
}

// ---- Stock status -------------------------------------------------------

export type StockStatus = 'ok' | 'low' | 'out';

/** Aman (stok > min), Menipis (0 < stok <= min), Habis (stok <= 0). */
export function stockStatus(stock: number, minStock: number): StockStatus {
  if (stock <= 0) return 'out';
  if (stock <= minStock) return 'low';
  return 'ok';
}

export const STATUS_LABEL: Record<StockStatus, string> = { ok: 'Aman', low: 'Menipis', out: 'Habis' };

/** Suggested purchase quantity: (min x 2) - stock, at least 1 for out-of-stock items. */
export function suggestedPurchase(stock: number, minStock: number): number {
  const s = roundQty(Math.max(0, minStock * 2 - stock));
  if (s > 0) return s;
  return stock <= 0 ? 1 : 0;
}

/** Next HPP (per base unit) after receiving stock. */
export function nextCost(
  method: 'average' | 'last',
  oldStock: number,
  oldCost: number,
  inQty: number,
  inCostPerBase: number,
): number {
  if (method === 'last') return inCostPerBase;
  const base = Math.max(0, oldStock);
  const total = base + inQty;
  if (total <= 0) return inCostPerBase;
  return Math.round((base * oldCost + inQty * inCostPerBase) / total);
}

// ---- Payments -----------------------------------------------------------

export function paymentsSum(payments: Payment[]): number {
  return payments.reduce((s, p) => s + p.amount, 0);
}

/** Cash returned to the customer. */
export function changeOf(payments: Payment[]): number {
  return payments.reduce((s, p) => (p.method === 'cash' ? s + Math.max(0, (p.tendered ?? p.amount) - p.amount) : s), 0);
}

/** Returns an error message, or null when the payments exactly cover the total. */
export function validatePayments(total: number, payments: Payment[]): string | null {
  if (total === 0 && payments.length === 0) return null;
  if (payments.length === 0) return 'Pilih metode pembayaran.';
  if (payments.filter((p) => p.method === 'kasbon').length > 1) return 'Kasbon hanya boleh satu kali per transaksi.';
  for (const p of payments) {
    if (!Number.isInteger(p.amount) || p.amount <= 0) return 'Jumlah pembayaran harus lebih dari 0.';
    if (p.method === 'kasbon' && !p.customerId) return 'Pilih pelanggan untuk kasbon.';
    if (p.method === 'kasbon' && p.status === 'pending') return 'Kasbon tidak bisa berstatus menunggu konfirmasi.';
    if (p.method === 'cash' && (p.tendered ?? p.amount) < p.amount) {
      return 'Uang yang diterima kurang dari jumlah tunai.';
    }
  }
  const sum = paymentsSum(payments);
  if (sum < total) return `Pembayaran kurang Rp ${(total - sum).toLocaleString('id-ID')}.`;
  if (sum > total) return `Pembayaran lebih Rp ${(sum - total).toLocaleString('id-ID')}. Jumlah harus pas dengan total.`;
  return null;
}

export function itemCost(item: Pick<TransactionItem, 'qty' | 'costPrice'>): number {
  return Math.round(item.qty * item.costPrice);
}

export function methodLabel(p: Pick<Payment, 'method'>): string {
  return METHOD_LABEL[p.method];
}
