// WhatsApp helpers: phone normalization, wa.me links and the message texts.
// No WhatsApp API is involved. wa.me opens the app (or WhatsApp Web) with the text already typed.

import { daysBetweenKeys, formatDateKey, formatDateTime, formatNumber, formatQty, formatRupiah, todayKey } from './format';
import type { DebtEntry, Settings, Transaction } from './types';
import { METHOD_LABEL } from './types';

/**
 * "0812-3456-7890", "+62 812 3456 7890" and "812..." all become "6281234567890".
 * Returns null for anything that is not an Indonesian mobile number.
 */
export function normalizePhoneID(input: string | undefined | null): string | null {
  if (!input) return null;
  let d = input.replace(/\D/g, '');
  if (!d) return null;
  if (d.startsWith('00')) d = d.slice(2);
  if (d.startsWith('0')) d = '62' + d.slice(1);
  else if (d.startsWith('8')) d = '62' + d;
  if (!d.startsWith('62')) return null;
  const local = d.slice(2);
  if (!local.startsWith('8') || local.length < 8 || local.length > 13) return null;
  return d;
}

/** "6281234567890" -> "0812 3456 7890" (display only). */
export function formatPhoneID(normalized: string): string {
  const local = '0' + normalized.slice(2);
  return local.replace(/^(\d{4})(\d{4})(\d+)$/, '$1 $2 $3');
}

export function waLink(phone: string | null, text: string): string {
  const q = `text=${encodeURIComponent(text)}`;
  return phone ? `https://wa.me/${phone}?${q}` : `https://wa.me/?${q}`;
}

function header(s: Settings): string[] {
  const out = [`*${s.storeName}*`];
  if (s.address.trim()) out.push(s.address.trim());
  if (s.phone?.trim()) out.push(`Telp ${s.phone.trim()}`);
  return out;
}

export interface ReceiptExtra {
  /** Customer's total kasbon after this sale (from the debt notebook). */
  debtAfter?: number;
}

/** A receipt written for a chat bubble (no column alignment, WhatsApp bold with *...*). */
export function receiptWhatsApp(t: Transaction, s: Settings, extra: ReceiptExtra = {}): string {
  const out = header(s);
  out.push('');
  if (t.status === 'voided') out.push('*TRANSAKSI DIBATALKAN*' + (t.voidReason ? ` (${t.voidReason})` : ''));
  out.push(`Struk *${t.receiptNo}*`);
  out.push(`${formatDateTime(t.createdAt)} · Kasir ${t.cashierName}`);
  if (t.customerName) out.push(`Pelanggan: ${t.customerName}`);
  out.push('');
  out.push('*Pesanan*');
  for (const i of t.items) {
    out.push(i.name);
    out.push(`  ${formatQty(i.unitQty)} ${i.unitName} x ${formatNumber(i.unitPrice)} = ${formatRupiah(Math.round(i.unitQty * i.unitPrice))}`);
    if (i.discount > 0) out.push(`  Diskon -${formatRupiah(i.discount)}`);
    if (i.note) out.push(`  * ${i.note}`);
  }
  out.push('');
  out.push(`Subtotal: ${formatRupiah(t.subtotal)}`);
  if (t.discount > 0) out.push(`Diskon: -${formatRupiah(t.discount)}`);
  if (t.tax > 0) out.push(`PPN ${t.taxPercent}%: ${formatRupiah(t.tax)}`);
  if (t.rounding !== 0) out.push(`Pembulatan: ${t.rounding > 0 ? '+' : '-'}${formatRupiah(Math.abs(t.rounding))}`);
  out.push(`*TOTAL: ${formatRupiah(t.total)}*`);
  out.push('');
  out.push('*Pembayaran*');
  for (const p of t.payments) {
    out.push(`${METHOD_LABEL[p.method]}: ${formatRupiah(p.amount)}${p.status === 'pending' ? ' (menunggu konfirmasi)' : ''}`);
    if (p.method === 'cash' && (p.tendered ?? p.amount) > p.amount) out.push(`  Diterima: ${formatRupiah(p.tendered as number)}`);
  }
  if (t.change > 0) out.push(`Kembali: ${formatRupiah(t.change)}`);
  if (extra.debtAfter !== undefined && t.customerName) {
    out.push('');
    out.push(`*Total kasbon ${t.customerName}: ${formatRupiah(extra.debtAfter)}*`);
  }
  if (s.receiptFooter.trim()) {
    out.push('');
    out.push(s.receiptFooter.trim());
  }
  return out.join('\n');
}

/** Proof of a kasbon payment, sent to the customer after they paid. */
export function debtPaymentWhatsApp(args: { settings: Settings; customerName: string; entry: DebtEntry }): string {
  const { settings: s, customerName, entry } = args;
  const out = header(s);
  out.push('');
  out.push('*Bukti pembayaran kasbon*');
  out.push(`${formatDateTime(entry.createdAt)} · Kasir ${entry.cashierName}`);
  out.push(`Pelanggan: ${customerName}`);
  out.push('');
  out.push(`Dibayar: *${formatRupiah(entry.amount)}*${entry.method ? ` (${METHOD_LABEL[entry.method]})` : ''}`);
  if (entry.reference) out.push(`Ref: ${entry.reference}`);
  if (entry.balanceAfter > 0) out.push(`Sisa kasbon: *${formatRupiah(entry.balanceAfter)}*`);
  else if (entry.balanceAfter === 0) out.push('Kasbon *LUNAS*. Terima kasih!');
  else out.push(`Kelebihan bayar: *${formatRupiah(-entry.balanceAfter)}*`);
  if (entry.balanceAfter > 0 && s.receiptFooter.trim()) {
    out.push('');
    out.push(s.receiptFooter.trim());
  }
  return out.join('\n');
}

/** Friendly reminder for a customer who still owes. */
export function debtReminderWhatsApp(args: { settings: Settings; customerName: string; balance: number; since?: string | null; today?: string }): string {
  const { settings: s, customerName, balance, since } = args;
  const today = args.today ?? todayKey();
  const out = [`Halo ${customerName}, ini pengingat dari *${s.storeName}*.`, ''];
  let line = `Kasbon Anda saat ini *${formatRupiah(balance)}*`;
  if (since) {
    const days = daysBetweenKeys(since, today);
    line += ` (sejak ${formatDateKey(since)}${days > 0 ? `, ${days} hari` : ''})`;
  }
  out.push(line + '.');
  out.push('Bisa dibayar sebagian atau sekaligus di warung. Terima kasih.');
  if (s.phone?.trim()) out.push(`Info: ${s.phone.trim()}`);
  return out.join('\n');
}
