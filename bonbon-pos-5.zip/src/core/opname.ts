// Stock opname: count the shelves, compare with the system, then apply the differences in one go.
//
// Each line remembers the system stock at the moment it was counted. When the session is finished
// only that DIFFERENCE is applied to the live stock, so sales made while counting are not undone.

import { isDecimalUnit, roundQty } from './calc';
import { formatDate, formatQty, newId } from './format';
import type { Store } from './store';
import type { OpnameLine, OpnameSession, OpnameSummary, Product } from './types';
import { DomainError } from './types';

export const OPNAME_ALL = 'Semua';

/** Difference for one line: counted minus what the system had at the time. null while not counted. */
export function lineDiff(l: Pick<OpnameLine, 'countedQty' | 'systemQty'>): number | null {
  return l.countedQty === null ? null : roundQty(l.countedQty - l.systemQty);
}

export function summarizeOpname(lines: OpnameLine[], costOf: (productId: string) => number): OpnameSummary {
  let counted = 0;
  let withDiff = 0;
  let plusQty = 0;
  let minusQty = 0;
  let diffValue = 0;
  for (const l of lines) {
    const d = lineDiff(l);
    if (d === null) continue;
    counted += 1;
    if (d === 0) continue;
    withDiff += 1;
    if (d > 0) plusQty = roundQty(plusQty + d);
    else minusQty = roundQty(minusQty + -d);
    diffValue += Math.round(d * costOf(l.productId));
  }
  return { counted, withDiff, plusQty, minusQty, diffValue };
}

export function startOpname(store: Store, input: { scope: string; note?: string }, now: Date = new Date()): Promise<OpnameSession> {
  return store.mutate((tx) => {
    if (tx.list('opnames').some((o) => o.status === 'draft')) throw new DomainError('Masih ada opname yang belum selesai. Selesaikan atau batalkan dulu.');
    const scope = input.scope.trim() || OPNAME_ALL;
    const products = tx
      .list('products')
      .filter((p) => p.active && (scope === OPNAME_ALL || p.category === scope))
      .sort((a, b) => a.category.localeCompare(b.category, 'id') || a.name.localeCompare(b.name, 'id'));
    if (products.length === 0) throw new DomainError('Tidak ada produk aktif di kategori ini.');
    const session: OpnameSession = {
      id: newId(),
      status: 'draft',
      scope,
      note: input.note?.trim() || undefined,
      startedAt: now.toISOString(),
      lines: products.map((p) => ({ productId: p.id, name: p.name, unit: p.baseUnit, category: p.category, systemQty: p.stock, countedQty: null })),
    };
    tx.put('opnames', session);
    return session;
  });
}

function countError(p: Pick<Product, 'baseUnit'>, qty: number): string | null {
  if (!Number.isFinite(qty) || qty < 0) return 'Jumlah tidak boleh negatif.';
  if (roundQty(qty) !== qty) return 'Jumlah maksimal 3 angka di belakang koma.';
  if (!isDecimalUnit(p.baseUnit) && !Number.isInteger(qty)) return `Jumlah ${p.baseUnit} harus bilangan bulat.`;
  return null;
}

/** Saves one counted quantity (null clears it). Records the system stock at this moment. */
export function saveOpnameCount(
  store: Store,
  input: { sessionId: string; productId: string; countedQty: number | null },
  now: Date = new Date(),
): Promise<OpnameSession> {
  return store.mutate((tx) => {
    const s = tx.get('opnames', input.sessionId);
    if (!s) throw new DomainError('Sesi opname tidak ditemukan.');
    if (s.status !== 'draft') throw new DomainError('Sesi opname ini sudah selesai.');
    const idx = s.lines.findIndex((l) => l.productId === input.productId);
    if (idx < 0) throw new DomainError('Produk ini tidak ada di sesi opname.');
    const product = tx.get('products', input.productId);
    if (!product) throw new DomainError('Produk tidak ditemukan.');
    const line = s.lines[idx];
    let next: OpnameLine;
    if (input.countedQty === null) {
      next = { ...line, countedQty: null, countedAt: undefined, systemQty: product.stock };
    } else {
      const err = countError(product, input.countedQty);
      if (err) throw new DomainError(`${line.name}: ${err}`);
      next = { ...line, countedQty: roundQty(input.countedQty), countedAt: now.toISOString(), systemQty: product.stock };
    }
    const lines = s.lines.map((l, i) => (i === idx ? next : l));
    const saved = { ...s, lines };
    tx.put('opnames', saved);
    return saved;
  });
}

export function cancelOpname(store: Store, sessionId: string): Promise<void> {
  return store.mutate((tx) => {
    const s = tx.get('opnames', sessionId);
    if (!s) throw new DomainError('Sesi opname tidak ditemukan.');
    if (s.status !== 'draft') throw new DomainError('Opname yang sudah selesai tidak bisa dibatalkan.');
    tx.del('opnames', sessionId);
  });
}

/** Applies every difference to the stock (one movement per product) and closes the session. */
export function finishOpname(store: Store, sessionId: string, now: Date = new Date()): Promise<OpnameSession> {
  return store.mutate((tx) => {
    const s = tx.get('opnames', sessionId);
    if (!s) throw new DomainError('Sesi opname tidak ditemukan.');
    if (s.status !== 'draft') throw new DomainError('Sesi opname ini sudah selesai.');
    if (!s.lines.some((l) => l.countedQty !== null)) throw new DomainError('Belum ada produk yang dihitung.');
    const at = now.toISOString();
    for (const l of s.lines) {
      const d = lineDiff(l);
      if (d === null || d === 0) continue;
      const p = tx.get('products', l.productId);
      if (!p) continue;
      const stock = roundQty(p.stock + d);
      if (stock < 0 && !tx.settings.allowNegativeStock) {
        throw new DomainError(`${p.name}: setelah dihitung, penjualan baru membuat stok jadi minus. Hitung ulang produk ini.`);
      }
      tx.put('products', { ...p, stock, updatedAt: at });
      tx.put('stockMovements', {
        id: newId(),
        productId: p.id,
        type: 'opname',
        qtyChange: d,
        balanceAfter: stock,
        refId: s.id,
        reason: `Opname ${formatDate(s.startedAt)}: dihitung ${formatQty(l.countedQty as number)} ${l.unit}, sistem ${formatQty(l.systemQty)}`,
        userId: 'kasir',
        createdAt: at,
      });
    }
    const costOf = (id: string) => tx.get('products', id)?.costPrice ?? 0;
    const done: OpnameSession = { ...s, status: 'done', finishedAt: at, summary: summarizeOpname(s.lines, costOf) };
    tx.put('opnames', done);
    return done;
  });
}
