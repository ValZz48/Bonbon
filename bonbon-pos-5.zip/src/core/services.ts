// Business operations. Each exported async function is ONE atomic store mutation:
// stock, stock log and transaction are written together or not at all.

import type { DiscountSpec, Totals } from './calc';
import {
  calcTotals,
  changeOf,
  costPerBase,
  isDecimalUnit,
  nextCost,
  roundQty,
  toBaseQty,
  validatePayments,
} from './calc';
import { dateKeyOf, formatQty, formatRupiah, newId } from './format';
import type { Store, Tx } from './store';
import type {
  Customer,
  DebtEntry,
  DebtEntryType,
  Payment,
  PaymentMethod,
  PaymentStatus,
  Product,
  ProductUnit,
  Settings,
  Shift,
  Transaction,
  TransactionItem,
} from './types';
import { DEFAULT_SETTINGS, DomainError, METHOD_LABEL, debtDelta } from './types';
import { normalizePhoneID } from './whatsapp';

/** There is no login (one person uses the app); every action is attributed to this local user. */
export const LOCAL_USER = 'kasir';

// ---- Cart resolution (shared by the UI and checkout) --------------------

export interface CartLineInput {
  productId: string;
  unitName: string; // baseUnit or the name of a ProductUnit
  unitQty: number;
  discount?: DiscountSpec;
  note?: string;
}

export interface ResolvedLine {
  input: CartLineInput;
  product: Product;
  unitName: string;
  conversion: number;
  unitPrice: number;
  baseQty: number;
}

export function resolveLine(
  product: Product | undefined,
  units: ProductUnit[],
  input: CartLineInput,
): ResolvedLine | null {
  if (!product) return null;
  if (input.unitName === product.baseUnit) {
    return {
      input,
      product,
      unitName: product.baseUnit,
      conversion: 1,
      unitPrice: product.sellPrice,
      baseQty: toBaseQty(input.unitQty, 1),
    };
  }
  const u = units.find((x) => x.unitName === input.unitName);
  if (!u) return null;
  return {
    input,
    product,
    unitName: u.unitName,
    conversion: u.conversion,
    unitPrice: u.sellPrice,
    baseQty: toBaseQty(input.unitQty, u.conversion),
  };
}

export function calcCart(lines: ResolvedLine[], cartDiscount: DiscountSpec | undefined, settings: Settings): Totals {
  return calcTotals(
    lines.map((r) => ({ unitQty: r.input.unitQty, unitPrice: r.unitPrice, discount: r.input.discount })),
    cartDiscount,
    settings,
  );
}

/** Quantity rule: > 0, whole numbers unless the unit is weight/volume, max 3 decimals. */
/** Far above anything a shop sells or stocks; stops a slipped finger from making totals overflow. */
export const MAX_QTY = 1_000_000;

export function qtyError(unitName: string, unitQty: number): string | null {
  if (!Number.isFinite(unitQty) || unitQty <= 0) return 'Jumlah harus lebih dari 0.';
  if (unitQty > MAX_QTY) return 'Jumlah terlalu besar (maksimal 1.000.000).';
  if (roundQty(unitQty) !== unitQty) return 'Jumlah maksimal 3 angka di belakang koma.';
  if (!isDecimalUnit(unitName) && !Number.isInteger(unitQty)) return `Jumlah ${unitName} harus bilangan bulat.`;
  return null;
}

/** The running shift, if one is open. At most one shift is open at a time. */
export function currentShift(tx: Tx): Shift | undefined {
  return tx.list('shifts').find((x) => x.status === 'open');
}

function unitsOf(tx: Tx, productId: string): ProductUnit[] {
  return tx.list('productUnits').filter((u) => u.productId === productId);
}

function toMoney(n: unknown, label: string): number {
  const v = typeof n === 'number' ? n : Number(n);
  if (!Number.isFinite(v) || v < 0) throw new DomainError(`${label} tidak boleh kosong atau negatif.`);
  return Math.round(v);
}

// ---- Settings -----------------------------------------------------------

export function saveSettings(store: Store, patch: Partial<Settings>): Promise<Settings> {
  return store.mutate((tx) => {
    const next: Settings = { ...tx.settings, ...patch, id: 'main' };
    next.storeName = next.storeName.trim() || DEFAULT_SETTINGS.storeName;
    next.cashierName = next.cashierName.trim() || 'Kasir';
    if (!Number.isFinite(next.taxPercent) || next.taxPercent < 0 || next.taxPercent > 100) {
      throw new DomainError('Persentase pajak harus antara 0 dan 100.');
    }
    if (!Number.isFinite(next.defaultMinStock) || next.defaultMinStock < 0) {
      throw new DomainError('Stok minimum default tidak boleh negatif.');
    }
    next.enabledMethods = next.enabledMethods.filter((m) => m !== 'kasbon');
    if (next.enabledMethods.length === 0) throw new DomainError('Aktifkan minimal satu metode pembayaran.');
    next.kasbonEnabled = next.kasbonEnabled !== false;
    next.requireShift = next.requireShift === true;
    next.stockNotify = next.stockNotify === true;
    if (!Number.isInteger(next.stockNotifyHour) || next.stockNotifyHour < 0 || next.stockNotifyHour > 23) next.stockNotifyHour = DEFAULT_SETTINGS.stockNotifyHour;
    if (next.paperWidth !== 58 && next.paperWidth !== 80) next.paperWidth = 58;
    tx.put('settings', next);
    return next;
  });
}

// ---- Products -----------------------------------------------------------

export interface UnitInput {
  id?: string;
  unitName: string;
  conversion: number;
  sellPrice: number;
}

export interface ProductInput {
  id?: string;
  name: string;
  sku?: string;
  barcode?: string;
  category: string;
  baseUnit: string;
  costPrice: number;
  sellPrice: number;
  minStock?: number;
  expiryDate?: string;
  units?: UnitInput[];
  /** Only used when creating: written to the stock log as "Stok awal". */
  initialStock?: number;
}

export function nextSku(products: Product[]): string {
  let max = 0;
  for (const p of products) {
    const m = /^SKU-(\d+)$/i.exec(p.sku);
    if (m) max = Math.max(max, Number(m[1]));
  }
  return `SKU-${String(max + 1).padStart(4, '0')}`;
}

export function saveProduct(store: Store, input: ProductInput, now: Date = new Date()): Promise<Product> {
  return store.mutate((tx) => {
    const at = now.toISOString();
    const existing = input.id ? tx.get('products', input.id) : undefined;
    if (input.id && !existing) throw new DomainError('Produk tidak ditemukan.');

    const name = input.name.trim();
    if (!name) throw new DomainError('Nama produk wajib diisi.');
    const baseUnit = input.baseUnit.trim();
    if (!baseUnit) throw new DomainError('Satuan dasar wajib diisi.');
    const costPrice = toMoney(input.costPrice, 'HPP');
    const sellPrice = toMoney(input.sellPrice, 'Harga jual');
    const minStockRaw = input.minStock;
    if (minStockRaw !== undefined && (!Number.isFinite(minStockRaw) || minStockRaw < 0)) {
      throw new DomainError('Stok minimum tidak boleh negatif.');
    }
    const minStock = roundQty(minStockRaw ?? tx.settings.defaultMinStock);

    const all = tx.list('products');
    const sku = (input.sku ?? '').trim() || nextSku(all);
    if (all.some((p) => p.id !== existing?.id && p.sku.toLowerCase() === sku.toLowerCase())) {
      throw new DomainError(`SKU ${sku} sudah dipakai produk lain.`);
    }
    const barcode = (input.barcode ?? '').trim() || undefined;
    if (barcode) {
      const clash = all.find((p) => p.id !== existing?.id && p.barcode === barcode);
      if (clash) throw new DomainError(`Barcode ${barcode} sudah dipakai ${clash.name}.`);
    }

    // satuan konversi
    const units = (input.units ?? []).map((u) => {
      const unitName = u.unitName.trim();
      if (!unitName) throw new DomainError('Nama satuan tambahan wajib diisi.');
      if (unitName.toLowerCase() === baseUnit.toLowerCase()) {
        throw new DomainError(`Satuan tambahan tidak boleh sama dengan satuan dasar (${baseUnit}).`);
      }
      if (!Number.isFinite(u.conversion) || u.conversion <= 0) {
        throw new DomainError(`Isi per ${unitName} harus lebih dari 0.`);
      }
      return { id: u.id, unitName, conversion: roundQty(u.conversion), sellPrice: toMoney(u.sellPrice, `Harga ${unitName}`) };
    });
    const seen = new Set<string>();
    for (const u of units) {
      const k = u.unitName.toLowerCase();
      if (seen.has(k)) throw new DomainError(`Satuan ${u.unitName} muncul dua kali.`);
      seen.add(k);
    }

    const product: Product = {
      id: existing?.id ?? newId(),
      sku,
      barcode,
      name,
      category: input.category.trim() || 'Umum',
      baseUnit,
      costPrice,
      sellPrice,
      stock: existing?.stock ?? 0,
      minStock,
      active: existing?.active ?? true,
      expiryDate: input.expiryDate?.trim() || undefined,
      createdAt: existing?.createdAt ?? at,
      updatedAt: at,
    };

    const keep = new Set(units.filter((u) => u.id).map((u) => u.id as string));
    for (const old of unitsOf(tx, product.id)) if (!keep.has(old.id)) tx.del('productUnits', old.id);
    for (const u of units) {
      tx.put('productUnits', {
        id: u.id ?? newId(),
        productId: product.id,
        unitName: u.unitName,
        conversion: u.conversion,
        sellPrice: u.sellPrice,
      });
    }

    if (!existing && input.initialStock !== undefined && input.initialStock !== 0) {
      const qtyErr = qtyError(baseUnit, input.initialStock);
      if (qtyErr) throw new DomainError(`Stok awal: ${qtyErr}`);
      product.stock = roundQty(input.initialStock);
      tx.put('stockMovements', {
        id: newId(),
        productId: product.id,
        type: 'adjustment',
        qtyChange: product.stock,
        balanceAfter: product.stock,
        reason: 'Stok awal',
        userId: LOCAL_USER,
        createdAt: at,
      });
    }

    tx.put('products', product);
    return product;
  });
}

export function setProductActive(store: Store, id: string, active: boolean, now: Date = new Date()): Promise<Product> {
  return store.mutate((tx) => {
    const p = tx.get('products', id);
    if (!p) throw new DomainError('Produk tidak ditemukan.');
    const next = { ...p, active, updatedAt: now.toISOString() };
    tx.put('products', next);
    return next;
  });
}

// ---- Stock --------------------------------------------------------------

export interface ReceiveInput {
  productId: string;
  unitName?: string; // defaults to baseUnit
  unitQty: number;
  unitCost: number; // purchase price per `unitName`
  supplier?: string;
  note?: string;
}

export function receiveStock(
  store: Store,
  input: ReceiveInput,
  now: Date = new Date(),
): Promise<{ product: Product; baseQty: number; newCost: number }> {
  return store.mutate((tx) => {
    const p = tx.get('products', input.productId);
    if (!p) throw new DomainError('Pilih produk terlebih dahulu.');
    const unitName = input.unitName?.trim() || p.baseUnit;
    const r = resolveLine(p, unitsOf(tx, p.id), { productId: p.id, unitName, unitQty: input.unitQty });
    if (!r) throw new DomainError(`Satuan ${unitName} tidak ditemukan untuk ${p.name}.`);
    const err = qtyError(unitName, input.unitQty);
    if (err) throw new DomainError(err);
    const unitCost = toMoney(input.unitCost, 'Harga beli');

    const baseQty = r.baseQty;
    const newCost = nextCost(tx.settings.costMethod, p.stock, p.costPrice, baseQty, costPerBase(unitCost, r.conversion));
    const stock = roundQty(p.stock + baseQty);
    const at = now.toISOString();
    const reasonParts = [input.supplier?.trim() ? `Supplier: ${input.supplier.trim()}` : '', input.note?.trim() ?? ''].filter(Boolean);
    const next: Product = { ...p, stock, costPrice: newCost, updatedAt: at };
    tx.put('products', next);
    tx.put('stockMovements', {
      id: newId(),
      productId: p.id,
      type: 'purchase',
      qtyChange: baseQty,
      balanceAfter: stock,
      reason: reasonParts.join(' · ') || undefined,
      userId: LOCAL_USER,
      createdAt: at,
    });
    return { product: next, baseQty, newCost };
  });
}

export interface AdjustInput {
  productId: string;
  qtyChange: number; // base unit, + or -
  reason: string;
}

export function adjustStock(store: Store, input: AdjustInput, now: Date = new Date()): Promise<Product> {
  return store.mutate((tx) => {
    const p = tx.get('products', input.productId);
    if (!p) throw new DomainError('Pilih produk terlebih dahulu.');
    const reason = input.reason.trim();
    if (!reason) throw new DomainError('Alasan penyesuaian wajib diisi.');
    if (!Number.isFinite(input.qtyChange) || input.qtyChange === 0) throw new DomainError('Jumlah penyesuaian tidak boleh 0.');
    if (Math.abs(input.qtyChange) > MAX_QTY) throw new DomainError('Jumlah penyesuaian terlalu besar (maksimal 1.000.000).');
    const change = roundQty(input.qtyChange);
    if (!isDecimalUnit(p.baseUnit) && !Number.isInteger(change)) {
      throw new DomainError(`Jumlah ${p.baseUnit} harus bilangan bulat.`);
    }
    const stock = roundQty(p.stock + change);
    if (stock < 0 && !tx.settings.allowNegativeStock) {
      throw new DomainError(`Stok tidak boleh minus. Stok saat ini ${formatQty(p.stock)} ${p.baseUnit}.`);
    }
    const at = now.toISOString();
    const next: Product = { ...p, stock, updatedAt: at };
    tx.put('products', next);
    tx.put('stockMovements', {
      id: newId(),
      productId: p.id,
      type: 'adjustment',
      qtyChange: change,
      balanceAfter: stock,
      reason,
      userId: LOCAL_USER,
      createdAt: at,
    });
    return next;
  });
}

// ---- Sales --------------------------------------------------------------

export interface PaymentInput {
  method: PaymentMethod;
  amount: number;
  reference?: string;
  status?: PaymentStatus;
  tendered?: number; // cash only
  customerId?: string; // kasbon only
}

export interface CheckoutInput {
  lines: CartLineInput[];
  cartDiscount?: DiscountSpec;
  payments: PaymentInput[];
}

export function checkout(store: Store, input: CheckoutInput, now: Date = new Date()): Promise<Transaction> {
  return store.mutate((tx) => {
    const settings = tx.settings;
    if (input.lines.length === 0) throw new DomainError('Keranjang masih kosong.');
    const shift = currentShift(tx);
    if (settings.requireShift && !shift) throw new DomainError('Buka shift dulu di menu Kas sebelum berjualan.');

    const resolved: ResolvedLine[] = input.lines.map((l) => {
      const p = tx.get('products', l.productId);
      if (!p || !p.active) throw new DomainError('Ada produk yang sudah tidak tersedia. Hapus dari keranjang.');
      const err = qtyError(l.unitName, l.unitQty);
      if (err) throw new DomainError(`${p.name}: ${err}`);
      const r = resolveLine(p, unitsOf(tx, p.id), l);
      if (!r) throw new DomainError(`Satuan ${l.unitName} untuk ${p.name} tidak ditemukan.`);
      return r;
    });

    const need = new Map<string, number>();
    for (const r of resolved) need.set(r.product.id, roundQty((need.get(r.product.id) ?? 0) + r.baseQty));
    if (!settings.allowNegativeStock) {
      for (const [id, qty] of need) {
        const p = tx.get('products', id) as Product;
        if (p.stock < qty) {
          throw new DomainError(`Stok ${p.name} tidak cukup. Tersisa ${formatQty(p.stock)} ${p.baseUnit}.`);
        }
      }
    }

    const totals = calcCart(resolved, input.cartDiscount, settings);
    const payments: Payment[] = input.payments.map((p) => ({
      method: p.method,
      amount: p.amount,
      reference: p.reference?.trim() || undefined,
      status: p.method === 'kasbon' ? ('success' as const) : (p.status ?? 'success'),
      ...(p.method === 'cash' ? { tendered: p.tendered ?? p.amount } : {}),
      ...(p.method === 'kasbon' ? { customerId: p.customerId } : {}),
    }));
    const payErr = validatePayments(totals.total, payments);
    if (payErr) throw new DomainError(payErr);

    // kasbon: the customer must exist, be active and stay within their limit
    const kasbon = payments.find((p) => p.method === 'kasbon');
    let customer: Customer | undefined;
    if (kasbon) {
      if (!settings.kasbonEnabled) throw new DomainError('Kasbon dinonaktifkan di Pengaturan.');
      customer = tx.get('customers', kasbon.customerId as string);
      if (!customer || !customer.active) throw new DomainError('Pelanggan kasbon tidak ditemukan atau sudah dinonaktifkan.');
      const owed = balanceOf(tx, customer.id);
      const limit = customer.creditLimit ?? 0;
      if (limit > 0 && owed + kasbon.amount > limit) {
        throw new DomainError(`Melebihi batas kasbon ${customer.name}. Batas ${formatRupiah(limit)}, kasbon saat ini ${formatRupiah(owed)}.`);
      }
    }

    const createdAt = now.toISOString();
    const dateKey = dateKeyOf(now);
    const id = newId();

    const items: TransactionItem[] = resolved.map((r, i) => ({
      productId: r.product.id,
      name: r.product.name,
      unitName: r.unitName,
      unitQty: r.input.unitQty,
      conversion: r.conversion,
      qty: r.baseQty,
      unitPrice: r.unitPrice,
      costPrice: r.product.costPrice,
      discount: totals.lines[i].discount,
      note: r.input.note?.trim() || undefined,
    }));

    const running = new Map<string, Product>();
    for (const r of resolved) {
      const cur = running.get(r.product.id) ?? (tx.get('products', r.product.id) as Product);
      const stock = roundQty(cur.stock - r.baseQty);
      const next: Product = { ...cur, stock, updatedAt: createdAt };
      running.set(cur.id, next);
      tx.put('products', next);
      tx.put('stockMovements', {
        id: newId(),
        productId: cur.id,
        type: 'sale',
        qtyChange: -r.baseQty,
        balanceAfter: stock,
        refId: id,
        userId: LOCAL_USER,
        createdAt,
      });
    }

    const transaction: Transaction = {
      id,
      receiptNo: tx.nextReceiptNo(dateKey),
      dateKey,
      ...(shift ? { shiftId: shift.id } : {}),
      cashierId: LOCAL_USER,
      cashierName: settings.cashierName,
      items,
      subtotal: totals.subtotal,
      discount: totals.discount,
      taxPercent: settings.taxEnabled ? settings.taxPercent : 0,
      tax: totals.tax,
      rounding: totals.rounding,
      total: totals.total,
      payments,
      change: changeOf(payments),
      ...(customer ? { customerId: customer.id, customerName: customer.name } : {}),
      status: 'completed',
      createdAt,
    };
    tx.put('transactions', transaction);
    if (kasbon && customer) {
      appendDebt(tx, { customerId: customer.id, type: 'kasbon', amount: kasbon.amount, txId: id, receiptNo: transaction.receiptNo }, now);
    }
    return transaction;
  });
}

export function voidTransaction(store: Store, id: string, reason: string, now: Date = new Date()): Promise<Transaction> {
  return store.mutate((tx) => {
    const t = tx.get('transactions', id);
    if (!t) throw new DomainError('Transaksi tidak ditemukan.');
    if (t.status !== 'completed') throw new DomainError('Transaksi ini sudah dibatalkan atau diretur.');
    if (t.dateKey !== dateKeyOf(now)) throw new DomainError('Void hanya bisa dilakukan untuk transaksi hari ini.');
    if (tx.list('returns').some((r) => r.txId === t.id)) throw new DomainError('Transaksi ini sudah diretur sebagian, jadi tidak bisa di-void.');
    const why = reason.trim();
    if (!why) throw new DomainError('Alasan void wajib diisi.');

    const at = now.toISOString();
    const running = new Map<string, Product>();
    for (const item of t.items) {
      const cur = running.get(item.productId) ?? tx.get('products', item.productId);
      if (!cur) continue;
      const stock = roundQty(cur.stock + item.qty);
      const next: Product = { ...cur, stock, updatedAt: at };
      running.set(cur.id, next);
      tx.put('products', next);
      tx.put('stockMovements', {
        id: newId(),
        productId: cur.id,
        type: 'void',
        qtyChange: item.qty,
        balanceAfter: stock,
        refId: t.id,
        reason: why,
        userId: LOCAL_USER,
        createdAt: at,
      });
    }
    const shift = currentShift(tx);
    const voided: Transaction = { ...t, status: 'voided', voidReason: why, voidedAt: at, ...(shift ? { voidShiftId: shift.id } : {}) };
    tx.put('transactions', voided);
    // the kasbon this sale created is taken back off the customer's notebook
    const kasbon = t.payments.find((p) => p.method === 'kasbon');
    if (kasbon && t.customerId) {
      appendDebt(tx, { customerId: t.customerId, type: 'void', amount: kasbon.amount, txId: t.id, receiptNo: t.receiptNo, note: why }, now);
    }
    return voided;
  });
}

/** Mark a "Menunggu konfirmasi" payment as received. */
export function confirmPayment(store: Store, txId: string, paymentIndex: number): Promise<Transaction> {
  return store.mutate((tx) => {
    const t = tx.get('transactions', txId);
    if (!t) throw new DomainError('Transaksi tidak ditemukan.');
    const p = t.payments[paymentIndex];
    if (!p) throw new DomainError('Pembayaran tidak ditemukan.');
    const payments = t.payments.map((x, i) => (i === paymentIndex ? { ...x, status: 'success' as const } : x));
    const next = { ...t, payments };
    tx.put('transactions', next);
    return next;
  });
}

// ---- Customers and kasbon ------------------------------------------------

export function balanceOf(tx: Tx, customerId: string): number {
  let sum = 0;
  for (const e of tx.list('debtEntries')) if (e.customerId === customerId) sum += debtDelta(e);
  return sum;
}

export interface DebtLine {
  customerId: string;
  type: DebtEntryType;
  amount: number;
  txId?: string;
  receiptNo?: string;
  method?: PaymentMethod;
  reference?: string;
  note?: string;
}

/** Adds one line to the customer's notebook. Must run inside a mutation. */
export function appendDebt(tx: Tx, line: DebtLine, now: Date): DebtEntry {
  let seq = 0;
  let balance = 0;
  for (const e of tx.list('debtEntries')) {
    if (e.customerId !== line.customerId) continue;
    seq = Math.max(seq, e.seq);
    balance += debtDelta(e);
  }
  const entry: DebtEntry = {
    id: newId(),
    customerId: line.customerId,
    seq: seq + 1,
    type: line.type,
    amount: line.amount,
    balanceAfter: balance + debtDelta(line),
    txId: line.txId,
    receiptNo: line.receiptNo,
    method: line.method,
    reference: line.reference?.trim() || undefined,
    note: line.note?.trim() || undefined,
    shiftId: currentShift(tx)?.id,
    dateKey: dateKeyOf(now),
    createdAt: now.toISOString(),
    cashierName: tx.settings.cashierName,
  };
  tx.put('debtEntries', entry);
  return entry;
}

export interface CustomerInput {
  id?: string;
  name: string;
  phone?: string;
  note?: string;
  /** Rupiah; empty, 0 or null means no limit. */
  creditLimit?: number | null;
}

export function saveCustomer(store: Store, input: CustomerInput, now: Date = new Date()): Promise<Customer> {
  return store.mutate((tx) => {
    const existing = input.id ? tx.get('customers', input.id) : undefined;
    if (input.id && !existing) throw new DomainError('Pelanggan tidak ditemukan.');
    const name = input.name.trim().replace(/\s+/g, ' ');
    if (!name) throw new DomainError('Nama pelanggan wajib diisi.');
    if (name.length > 60) throw new DomainError('Nama pelanggan maksimal 60 huruf.');

    const rawPhone = (input.phone ?? '').trim();
    let phone: string | undefined;
    if (rawPhone) {
      const n = normalizePhoneID(rawPhone);
      if (!n) throw new DomainError('Nomor WhatsApp tidak valid. Contoh: 0812 3456 7890.');
      phone = n;
    }

    const others = tx.list('customers').filter((c) => c.id !== existing?.id);
    const sameName = others.find((c) => c.name.toLowerCase() === name.toLowerCase());
    if (sameName) throw new DomainError(`Pelanggan bernama ${sameName.name} sudah ada. Beri pembeda, mis. "${name} RT 3".`);
    if (phone) {
      const samePhone = others.find((c) => c.phone === phone);
      if (samePhone) throw new DomainError(`Nomor ini sudah dipakai ${samePhone.name}.`);
    }

    let creditLimit: number | undefined;
    if (input.creditLimit !== undefined && input.creditLimit !== null && input.creditLimit !== 0) {
      if (!Number.isFinite(input.creditLimit) || input.creditLimit < 0) throw new DomainError('Batas kasbon tidak boleh negatif.');
      creditLimit = Math.round(input.creditLimit);
    }

    const at = now.toISOString();
    const customer: Customer = {
      id: existing?.id ?? newId(),
      name,
      phone,
      note: input.note?.trim() || undefined,
      creditLimit,
      active: existing?.active ?? true,
      createdAt: existing?.createdAt ?? at,
      updatedAt: at,
    };
    tx.put('customers', customer);
    return customer;
  });
}

export function setCustomerActive(store: Store, id: string, active: boolean, now: Date = new Date()): Promise<Customer> {
  return store.mutate((tx) => {
    const c = tx.get('customers', id);
    if (!c) throw new DomainError('Pelanggan tidak ditemukan.');
    const owed = balanceOf(tx, id);
    if (!active && owed !== 0) {
      throw new DomainError(`${c.name} masih punya catatan kasbon ${formatRupiah(owed)}. Selesaikan dulu sebelum dinonaktifkan.`);
    }
    const next = { ...c, active, updatedAt: now.toISOString() };
    tx.put('customers', next);
    return next;
  });
}

function wholeRupiah(n: number, label: string): number {
  if (!Number.isFinite(n) || !Number.isInteger(n) || n <= 0) throw new DomainError(`${label} harus berupa rupiah utuh lebih dari 0.`);
  return n;
}

function customerOf(tx: Tx, id: string): Customer {
  const c = tx.get('customers', id);
  if (!c) throw new DomainError('Pilih pelanggan terlebih dahulu.');
  return c;
}

export interface DebtPaymentInput {
  customerId: string;
  amount: number;
  method: PaymentMethod;
  reference?: string;
  note?: string;
}

/** The customer pays some or all of their kasbon. */
export function receiveDebtPayment(store: Store, input: DebtPaymentInput, now: Date = new Date()): Promise<DebtEntry> {
  return store.mutate((tx) => {
    const c = customerOf(tx, input.customerId);
    if (input.method === 'kasbon' || !(input.method in METHOD_LABEL)) throw new DomainError('Pilih metode pembayaran.');
    const amount = wholeRupiah(input.amount, 'Jumlah pembayaran');
    const owed = balanceOf(tx, c.id);
    if (owed <= 0) throw new DomainError(`${c.name} tidak punya kasbon yang harus dibayar.`);
    if (amount > owed) throw new DomainError(`Pembayaran melebihi kasbon. Sisa kasbon ${formatRupiah(owed)}.`);
    return appendDebt(tx, { customerId: c.id, type: 'payment', amount, method: input.method, reference: input.reference, note: input.note }, now);
  });
}

/** Records an old debt that was not made through the cashier (e.g. from a paper notebook). */
export function addManualDebt(store: Store, input: { customerId: string; amount: number; note?: string }, now: Date = new Date()): Promise<DebtEntry> {
  return store.mutate((tx) => {
    const c = customerOf(tx, input.customerId);
    if (!c.active) throw new DomainError(`${c.name} sudah dinonaktifkan.`);
    const amount = wholeRupiah(input.amount, 'Jumlah kasbon');
    return appendDebt(tx, { customerId: c.id, type: 'kasbon', amount, note: input.note?.trim() || 'Kasbon manual' }, now);
  });
}

/** Cancels part or all of a debt without a payment (e.g. the customer moved away). A reason is required. */
export function writeOffDebt(store: Store, input: { customerId: string; amount: number; reason: string }, now: Date = new Date()): Promise<DebtEntry> {
  return store.mutate((tx) => {
    const c = customerOf(tx, input.customerId);
    const reason = input.reason.trim();
    if (!reason) throw new DomainError('Alasan wajib diisi.');
    const amount = wholeRupiah(input.amount, 'Jumlah');
    const owed = balanceOf(tx, c.id);
    if (owed <= 0) throw new DomainError(`${c.name} tidak punya kasbon.`);
    if (amount > owed) throw new DomainError(`Jumlah melebihi kasbon. Sisa kasbon ${formatRupiah(owed)}.`);
    return appendDebt(tx, { customerId: c.id, type: 'writeoff', amount, note: reason }, now);
  });
}
