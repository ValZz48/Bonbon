// Domain types for the Bonbon POS (Fase 1, kasbon, and Fase 2: shift, retur, opname).
// Money is always an integer number of Rupiah. Quantities are in the product's base unit.

export type PaymentMethod = 'cash' | 'qris' | 'transfer' | 'ewallet' | 'debit' | 'credit' | 'kasbon';
export type PaymentStatus = 'success' | 'pending';

export interface Product {
  id: string;
  sku: string;
  barcode?: string; // unique when set
  name: string;
  category: string;
  baseUnit: string; // pcs, porsi, kg, botol
  costPrice: number; // HPP per base unit, Rupiah
  sellPrice: number; // retail price per base unit
  stock: number; // in baseUnit (max 3 decimals, e.g. kg)
  minStock: number; // warning threshold
  active: boolean;
  expiryDate?: string; // ISO date, optional (display only in Fase 1)
  createdAt: string;
  updatedAt: string;
}

/** Alternative selling unit, e.g. 1 dus = 24 pcs. */
export interface ProductUnit {
  id: string;
  productId: string;
  unitName: string;
  conversion: number; // 1 unit = `conversion` baseUnit
  sellPrice: number; // price per this unit
}

export type StockMovementType =
  | 'purchase'
  | 'sale'
  | 'void'
  | 'return'
  | 'adjustment'
  | 'opname'
  | 'expired';

export interface StockMovement {
  id: string;
  productId: string;
  type: StockMovementType;
  qtyChange: number; // + in, - out, in baseUnit
  balanceAfter: number; // stock right after this movement
  refId?: string; // transaction id etc.
  reason?: string; // required for adjustments
  userId: string;
  createdAt: string;
}

export interface TransactionItem {
  productId: string;
  name: string; // snapshot
  unitName: string; // unit the cashier sold in
  unitQty: number; // quantity in that unit
  conversion: number; // base units per sold unit (snapshot)
  qty: number; // quantity in baseUnit = unitQty * conversion
  unitPrice: number; // snapshot sell price per sold unit
  costPrice: number; // snapshot HPP per baseUnit
  discount: number; // item discount in Rupiah (never a percentage)
  note?: string;
}

export interface Payment {
  method: PaymentMethod;
  amount: number; // portion of the bill covered by this payment
  reference?: string;
  status: PaymentStatus;
  customerId?: string; // required for kasbon
  tendered?: number; // cash handed over (>= amount); change = tendered - amount
}

export interface Transaction {
  id: string;
  receiptNo: string; // INV-YYYYMMDD-0001
  dateKey: string; // YYYY-MM-DD in WIB, for grouping
  shiftId?: string;
  cashierId: string;
  cashierName: string; // snapshot
  items: TransactionItem[];
  subtotal: number; // sum of items after item discounts
  discount: number; // cart-level discount
  taxPercent: number; // snapshot, 0 when tax is off
  tax: number;
  rounding: number;
  total: number;
  payments: Payment[];
  change: number; // cash change returned
  /** Set when part of the bill went on kasbon (snapshot of the customer). */
  customerId?: string;
  customerName?: string;
  status: 'completed' | 'voided' | 'returned';
  voidReason?: string;
  voidedAt?: string;
  /** shift that was open when the sale was voided: the cash refund leaves THAT drawer */
  voidShiftId?: string;
  createdAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone?: string; // normalized to 62xxxxxxxxxx
  note?: string;
  /** Maximum outstanding kasbon in Rupiah; 0 or unset = no limit. */
  creditLimit?: number;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

/**
 * One line in a customer's kasbon notebook. `amount` is always positive:
 * kasbon adds to the debt; payment, void and writeoff reduce it.
 */
export type DebtEntryType = 'kasbon' | 'payment' | 'void' | 'writeoff' | 'return';

export interface DebtEntry {
  id: string;
  customerId: string;
  seq: number; // 1, 2, 3... per customer, keeps the notebook order stable
  type: DebtEntryType;
  amount: number;
  balanceAfter: number; // customer's debt right after this line (negative = overpaid)
  txId?: string; // kasbon from a sale, or the void of that sale
  receiptNo?: string; // snapshot of the sale's receipt number
  method?: PaymentMethod; // for payments
  reference?: string;
  note?: string;
  shiftId?: string; // shift that was open when the line was written
  dateKey: string;
  createdAt: string;
  cashierName: string;
}

export const DEBT_LABEL: Record<DebtEntryType, string> = {
  kasbon: 'Kasbon',
  payment: 'Pembayaran',
  void: 'Void transaksi',
  writeoff: 'Utang dihapus',
  return: 'Retur barang',
};

/** Signed effect of an entry on the customer's debt. */
export function debtDelta(e: Pick<DebtEntry, 'type' | 'amount'>): number {
  return e.type === 'kasbon' ? e.amount : -e.amount;
}

export type RoundingMode = 'none' | '100' | '500';

export interface Settings {
  id: 'main';
  storeName: string;
  address: string;
  phone?: string;
  cashierName: string;
  taxEnabled: boolean;
  taxPercent: number;
  roundingMode: RoundingMode;
  allowNegativeStock: boolean;
  defaultMinStock: number;
  expiryWarnDays: number;
  costMethod: 'average' | 'last';
  receiptFooter: string;
  paperWidth: 58 | 80;
  enabledMethods: PaymentMethod[];
  /** Kasbon (pay later) is offered at checkout. Kept apart from enabledMethods on purpose. */
  kasbonEnabled: boolean;
  /** Selling needs an open shift (Kas). Off by default: a one-person shop can sell without opening one. */
  requireShift: boolean;
  /** Android app only: a daily notification listing products that are out or low. Off until the user turns it on (it needs permission). */
  stockNotify: boolean;
  /** hour of day (0 to 23, WIB device time) for that notification */
  stockNotifyHour: number;
  /** true once sample data was offered, so a fresh install seeds only once */
  demoOffered?: boolean;
  /** when the data was last exported as a backup file (ISO time) */
  lastBackupAt?: string;
}

export const DEFAULT_SETTINGS: Settings = {
  id: 'main',
  storeName: 'Warung Manop',
  address: 'Jl. Merdeka No. 10, Jakarta',
  phone: '',
  cashierName: 'Kasir',
  taxEnabled: false,
  taxPercent: 11,
  roundingMode: 'none',
  allowNegativeStock: false,
  defaultMinStock: 5,
  expiryWarnDays: 7,
  costMethod: 'average',
  receiptFooter: 'Terima kasih sudah berbelanja!',
  paperWidth: 58,
  enabledMethods: ['cash', 'qris', 'transfer', 'ewallet', 'debit', 'credit'],
  kasbonEnabled: true,
  requireShift: false,
  stockNotify: false,
  stockNotifyHour: 8,
};

/** Methods offered at checkout: the enabled ones, plus kasbon when switched on. */
export function checkoutMethods(s: Pick<Settings, 'enabledMethods' | 'kasbonEnabled'>): PaymentMethod[] {
  return s.kasbonEnabled ? [...s.enabledMethods, 'kasbon'] : [...s.enabledMethods];
}

export const METHOD_LABEL: Record<PaymentMethod, string> = {
  cash: 'Tunai',
  qris: 'QRIS',
  transfer: 'Transfer',
  ewallet: 'E-wallet',
  debit: 'Debit',
  credit: 'Kredit',
  kasbon: 'Kasbon',
};

export const MOVEMENT_LABEL: Record<StockMovementType, string> = {
  purchase: 'Stok masuk',
  sale: 'Penjualan',
  void: 'Void',
  return: 'Retur',
  adjustment: 'Penyesuaian',
  opname: 'Opname',
  expired: 'Kadaluarsa',
};

/** Error with a message that is safe to show to the cashier. */
export class DomainError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'DomainError';
  }
}

// ---- Fase 2: shift and cash drawer ------------------------------------------

export interface Shift {
  id: string;
  status: 'open' | 'closed';
  openedAt: string;
  openingCash: number; // cash in the drawer when the shift started
  cashierName: string;
  note?: string;
  closedAt?: string;
  countedCash?: number; // what the cashier counted at closing
  expectedCash?: number; // what the system expected at closing
  difference?: number; // counted - expected (negative = short)
  closeNote?: string;
  /** frozen at closing so later activity (a void the next day) cannot change a closed shift */
  summary?: ShiftSummary;
}

export type MoneyMethod = Exclude<PaymentMethod, 'kasbon'>;

export interface ShiftMethodTotal {
  method: MoneyMethod;
  sales: number; // received for sales in this shift
  debtPayments: number; // kasbon instalments received
  refunds: number; // paid back for voids and returns
  net: number; // sales + debtPayments - refunds
}

export interface ShiftSummary {
  salesCount: number; // sales in the shift that were not voided
  salesTotal: number; // their bill totals (kasbon part included)
  kasbonSales: number; // part of those sales put on kasbon (not money received)
  pending: number; // payments still waiting for confirmation (not counted as received)
  voidCount: number; // voids done while this shift was open
  returnCount: number;
  methods: ShiftMethodTotal[];
  cash: {
    opening: number;
    sales: number;
    debtPayments: number;
    moneyIn: number; // cash put in the drawer by hand
    refunds: number; // cash paid back for voids and returns
    moneyOut: number; // cash taken out by hand
    expected: number;
  };
}

export interface CashMove {
  id: string;
  shiftId: string;
  type: 'in' | 'out';
  amount: number;
  note: string;
  createdAt: string;
}

// ---- Fase 2: returns ------------------------------------------------------------

export interface ReturnLine {
  itemIndex: number; // index into the sale's items
  productId: string;
  name: string;
  unitName: string;
  unitQty: number; // in the unit it was sold in
  qty: number; // in the product's base unit
  value: number; // the line's net sales value being reversed (before cart discount, tax and rounding)
  cost: number; // HPP put back, 0 when the goods are not restocked
}

export interface ReturnRecord {
  id: string;
  txId: string;
  receiptNo: string; // snapshot
  dateKey: string;
  createdAt: string;
  shiftId?: string;
  lines: ReturnLine[];
  restock: boolean; // goods go back on the shelf (stock goes up)
  refundMethod: PaymentMethod; // how the money went back; kasbon = taken off the customer's debt
  refund: number; // money paid back, including tax and rounding share
  revenue: number; // reduction of net sales (subtotal - cart discount)
  cogs: number; // reduction of HPP (restocked goods only)
  reason: string;
  customerId?: string;
  cashierName: string;
}

// ---- Fase 2: stock opname --------------------------------------------------------

export interface OpnameLine {
  productId: string;
  name: string; // snapshot
  unit: string;
  category: string;
  /** stock in the system when this line was counted (or when the session began, until it is counted) */
  systemQty: number;
  countedQty: number | null;
  countedAt?: string;
}

export interface OpnameSummary {
  counted: number; // lines counted
  withDiff: number; // lines whose count differs from the system
  plusQty: number;
  minusQty: number;
  diffValue: number; // net value of the differences at HPP (negative = loss)
}

export interface OpnameSession {
  id: string;
  status: 'draft' | 'done';
  scope: string; // 'Semua' or a category name
  note?: string;
  startedAt: string;
  finishedAt?: string;
  lines: OpnameLine[];
  summary?: OpnameSummary;
}

// ---- held carts (Tahan) --------------------------------------------------------------

export interface HeldLine {
  productId: string;
  unitName: string;
  unitQty: number;
  discount?: { type: 'nominal' | 'percent'; value: number };
  note?: string;
}

/** A cart set aside while another customer is served. It is NOT a sale: no stock is taken, nothing is recorded. */
export interface HeldCart {
  id: string;
  label?: string;
  createdAt: string;
  lines: HeldLine[];
  discount?: { type: 'nominal' | 'percent'; value: number };
}
