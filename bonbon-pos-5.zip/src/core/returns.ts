// Returns (retur): the customer gives back part or all of a finished sale.
//
// Money is split exactly: every figure is "what the whole sale would be worth up to now" minus
// "what it was worth before this return", so a sale returned in several steps always adds up to
// the sale's own totals, to the Rupiah.

import { isDecimalUnit, itemCost, lineAmounts, roundQty } from './calc';
import { dateKeyOf, formatQty, formatRupiah, newId } from './format';
import { appendDebt, balanceOf, currentShift, qtyError } from './services';
import type { Store } from './store';
import type { PaymentMethod, ReturnLine, ReturnRecord, Transaction, TransactionItem } from './types';
import { DomainError, METHOD_LABEL } from './types';

export const RETURN_REASONS = ['Barang rusak', 'Salah beli', 'Salah produk', 'Tidak sesuai', 'Kadaluarsa'];

/** Net value of a sold line (after its own discount, before the cart discount, tax and rounding). */
export function itemNet(item: TransactionItem): number {
  return lineAmounts({ unitQty: item.unitQty, unitPrice: item.unitPrice, discount: { type: 'nominal', value: item.discount } }).net;
}

/** Quantities (in the sold unit) already returned, per item index. */
export function returnedQtyByItem(tx: Transaction, returns: ReturnRecord[]): number[] {
  const out = tx.items.map(() => 0);
  for (const r of returns) {
    if (r.txId !== tx.id) continue;
    for (const l of r.lines) out[l.itemIndex] = roundQty(out[l.itemIndex] + l.unitQty);
  }
  return out;
}

/** What is still left to return, per item index. */
export function returnableQty(tx: Transaction, returns: ReturnRecord[]): number[] {
  const done = returnedQtyByItem(tx, returns);
  return tx.items.map((i, idx) => roundQty(i.unitQty - done[idx]));
}

/** Value of `qty` units of an item; the full quantity is exactly the full line value. */
function partOf(whole: number, qty: number, of: number): number {
  return qty >= of ? whole : Math.round((whole * qty) / of);
}

/** Share of `target` that goes with a cumulative sales value (exact at 100%). */
function share(target: number, cumValue: number, subtotal: number): number {
  if (subtotal <= 0) return 0;
  return cumValue >= subtotal ? target : Math.round((target * cumValue) / subtotal);
}

export interface ReturnPreview {
  lines: ReturnLine[];
  refund: number;
  revenue: number;
  cogs: number;
  /** every item of the sale is back after this return */
  complete: boolean;
}

export interface ReturnSelection {
  itemIndex: number;
  unitQty: number;
}

/** Pure calculation shared by the dialog (live preview) and the service. Throws DomainError for bad input. */
export function previewReturn(tx: Transaction, prior: ReturnRecord[], selection: ReturnSelection[], restock: boolean): ReturnPreview {
  const done = returnedQtyByItem(tx, prior);
  const picks = new Map<number, number>();
  for (const s of selection) {
    if (!(s.unitQty > 0)) continue;
    picks.set(s.itemIndex, roundQty((picks.get(s.itemIndex) ?? 0) + s.unitQty));
  }
  if (picks.size === 0) throw new DomainError('Pilih barang yang diretur.');

  let before = 0;
  let after = 0;
  let costBefore = 0;
  let costAfter = 0;
  const lines: ReturnLine[] = [];
  tx.items.forEach((item, idx) => {
    const net = itemNet(item);
    const cost = itemCost(item);
    const pick = picks.get(idx) ?? 0;
    const doneQty = done[idx];
    const cum = roundQty(doneQty + pick);
    if (pick > 0) {
      const err = qtyError(item.unitName, pick);
      if (err) throw new DomainError(`${item.name}: ${err}`);
      if (cum > item.unitQty) {
        throw new DomainError(`${item.name}: yang bisa diretur tinggal ${formatQty(roundQty(item.unitQty - doneQty))} ${item.unitName}.`);
      }
    }
    before += partOf(net, doneQty, item.unitQty);
    after += partOf(net, cum, item.unitQty);
    const costDone = partOf(cost, doneQty, item.unitQty);
    const costCum = partOf(cost, cum, item.unitQty);
    costBefore += costDone;
    costAfter += costCum;
    if (pick > 0) {
      lines.push({
        itemIndex: idx,
        productId: item.productId,
        name: item.name,
        unitName: item.unitName,
        unitQty: pick,
        qty: roundQty(pick * item.conversion),
        value: partOf(net, cum, item.unitQty) - partOf(net, doneQty, item.unitQty),
        cost: restock ? costCum - costDone : 0,
      });
    }
  });

  const refund = share(tx.total, after, tx.subtotal) - share(tx.total, before, tx.subtotal);
  const revenue = share(tx.subtotal - tx.discount, after, tx.subtotal) - share(tx.subtotal - tx.discount, before, tx.subtotal);
  const cogs = restock ? costAfter - costBefore : 0;
  const complete = tx.items.every((item, idx) => roundQty(done[idx] + (picks.get(idx) ?? 0)) >= item.unitQty);
  return { lines, refund, revenue, cogs, complete };
}

export interface ReturnInput {
  txId: string;
  lines: ReturnSelection[];
  /** how the money goes back: 'kasbon' takes it off the customer's debt */
  refundMethod: PaymentMethod;
  /** goods can be sold again, so stock goes up (false for broken or spoiled goods) */
  restock: boolean;
  reason: string;
}

export function returnItems(store: Store, input: ReturnInput, now: Date = new Date()): Promise<ReturnRecord> {
  return store.mutate((tx) => {
    const sale = tx.get('transactions', input.txId);
    if (!sale) throw new DomainError('Transaksi tidak ditemukan.');
    if (sale.status === 'voided') throw new DomainError('Transaksi ini sudah dibatalkan (void), tidak bisa diretur.');
    if (sale.status === 'returned') throw new DomainError('Semua barang di transaksi ini sudah diretur.');
    if (sale.payments.some((p) => p.status === 'pending')) throw new DomainError('Konfirmasi dulu pembayaran yang masih menunggu sebelum meretur.');
    const reason = input.reason.trim();
    if (!reason) throw new DomainError('Alasan retur wajib diisi.');

    const method = input.refundMethod;
    const settings = tx.settings;
    const allowed: PaymentMethod[] = ['cash', ...settings.enabledMethods.filter((m) => m !== 'cash')];
    if (method === 'kasbon') {
      if (!sale.customerId) throw new DomainError('Potong kasbon hanya bisa untuk transaksi yang atas nama pelanggan.');
    } else if (!allowed.includes(method)) {
      throw new DomainError('Pilih cara pengembalian uang.');
    }

    const prior = tx.list('returns').filter((r) => r.txId === sale.id);
    const p = previewReturn(sale, prior, input.lines, input.restock);
    // A free item (100% discount) is worth Rp 0 but can still be handed back, so a return may refund nothing.

    let customerId: string | undefined;
    if (method === 'kasbon' && p.refund > 0) {
      customerId = sale.customerId;
      const owed = balanceOf(tx, customerId as string);
      if (owed <= 0) throw new DomainError(`${sale.customerName ?? 'Pelanggan'} tidak punya kasbon. Pilih cara lain, misalnya tunai.`);
      if (p.refund > owed) {
        throw new DomainError(`Kasbon ${sale.customerName ?? 'pelanggan'} tinggal ${formatRupiah(owed)}, kurang dari nilai retur ${formatRupiah(p.refund)}. Pilih tunai untuk sisanya.`);
      }
    }

    const at = now.toISOString();
    const record: ReturnRecord = {
      id: newId(),
      txId: sale.id,
      receiptNo: sale.receiptNo,
      dateKey: dateKeyOf(now),
      createdAt: at,
      shiftId: currentShift(tx)?.id,
      lines: p.lines,
      restock: input.restock,
      refundMethod: method,
      refund: p.refund,
      revenue: p.revenue,
      cogs: p.cogs,
      reason,
      customerId,
      cashierName: settings.cashierName,
    };

    if (input.restock) {
      const running = new Map<string, number>();
      for (const l of p.lines) running.set(l.productId, roundQty((running.get(l.productId) ?? 0) + l.qty));
      for (const [productId, qty] of running) {
        const prod = tx.get('products', productId);
        if (!prod) continue;
        if (!isDecimalUnit(prod.baseUnit) && !Number.isInteger(qty)) throw new DomainError(`Jumlah ${prod.baseUnit} harus bilangan bulat.`);
        const stock = roundQty(prod.stock + qty);
        tx.put('products', { ...prod, stock, updatedAt: at });
        tx.put('stockMovements', {
          id: newId(),
          productId,
          type: 'return',
          qtyChange: qty,
          balanceAfter: stock,
          refId: record.id,
          reason: `Retur ${sale.receiptNo}: ${reason}`,
          userId: 'kasir',
          createdAt: at,
        });
      }
    }

    tx.put('returns', record);
    if (p.complete) tx.put('transactions', { ...sale, status: 'returned' });
    if (method === 'kasbon' && customerId && p.refund > 0) {
      appendDebt(tx, { customerId, type: 'return', amount: p.refund, txId: sale.id, receiptNo: sale.receiptNo, note: `Retur: ${reason}` }, now);
    }
    return record;
  });
}

export function refundMethodLabel(m: PaymentMethod): string {
  return m === 'kasbon' ? 'Potong kasbon' : METHOD_LABEL[m];
}
