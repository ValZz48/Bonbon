// Hold (Tahan): put the cart aside, serve someone else, come back to it.
// A held cart is only a saved list. Stock is checked again when it is paid, never reserved.

import { newId } from './format';
import type { Store } from './store';
import type { HeldCart, HeldLine } from './types';
import { DomainError } from './types';

export const MAX_HOLDS = 10;

export interface HoldInput {
  lines: HeldLine[];
  discount?: HeldCart['discount'];
  label?: string;
}

function cleanLines(lines: HeldLine[]): HeldLine[] {
  return lines.map((l) => ({
    productId: l.productId,
    unitName: l.unitName,
    unitQty: l.unitQty,
    ...(l.discount ? { discount: { ...l.discount } } : {}),
    ...(l.note ? { note: l.note } : {}),
  }));
}

function make(input: HoldInput, now: Date): HeldCart {
  if (input.lines.length === 0) throw new DomainError('Keranjang masih kosong, tidak ada yang ditahan.');
  return {
    id: newId(),
    label: input.label?.trim().slice(0, 40) || undefined,
    createdAt: now.toISOString(),
    lines: cleanLines(input.lines),
    ...(input.discount ? { discount: { ...input.discount } } : {}),
  };
}

export function holdCart(store: Store, input: HoldInput, now: Date = new Date()): Promise<HeldCart> {
  return store.mutate((tx) => {
    if (tx.list('holds').length >= MAX_HOLDS) throw new DomainError(`Maksimal ${MAX_HOLDS} keranjang yang ditahan. Lanjutkan atau hapus salah satunya dulu.`);
    const h = make(input, now);
    tx.put('holds', h);
    return h;
  });
}

export function deleteHold(store: Store, id: string): Promise<void> {
  return store.mutate((tx) => {
    if (!tx.get('holds', id)) throw new DomainError('Keranjang tertahan tidak ditemukan.');
    tx.del('holds', id);
  });
}

/**
 * Takes a held cart out of the shelf so it can go back into the cart.
 * If the screen still has a cart with items, that cart is held in the same step (swap), so nothing is lost.
 */
export function resumeHold(store: Store, id: string, current?: HoldInput, now: Date = new Date()): Promise<HeldCart> {
  return store.mutate((tx) => {
    const h = tx.get('holds', id);
    if (!h) throw new DomainError('Keranjang tertahan tidak ditemukan.');
    tx.del('holds', id);
    if (current && current.lines.length > 0) tx.put('holds', make(current, now));
    return h;
  });
}
