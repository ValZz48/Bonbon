// Read-only helpers over a State snapshot (dashboard, lists, shopping list).

import { sameCode } from './barcode';
import type { StockStatus } from './calc';
import { STATUS_LABEL, itemCost, roundQty, stockStatus, suggestedPurchase } from './calc';
import { addDaysKey, daysBetweenKeys } from './format';
import type { State } from './store';
import type { Customer, DebtEntry, Product, Transaction } from './types';

export function statusOf(p: Product): StockStatus {
  return stockStatus(p.stock, p.minStock);
}

export function categoriesOf(state: State): string[] {
  return [...new Set(state.products.filter((p) => p.active).map((p) => p.category))].sort((a, b) => a.localeCompare(b, 'id'));
}

export interface ProductFilter {
  q?: string;
  category?: string;
  includeInactive?: boolean;
}

export function filterProducts(state: State, f: ProductFilter): Product[] {
  const q = (f.q ?? '').trim().toLowerCase();
  return state.products.filter((p) => {
    if (!f.includeInactive && !p.active) return false;
    if (f.category && p.category !== f.category) return false;
    if (!q) return true;
    return p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q) || (p.barcode ?? '').includes(q);
  });
}

/** Exact barcode / SKU match among active products (scanner input). */
export function findByCode(state: State, code: string): Product | undefined {
  const c = code.trim().toLowerCase();
  if (!c) return undefined;
  const active = state.products.filter((p) => p.active);
  return (
    active.find((p) => (p.barcode ?? '').toLowerCase() === c || p.sku.toLowerCase() === c) ??
    // cameras report a UPC-A as 12 digits or as EAN-13 with a leading 0: treat those as the same code
    active.find((p) => sameCode(p.barcode ?? '', c))
  );
}

// ---- Sales summaries -----------------------------------------------------

/** Net sales = subtotal - cart discount (excludes tax and rounding). */
export function revenueOf(t: Transaction): number {
  return t.subtotal - t.discount;
}

export function cogsOf(t: Transaction): number {
  return t.items.reduce((s, i) => s + itemCost(i), 0);
}

export interface DaySummary {
  dateKey: string;
  count: number;
  revenue: number;
  cogs: number;
  profit: number;
  voided: number;
  /** money paid back for returns made on this day */
  refunds: number;
  returnCount: number;
}

/**
 * One day of sales. Returns count on the day they were made (not on the day of the original sale),
 * so revenue and HPP are net of what customers gave back.
 */
export function summarizeDay(state: State, dateKey: string): DaySummary {
  const list = state.txByDate.get(dateKey) ?? [];
  let count = 0;
  let revenue = 0;
  let cogs = 0;
  let voided = 0;
  for (const t of list) {
    if (t.status === 'voided') {
      voided += 1;
      continue;
    }
    count += 1;
    revenue += revenueOf(t);
    cogs += cogsOf(t);
  }
  let refunds = 0;
  let returnCount = 0;
  for (const r of state.returnsByDate.get(dateKey) ?? []) {
    revenue -= r.revenue;
    cogs -= r.cogs;
    refunds += r.refund;
    returnCount += 1;
  }
  return { dateKey, count, revenue, cogs, profit: revenue - cogs, voided, refunds, returnCount };
}

/** Oldest first, ending at `endKey`. */
export function revenueSeries(state: State, endKey: string, days = 7): DaySummary[] {
  const out: DaySummary[] = [];
  for (let i = days - 1; i >= 0; i--) out.push(summarizeDay(state, addDaysKey(endKey, -i)));
  return out;
}

// ---- Stock alerts ---------------------------------------------------------

export interface AlertItem {
  product: Product;
  status: Exclude<StockStatus, 'ok'>;
  suggested: number;
}

/** Low and out-of-stock products: out first, then by how far below the minimum they are. */
export function stockAlerts(state: State): AlertItem[] {
  const items: AlertItem[] = [];
  for (const p of state.products) {
    if (!p.active) continue;
    const s = statusOf(p);
    if (s === 'ok') continue;
    items.push({ product: p, status: s, suggested: suggestedPurchase(p.stock, p.minStock) });
  }
  const ratio = (p: Product) => (p.minStock > 0 ? p.stock / p.minStock : 0);
  return items.sort((a, b) => {
    if (a.status !== b.status) return a.status === 'out' ? -1 : 1;
    return ratio(a.product) - ratio(b.product) || a.product.name.localeCompare(b.product.name, 'id');
  });
}

export function alertCounts(state: State): { low: number; out: number } {
  let low = 0;
  let out = 0;
  for (const p of state.products) {
    if (!p.active) continue;
    const s = statusOf(p);
    if (s === 'low') low += 1;
    else if (s === 'out') out += 1;
  }
  return { low, out };
}

// ---- Kasbon -----------------------------------------------------------------

export function customerBalance(state: State, customerId: string): number {
  return state.balanceByCustomer.get(customerId) ?? 0;
}

/** Date key since when the customer has owed money without a break (null when nothing is owed). */
export function debtSince(entries: DebtEntry[]): string | null {
  let since: string | null = null;
  let prev = 0;
  for (const e of entries) {
    if (e.balanceAfter > 0 && prev <= 0) since = e.dateKey;
    if (e.balanceAfter <= 0) since = null;
    prev = e.balanceAfter;
  }
  return since;
}

export interface DebtorRow {
  customer: Customer;
  balance: number;
  since: string | null;
  days: number; // whole days since `since`
  lastAt: string | null; // latest notebook line
}

/** Every customer with their balance. Debtors first (largest balance first), then the rest by name. */
export function debtorRows(state: State, today: string): DebtorRow[] {
  const rows = state.customers.map((customer) => {
    const entries = state.debtByCustomer.get(customer.id) ?? [];
    const since = debtSince(entries);
    return {
      customer,
      balance: customerBalance(state, customer.id),
      since,
      days: since ? Math.max(0, daysBetweenKeys(since, today)) : 0,
      lastAt: entries.length ? entries[entries.length - 1].createdAt : null,
    };
  });
  return rows.sort((a, b) => {
    const ad = a.balance > 0 ? 1 : 0;
    const bd = b.balance > 0 ? 1 : 0;
    if (ad !== bd) return bd - ad;
    return b.balance - a.balance || a.customer.name.localeCompare(b.customer.name, 'id');
  });
}

export interface DebtSummary {
  total: number; // outstanding kasbon across customers
  debtors: number;
  oldestDays: number;
  oldestName: string | null;
}

export function debtSummary(state: State, today: string): DebtSummary {
  let total = 0;
  let debtors = 0;
  let oldestDays = 0;
  let oldestName: string | null = null;
  for (const r of debtorRows(state, today)) {
    if (r.balance <= 0) continue;
    total += r.balance;
    debtors += 1;
    if (r.days >= oldestDays) {
      oldestDays = r.days;
      oldestName = r.customer.name;
    }
  }
  return { total, debtors, oldestDays, oldestName };
}

export { STATUS_LABEL, roundQty };
