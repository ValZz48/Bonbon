// Stock reminders. Stock only ever changes inside the app, so what the app knows at the moment it
// goes quiet is exactly what a later reminder should say. Pure functions; the app wires them to
// toasts (everywhere) and to Android notifications (APK only).

import { formatQty } from './format';
import type { AlertItem } from './queries';
import type { StockStatus } from './calc';

export type Level = StockStatus; // 'ok' | 'low' | 'out'
const RANK: Record<Level, number> = { ok: 0, low: 1, out: 2 };

/** id -> level for the products currently needing attention (missing = ok). */
export function levelMap(items: AlertItem[]): Map<string, Level> {
  return new Map(items.map((i) => [i.product.id, i.status]));
}

/** Items that got worse since `before` (ok -> low, ok -> out, low -> out). Improving or staying put is not news. */
export function worsened(before: Map<string, Level>, items: AlertItem[]): AlertItem[] {
  return items.filter((i) => RANK[i.status] > RANK[before.get(i.product.id) ?? 'ok']);
}

function names(items: AlertItem[], max: number): string {
  const shown = items.slice(0, max).map((i) => i.product.name);
  const more = items.length - shown.length;
  return shown.join(', ') + (more > 0 ? ` dan ${more} lainnya` : '');
}

/** Short toast text, e.g. "Stok habis: Indomie, Telur. Menipis: Gula (3 kg)." */
export function toastText(items: AlertItem[]): string {
  const out = items.filter((i) => i.status === 'out');
  const low = items.filter((i) => i.status === 'low');
  const parts: string[] = [];
  if (out.length) parts.push(`Stok habis: ${names(out, 3)}.`);
  if (low.length) parts.push(`Menipis: ${names(low, 3)}.`);
  return parts.join(' ');
}

export interface DailySummary {
  title: string;
  body: string;
  /** one line per product, shown when the notification is expanded */
  detail: string;
}

/** Text of the daily reminder, or null when nothing needs attention (then no reminder is scheduled). */
export function dailySummary(items: AlertItem[]): DailySummary | null {
  if (items.length === 0) return null;
  const out = items.filter((i) => i.status === 'out');
  const low = items.filter((i) => i.status === 'low');
  const counts = [out.length ? `${out.length} habis` : '', low.length ? `${low.length} menipis` : ''].filter(Boolean).join(', ');
  const lines = items.slice(0, 10).map((i) => `${i.status === 'out' ? 'Habis' : 'Menipis'}: ${i.product.name} (sisa ${formatQty(i.product.stock)} ${i.product.baseUnit})`);
  if (items.length > 10) lines.push(`dan ${items.length - 10} produk lainnya`);
  return {
    title: 'Stok perlu perhatian',
    body: `${counts}. ${names(items, 3)}.`,
    detail: lines.join('\n'),
  };
}
