// Backup and restore: the whole database as one JSON file.
//
// All data lives in this browser only, so a lost or cleared phone means lost records. A backup file is the way out.
// Restoring REPLACES everything, so a file is checked thoroughly first and applied in one atomic step.

import { dateKeyOf } from './format';
import type { Snapshot, TableName } from './persistence';
import { TABLES, emptySnapshot } from './persistence';
import type { Store } from './store';
import type { Settings } from './types';
import { DEFAULT_SETTINGS, DomainError } from './types';

export const BACKUP_APP = 'warung-manop';
export const BACKUP_FORMAT = 1;
export const BACKUP_REMIND_DAYS = 7;

export interface BackupCounts {
  products: number;
  transactions: number;
  customers: number;
  debtEntries: number;
  returns: number;
  shifts: number;
}

export interface BackupFile {
  app: typeof BACKUP_APP;
  format: number;
  exportedAt: string;
  storeName: string;
  counts: BackupCounts;
  tables: Snapshot;
}

export interface BackupInfo {
  exportedAt: string;
  storeName: string;
  counts: BackupCounts;
}

function countsOf(snap: Snapshot): BackupCounts {
  return {
    products: snap.products.length,
    transactions: snap.transactions.length,
    customers: snap.customers.length,
    debtEntries: snap.debtEntries.length,
    returns: snap.returns.length,
    shifts: snap.shifts.length,
  };
}

/** Builds the backup from the live data. `lastBackupAt` inside the file already carries this backup's own time. */
export function createBackup(store: Store, now: Date = new Date()): BackupFile {
  const tables = store.snapshot();
  const stamp = now.toISOString();
  const current = tables.settings.find((s) => s.id === 'main');
  tables.settings = [{ ...DEFAULT_SETTINGS, ...(current ?? {}), id: 'main', lastBackupAt: stamp } as Settings];
  return {
    app: BACKUP_APP,
    format: BACKUP_FORMAT,
    exportedAt: stamp,
    storeName: tables.settings[0].storeName,
    counts: countsOf(tables),
    tables,
  };
}

export function backupText(file: BackupFile): string {
  return JSON.stringify(file);
}

/** Remembers that a backup was just taken (shown in Settings, and the Beranda reminder goes away). */
export function markBackedUp(store: Store, now: Date = new Date()): Promise<void> {
  return store.mutate((tx) => {
    tx.put('settings', { ...tx.settings, lastBackupAt: now.toISOString() });
  });
}

export function backupFileName(now: Date = new Date()): string {
  return `bonbon-cadangan-${dateKeyOf(now)}.json`;
}

/** Whole days since the last backup, or null if there never was one. */
export function backupAgeDays(lastBackupAt: string | undefined, now: Date = new Date()): number | null {
  if (!lastBackupAt) return null;
  const t = Date.parse(lastBackupAt);
  if (!Number.isFinite(t)) return null;
  return Math.max(0, Math.floor((now.getTime() - t) / 86_400_000));
}

// ---- validation ---------------------------------------------------------------------------

type Row = Record<string, unknown>;
const isObj = (v: unknown): v is Row => typeof v === 'object' && v !== null && !Array.isArray(v);
const isStr = (v: unknown) => typeof v === 'string';
const isNum = (v: unknown) => typeof v === 'number' && Number.isFinite(v);
const isArr = Array.isArray;
const DATE_KEY = /^\d{4}-\d{2}-\d{2}$/;
/** A real shop's data is a few MB at most; anything far larger is not a backup and would freeze the phone. */
export const MAX_BACKUP_CHARS = 40_000_000;
/** every element is an object whose listed fields are finite numbers / strings */
const rowsOk = (v: unknown, nums: string[], strs: string[] = []) => isArr(v) && v.every((x) => isObj(x) && nums.every((k) => isNum(x[k])) && strs.every((k) => isStr(x[k])));

/** What every row of a table must look like at minimum. Returns a problem description or null. */
const CHECKS: { [K in TableName]: (r: Row) => string | null } = {
  products: (r) => (!isStr(r.name) || !isNum(r.stock) || !isStr(r.baseUnit) || !isNum(r.sellPrice) || !isNum(r.costPrice) ? 'produk tidak lengkap' : null),
  productUnits: (r) => (!isStr(r.productId) || !isNum(r.conversion) || (r.conversion as number) <= 0 ? 'satuan produk tidak lengkap' : null),
  stockMovements: (r) => (!isStr(r.productId) || !isNum(r.qtyChange) || !isStr(r.type) || !isStr(r.createdAt) ? 'catatan stok tidak lengkap' : null),
  transactions: (r) =>
    !isStr(r.receiptNo) || !rowsOk(r.items, ['qty', 'unitPrice', 'costPrice'], ['name']) || !rowsOk(r.payments, ['amount'], ['method']) || !isNum(r.total) || !isNum(r.subtotal) || !isStr(r.dateKey) || !DATE_KEY.test(r.dateKey as string) || !['completed', 'voided', 'returned'].includes(r.status as string)
      ? 'transaksi tidak lengkap'
      : null,
  customers: (r) => (!isStr(r.name) ? 'pelanggan tidak lengkap' : null),
  debtEntries: (r) => (!isStr(r.customerId) || !isNum(r.amount) || !isNum(r.seq) || !['kasbon', 'payment', 'void', 'writeoff', 'return'].includes(r.type as string) ? 'catatan kasbon tidak lengkap' : null),
  shifts: (r) => (!isStr(r.openedAt) || !isNum(r.openingCash) || !['open', 'closed'].includes(r.status as string) ? 'data kas tidak lengkap' : null),
  cashMoves: (r) => (!isStr(r.shiftId) || !isNum(r.amount) || !['in', 'out'].includes(r.type as string) ? 'uang masuk/keluar tidak lengkap' : null),
  returns: (r) => (!isStr(r.txId) || !isArr(r.lines) || !r.lines.every(isObj) || !isNum(r.refund) || !isStr(r.dateKey) ? 'data retur tidak lengkap' : null),
  opnames: (r) => (!isArr(r.lines) || !['draft', 'done'].includes(r.status as string) ? 'data opname tidak lengkap' : null),
  holds: (r) => (!isArr(r.lines) ? 'keranjang tertahan tidak lengkap' : null),
  settings: (r) => (r.id !== 'main' || !isStr(r.storeName) ? 'pengaturan tidak lengkap' : null),
};

const TABLE_NAME: Record<TableName, string> = {
  products: 'produk',
  productUnits: 'satuan',
  stockMovements: 'pergerakan stok',
  transactions: 'transaksi',
  customers: 'pelanggan',
  debtEntries: 'kasbon',
  shifts: 'kas laci',
  cashMoves: 'uang masuk/keluar',
  returns: 'retur',
  opnames: 'opname',
  holds: 'keranjang tertahan',
  settings: 'pengaturan',
};

export interface ParsedBackup {
  snapshot: Snapshot;
  info: BackupInfo;
}

/** Reads and checks backup text. Throws a DomainError with a plain message when the file cannot be trusted. */
export function parseBackup(text: string): ParsedBackup {
  if (text.length > MAX_BACKUP_CHARS) throw new DomainError('Berkas ini terlalu besar untuk berkas cadangan Bonbon.');
  const trimmed = text.replace(/^﻿/, '').trim();
  if (!trimmed) throw new DomainError('Berkas cadangan kosong.');
  let data: unknown;
  try {
    data = JSON.parse(trimmed);
  } catch {
    const cut = trimmed.startsWith('{') ? ` Teks terbaca ${trimmed.length.toLocaleString('id-ID')} karakter lalu terputus. Teks panjang sering dipotong saat dikirim lewat WhatsApp; pakai tombol "Simpan / kirim cadangan" lalu pilih berkasnya.` : '';
    throw new DomainError(`Isinya bukan cadangan yang utuh. Pastikan berkas atau teks disalin lengkap, dari awal sampai akhir.${cut}`);
  }
  if (!isObj(data) || data.app !== BACKUP_APP || !isObj(data.tables)) throw new DomainError('Ini bukan berkas cadangan Bonbon.');
  if (typeof data.format !== 'number' || data.format > BACKUP_FORMAT) throw new DomainError('Cadangan ini dibuat oleh versi aplikasi yang lebih baru. Perbarui aplikasi dulu.');

  const snapshot = emptySnapshot();
  const tables = data.tables as Row;
  for (const t of TABLES) {
    const rows = tables[t];
    if (rows === undefined) continue; // an older file without a newer table: that table is simply empty
    if (!isArr(rows)) throw new DomainError(`Data ${TABLE_NAME[t]} di cadangan rusak.`);
    const seen = new Set<string>();
    rows.forEach((r, i) => {
      if (!isObj(r) || !isStr(r.id) || (r.id as string) === '') throw new DomainError(`Data ${TABLE_NAME[t]} baris ${i + 1} di cadangan rusak (tanpa ID).`);
      if (seen.has(r.id as string)) throw new DomainError(`Data ${TABLE_NAME[t]} di cadangan punya ID ganda.`);
      seen.add(r.id as string);
      const problem = CHECKS[t](r);
      if (problem) throw new DomainError(`Data ${TABLE_NAME[t]} baris ${i + 1} di cadangan rusak (${problem}).`);
    });
    (snapshot[t] as unknown[]) = rows;
  }
  if (snapshot.settings.length > 1) throw new DomainError('Pengaturan di cadangan ganda.');

  // cross-checks that would otherwise show up later as strange screens
  const productIds = new Set(snapshot.products.map((p) => p.id));
  if (snapshot.productUnits.some((u) => !productIds.has(u.productId))) throw new DomainError('Cadangan rusak: ada satuan yang produknya tidak ada.');
  const customerIds = new Set(snapshot.customers.map((c) => c.id));
  if (snapshot.debtEntries.some((e) => !customerIds.has(e.customerId))) throw new DomainError('Cadangan rusak: ada catatan kasbon yang pelanggannya tidak ada.');
  const txIds = new Set(snapshot.transactions.map((t) => t.id));
  if (snapshot.returns.some((r) => !txIds.has(r.txId))) throw new DomainError('Cadangan rusak: ada retur yang transaksinya tidak ada.');
  const shiftIds = new Set(snapshot.shifts.map((s) => s.id));
  if (snapshot.cashMoves.some((m) => !shiftIds.has(m.shiftId))) throw new DomainError('Cadangan rusak: ada uang masuk/keluar yang kasnya tidak ada.');
  if (snapshot.shifts.filter((s) => s.status === 'open').length > 1) throw new DomainError('Cadangan rusak: lebih dari satu kas yang masih terbuka.');

  const exportedAt = isStr(data.exportedAt) ? (data.exportedAt as string) : '';
  const settings = snapshot.settings[0];
  return {
    snapshot,
    info: { exportedAt, storeName: settings?.storeName ?? (isStr(data.storeName) ? (data.storeName as string) : 'Warung Manop'), counts: countsOf(snapshot) },
  };
}

/** Replaces all current data with the backup. Atomic: if saving fails, nothing changes. */
export function restoreBackup(store: Store, parsed: ParsedBackup): Promise<void> {
  const snap = emptySnapshot();
  for (const t of TABLES) (snap[t] as unknown[]) = parsed.snapshot[t];
  // the file may come from a different version: fill in settings added since, and keep sample data from being re-offered
  const s = (snap.settings[0] ?? {}) as Partial<Settings>;
  snap.settings = [{ ...DEFAULT_SETTINGS, ...s, id: 'main', demoOffered: true }];
  return store.restore(snap);
}
