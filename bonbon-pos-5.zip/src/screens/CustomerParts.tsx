import { useMemo, useState } from 'react';
import { LuPlus, LuSearch, LuUserRound } from 'react-icons/lu';
import { formatRupiah } from '../core/format';
import { saveCustomer } from '../core/services';
import type { Customer } from '../core/types';
import { formatPhoneID } from '../core/whatsapp';
import { useAppState, useStore } from '../app/state';
import { Field, Modal, MoneyInput, cx, errorMessage, useToast } from '../app/ui';

/** Add or edit a customer. */
export function CustomerForm({ customer, initialName, onClose, onSaved }: { customer?: Customer; initialName?: string; onClose: () => void; onSaved: (c: Customer) => void }) {
  const store = useStore();
  const toast = useToast();
  const [name, setName] = useState(customer?.name ?? initialName ?? '');
  const [phone, setPhone] = useState(customer?.phone ? formatPhoneID(customer.phone) : '');
  const [limit, setLimit] = useState<number | null>(customer?.creditLimit ?? null);
  const [note, setNote] = useState(customer?.note ?? '');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      const saved = await saveCustomer(store, { id: customer?.id, name, phone, note, creditLimit: limit });
      toast(customer ? 'Data pelanggan disimpan.' : `${saved.name} ditambahkan.`);
      onSaved(saved);
    } catch (e) {
      setError(errorMessage(e));
      setBusy(false);
    }
  };

  return (
    <Modal
      title={customer ? 'Ubah pelanggan' : 'Pelanggan baru'}
      size="sm"
      onClose={busy ? () => undefined : onClose}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>
            Batal
          </button>
          <button type="button" className="btn btn-primary" onClick={submit} disabled={busy || !name.trim()}>
            {busy ? 'Menyimpan...' : 'Simpan'}
          </button>
        </>
      }
    >
      <div className="grid gap-4">
        <Field label="Nama">
          <input className="input" autoComplete="off" value={name} onChange={(e) => setName(e.target.value)} placeholder="Mis. Pak Budi" onKeyDown={(e) => e.key === 'Enter' && submit()} />
        </Field>
        <Field label="Nomor WhatsApp (opsional)" hint="Untuk kirim struk dan pengingat kasbon.">
          <input className="input" inputMode="tel" autoComplete="off" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="0812 3456 7890" onKeyDown={(e) => e.key === 'Enter' && submit()} />
        </Field>
        <Field label="Batas kasbon (opsional)" hint="Kasbon baru ditolak jika total utang melewati batas ini. Kosongkan jika tanpa batas.">
          <MoneyInput value={limit} onChange={setLimit} aria-label="Batas kasbon" />
        </Field>
        <Field label="Catatan (opsional)">
          <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Mis. tetangga RT 3, gajian tiap tanggal 25" onKeyDown={(e) => e.key === 'Enter' && submit()} />
        </Field>
      </div>
      {error && (
        <p role="alert" className="err mt-3 text-sm">
          {error}
        </p>
      )}
    </Modal>
  );
}

/** Inline customer chooser (no floating popover): search, pick, or add a new customer on the spot. */
export function CustomerPicker({ value, onChange }: { value: string | null; onChange: (id: string | null) => void }) {
  const state = useAppState();
  const [q, setQ] = useState('');
  const [adding, setAdding] = useState(false);

  const active = useMemo(() => state.customers.filter((c) => c.active), [state.customers]);
  const selected = value ? state.customersById.get(value) : undefined;
  const matches = useMemo(() => {
    const s = q.trim().toLowerCase();
    const digits = s.replace(/\D/g, '');
    const list = s ? active.filter((c) => c.name.toLowerCase().includes(s) || (digits.length >= 3 && (c.phone ?? '').includes(digits.replace(/^0/, '62')))) : active;
    return list;
  }, [active, q]);

  if (selected) {
    const owed = state.balanceByCustomer.get(selected.id) ?? 0;
    return (
      <div>
        <span className="label">Pelanggan</span>
        <div className="flex items-center justify-between gap-3 rounded-md border border-line bg-sunken px-3 py-2">
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold">{selected.name}</p>
            <p className="text-xs text-muted">
              {selected.phone ? formatPhoneID(selected.phone) + ' · ' : ''}
              {owed > 0 ? `kasbon saat ini ${formatRupiah(owed)}` : owed < 0 ? `kelebihan bayar ${formatRupiah(-owed)}` : 'belum ada kasbon'}
              {selected.creditLimit ? ` · batas ${formatRupiah(selected.creditLimit)}` : ''}
            </p>
          </div>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => onChange(null)}>
            Ganti
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <span className="label">Pelanggan</span>
      <div className="relative">
        <LuSearch className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-faint" size={16} />
        <input
          className="input pl-9"
          placeholder="Cari nama atau nomor pelanggan"
          aria-label="Cari pelanggan"
          autoComplete="off"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && matches.length > 0) {
              e.preventDefault();
              onChange(matches[0].id);
              setQ('');
            }
          }}
        />
      </div>
      <ul className="scroll-y mt-1.5 max-h-60 divide-y divide-line rounded-xl border border-line">
        {matches.length === 0 && (
          <li className="px-3 py-3 text-sm text-muted">{active.length === 0 ? 'Belum ada pelanggan. Tambahkan yang pertama.' : 'Pelanggan tidak ditemukan.'}</li>
        )}
        {matches.map((c) => {
          const owed = state.balanceByCustomer.get(c.id) ?? 0;
          return (
            <li key={c.id}>
              <button
                type="button"
                className="flex min-h-11 w-full items-center justify-between gap-3 bg-panel px-3 py-2 text-left hover:bg-sunken"
                onClick={() => {
                  onChange(c.id);
                  setQ('');
                }}
              >
                <span className="flex min-w-0 items-center gap-2">
                  <LuUserRound size={16} className="shrink-0 text-faint" aria-hidden="true" />
                  <span className="truncate text-sm font-semibold">{c.name}</span>
                </span>
                <span className={cx('money shrink-0 text-xs', owed > 0 ? 'font-semibold text-warn' : 'text-muted')}>{owed > 0 ? formatRupiah(owed) : '-'}</span>
              </button>
            </li>
          );
        })}
      </ul>
      <button type="button" className="btn btn-soft btn-sm mt-2" onClick={() => setAdding(true)}>
        <LuPlus size={15} /> Pelanggan baru
      </button>
      {adding && (
        <CustomerForm
          initialName={q.trim()}
          onClose={() => setAdding(false)}
          onSaved={(c) => {
            setAdding(false);
            onChange(c.id);
            setQ('');
          }}
        />
      )}
    </div>
  );
}
