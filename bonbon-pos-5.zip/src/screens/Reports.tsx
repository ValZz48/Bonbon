import { useMemo, useState } from 'react';
import { LuCopy, LuDownload, LuPrinter } from 'react-icons/lu';
import { formatDateTime, todayKey } from '../core/format';
import type { Period, PeriodPreset, ReportTable } from '../core/reports';
import {
  PERIOD_LABEL,
  categoryRows,
  categoryTable,
  dailyRows,
  dailyTable,
  kasbonFlowTable,
  kasbonReport,
  kasbonTable,
  methodReport,
  methodTable,
  periodError,
  periodLabel,
  presetPeriod,
  productRows,
  productTable,
  rp,
  salesSummary,
  stockCategoryTable,
  stockValueByCategory,
  stockValueRows,
  stockValueTable,
  summaryTable,
  tableCsv,
} from '../core/reports';
import { printReport } from '../app/print';
import { CAN_BROWSER_PRINT, CAN_DOWNLOAD, IS_ARTIFACT, IS_NATIVE, downloadText } from '../app/runtime';
import { useAppState } from '../app/state';
import { PageHeader, Tabs, cx, useCopy } from '../app/ui';

type Tab = 'ringkasan' | 'produk' | 'bayar' | 'stok' | 'kasbon';
const TAB_LABEL: Record<Tab, string> = { ringkasan: 'Ringkasan', produk: 'Produk', bayar: 'Pembayaran', stok: 'Stok', kasbon: 'Kasbon' };
const PRESETS: Exclude<PeriodPreset, 'custom'>[] = ['today', 'yesterday', 'week', 'last7', 'month', 'lastMonth'];

function TableView({ t }: { t: ReportTable }) {
  return (
    <section className="card mb-4 overflow-hidden" aria-label={t.title}>
      <h2 className="border-b border-line bg-sunken px-4 py-2.5 text-sm font-bold">{t.title}</h2>
      {t.rows.length === 0 ? (
        <p className="px-4 py-5 text-sm text-muted">Tidak ada data pada periode ini.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm" style={{ minWidth: t.columns.length > 3 ? `${t.columns.length * 7.5}rem` : undefined }}>
            <thead>
              <tr className="border-b border-line text-left text-xs text-muted">
                {t.columns.map((c, i) => (
                  <th key={c} scope="col" className={cx('px-4 py-2 font-semibold', t.numeric.includes(i) && 'text-right')}>
                    {c}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {t.rows.map((r, ri) => (
                <tr key={ri}>
                  {r.map((c, i) => (
                    <td key={i} className={cx('px-4 py-2', t.numeric.includes(i) ? 'money text-right whitespace-nowrap' : 'min-w-32')}>
                      {c}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
            {t.footer && (
              <tfoot>
                <tr className="border-t-2 border-line font-bold">
                  {t.footer.map((c, i) => (
                    <td key={i} className={cx('px-4 py-2', t.numeric.includes(i) ? 'money text-right whitespace-nowrap' : '')}>
                      {c}
                    </td>
                  ))}
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      )}
    </section>
  );
}

function csvOf(tables: ReportTable[]): string {
  return tables.map((t) => `${t.title}\r\n${tableCsv(t)}`).join('\r\n\r\n');
}

export function ReportsScreen() {
  const state = useAppState();
  const copy = useCopy();
  const today = todayKey();
  const [preset, setPreset] = useState<PeriodPreset>('week');
  const [custom, setCustom] = useState<Period>({ from: today, to: today });
  const [tab, setTab] = useState<Tab>('ringkasan');

  const period = preset === 'custom' ? custom : presetPeriod(preset, today);
  const error = preset === 'custom' ? periodError(custom) : null;

  const built = useMemo(() => {
    if (error) return null;
    const summary = salesSummary(state, period);
    const days = dailyRows(state, period);
    const products = productRows(state, period);
    const stockRows = stockValueRows(state);
    const kasbon = kasbonReport(state, period, today);
    const ringkasan: ReportTable[] = [summaryTable(summary), ...(days.length > 1 ? [dailyTable(days)] : [])];
    const tables: Record<Tab, ReportTable[]> = {
      ringkasan,
      produk: [productTable(products, summary), categoryTable(categoryRows(products))],
      bayar: [methodTable(methodReport(state, period))],
      stok: [stockCategoryTable(stockValueByCategory(stockRows)), stockValueTable(stockRows)],
      kasbon: [kasbonFlowTable(kasbon), kasbonTable(kasbon)],
    };
    return { summary, tables };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state, period.from, period.to, error, today]);

  const tables = built?.tables[tab] ?? [];
  const label = periodLabel(period);
  const title = `Laporan ${TAB_LABEL[tab]}`;
  // the stock value is a snapshot of now, so its tab does not follow the period
  const subtitle = tab === 'stok' ? `Per ${formatDateTime(new Date())}` : label;
  const fileBase = `laporan-${tab}-${period.from}${period.from === period.to ? '' : `_${period.to}`}`;

  return (
    <>
      <PageHeader title="Laporan" subtitle="Omzet, laba, produk terlaris, metode bayar, nilai stok, dan kasbon pada periode yang kamu pilih." />

      <div className="mb-3 flex flex-wrap items-center gap-2">
        <div className="-mx-1 flex max-w-full gap-2 overflow-x-auto px-1 pb-1" role="group" aria-label="Periode laporan">
          {([...PRESETS, 'custom'] as PeriodPreset[]).map((p) => (
            <button
              key={p}
              type="button"
              aria-pressed={preset === p}
              onClick={() => setPreset(p)}
              className={cx('min-h-9 shrink-0 rounded-full border px-3.5 text-[13px] font-semibold', preset === p ? 'border-accent bg-accent text-onaccent' : 'border-line bg-panel text-muted hover:text-ink')}
            >
              {PERIOD_LABEL[p]}
            </button>
          ))}
        </div>
      </div>
      {preset === 'custom' && (
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <input type="date" className="input w-auto" aria-label="Dari tanggal" value={custom.from} max={today} onChange={(e) => setCustom((c) => ({ ...c, from: e.target.value }))} />
          <span className="text-sm text-muted">sampai</span>
          <input type="date" className="input w-auto" aria-label="Sampai tanggal" value={custom.to} max={today} onChange={(e) => setCustom((c) => ({ ...c, to: e.target.value }))} />
        </div>
      )}
      {error ? (
        <p role="alert" className="err mb-3 text-sm">
          {error}
        </p>
      ) : (
        <p className="mb-3 text-sm text-muted">{subtitle}</p>
      )}

      {built && tab === 'ringkasan' && (
        <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4" aria-label="Angka utama">
          {(
            [
              ['Penjualan bersih', rp(built.summary.revenue)],
              ['Laba kotor', rp(built.summary.profit)],
              ['Transaksi', String(built.summary.count)],
              ['Rata-rata per transaksi', rp(built.summary.avgTicket)],
            ] as const
          ).map(([k, v]) => (
            <div key={k} className="card p-3.5">
              <p className="text-xs text-muted">{k}</p>
              <p className="money mt-0.5 text-lg leading-tight font-extrabold">{v}</p>
            </div>
          ))}
        </div>
      )}

      <Tabs<Tab> tabs={(Object.keys(TAB_LABEL) as Tab[]).map((id) => ({ id, label: TAB_LABEL[id] }))} value={tab} onChange={setTab} />

      {built && (
        <>
          <div className="mb-4 flex flex-wrap items-center gap-2">
            <button type="button" className="btn btn-soft" onClick={() => copy(csvOf(tables), 'Data CSV disalin. Tempel ke Excel atau Google Sheets.')}>
              <LuCopy size={15} /> Salin CSV
            </button>
            {CAN_DOWNLOAD && (
              <button type="button" className="btn btn-soft" onClick={() => downloadText(`${fileBase}.csv`, csvOf(tables))}>
                <LuDownload size={15} /> Unduh CSV
              </button>
            )}
            {CAN_BROWSER_PRINT && (
              <button
                type="button"
                className="btn btn-soft"
                onClick={() => printReport({ storeName: state.settings.storeName, title, subtitle, tables, printedAt: formatDateTime(new Date()) })}
              >
                <LuPrinter size={15} /> Cetak / Simpan PDF
              </button>
            )}
          </div>
          {IS_ARTIFACT && <p className="mb-4 text-xs text-muted">Unduh CSV dan cetak PDF tersedia di versi web (hasil deploy). Di pratinjau ini kamu bisa menyalin CSV.</p>}
          {IS_NATIVE && <p className="mb-4 text-xs text-muted">Unduh CSV membuka menu bagikan Android (simpan ke Drive, kirim lewat WhatsApp, atau buka di Excel). Cetak PDF belum tersedia di aplikasi.</p>}
          {tables.map((t) => (
            <TableView key={t.title} t={t} />
          ))}
        </>
      )}
    </>
  );
}
