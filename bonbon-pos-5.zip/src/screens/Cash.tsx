import { useMemo, useState } from 'react';
import { LuArrowDownToLine, LuArrowUpFromLine, LuCopy, LuLock, LuWallet } from 'react-icons/lu';
import { formatDateTime, formatRupiah, formatTime } from '../core/format';
import { addCashMove, closeShift, openShift, shiftDataOf, shiftSummaryOf, shiftText, summarizeShift } from '../core/shifts';
import type { CashMove, Shift, ShiftSummary } from '../core/types';
import { METHOD_LABEL } from '../core/types';
import { BonbonMark } from '../app/brand';
import { useAppState, useStore } from '../app/state';
import { EmptyState, Field, Modal, MoneyInput, PageHeader, cx, useAction, useCopy } from '../app/ui';

function diffLabel(d: number): string {
  return d === 0 ? 'Pas' : d > 0 ? `Lebih ${formatRupiah(d)}` : `Kurang ${formatRupiah(-d)}`;
}
function DiffPill({ d }: { d: number }) {
  return <span className={cx('pill', d === 0 ? 'pill-good' : d > 0 ? 'pill-warn' : 'pill-bad')}>{diffLabel(d)}</span>;
}

/** The drawer arithmetic, one line per part, so it can be checked by eye. */
function DrawerBreakdown({ s }: { s: ShiftSummary }) {
  const c = s.cash;
  const rows: [string, number, '+' | '-' | ''][] = [
    ['Uang awal', c.opening, ''],
    ['Penjualan tunai', c.sales, '+'],
  ];
  if (c.debtPayments) rows.push(['Cicilan kasbon tunai', c.debtPayments, '+']);
  if (c.moneyIn) rows.push(['Uang masuk', c.moneyIn, '+']);
  if (c.refunds) rows.push(['Void dan retur tunai', c.refunds, '-']);
  if (c.moneyOut) rows.push(['Uang keluar', c.moneyOut, '-']);
  return (
    <dl className="grid gap-1.5 text-sm">
      {rows.map(([label, v, sign]) => (
        <div key={label} className="flex justify-between gap-3">
          <dt className="text-muted">{label}</dt>
          <dd className="money">
            {sign}
            {formatRupiah(v)}
          </dd>
        </div>
      ))}
      <div className="flex justify-between gap-3 border-t border-dashed border-line pt-2 font-semibold">
        <dt>Seharusnya di laci</dt>
        <dd className="money">{formatRupiah(c.expected)}</dd>
      </div>
    </dl>
  );
}

function MethodList({ s }: { s: ShiftSummary }) {
  if (s.methods.length === 0) return <p className="text-sm text-muted">Belum ada uang diterima.</p>;
  return (
    <ul className="divide-y divide-line text-sm">
      {s.methods.map((m) => (
        <li key={m.method} className="flex items-baseline justify-between gap-3 py-2">
          <span>{METHOD_LABEL[m.method]}</span>
          <span className="money font-semibold">{formatRupiah(m.net)}</span>
        </li>
      ))}
    </ul>
  );
}

// ---- dialogs ----------------------------------------------------------------------------

function OpenDialog({ suggested, onClose }: { suggested: number; onClose: () => void }) {
  const store = useStore();
  const { busy, run } = useAction();
  const [cash, setCash] = useState<number | null>(suggested);
  const [note, setNote] = useState('');
  const submit = async () => {
    if (cash === null) return;
    const s = await run(() => openShift(store, { openingCash: cash, note }), 'Kas laci dibuka.');
    if (s) onClose();
  };
  return (
    <Modal
      title="Buka kas laci"
      size="sm"
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>
            Batal
          </button>
          <button type="button" className="btn btn-primary" onClick={submit} disabled={busy || cash === null}>
            Buka kas
          </button>
        </>
      }
    >
      <p className="mb-3 text-sm text-muted">Hitung uang yang ada di laci sekarang (modal receh), lalu isi di bawah. Angka ini jadi patokan saat menutup kas nanti.</p>
      <Field label="Uang di laci sekarang">
        <MoneyInput value={cash} onChange={setCash} autoFocus onEnter={submit} aria-label="Uang awal di laci" />
      </Field>
      <Field label="Catatan (boleh kosong)" className="mt-3">
        <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Mis. shift pagi" />
      </Field>
    </Modal>
  );
}

function MoveDialog({ type, onClose }: { type: 'in' | 'out'; onClose: () => void }) {
  const store = useStore();
  const { busy, run } = useAction();
  const [amount, setAmount] = useState<number | null>(null);
  const [note, setNote] = useState('');
  const out = type === 'out';
  const quick = out ? ['Beli barang', 'Bayar supplier', 'Ambil untuk pribadi', 'Beli plastik/perlengkapan'] : ['Tambah uang kembalian', 'Setoran modal', 'Pinjam sementara'];
  const submit = async () => {
    if (amount === null) return;
    const m = await run(() => addCashMove(store, { type, amount, note }), out ? 'Uang keluar dicatat.' : 'Uang masuk dicatat.');
    if (m) onClose();
  };
  return (
    <Modal
      title={out ? 'Uang keluar dari laci' : 'Uang masuk ke laci'}
      size="sm"
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>
            Batal
          </button>
          <button type="button" className="btn btn-primary" onClick={submit} disabled={busy || amount === null || amount <= 0}>
            Catat
          </button>
        </>
      }
    >
      <p className="mb-3 text-sm text-muted">
        {out ? 'Catat uang laci yang dipakai di luar penjualan, supaya hitungan kas tidak selisih.' : 'Catat uang yang kamu masukkan ke laci di luar penjualan.'}
      </p>
      <Field label="Jumlah">
        <MoneyInput value={amount} onChange={setAmount} autoFocus aria-label="Jumlah uang" />
      </Field>
      <div className="my-3 flex flex-wrap gap-2">
        {quick.map((q) => (
          <button key={q} type="button" onClick={() => setNote(q)} className={cx('min-h-9 rounded-full border px-3 text-[13px] font-semibold', note === q ? 'border-accent bg-accentsoft text-accent' : 'border-line bg-panel text-muted hover:text-ink')}>
            {q}
          </button>
        ))}
      </div>
      <Field label="Keterangan (wajib)">
        <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder={out ? 'Untuk apa uang ini?' : 'Dari mana uang ini?'} onKeyDown={(e) => e.key === 'Enter' && submit()} />
      </Field>
    </Modal>
  );
}

function CloseDialog({ summary, onClose }: { summary: ShiftSummary; onClose: () => void }) {
  const store = useStore();
  const { busy, run } = useAction();
  const [counted, setCounted] = useState<number | null>(null);
  const [note, setNote] = useState('');
  const diff = counted === null ? null : counted - summary.cash.expected;
  const blocked = summary.pending > 0;
  const submit = async () => {
    if (counted === null) return;
    const s = await run(() => closeShift(store, { countedCash: counted, note }), 'Kas laci ditutup.');
    if (s) onClose();
  };
  return (
    <Modal
      title="Tutup kas laci"
      size="sm"
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>
            Batal
          </button>
          <button type="button" className="btn btn-primary" onClick={submit} disabled={busy || counted === null}>
            Tutup kas
          </button>
        </>
      }
    >
      <p className="mb-3 text-sm text-muted">Hitung seluruh uang tunai di laci, lalu isi jumlahnya. Aplikasi membandingkan dengan yang seharusnya ada.</p>
      {blocked && (
        <p role="alert" className="mb-3 rounded-md bg-warnsoft px-3 py-2 text-sm text-warn">
          Ada pembayaran {formatRupiah(summary.pending)} yang masih menunggu konfirmasi. Konfirmasi dulu di Riwayat sebelum menutup kas.
        </p>
      )}
      <div className="mb-3 flex justify-between text-sm">
        <span className="text-muted">Seharusnya di laci</span>
        <strong className="money">{formatRupiah(summary.cash.expected)}</strong>
      </div>
      <Field label="Uang yang dihitung">
        <MoneyInput value={counted} onChange={setCounted} autoFocus onEnter={submit} aria-label="Uang yang dihitung" />
      </Field>
      <p className="mt-2 min-h-6 text-sm" aria-live="polite">
        {diff !== null && (
          <>
            Selisih: <DiffPill d={diff} />
          </>
        )}
      </p>
      <Field label="Catatan (boleh kosong)" className="mt-2">
        <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Mis. kurang receh Rp 500" />
      </Field>
    </Modal>
  );
}

function ShiftDetail({ shift, onClose }: { shift: Shift; onClose: () => void }) {
  const state = useAppState();
  const copy = useCopy();
  const s = shiftSummaryOf(shift, shiftDataOf(state));
  const moves = state.cashMoves.filter((m) => m.shiftId === shift.id).slice().reverse();
  return (
    <Modal
      title={`Kas ${formatDateTime(shift.openedAt)}`}
      onClose={onClose}
      footer={
        <button type="button" className="btn btn-soft" onClick={() => copy(shiftText(shift, s, state.settings.storeName), 'Rekap kas disalin.')}>
          <LuCopy size={15} /> Salin rekap
        </button>
      }
    >
      <p className="mb-3 text-sm text-muted">
        {formatDateTime(shift.openedAt)} {shift.closedAt ? `sampai ${formatTime(shift.closedAt)}` : ''}
        {shift.note ? ` · ${shift.note}` : ''}
      </p>
      <p className="mb-1 text-sm">
        Penjualan: <strong>{s.salesCount} transaksi</strong>, <span className="money">{formatRupiah(s.salesTotal)}</span>
        {s.voidCount > 0 && ` · ${s.voidCount} void`}
        {s.returnCount > 0 && ` · ${s.returnCount} retur`}
      </p>
      {s.kasbonSales > 0 && <p className="mb-3 text-xs text-muted">Termasuk kasbon {formatRupiah(s.kasbonSales)} yang belum diterima.</p>}
      <h3 className="mt-4 mb-2 text-sm font-bold">Uang tunai di laci</h3>
      <DrawerBreakdown s={s} />
      {shift.countedCash !== undefined && (
        <dl className="mt-2 grid gap-1.5 text-sm">
          <div className="flex justify-between gap-3">
            <dt className="text-muted">Dihitung</dt>
            <dd className="money">{formatRupiah(shift.countedCash)}</dd>
          </div>
          <div className="flex items-center justify-between gap-3">
            <dt className="text-muted">Selisih</dt>
            <dd>
              <DiffPill d={shift.difference ?? 0} />
            </dd>
          </div>
        </dl>
      )}
      {shift.closeNote && <p className="mt-2 text-sm text-muted">Catatan: {shift.closeNote}</p>}
      <h3 className="mt-4 mb-1 text-sm font-bold">Uang diterima per metode</h3>
      <MethodList s={s} />
      {moves.length > 0 && (
        <>
          <h3 className="mt-4 mb-1 text-sm font-bold">Uang masuk dan keluar</h3>
          <MoveList moves={moves} />
        </>
      )}
    </Modal>
  );
}

function MoveList({ moves }: { moves: CashMove[] }) {
  return (
    <ul className="divide-y divide-line text-sm">
      {moves.map((m) => (
        <li key={m.id} className="flex items-start justify-between gap-3 py-2">
          <span className="min-w-0">
            <span className="block">{m.note}</span>
            <span className="block text-xs text-muted">{formatTime(m.createdAt)}</span>
          </span>
          <span className={cx('money shrink-0 font-semibold', m.type === 'in' ? 'text-good' : 'text-bad')}>
            {m.type === 'in' ? '+' : '-'}
            {formatRupiah(m.amount)}
          </span>
        </li>
      ))}
    </ul>
  );
}

// ---- screen -----------------------------------------------------------------------------

export function CashScreen() {
  const state = useAppState();
  const [opening, setOpening] = useState(false);
  const [closing, setClosing] = useState(false);
  const [moving, setMoving] = useState<'in' | 'out' | null>(null);
  const [detail, setDetail] = useState<string | null>(null);
  const [limit, setLimit] = useState(40);

  const open = state.openShift;
  const data = useMemo(() => shiftDataOf(state), [state]);
  const live = useMemo(() => (open ? summarizeShift(open, data) : null), [open, data]);
  const closed = state.shifts.filter((s) => s.status === 'closed');
  const lastCounted = closed[0]?.countedCash ?? 0;
  const moves = open ? state.cashMoves.filter((m) => m.shiftId === open.id) : [];
  const detailShift = detail ? state.shiftsById.get(detail) : undefined;

  return (
    <>
      <PageHeader
        title="Kas Laci"
        subtitle={state.settings.requireShift ? 'Kasir hanya bisa berjualan saat kas dibuka.' : 'Cek uang tunai di laci: buka di awal, tutup di akhir hari, lihat selisihnya.'}
      />

      {!open || !live ? (
        <div className="card mb-5">
          <EmptyState
            icon={<LuWallet size={22} />}
            title="Kas laci belum dibuka"
            action={
              <button type="button" className="btn btn-primary" onClick={() => setOpening(true)}>
                Buka kas
              </button>
            }
          >
            Buka kas dengan mengisi uang receh yang ada di laci. Fitur ini opsional, kamu tetap bisa berjualan tanpa membukanya{state.settings.requireShift ? ' kecuali pengaturan Wajib buka kas dinyalakan' : ''}.
          </EmptyState>
        </div>
      ) : (
        <>
          <section aria-label="Kas berjalan" className="hero relative mb-4 overflow-hidden rounded-3xl p-5 shadow-[0_14px_36px_rgb(69_64_216/0.28)] sm:p-6">
            <BonbonMark className="pointer-events-none absolute -right-8 -bottom-10 h-48 w-auto text-onhero opacity-[0.1]" />
            <div className="relative">
              <p className="text-[13px] font-semibold">
                Dibuka {formatDateTime(open.openedAt)}
                {open.note ? ` · ${open.note}` : ''}
              </p>
              <p className="mt-3 text-sm font-medium">Uang di laci seharusnya</p>
              <p className="money mt-1 text-[38px] leading-none font-extrabold break-words sm:text-[44px]" aria-live="polite">
                {formatRupiah(live.cash.expected)}
              </p>
              {live.pending > 0 && (
                <p className="mt-3 rounded-xl bg-white/15 px-3 py-2 text-[13px] font-semibold">Ada pembayaran {formatRupiah(live.pending)} yang menunggu konfirmasi (belum dihitung).</p>
              )}
              <div className="mt-5 grid grid-cols-2 gap-2 sm:max-w-md">
                <button type="button" className="btn border border-white/40 bg-white/15 text-onhero hover:bg-white/25" onClick={() => setMoving('in')}>
                  <LuArrowDownToLine size={16} /> Uang masuk
                </button>
                <button type="button" className="btn border border-white/40 bg-white/15 text-onhero hover:bg-white/25" onClick={() => setMoving('out')}>
                  <LuArrowUpFromLine size={16} /> Uang keluar
                </button>
                <button type="button" className="btn btn-white col-span-2" onClick={() => setClosing(true)}>
                  <LuLock size={16} /> Tutup kas
                </button>
              </div>
            </div>
          </section>

          <div className="mb-4 grid gap-4 md:grid-cols-2">
            <section className="card p-4" aria-label="Hitungan uang tunai">
              <h2 className="mb-3 text-sm font-bold">Hitungan uang tunai</h2>
              <DrawerBreakdown s={live} />
            </section>
            <section className="card p-4" aria-label="Uang diterima per metode">
              <h2 className="mb-1 text-sm font-bold">Uang diterima per metode</h2>
              <MethodList s={live} />
              <p className="mt-2 text-xs text-muted">
                {live.salesCount} transaksi, {formatRupiah(live.salesTotal)}
                {live.kasbonSales > 0 ? ` (kasbon ${formatRupiah(live.kasbonSales)} belum diterima)` : ''}
              </p>
            </section>
          </div>

          {moves.length > 0 && (
            <section className="card mb-4 p-4" aria-label="Uang masuk dan keluar">
              <h2 className="mb-1 text-sm font-bold">Uang masuk dan keluar</h2>
              <MoveList moves={moves} />
            </section>
          )}
        </>
      )}

      <section aria-label="Riwayat kas">
        <h2 className="mb-2 text-sm font-bold">Riwayat kas</h2>
        <div className="card overflow-hidden">
          {closed.length === 0 ? (
            <p className="px-4 py-6 text-center text-sm text-muted">Belum ada kas yang ditutup.</p>
          ) : (
            <ul className="divide-y divide-line">
              {closed.slice(0, limit).map((s) => (
                <li key={s.id}>
                  <button type="button" onClick={() => setDetail(s.id)} className="flex min-h-14 w-full items-center justify-between gap-3 px-4 py-2.5 text-left hover:bg-sunken">
                    <span className="min-w-0">
                      <span className="block text-sm font-semibold">{formatDateTime(s.openedAt)}</span>
                      <span className="money block text-xs text-muted">
                        Dihitung {formatRupiah(s.countedCash ?? 0)} · {s.summary?.salesCount ?? 0} transaksi
                      </span>
                    </span>
                    <DiffPill d={s.difference ?? 0} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
        {closed.length > limit && (
          <div className="mt-3 text-center">
            <button type="button" className="btn btn-ghost" onClick={() => setLimit((n) => n + 40)}>
              Tampilkan lebih banyak ({closed.length - limit} lagi)
            </button>
          </div>
        )}
      </section>

      {opening && <OpenDialog suggested={lastCounted} onClose={() => setOpening(false)} />}
      {closing && live && <CloseDialog summary={live} onClose={() => setClosing(false)} />}
      {moving && <MoveDialog type={moving} onClose={() => setMoving(null)} />}
      {detailShift && <ShiftDetail shift={detailShift} onClose={() => setDetail(null)} />}
    </>
  );
}
