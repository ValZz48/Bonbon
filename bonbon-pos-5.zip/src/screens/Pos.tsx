import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  LuChevronUp,
  LuMessageSquareText,
  LuMinus,
  LuPause,
  LuPackageSearch,
  LuPlus,
  LuScanBarcode,
  LuSearch,
  LuShoppingCart,
  LuTag,
  LuTrash2,
  LuTriangleAlert,
  LuX,
} from 'react-icons/lu';
import type { DiscountSpec } from '../core/calc';
import { roundQty, stockStatus } from '../core/calc';
import { formatNumber, formatQty, formatRupiah } from '../core/format';
import { categoriesOf, filterProducts, findByCode } from '../core/queries';
import type { PaymentInput } from '../core/services';
import { checkout, qtyError } from '../core/services';
import type { Product, Transaction } from '../core/types';
import { checkoutMethods } from '../core/types';
import { type CartRow, useCart, useCartView } from '../app/cart';
import { BarcodeScanner, type ScanHandler } from '../app/BarcodeScanner';
import { useNav } from '../app/nav';
import { ReceiptModal } from '../app/Receipt';
import { useAppState, useStore } from '../app/state';
import { buzz } from '../app/runtime';
import { ConfirmDialog, EmptyState, Modal, NumberInput, StatusPill, catClass, cx, useToast } from '../app/ui';
import { HeldListDialog, HoldDialog, loadHeld } from './Holds';
import { PaymentModal } from './PaymentModal';

// ---- helpers ---------------------------------------------------------------------

const modalOpen = () => document.querySelector('[data-modal]') !== null;

function DiscountEditor({
  value,
  onChange,
  label,
}: {
  value?: DiscountSpec;
  onChange: (d?: DiscountSpec) => void;
  label: string;
}) {
  const type = value?.type ?? 'nominal';
  return (
    <div className="flex items-center gap-2">
      <div className="inline-flex shrink-0 overflow-hidden rounded-md border border-line" role="group" aria-label={`Jenis ${label}`}>
        {(
          [
            ['nominal', 'Rp'],
            ['percent', '%'],
          ] as const
        ).map(([t, text]) => (
          <button
            key={t}
            type="button"
            aria-pressed={type === t}
            onClick={() => onChange({ type: t, value: value?.value ?? 0 })}
            className={cx('min-h-9 min-w-9 px-2.5 text-[13px] font-semibold', type === t ? 'bg-accent text-onaccent' : 'bg-panel text-muted hover:bg-sunken')}
          >
            {text}
          </button>
        ))}
      </div>
      <NumberInput
        className="min-h-9 py-1"
        aria-label={label}
        placeholder="0"
        value={value && value.value > 0 ? value.value : null}
        onChange={(n) => onChange(n && n > 0 ? { type, value: type === 'percent' ? Math.min(n, 100) : Math.round(n) } : undefined)}
      />
    </div>
  );
}

function ProductTile({ p, inCart, disabled, onAdd }: { p: Product; inCart: number; disabled: boolean; onAdd: () => void }) {
  const status = stockStatus(p.stock, p.minStock);
  return (
    <button
      type="button"
      onClick={onAdd}
      disabled={disabled}
      aria-label={`Tambah ${p.name}, ${formatRupiah(p.sellPrice)}, stok ${formatQty(p.stock)} ${p.baseUnit}`}
      className={cx(
        // white card, hairline border; lifts and turns blue-edged on hover, squeezes when pressed
        'group relative flex min-h-[116px] flex-col justify-between gap-2.5 rounded-2xl border bg-panel p-3.5 text-left transition-[transform,box-shadow,border-color] duration-150 ease-out',
        catClass(p.category),
        disabled ? 'border-line opacity-55' : 'border-line hover:-translate-y-0.5 hover:border-accent hover:shadow-[var(--lift)] active:translate-y-0 active:scale-[0.97]',
        inCart > 0 && 'border-accent shadow-[0_0_0_3px_var(--accentsoft)]',
      )}
    >
      {inCart > 0 && (
        <span key={inCart} className="anim-pop num absolute -top-2.5 -right-2 flex min-w-7 items-center justify-center rounded-full bg-accent px-1.5 py-0.5 text-xs font-extrabold text-onaccent shadow-md">
          {formatQty(inCart)}
        </span>
      )}
      <span>
        <span className="mb-1 flex items-center gap-1.5 text-[11px] font-semibold text-muted">
          <span className="cat-dot size-1.5 shrink-0 rounded-full" aria-hidden="true" />
          <span className="truncate">{p.category || 'Tanpa kategori'}</span>
        </span>
        <span className="line-clamp-2 text-[14px] leading-snug font-bold">{p.name}</span>
      </span>
      <span>
        <span className="money block text-[16px] font-extrabold text-accent">{formatRupiah(p.sellPrice)}</span>
        <span className="mt-1 flex items-center justify-between gap-2">
          <span className="text-xs font-medium text-muted">
            {formatQty(p.stock)} {p.baseUnit}
          </span>
          {status !== 'ok' && <StatusPill status={status} />}
        </span>
      </span>
    </button>
  );
}

// ---- cart ------------------------------------------------------------------------

function CartLineView({ row }: { row: CartRow }) {
  const { dispatch } = useCart();
  const state = useAppState();
  const toast = useToast();
  const [open, setOpen] = useState(Boolean(row.line.note) || Boolean(row.line.discount));
  const { line, resolved } = row;
  const p = resolved.product;
  const units = state.unitsByProduct.get(p.id) ?? [];
  const err = qtyError(line.unitName, line.unitQty);

  const canIncrease = () => {
    if (state.settings.allowNegativeStock) return true;
    return row.need + resolved.conversion <= row.stock;
  };

  return (
    <li className="border-b border-line py-3 last:border-b-0">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm leading-snug font-semibold">{p.name}</p>
          <p className="money text-xs text-muted">
            {formatRupiah(resolved.unitPrice)} / {resolved.unitName}
          </p>
        </div>
        <div className="text-right">
          <p className="money text-sm font-bold">{formatRupiah(row.net)}</p>
          {row.lineDiscount > 0 && <p className="money text-xs text-good">-{formatNumber(row.lineDiscount)}</p>}
        </div>
      </div>

      <div className="mt-2 flex items-center gap-2">
        <div className="inline-flex items-center gap-1">
          <button
            type="button"
            className="btn-icon size-9"
            aria-label={`Kurangi ${p.name}`}
            onClick={() => {
              const next = roundQty(line.unitQty - 1);
              if (next <= 0) dispatch({ type: 'remove', key: line.key });
              else dispatch({ type: 'qty', key: line.key, qty: next });
            }}
          >
            <LuMinus size={15} />
          </button>
          <NumberInput
            className={cx('min-h-9 w-14 px-1 py-1 text-center', err && 'input-invalid')}
            aria-label={`Jumlah ${p.name}`}
            value={line.unitQty}
            onChange={(n) => {
              if (n !== null) dispatch({ type: 'qty', key: line.key, qty: n });
            }}
          />
          <button
            type="button"
            className="btn-icon size-9"
            aria-label={`Tambah ${p.name}`}
            onClick={() => {
              if (!canIncrease()) {
                toast(`Stok ${p.name} hanya ${formatQty(row.stock)} ${p.baseUnit}.`, 'err');
                return;
              }
              dispatch({ type: 'qty', key: line.key, qty: roundQty(line.unitQty + 1) });
            }}
          >
            <LuPlus size={15} />
          </button>
        </div>

        {units.length > 0 ? (
          <select
            className="input min-h-9 w-24 min-w-0 py-1 pr-6 pl-2 text-[13px]"
            aria-label={`Satuan ${p.name}`}
            value={line.unitName}
            onChange={(e) => dispatch({ type: 'unit', key: line.key, unitName: e.target.value })}
          >
            <option value={p.baseUnit}>{p.baseUnit}</option>
            {units.map((u) => (
              <option key={u.id} value={u.unitName}>
                {u.unitName} (isi {formatQty(u.conversion)})
              </option>
            ))}
          </select>
        ) : (
          <span className="text-[13px] text-muted">{resolved.unitName}</span>
        )}

        <span className="ml-auto inline-flex items-center gap-1">
          <button
            type="button"
            className={cx('btn-icon size-9', open && 'border-accent text-accent')}
            aria-label="Diskon dan catatan"
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            <LuTag size={15} />
          </button>
          <button type="button" className="btn-icon size-9" aria-label={`Hapus ${p.name}`} onClick={() => dispatch({ type: 'remove', key: line.key })}>
            <LuTrash2 size={15} />
          </button>
        </span>
      </div>

      {err && <p className="err">{err}</p>}
      {!err && row.overStock && (
        <p className={cx('mt-1.5 flex items-center gap-1.5 text-xs font-medium', state.settings.allowNegativeStock ? 'text-warn' : 'text-bad')}>
          <LuTriangleAlert size={14} />
          Melebihi stok. Tersisa {formatQty(row.stock)} {p.baseUnit}
          {state.settings.allowNegativeStock ? ' (stok akan minus).' : '.'}
        </p>
      )}

      {open && (
        <div className="mt-3 grid gap-2 rounded-xl bg-sunken p-3">
          <div>
            <span className="label">Diskon item</span>
            <DiscountEditor label={`Diskon ${p.name}`} value={line.discount} onChange={(d) => dispatch({ type: 'lineDiscount', key: line.key, discount: d })} />
          </div>
          <label className="block">
            <span className="label">Catatan</span>
            <div className="relative">
              <LuMessageSquareText className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-faint" size={15} />
              <input
                className="input min-h-9 py-1 pl-9"
                placeholder="Mis. tanpa kantong"
                value={line.note ?? ''}
                onChange={(e) => dispatch({ type: 'note', key: line.key, note: e.target.value })}
              />
            </div>
          </label>
        </div>
      )}
    </li>
  );
}

function CartPanel({ onPay, onClear, onHold, className, sheet = false }: { onPay: () => void; onClear: () => void; onHold: () => void; className?: string; sheet?: boolean }) {
  const view = useCartView();
  const { cart, dispatch } = useCart();
  const state = useAppState();
  const [discOpen, setDiscOpen] = useState(Boolean(cart.discount));
  const t = view.totals;
  const qtyProblem = view.rows.some((r) => qtyError(r.line.unitName, r.line.unitQty));
  const cannotPay = view.rows.length === 0 || view.blocked || qtyProblem || view.stale;

  return (
    <section
      className={cx(sheet ? 'flex min-h-0 flex-col' : 'card flex min-h-0 flex-col', sheet && 'short:grid short:min-h-0 short:grid-cols-[minmax(0,1fr)_17rem] short:grid-rows-[auto_minmax(0,1fr)]', className)}
      aria-label="Keranjang"
    >
      <header className={cx('flex items-center justify-between gap-3 border-b border-line px-4 py-3', sheet && 'short:col-span-2')}>
        <h2 className="flex items-center gap-2 text-base font-bold">
          <span className="icon-box size-8">
            <LuShoppingCart size={16} aria-hidden="true" />
          </span>
          <span className={sheet ? 'sr-only' : undefined}>Keranjang</span>
          {view.itemCount > 0 && <span className="pill pill-info">{view.itemCount} item</span>}
        </h2>
        {view.itemCount > 0 && (
          <span className="flex items-center gap-1">
            <button type="button" className="btn btn-ghost btn-sm" onClick={onHold}>
              <LuPause size={14} aria-hidden="true" /> Tahan
            </button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={onClear}>
              Kosongkan
            </button>
          </span>
        )}
      </header>

      <div className={cx('scroll-y min-h-[96px] flex-1 px-4', sheet && 'short:min-h-0')}>
        {view.rows.length === 0 ? (
          <EmptyState icon={<LuPackageSearch size={22} />} title="Keranjang kosong">
            Pilih produk, atau tekan Scan untuk memindai barcode dengan kamera.
          </EmptyState>
        ) : (
          <ul>
            {view.rows.map((r) => (
              <CartLineView key={r.line.key} row={r} />
            ))}
          </ul>
        )}
      </div>

      <footer
        className={cx(
          'shrink-0 border-t border-line px-4 pt-3 pb-[calc(1rem+env(safe-area-inset-bottom,0px))] lg:pb-4',
          sheet && 'short:col-start-2 short:row-start-2 short:overflow-y-auto short:border-t-0 short:border-l',
        )}
      >
        {view.stale && <p className="err mb-2">Ada produk di keranjang yang sudah tidak aktif. Hapus dulu.</p>}
        <div className="mb-2">
          <button type="button" className="inline-flex min-h-9 items-center gap-1.5 text-[13px] font-semibold text-accent" onClick={() => setDiscOpen((v) => !v)} aria-expanded={discOpen}>
            <LuTag size={14} /> {cart.discount ? 'Ubah diskon transaksi' : 'Diskon transaksi'}
          </button>
          {discOpen && (
            <div className="mt-1">
              <DiscountEditor label="Diskon transaksi" value={cart.discount} onChange={(d) => dispatch({ type: 'cartDiscount', discount: d })} />
            </div>
          )}
        </div>

        <dl className="grid gap-1 text-sm">
          <div className="flex justify-between">
            <dt className="text-muted">Subtotal</dt>
            <dd className="money">{formatRupiah(t.subtotal)}</dd>
          </div>
          {t.discount > 0 && (
            <div className="flex justify-between">
              <dt className="text-muted">Diskon</dt>
              <dd className="money text-good">-{formatRupiah(t.discount)}</dd>
            </div>
          )}
          {t.tax > 0 && (
            <div className="flex justify-between">
              <dt className="text-muted">PPN {state.settings.taxPercent}%</dt>
              <dd className="money">{formatRupiah(t.tax)}</dd>
            </div>
          )}
          {t.rounding !== 0 && (
            <div className="flex justify-between">
              <dt className="text-muted">Pembulatan</dt>
              <dd className="money">{t.rounding > 0 ? '+' : '-'}{formatNumber(Math.abs(t.rounding))}</dd>
            </div>
          )}
        </dl>
        <div className="mt-2 mb-3 flex items-baseline justify-between border-t border-dashed border-line pt-2">
          <span className="text-sm font-semibold">Total</span>
          <span className="money text-[32px] leading-none font-extrabold" aria-live="polite">
            <span key={t.total} className="anim-tick inline-block">
              {formatRupiah(t.total)}
            </span>
          </span>
        </div>
        <button type="button" className="btn btn-primary h-14 w-full text-base font-extrabold" disabled={cannotPay} onClick={onPay}>
          Bayar
          <kbd className="ml-1 hidden rounded border border-current/40 px-1.5 py-0.5 font-mono text-[11px] font-medium opacity-80 lg:inline">F2</kbd>
        </button>
      </footer>
    </section>
  );
}

// ---- screen ----------------------------------------------------------------------

export function PosScreen() {
  const state = useAppState();
  const store = useStore();
  const toast = useToast();
  const nav = useNav();
  const { cart, dispatch, nextKey } = useCart();
  const view = useCartView();

  const [q, setQ] = useState('');
  const [category, setCategory] = useState('');
  const [paying, setPaying] = useState(false);
  const [sheet, setSheet] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [holding, setHolding] = useState(false);
  const [heldList, setHeldList] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [receipt, setReceipt] = useState<Transaction | null>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  const categories = useMemo(() => categoriesOf(state), [state]);
  const products = useMemo(() => filterProducts(state, { q, category }), [state, q, category]);
  const inCart = useMemo(() => {
    const m = new Map<string, number>();
    for (const r of view.rows) m.set(r.resolved.product.id, roundQty((m.get(r.resolved.product.id) ?? 0) + r.line.unitQty));
    return m;
  }, [view.rows]);

  const focusSearch = useCallback(() => {
    if (window.matchMedia?.('(pointer: fine)').matches) searchRef.current?.focus();
  }, []);
  useEffect(focusSearch, [focusSearch]);

  /** Adds one base unit of the product, or returns why it cannot be added. */
  const tryAdd = useCallback(
    (p: Product): string | null => {
      const need = view.rows.filter((r) => r.resolved.product.id === p.id).reduce((s, r) => s + r.resolved.baseQty, 0);
      if (!state.settings.allowNegativeStock && need + 1 > p.stock) {
        return p.stock <= 0 ? `${p.name} habis.` : `Stok ${p.name} hanya ${formatQty(p.stock)} ${p.baseUnit}.`;
      }
      dispatch({ type: 'add', key: nextKey(), productId: p.id, unitName: p.baseUnit });
      buzz(10);
      return null;
    },
    [dispatch, nextKey, state.settings.allowNegativeStock, view.rows],
  );

  const add = useCallback(
    (p: Product) => {
      const why = tryAdd(p);
      if (why) toast(why, 'err');
      return why === null;
    },
    [toast, tryAdd],
  );

  /** One code from the camera scanner: add the matching product, or say plainly why not. */
  const onScan: ScanHandler = (code) => {
    const p = findByCode(state, code);
    if (!p) return { tone: 'err', message: `Barcode ${code} belum terdaftar. Tambahkan lewat menu Produk.` };
    const why = tryAdd(p);
    if (why) return { tone: 'err', message: why };
    return { tone: 'ok', message: `${p.name} ditambahkan (${formatRupiah(p.sellPrice)})` };
  };

  const onSearchEnter = () => {
    const code = q.trim();
    if (!code) return;
    const exact = findByCode(state, code);
    const target = exact ?? (products.length === 1 ? products[0] : undefined);
    if (target) {
      if (add(target)) setQ('');
    } else if (products.length === 0) {
      toast(`Produk "${code}" tidak ditemukan.`, 'err');
    }
  };

  const shiftBlocked = state.settings.requireShift && !state.openShift;
  const startPay = useCallback(() => {
    if (shiftBlocked) {
      toast('Buka kas laci dulu sebelum berjualan.', 'err');
      nav.go('kas');
      return;
    }
    setPaying(true);
  }, [shiftBlocked, toast, nav]);

  const canPay = view.rows.length > 0 && !view.blocked && !view.stale && !view.rows.some((r) => qtyError(r.line.unitName, r.line.unitQty));

  // F2 = bayar, Esc = batal
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (modalOpen()) return;
      if (e.key === 'F2') {
        e.preventDefault();
        if (canPay) startPay();
        else if (view.rows.length === 0) toast('Keranjang masih kosong.', 'err');
      } else if (e.key === 'Escape') {
        if (q) setQ('');
        else if (view.rows.length > 0) setConfirmClear(true);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [canPay, q, toast, view.rows.length, startPay]);

  const submit = async (payments: PaymentInput[]) => {
    const tx = await checkout(store, {
      lines: cart.lines.map(({ key: _key, ...l }) => l),
      cartDiscount: cart.discount,
      payments,
    });
    dispatch({ type: 'clear' });
    setPaying(false);
    setSheet(false);
    setReceipt(tx);
  };

  if (state.products.filter((p) => p.active).length === 0) {
    return (
      <div className="card">
        <EmptyState
          icon={<LuPackageSearch size={22} />}
          title="Belum ada produk"
          action={
            <button type="button" className="btn btn-primary" onClick={() => nav.go('produk')}>
              Tambah produk
            </button>
          }
        >
          Tambahkan produk dan stoknya dulu, atau isi data contoh dari halaman Pengaturan.
        </EmptyState>
      </div>
    );
  }

  return (
    <>
      <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,1fr)_390px] xl:grid-cols-[minmax(0,1fr)_420px]">
        <section aria-label="Daftar produk" className="min-w-0 pb-24 lg:pb-0">
          {shiftBlocked && (
            <div role="status" className="mb-3 flex flex-wrap items-center justify-between gap-2 rounded-lg bg-warnsoft px-4 py-3 text-sm font-medium text-warn">
              <span>Kas laci belum dibuka. Buka dulu supaya transaksi bisa dibayar.</span>
              <button type="button" className="btn btn-primary btn-sm" onClick={() => nav.go('kas')}>
                Buka kas
              </button>
            </div>
          )}
          <div className="mb-3 flex gap-2">
            <div className="relative min-w-0 flex-1">
              <LuSearch className="pointer-events-none absolute top-1/2 left-3.5 -translate-y-1/2 text-faint" size={18} />
              <input
                ref={searchRef}
                className="input h-12 pr-11 pl-11 text-[15px]"
                placeholder="Cari produk"
                aria-label="Cari produk atau scan barcode"
                value={q}
                autoComplete="off"
                onChange={(e) => setQ(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    onSearchEnter();
                  }
                }}
              />
              {q && (
                <button type="button" className="btn-icon absolute top-1/2 right-1.5 size-9 -translate-y-1/2 border-transparent" aria-label="Hapus pencarian" onClick={() => { setQ(''); focusSearch(); }}>
                  <LuX size={16} />
                </button>
              )}
            </div>
            <button type="button" className="btn btn-soft h-12 shrink-0 px-4" onClick={() => setScanning(true)} aria-label="Scan barcode dengan kamera">
              <LuScanBarcode size={20} aria-hidden="true" /> Scan
            </button>
            {state.holds.length > 0 && (
              <button type="button" className="btn btn-soft relative h-12 shrink-0 px-3.5" onClick={() => setHeldList(true)} aria-label={`Keranjang tertahan, ${state.holds.length}`}>
                <LuPause size={20} aria-hidden="true" />
                <span className="money absolute -top-1.5 -right-1.5 min-w-5 rounded-full bg-warn px-1 text-center text-[11px] leading-5 font-bold text-canvas">{state.holds.length}</span>
              </button>
            )}
          </div>

          <div className="-mx-1 mb-3 flex gap-2 overflow-x-auto px-1 pb-1" role="group" aria-label="Kategori">
            {['', ...categories].map((c) => (
              <button
                key={c || 'all'}
                type="button"
                aria-pressed={category === c}
                onClick={() => setCategory(c)}
                className={cx(
                  'min-h-9 shrink-0 rounded-full border px-3.5 text-[13px] font-semibold transition-colors',
                  category === c ? 'border-accent bg-accent text-onaccent' : 'border-line bg-panel text-muted hover:text-ink',
                )}
              >
                {c || 'Semua'}
              </button>
            ))}
          </div>

          {products.length === 0 ? (
            <div className="card">
              <EmptyState icon={<LuSearch size={22} />} title="Produk tidak ditemukan">
                Coba kata kunci lain atau pilih kategori Semua.
              </EmptyState>
            </div>
          ) : (
            <div className="grid grid-cols-[repeat(auto-fill,minmax(148px,1fr))] gap-3">
              {products.map((p) => (
                <ProductTile
                  key={p.id}
                  p={p}
                  inCart={inCart.get(p.id) ?? 0}
                  disabled={!state.settings.allowNegativeStock && p.stock <= 0}
                  onAdd={() => {
                    add(p);
                    focusSearch();
                  }}
                />
              ))}
            </div>
          )}
        </section>

        <aside className="sticky top-4 hidden max-h-[calc(100dvh-2rem)] lg:flex lg:flex-col">
          <CartPanel className="max-h-[calc(100dvh-2rem)]" onPay={startPay} onClear={() => setConfirmClear(true)} onHold={() => setHolding(true)} />
        </aside>
      </div>

      {/* phone / small tablet: summary bar that opens the cart sheet */}
      <div className="fixed inset-x-0 bottom-[calc(env(safe-area-inset-bottom,0px)+84px)] z-30 pl-[max(16px,env(safe-area-inset-left,0px))] pr-[max(16px,env(safe-area-inset-right,0px))] lg:hidden">
        <button
          type="button"
          onClick={() => setSheet(true)}
          className="flex min-h-14 w-full items-center justify-between gap-3 rounded-xl bg-accent px-4 text-onaccent shadow-lg"
          aria-label="Buka keranjang"
        >
          <span className="flex items-center gap-2 text-sm font-semibold">
            <LuShoppingCart size={18} /> {view.itemCount} item
            <LuChevronUp size={16} />
          </span>
          <span className="money text-lg font-extrabold">{formatRupiah(view.totals.total)}</span>
        </button>
      </div>

      {sheet && (
        <Modal title="Keranjang" flush focusFirstField={false} onClose={() => setSheet(false)}>
          {/* The list scrolls inside the sheet; total and Bayar stay pinned at the bottom. */}
          <CartPanel
            sheet
            className="min-h-[22rem] flex-1 rounded-none border-0 short:min-h-0"
            onPay={() => {
              setSheet(false);
              startPay();
            }}
            onClear={() => setConfirmClear(true)}
            onHold={() => setHolding(true)}
          />
        </Modal>
      )}

      {holding && (
        <HoldDialog
          cart={cart}
          onClose={() => setHolding(false)}
          onDone={() => {
            dispatch({ type: 'clear' });
            setHolding(false);
            setSheet(false);
            focusSearch();
          }}
        />
      )}

      {heldList && (
        <HeldListDialog
          cart={cart}
          onClose={() => setHeldList(false)}
          onResume={(h) => {
            dispatch({ type: 'load', ...loadHeld(h, nextKey) });
            setHeldList(false);
            toast('Keranjang dilanjutkan.');
          }}
        />
      )}

      {scanning && <BarcodeScanner title="Scan barang" onCode={onScan} onClose={() => { setScanning(false); focusSearch(); }} />}

      {paying && (
        <PaymentModal
          total={view.totals.total}
          methods={checkoutMethods(state.settings)}
          onClose={() => setPaying(false)}
          onSubmit={submit}
        />
      )}

      {confirmClear && (
        <ConfirmDialog
          title="Kosongkan keranjang?"
          message="Semua item di keranjang akan dihapus. Stok tidak berubah."
          confirmLabel="Kosongkan"
          danger
          onClose={() => setConfirmClear(false)}
          onConfirm={() => {
            dispatch({ type: 'clear' });
            setConfirmClear(false);
            setSheet(false);
            focusSearch();
          }}
        />
      )}

      {receipt && (
        <ReceiptModal
          tx={receipt}
          settings={state.settings}
          closeLabel="Transaksi baru"
          onClose={() => {
            setReceipt(null);
            setTimeout(focusSearch, 0);
          }}
        />
      )}
    </>
  );
}
