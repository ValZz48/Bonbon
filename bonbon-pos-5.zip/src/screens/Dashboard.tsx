import { type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { LuArrowRight, LuArrowUpRight, LuChartColumn, LuCircleX, LuCreditCard, LuHandCoins, LuInfo, LuReceiptText, LuShieldAlert, LuShieldCheck, LuTrendingUp, LuTrophy, LuTriangleAlert, LuX } from 'react-icons/lu';
import { DEMO_SKUS } from '../core/demo';
import {
  addDaysKey,
  dayLabel,
  formatCompactRupiah,
  formatDateKey,
  formatLongDate,
  formatQty,
  formatRupiah,
  formatTime,
  todayKey,
} from '../core/format';
import type { DaySummary } from '../core/queries';
import { methodReport, productRows } from '../core/reports';
import { METHOD_LABEL } from '../core/types';
import { alertCounts, debtSummary, debtorRows, revenueSeries, stockAlerts, summarizeDay } from '../core/queries';
import { BonbonMark, TAGLINE } from '../app/brand';
import { useNav } from '../app/nav';
import { useBackupStatus } from './Backup';
import { useAppState } from '../app/state';
import { Avatar, EmptyState, Meter, PageHeader, Section, StatusPill, cx } from '../app/ui';

// ---- chart -------------------------------------------------------------------------

function niceCeil(max: number): { top: number; step: number } {
  if (max <= 0) return { top: 4, step: 1 };
  const rough = max / 4;
  const pow = 10 ** Math.floor(Math.log10(rough));
  const step = [1, 2, 2.5, 5, 10].map((m) => m * pow).find((s) => s >= rough) ?? pow * 10;
  return { top: Math.ceil(max / step) * step, step };
}

function useWidth<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  const [w, setW] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    setW(el.clientWidth);
    if (typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(() => setW(el.clientWidth));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return [ref, w] as const;
}

function RevenueChart({ series, today }: { series: DaySummary[]; today: string }) {
  const [wrap, width] = useWidth<HTMLDivElement>();
  const [active, setActive] = useState<number | null>(null);
  const H = 232;
  const m = { top: 22, right: 8, bottom: 38, left: 46 };
  const w = Math.max(width, 280);
  const innerW = w - m.left - m.right;
  const innerH = H - m.top - m.bottom;
  const max = Math.max(...series.map((d) => d.revenue), 0);
  const { top, step } = niceCeil(max);
  const ticks: number[] = [];
  for (let v = 0; v <= top + 1e-9; v += step) ticks.push(v);
  const slot = innerW / series.length;
  const barW = Math.min(24, slot * 0.58);
  const y = (v: number) => m.top + innerH - (v / top) * innerH;
  const maxIdx = series.findIndex((d) => d.revenue === max && max > 0);
  const todayIdx = series.findIndex((d) => d.dateKey === today);

  const bar = (i: number, d: DaySummary) => {
    const x = m.left + slot * i + (slot - barW) / 2;
    const h = (d.revenue / top) * innerH;
    if (h <= 0) return null;
    const r = Math.min(4, h, barW / 2);
    const base = m.top + innerH;
    const yy = base - h;
    return `M${x},${base}V${yy + r}a${r},${r} 0 0 1 ${r},${-r}H${x + barW - r}a${r},${r} 0 0 1 ${r},${r}V${base}Z`;
  };

  const a = active !== null ? series[active] : null;
  const tipLeft = active !== null ? Math.min(Math.max(m.left + slot * active + slot / 2, 90), w - 90) : 0;

  return (
    <div ref={wrap} className="relative" onPointerLeave={() => setActive(null)}>
      {width > 0 && (
        <svg width={w} height={H} role="img" aria-label={`Grafik batang omzet ${series.length} hari terakhir. Hari ini ${formatRupiah(series[todayIdx]?.revenue ?? 0)}.`} className="block">
          {ticks.map((t) => (
            <g key={t}>
              <line x1={m.left} x2={w - m.right} y1={y(t)} y2={y(t)} stroke="var(--line)" strokeWidth={1} strokeDasharray={t === 0 ? undefined : '3 4'} />
              <text x={m.left - 8} y={y(t)} dy="0.32em" textAnchor="end" fontSize={11} fill="var(--muted)" fontFamily="var(--font-ui)">
                {t === 0 ? '0' : formatCompactRupiah(t)}
              </text>
            </g>
          ))}
          {series.map((d, i) => {
            const p = bar(i, d);
            const cx0 = m.left + slot * i + slot / 2;
            const dl = dayLabel(d.dateKey);
            const isToday = d.dateKey === today;
            const label = i === todayIdx || i === maxIdx;
            return (
              <g key={d.dateKey}>
                {p && <path d={p} className="anim-grow" style={{ animationDelay: `${i * 45}ms` }} fill="var(--accent)" opacity={active === null ? (isToday ? 1 : 0.5) : active === i ? 1 : 0.3} />}
                {label && d.revenue > 0 && (
                  <text x={cx0} y={y(d.revenue) - 6} textAnchor="middle" fontSize={11} fontWeight={600} fill="var(--ink)" fontFamily="var(--font-ui)">
                    {formatCompactRupiah(d.revenue)}
                  </text>
                )}
                <text x={cx0} y={H - 20} textAnchor="middle" fontSize={11} fontWeight={isToday ? 700 : 400} fill={isToday ? 'var(--ink)' : 'var(--muted)'} fontFamily="var(--font-ui)">
                  {isToday ? 'Hari ini' : dl.weekday}
                </text>
                <text x={cx0} y={H - 6} textAnchor="middle" fontSize={11} fill="var(--faint)" fontFamily="var(--font-ui)">
                  {dl.day}
                </text>
                <rect
                  x={m.left + slot * i}
                  y={m.top}
                  width={slot}
                  height={innerH + m.bottom - 4}
                  fill="transparent"
                  tabIndex={0}
                  role="img"
                  aria-label={`${formatDateKey(d.dateKey)}: omzet ${formatRupiah(d.revenue)}, ${d.count} transaksi`}
                  onPointerEnter={() => setActive(i)}
                  onPointerMove={() => setActive(i)}
                  onFocus={() => setActive(i)}
                  onBlur={() => setActive(null)}
                />
              </g>
            );
          })}
        </svg>
      )}
      {a && (
        <div className="pointer-events-none absolute z-10 w-44 -translate-x-1/2 rounded-xl border border-line bg-panel px-3 py-2 text-xs shadow-[var(--lift)]" style={{ left: tipLeft, top: 0 }}>
          <p className="text-muted">{formatDateKey(a.dateKey)}</p>
          <p className="money text-base font-bold">{formatRupiah(a.revenue)}</p>
          <p className="text-muted">
            {a.count} transaksi · laba {formatCompactRupiah(a.profit)}
          </p>
        </div>
      )}
    </div>
  );
}

function RevenueTable({ series }: { series: DaySummary[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="th border-b border-line text-left">
            <th className="py-2 pr-3 font-semibold">Tanggal</th>
            <th className="py-2 pr-3 text-right font-semibold">Transaksi</th>
            <th className="py-2 pr-3 text-right font-semibold">Omzet</th>
            <th className="py-2 text-right font-semibold">Laba kotor</th>
          </tr>
        </thead>
        <tbody>
          {series.map((d) => (
            <tr key={d.dateKey} className="border-b border-line last:border-0">
              <td className="py-2 pr-3">{formatDateKey(d.dateKey)}</td>
              <td className="money py-2 pr-3 text-right">{d.count}</td>
              <td className="money py-2 pr-3 text-right">{formatRupiah(d.revenue)}</td>
              <td className="money py-2 text-right">{formatRupiah(d.profit)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ---- screen --------------------------------------------------------------------------

/** One headline number with its icon, label and a line of context. */
function Kpi({ icon, label, value, children, tone, className }: { icon: ReactNode; label: string; value: string; children?: ReactNode; tone?: 'warn' | 'bad' | 'good'; className?: string }) {
  return (
    <div className={cx('card min-w-0 p-4', className)}>
      <div className="flex items-center gap-2.5">
        <span className={cx('icon-box size-9', tone === 'bad' && 'icon-box-bad', tone === 'warn' && 'icon-box-warn', tone === 'good' && 'icon-box-good')}>{icon}</span>
        <p className="text-[13px] font-semibold text-muted">{label}</p>
      </div>
      <p
        className={cx(
          'money mt-3.5 leading-none font-extrabold break-words',
          // longer amounts step down in size so "Rp 1.234.567" stays on one line in a half-width card on a phone
          value.length <= 8 ? 'text-[28px]' : value.length <= 10 ? 'text-[23px]' : 'text-[19px]',
          tone === 'bad' && 'text-bad',
          tone === 'warn' && 'text-warn',
        )}
      >
        {value}
      </p>
      {children && <div className="mt-2.5 text-xs text-muted">{children}</div>}
    </div>
  );
}

function greeting(now = new Date()): string {
  const h = now.getHours();
  return h < 11 ? 'Selamat pagi' : h < 15 ? 'Selamat siang' : h < 18 ? 'Selamat sore' : 'Selamat malam';
}

/** The colour block at the top of Beranda: today's takings first, the week as small bars, one big way to start selling. */
function Hero({ revenue, delta, series, today, onOpen }: { revenue: number; delta: number | null; series: DaySummary[]; today: string; onOpen: () => void }) {
  const state = useAppState();
  const max = Math.max(...series.map((d) => d.revenue), 1);
  return (
    <section aria-label="Ringkasan hari ini" className="hero relative mb-4 overflow-hidden rounded-3xl p-5 shadow-[0_14px_36px_rgb(69_64_216/0.28)] sm:p-6">
      <BonbonMark className="pointer-events-none absolute -right-8 -bottom-10 h-52 w-auto text-onhero opacity-[0.1]" />
      <div className="relative flex flex-wrap items-end justify-between gap-x-6 gap-y-5">
        <div className="min-w-0">
          <p className="text-lg font-medium">{greeting()}!</p>
          <p className="mt-0.5 text-[13px] font-semibold">Omzet hari ini · {state.settings.storeName}</p>
          <p className="money mt-2 text-[38px] leading-none font-extrabold break-words sm:text-[46px]">
            <span key={revenue} className="anim-tick inline-block">
              {formatRupiah(revenue)}
            </span>
          </p>
          <p className="mt-2 flex items-center gap-1 text-[13px] font-semibold">
            {delta === null ? (
              'Belum ada pembanding kemarin'
            ) : (
              <>
                <LuArrowUpRight size={15} className={delta < 0 ? 'rotate-90' : ''} aria-hidden="true" />
                {delta >= 0 ? '+' : ''}
                {delta}% dari kemarin
              </>
            )}
          </p>
        </div>
        <div className="flex w-full items-end justify-between gap-4 sm:w-auto sm:flex-col sm:items-end">
          <div className="flex h-12 items-end gap-1.5" aria-hidden="true">
            {series.map((d, i) => (
              <span
                key={d.dateKey}
                className={cx('anim-grow w-3 rounded-t-md', d.dateKey === today ? 'bg-onhero' : 'bg-onhero/35')}
                style={{ height: `${Math.max(8, Math.round((d.revenue / max) * 100))}%`, animationDelay: `${120 + i * 50}ms` }}
              />
            ))}
          </div>
          <button type="button" className="btn btn-white h-12 px-5 text-[15px] font-extrabold" onClick={onOpen}>
            Buka kasir <LuArrowRight size={18} />
          </button>
        </div>
      </div>
      <p className="relative mt-4 text-[13px] font-medium">{TAGLINE}</p>
    </section>
  );
}

/** Dismissed reminders stay dismissed until the page is reloaded, even when leaving and returning to Beranda. */
const snoozed = { backup: false };

const METHOD_BAR: Record<string, string> = { cash: 'bg-accent', qris: 'bg-accent/60', transfer: 'bg-accent/35', kasbon: 'bg-warn' };

export function DashboardScreen() {
  const state = useAppState();
  const nav = useNav();
  const [showTable, setShowTable] = useState(false);
  const [bannerOff, setBannerOff] = useState(false);
  const [backupOff, setBackupOff] = useState(snoozed.backup);
  const backup = useBackupStatus();

  const today = todayKey();
  const sum = useMemo(() => summarizeDay(state, today), [state, today]);
  const yesterday = useMemo(() => summarizeDay(state, addDaysKey(today, -1)), [state, today]);
  const series = useMemo(() => revenueSeries(state, today, 7), [state, today]);
  const counts = alertCounts(state);
  const alerts = useMemo(() => stockAlerts(state).slice(0, 5), [state]);
  const recent = state.transactions.slice(0, 5);
  const debt = useMemo(() => debtSummary(state, today), [state, today]);
  const topDebtors = useMemo(() => debtorRows(state, today).filter((r) => r.balance > 0).slice(0, 3), [state, today]);
  const top = useMemo(() => productRows(state, { from: today, to: today }).filter((r) => r.revenue > 0).slice(0, 5), [state, today]);
  const methods = useMemo(() => methodReport(state, { from: today, to: today }), [state, today]);
  const hasDemo = state.products.some((p) => DEMO_SKUS.includes(p.sku));

  const delta = yesterday.revenue > 0 ? Math.round(((sum.revenue - yesterday.revenue) / yesterday.revenue) * 100) : null;
  const margin = sum.revenue > 0 ? Math.round((sum.profit / sum.revenue) * 100) : null;
  const weekTotal = series.reduce((s, d) => s + d.revenue, 0);
  const avgTicket = sum.count > 0 ? Math.round(sum.revenue / sum.count) : 0;
  const activeProducts = state.products.filter((p) => p.active).length;
  const topMax = top[0]?.revenue ?? 0;

  // payment mix of today's sales: money received per method, plus what went on kasbon
  const mix = [...methods.rows.filter((r) => r.sales > 0).map((r) => ({ key: r.method as string, label: r.label, amount: r.sales })), ...(methods.kasbonNew > 0 ? [{ key: 'kasbon', label: 'Kasbon baru', amount: methods.kasbonNew }] : [])];
  const mixTotal = mix.reduce((n, m) => n + m.amount, 0);

  return (
    <>
      <PageHeader title="Beranda" subtitle={formatLongDate()} />

      <Hero revenue={sum.revenue} delta={delta} series={series} today={today} onOpen={() => nav.go('kasir')} />

      {hasDemo && !bannerOff && (
        <div className="mb-4 flex items-start gap-3 rounded-2xl border border-line bg-accentsoft px-4 py-3 text-sm text-accent">
          <LuInfo className="mt-0.5 shrink-0" size={17} />
          <p className="flex-1">
            Ini data contoh supaya Anda bisa langsung mencoba. Hapus semuanya di <button type="button" className="font-bold underline" onClick={() => nav.go('pengaturan')}>Pengaturan</button> sebelum dipakai sungguhan.
          </p>
          <button type="button" className="btn-icon size-8 shrink-0 border-transparent bg-transparent" aria-label="Tutup" onClick={() => setBannerOff(true)}>
            <LuX size={15} />
          </button>
        </div>
      )}

      {backup.stale && !backupOff && (
        <div role="status" data-testid="backup-reminder" className="mb-4 flex items-start gap-3 rounded-2xl border border-line bg-warnsoft px-4 py-3 text-sm text-warn">
          <LuShieldAlert className="mt-0.5 shrink-0" size={17} />
          <p className="flex-1">
            <strong>{backup.never ? 'Data belum pernah dicadangkan.' : `Sudah ${backup.days} hari tidak dicadangkan.`}</strong> Data hanya ada di HP ini. Simpan cadangannya supaya aman kalau HP hilang atau rusak.{' '}
            <button type="button" className="font-bold underline" onClick={() => nav.go('pengaturan')}>
              Cadangkan sekarang
            </button>
          </p>
          <button type="button" className="btn-icon size-8 shrink-0 border-transparent bg-transparent" aria-label="Tutup pengingat cadangan" onClick={() => {
              snoozed.backup = true;
              setBackupOff(true);
            }}>
            <LuX size={15} />
          </button>
        </div>
      )}

      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-3">
        <Kpi icon={<LuReceiptText size={18} />} label="Transaksi" value={String(sum.count)}>
          {sum.count > 0 ? `Rata-rata ${formatRupiah(avgTicket)} per transaksi` : 'Belum ada penjualan hari ini'}
          {(sum.voided > 0 || sum.returnCount > 0) && (
            <span className="mt-0.5 block">{[sum.voided > 0 ? `${sum.voided} dibatalkan` : '', sum.returnCount > 0 ? `${sum.returnCount} retur (-${formatRupiah(sum.refunds)})` : ''].filter(Boolean).join(', ')}</span>
          )}
        </Kpi>
        <Kpi icon={<LuTrendingUp size={18} />} label="Laba kotor" value={formatRupiah(sum.profit)} tone={sum.profit > 0 ? 'good' : undefined}>
          {margin !== null ? (
            <>
              <span className="mb-1.5 flex items-center justify-between">
                <span>Margin dari omzet</span>
                <strong className="num text-ink">{margin}%</strong>
              </span>
              <Meter value={Math.max(0, margin)} max={100} tone="good" />
            </>
          ) : (
            'Omzet dikurangi HPP'
          )}
        </Kpi>
        <Kpi className="col-span-2 md:col-span-1" icon={counts.out > 0 ? <LuCircleX size={18} /> : <LuTriangleAlert size={18} />} label="Perlu perhatian" value={`${counts.low + counts.out} produk`} tone={counts.out > 0 ? 'bad' : counts.low > 0 ? 'warn' : undefined}>
          <span className="mb-1.5 block">
            {counts.out} habis, {counts.low} menipis
          </span>
          <span className="flex h-1.5 gap-0.5 overflow-hidden rounded-full bg-sunken" aria-hidden="true">
            <span className="anim-bar h-full bg-bad" style={{ width: `${activeProducts ? (counts.out / activeProducts) * 100 : 0}%` }} />
            <span className="anim-bar h-full bg-warn" style={{ width: `${activeProducts ? (counts.low / activeProducts) * 100 : 0}%` }} />
          </span>
        </Kpi>
      </div>

      <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,1.55fr)_minmax(0,1fr)]">
        <div className="grid min-w-0 gap-4">
          <Section
            title="Omzet 7 hari terakhir"
            icon={<LuChartColumn size={18} />}
            action={
              <button type="button" className="btn btn-ghost btn-sm" aria-pressed={showTable} onClick={() => setShowTable((v) => !v)}>
                {showTable ? 'Lihat grafik' : 'Lihat tabel'}
              </button>
            }
          >
            <div className="px-4 pb-4">
              <p className="mb-2 text-xs text-muted">
                Total minggu ini <strong className="money text-ink">{formatRupiah(weekTotal)}</strong> · rata-rata <strong className="money text-ink">{formatRupiah(Math.round(weekTotal / series.length))}</strong> per hari
              </p>
              {showTable ? <RevenueTable series={series} /> : <RevenueChart series={series} today={today} />}
            </div>
          </Section>

          <Section title="Terlaris hari ini" icon={<LuTrophy size={18} />} action={<button type="button" className="link" onClick={() => nav.go('laporan')}>Laporan</button>}>
            {top.length === 0 ? (
              <EmptyState icon={<LuTrophy size={22} />} title="Belum ada penjualan">
                Produk yang paling laku hari ini akan tampil di sini.
              </EmptyState>
            ) : (
              <ol className="divide-y divide-line">
                {top.map((r, i) => (
                  <li key={r.productId} className="flex items-center gap-3 px-4 py-3">
                    <span className="grid size-7 shrink-0 place-items-center rounded-full bg-sunken text-xs font-bold text-muted">{i + 1}</span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline justify-between gap-3">
                        <p className="truncate text-sm font-semibold">{r.name}</p>
                        <p className="money shrink-0 text-sm font-bold">{formatRupiah(r.revenue)}</p>
                      </div>
                      <div className="mt-1.5 flex items-center gap-3">
                        <Meter value={r.revenue} max={topMax} className="flex-1" />
                        <span className="num w-16 shrink-0 text-right text-xs text-muted">
                          {formatQty(r.qty)} {r.unit}
                        </span>
                      </div>
                    </div>
                  </li>
                ))}
              </ol>
            )}
          </Section>

          <Section title="Metode bayar hari ini" icon={<LuCreditCard size={18} />} action={<button type="button" className="link" onClick={() => nav.go('laporan')}>Rincian</button>}>
            {mix.length === 0 ? (
              <EmptyState icon={<LuCreditCard size={22} />} title="Belum ada pembayaran">
                Perbandingan tunai, QRIS, transfer, dan kasbon hari ini tampil di sini.
              </EmptyState>
            ) : (
              <div className="px-4 pb-4">
                <div className="flex h-3 gap-0.5 overflow-hidden rounded-full bg-sunken" role="img" aria-label={`Metode bayar: ${mix.map((m) => `${m.label} ${Math.round((m.amount / mixTotal) * 100)} persen`).join(', ')}`}>
                  {mix.map((m) => (
                    <span key={m.key} className={cx('anim-bar h-full', METHOD_BAR[m.key] ?? 'bg-accent/35')} style={{ width: `${(m.amount / mixTotal) * 100}%` }} />
                  ))}
                </div>
                <ul className="mt-3 grid gap-2">
                  {mix.map((m) => (
                    <li key={m.key} className="flex items-center justify-between gap-3 text-sm">
                      <span className="flex items-center gap-2">
                        <span className={cx('size-2.5 rounded-full', METHOD_BAR[m.key] ?? 'bg-accent/35')} aria-hidden="true" />
                        {m.label}
                      </span>
                      <span className="flex items-baseline gap-2">
                        <span className="money font-semibold">{formatRupiah(m.amount)}</span>
                        <span className="num w-9 text-right text-xs text-muted">{Math.round((m.amount / mixTotal) * 100)}%</span>
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </Section>
        </div>

        <div className="grid min-w-0 gap-4">
          <Section title="Stok perlu perhatian" icon={<LuTriangleAlert size={18} />} action={<button type="button" className="link" onClick={() => nav.go('belanja')}>Daftar belanja</button>}>
            {alerts.length === 0 ? (
              <EmptyState icon={<LuShieldCheck size={22} />} title="Semua stok aman">
                Tidak ada produk yang menipis.
              </EmptyState>
            ) : (
              <ul className="divide-y divide-line">
                {alerts.map((a) => (
                  <li key={a.product.id} className="px-4 py-3">
                    <div className="flex items-center justify-between gap-3">
                      <p className="truncate text-sm font-semibold">{a.product.name}</p>
                      <StatusPill status={a.status} />
                    </div>
                    <div className="mt-2 flex items-center gap-3">
                      <Meter value={a.product.stock} max={a.product.minStock} tone={a.status === 'out' ? 'bad' : 'warn'} className="flex-1" />
                      <span className="num w-32 shrink-0 text-right text-xs text-muted">
                        {formatQty(a.product.stock)} / min {formatQty(a.product.minStock)} {a.product.baseUnit}
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Section>

          {(state.settings.kasbonEnabled || debt.total > 0) && (
            <Section title="Kasbon pelanggan" icon={<LuHandCoins size={18} />} action={<button type="button" className="link" onClick={() => nav.go('kasbon')}>Buka kasbon</button>}>
              {topDebtors.length === 0 ? (
                <EmptyState icon={<LuHandCoins size={22} />} title="Tidak ada kasbon">
                  Kasbon dari layar Kasir akan tampil di sini sampai dibayar.
                </EmptyState>
              ) : (
                <>
                  <div className="mx-4 mb-1 flex items-baseline justify-between gap-3 rounded-xl bg-warnsoft px-3.5 py-3">
                    <span className="text-xs font-medium text-warn">{debt.debtors} pelanggan berutang</span>
                    <span className="money text-xl font-extrabold text-warn">{formatRupiah(debt.total)}</span>
                  </div>
                  <ul className="divide-y divide-line">
                    {topDebtors.map((r) => (
                      <li key={r.customer.id} className="flex items-center gap-3 px-4 py-3">
                        <Avatar name={r.customer.name} />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-semibold">{r.customer.name}</p>
                          <p className="text-xs text-muted">{r.days === 0 ? 'Sejak hari ini' : `${r.days} hari`}</p>
                        </div>
                        <p className="money text-sm font-bold">{formatRupiah(r.balance)}</p>
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </Section>
          )}

          <Section title="Transaksi terakhir" icon={<LuReceiptText size={18} />} action={<button type="button" className="link" onClick={() => nav.go('riwayat')}>Semua riwayat</button>}>
            {recent.length === 0 ? (
              <EmptyState icon={<LuReceiptText size={22} />} title="Belum ada transaksi">
                Transaksi dari layar Kasir akan tampil di sini.
              </EmptyState>
            ) : (
              <ul className="divide-y divide-line">
                {recent.map((t) => (
                  <li key={t.id} className="flex items-center gap-3 px-4 py-3">
                    <span className="icon-box size-9">
                      <LuReceiptText size={17} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="num truncate text-[13px] font-semibold">{t.receiptNo}</p>
                      <p className="text-xs text-muted">
                        {t.dateKey === today ? 'Hari ini' : formatDateKey(t.dateKey)}, {formatTime(t.createdAt)} · {[...new Set(t.payments.map((p) => METHOD_LABEL[p.method]))].join(' + ')}
                      </p>
                    </div>
                    <p className={cx('money text-sm font-bold', t.status === 'voided' && 'text-muted line-through')}>{formatRupiah(t.total)}</p>
                  </li>
                ))}
              </ul>
            )}
          </Section>
        </div>
      </div>
    </>
  );
}
