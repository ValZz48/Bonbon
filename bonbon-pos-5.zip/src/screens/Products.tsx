import { useMemo, useState } from 'react';
import { LuPackagePlus, LuPencil, LuPlus, LuPowerOff, LuPower, LuScanBarcode, LuSearch, LuTrash2 } from 'react-icons/lu';
import { stockStatus } from '../core/calc';
import { addDaysKey, formatDateKey, formatNumber, formatQty, formatRupiah, todayKey } from '../core/format';
import { categoriesOf, filterProducts } from '../core/queries';
import type { UnitInput } from '../core/services';
import { saveProduct, setProductActive } from '../core/services';
import type { Product } from '../core/types';
import { BarcodeScanner } from '../app/BarcodeScanner';
import { useNav } from '../app/nav';
import { useAppState, useStore } from '../app/state';
import {
  ConfirmDialog,
  EmptyState,
  Field,
  Modal,
  MoneyInput,
  NumberInput,
  PageHeader,
  StatusPill,
  catClass,
  cx,
  errorMessage,
  useAction,
  useToast,
} from '../app/ui';

interface UnitRow {
  rid: number;
  id?: string;
  unitName: string;
  conversion: number | null;
  sellPrice: number | null;
}

let rowSeq = 0;
const BASE_UNITS = ['pcs', 'porsi', 'botol', 'sachet', 'bungkus', 'kotak', 'kg', 'liter'];

function ProductForm({ product, onClose }: { product?: Product; onClose: () => void }) {
  const state = useAppState();
  const store = useStore();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [scanning, setScanning] = useState(false);
  const editing = Boolean(product);

  const [name, setName] = useState(product?.name ?? '');
  const [sku, setSku] = useState(product?.sku ?? '');
  const [barcode, setBarcode] = useState(product?.barcode ?? '');
  const [category, setCategory] = useState(product?.category ?? '');
  const [baseUnit, setBaseUnit] = useState(product?.baseUnit ?? 'pcs');
  const [cost, setCost] = useState<number | null>(product?.costPrice ?? null);
  const [price, setPrice] = useState<number | null>(product?.sellPrice ?? null);
  const [minStock, setMinStock] = useState<number | null>(product ? product.minStock : null);
  const [expiry, setExpiry] = useState(product?.expiryDate ?? '');
  const [initialStock, setInitialStock] = useState<number | null>(null);
  const [units, setUnits] = useState<UnitRow[]>(() =>
    (product ? (state.unitsByProduct.get(product.id) ?? []) : []).map((u) => ({
      rid: ++rowSeq,
      id: u.id,
      unitName: u.unitName,
      conversion: u.conversion,
      sellPrice: u.sellPrice,
    })),
  );
  const [error, setError] = useState<string | null>(null);

  const categories = useMemo(() => categoriesOf(state), [state]);
  const margin = price !== null && price > 0 ? price - (cost ?? 0) : null;
  const marginPct = margin !== null && price ? Math.round((margin / price) * 100) : null;

  const patchUnit = (rid: number, patch: Partial<UnitRow>) => setUnits((l) => l.map((u) => (u.rid === rid ? { ...u, ...patch } : u)));

  const submit = async () => {
    setError(null);
    if (price === null) return setError('Harga jual wajib diisi.');
    for (const u of units) {
      if (u.conversion === null) return setError(`Isi per ${u.unitName || 'satuan tambahan'} wajib diisi.`);
      if (u.sellPrice === null) return setError(`Harga ${u.unitName || 'satuan tambahan'} wajib diisi.`);
    }
    setBusy(true);
    try {
      await saveProduct(store, {
        id: product?.id,
        name,
        sku,
        barcode,
        category,
        baseUnit,
        costPrice: cost ?? 0,
        sellPrice: price,
        minStock: minStock ?? undefined,
        expiryDate: expiry || undefined,
        initialStock: !editing ? (initialStock ?? undefined) : undefined,
        units: units.map<UnitInput>((u) => ({ id: u.id, unitName: u.unitName, conversion: u.conversion as number, sellPrice: u.sellPrice as number })),
      });
      toast(editing ? 'Produk diperbarui.' : 'Produk ditambahkan.');
      onClose();
    } catch (e) {
      setError(errorMessage(e));
      setBusy(false);
    }
  };

  return (
    <>
    <Modal
      title={editing ? 'Ubah produk' : 'Tambah produk'}
      size="lg"
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Batal
          </button>
          <button type="button" className="btn btn-primary min-w-32" disabled={busy} onClick={submit}>
            {busy ? 'Menyimpan...' : 'Simpan produk'}
          </button>
        </>
      }
    >
      <form
        className="grid gap-4"
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        <Field label="Nama produk">
          <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Mis. Indomie Goreng" />
        </Field>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="SKU" hint="Kosongkan untuk dibuat otomatis.">
            <input className="input" value={sku} onChange={(e) => setSku(e.target.value)} placeholder="Otomatis" />
          </Field>
          <div className="min-w-0">
            <label className="label" htmlFor="product-barcode">
              Barcode (opsional)
            </label>
            <div className="flex gap-2">
              <input id="product-barcode" className="input min-w-0 flex-1" inputMode="numeric" value={barcode} onChange={(e) => setBarcode(e.target.value)} placeholder="Scan atau ketik" />
              <button type="button" className="btn btn-soft shrink-0 px-3.5" onClick={() => setScanning(true)} aria-label="Scan barcode dengan kamera">
                <LuScanBarcode size={19} aria-hidden="true" /> Scan
              </button>
            </div>
            <p className="hint">Harus unik. Bisa dengan kamera (tombol Scan) atau scanner USB.</p>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Kategori">
            <input className="input" list="category-options" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="Mis. Minuman" />
            <datalist id="category-options">
              {categories.map((c) => (
                <option key={c} value={c} />
              ))}
            </datalist>
          </Field>
          <Field label="Satuan dasar" hint="Satuan terkecil yang dijual eceran.">
            <input className="input" list="unit-options" value={baseUnit} onChange={(e) => setBaseUnit(e.target.value)} />
            <datalist id="unit-options">
              {BASE_UNITS.map((u) => (
                <option key={u} value={u} />
              ))}
            </datalist>
          </Field>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label={`HPP per ${baseUnit || 'satuan'}`} hint="Harga modal. Dipakai untuk menghitung laba kotor.">
            <MoneyInput value={cost} onChange={setCost} />
          </Field>
          <Field label={`Harga jual per ${baseUnit || 'satuan'}`} hint={margin !== null ? `Margin ${formatRupiah(margin)}${marginPct !== null ? ` (${marginPct}%)` : ''}` : undefined}>
            <MoneyInput value={price} onChange={setPrice} />
          </Field>
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Stok minimum" hint={`Kosong = ${formatQty(state.settings.defaultMinStock)} (default).`}>
            <NumberInput value={minStock} onChange={setMinStock} placeholder={formatQty(state.settings.defaultMinStock)} />
          </Field>
          {!editing && (
            <Field label="Stok awal (opsional)" hint="Tercatat di log stok.">
              <NumberInput value={initialStock} onChange={setInitialStock} placeholder="0" />
            </Field>
          )}
          <Field label="Kadaluarsa (opsional)">
            <input type="date" className="input" value={expiry} onChange={(e) => setExpiry(e.target.value)} />
          </Field>
        </div>

        <fieldset className="rounded-lg border border-line p-4">
          <legend className="px-1 text-sm font-bold">Satuan tambahan</legend>
          <p className="mb-3 text-xs text-muted">Contoh: 1 dus berisi 24 {baseUnit || 'pcs'}, dijual dengan harga sendiri. Stok tetap dihitung dalam {baseUnit || 'satuan dasar'}.</p>
          {units.length === 0 && <p className="mb-3 text-sm text-muted">Belum ada satuan tambahan.</p>}
          <div className="grid gap-3">
            {units.map((u) => (
              <div key={u.rid} className="grid grid-cols-[1fr_auto] items-end gap-2 sm:grid-cols-[1fr_110px_1fr_auto]">
                <Field label="Nama satuan" className="col-span-2 sm:col-span-1">
                  <input className="input" value={u.unitName} onChange={(e) => patchUnit(u.rid, { unitName: e.target.value })} placeholder="dus" />
                </Field>
                <Field label={`Isi (${baseUnit || 'pcs'})`}>
                  <NumberInput value={u.conversion} onChange={(n) => patchUnit(u.rid, { conversion: n })} placeholder="24" />
                </Field>
                <Field label="Harga jual">
                  <MoneyInput value={u.sellPrice} onChange={(n) => patchUnit(u.rid, { sellPrice: n })} />
                </Field>
                <button type="button" className="btn-icon" aria-label="Hapus satuan" onClick={() => setUnits((l) => l.filter((x) => x.rid !== u.rid))}>
                  <LuTrash2 size={16} />
                </button>
              </div>
            ))}
          </div>
          <button type="button" className="btn btn-ghost btn-sm mt-3" onClick={() => setUnits((l) => [...l, { rid: ++rowSeq, unitName: '', conversion: null, sellPrice: null }])}>
            <LuPlus size={15} /> Tambah satuan
          </button>
        </fieldset>

        {error && (
          <p role="alert" className="err text-sm">
            {error}
          </p>
        )}
        <button type="submit" className="hidden" aria-hidden="true" tabIndex={-1} />
      </form>
    </Modal>
    {scanning && (
      <BarcodeScanner
        title="Scan barcode produk"
        once
        onClose={() => setScanning(false)}
        onCode={(code) => {
          const clash = state.products.find((p) => p.id !== product?.id && p.barcode === code);
          if (clash) return { tone: 'err', message: `Barcode ${code} sudah dipakai ${clash.name}.` };
          setBarcode(code);
          return { tone: 'ok', message: `Barcode ${code} terisi.` };
        }}
      />
    )}
    </>
  );
}

export function ProductsScreen() {
  const state = useAppState();
  const store = useStore();
  const nav = useNav();
  const { run } = useAction();
  const [q, setQ] = useState('');
  const [category, setCategory] = useState('');
  const [showInactive, setShowInactive] = useState(false);
  const [form, setForm] = useState<{ product?: Product } | null>(null);
  const [toDisable, setToDisable] = useState<Product | null>(null);

  const categories = useMemo(() => categoriesOf(state), [state]);
  const list = useMemo(() => filterProducts(state, { q, category, includeInactive: showInactive }), [state, q, category, showInactive]);
  const activeCount = state.products.filter((p) => p.active).length;
  const warnUntil = addDaysKey(todayKey(), state.settings.expiryWarnDays);

  return (
    <>
      <PageHeader
        title="Produk"
        subtitle={`${activeCount} produk aktif`}
        actions={
          <button type="button" className="btn btn-primary" onClick={() => setForm({})}>
            <LuPackagePlus size={18} /> Tambah produk
          </button>
        }
      />

      <div className="mb-3 grid gap-2 sm:grid-cols-[minmax(0,1fr)_200px_auto]">
        <div className="relative">
          <LuSearch className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-faint" size={16} />
          <input className="input pl-9" placeholder="Cari nama, SKU, atau barcode" aria-label="Cari produk" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <select className="input" aria-label="Filter kategori" value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">Semua kategori</option>
          {categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        <label className="flex min-h-11 items-center gap-2 px-1 text-sm text-muted">
          <input type="checkbox" className="size-4 accent-[var(--accent)]" checked={showInactive} onChange={(e) => setShowInactive(e.target.checked)} />
          Tampilkan nonaktif
        </label>
      </div>

      <div className="card overflow-hidden">
        <div className="th hidden gap-3 border-b border-line bg-sunken px-4 py-2.5 md:grid md:grid-cols-[minmax(0,2.4fr)_1fr_1.3fr_1fr_1fr_92px]">
          <span>Produk</span>
          <span>Kategori</span>
          <span>Stok</span>
          <span className="text-right">HPP</span>
          <span className="text-right">Harga jual</span>
          <span />
        </div>
        {list.length === 0 ? (
          <EmptyState icon={<LuSearch size={22} />} title="Produk tidak ditemukan">
            Ubah kata kunci atau filter, atau tambahkan produk baru.
          </EmptyState>
        ) : (
          <ul className="divide-y divide-line">
            {list.map((p) => {
              const units = state.unitsByProduct.get(p.id) ?? [];
              const status = stockStatus(p.stock, p.minStock);
              const nearExpiry = p.expiryDate && p.expiryDate <= warnUntil;
              const words = p.name.trim().split(/\s+/);
              const initials = ((words[0]?.[0] ?? '?') + (words.length > 1 ? (words[1]?.[0] ?? '') : '')).toUpperCase();
              return (
                <li
                  key={p.id}
                  className={cx(
                    'grid grid-cols-[minmax(0,1fr)_auto] items-center gap-x-3 gap-y-2.5 px-4 py-3.5 transition-colors hover:bg-sunken/60 md:grid-cols-[minmax(0,2.4fr)_1fr_1.3fr_1fr_1fr_92px]',
                    !p.active && 'opacity-60',
                  )}
                >
                  <div className="flex min-w-0 items-center gap-3">
                    <span className={cx('tile-badge grid size-11 shrink-0 place-items-center rounded-xl text-sm font-extrabold', catClass(p.category))} aria-hidden="true">
                      {initials}
                    </span>
                    <div className="min-w-0">
                      <p className="line-clamp-2 text-sm font-bold leading-snug">
                        {p.name}
                        {!p.active && <span className="pill pill-plain ml-2 align-middle">Nonaktif</span>}
                      </p>
                      <p className="truncate text-xs text-muted">
                        <span className="md:hidden">{p.category} · </span>
                        {p.sku}
                        {p.barcode ? ` · ${p.barcode}` : ''}
                        {units.length > 0 ? ` · ${units.map((u) => `${u.unitName} ×${formatQty(u.conversion)}`).join(', ')}` : ''}
                      </p>
                    </div>
                  </div>
                  <div className="text-right md:hidden">
                    <p className="money text-[15px] font-extrabold">{formatRupiah(p.sellPrice)}</p>
                    <p className="money text-xs text-muted">HPP {formatNumber(p.costPrice)}</p>
                  </div>
                  <p className="hidden text-sm text-muted md:block">{p.category}</p>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="money text-sm font-bold">
                      {formatQty(p.stock)} <span className="text-xs font-normal text-muted">{p.baseUnit}</span>
                    </span>
                    {p.active && <StatusPill status={status} />}
                    {p.active && nearExpiry && p.expiryDate && (
                      <span className="pill pill-warn" title={`Kadaluarsa ${formatDateKey(p.expiryDate)}`}>
                        Kadaluarsa {formatDateKey(p.expiryDate)}
                      </span>
                    )}
                  </div>
                  <p className="money hidden text-sm text-muted md:block md:text-right">{formatNumber(p.costPrice)}</p>
                  <p className="money hidden text-sm font-bold md:block md:text-right">{formatRupiah(p.sellPrice)}</p>
                  <div className="flex justify-end gap-1.5">
                    {p.active && (
                      <button type="button" className="btn-icon" aria-label={`Catat stok masuk ${p.name}`} title="Stok masuk" onClick={() => nav.go('stok', { productId: p.id, tab: 'masuk' })}>
                        <LuPackagePlus size={16} />
                      </button>
                    )}
                    <button type="button" className="btn-icon" aria-label={`Ubah ${p.name}`} title="Ubah" onClick={() => setForm({ product: p })}>
                      <LuPencil size={16} />
                    </button>
                    <button
                      type="button"
                      className="btn-icon"
                      aria-label={p.active ? `Nonaktifkan ${p.name}` : `Aktifkan ${p.name}`}
                      title={p.active ? 'Nonaktifkan' : 'Aktifkan'}
                      onClick={() => (p.active ? setToDisable(p) : run(() => setProductActive(store, p.id, true), `${p.name} diaktifkan.`))}
                    >
                      {p.active ? <LuPowerOff size={16} /> : <LuPower size={16} />}
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      {form && <ProductForm product={form.product} onClose={() => setForm(null)} />}
      {toDisable && (
        <ConfirmDialog
          title="Nonaktifkan produk?"
          message={
            <>
              <strong className="text-ink">{toDisable.name}</strong> tidak akan muncul di layar kasir. Riwayat transaksi dan log stok tetap tersimpan, dan produk bisa diaktifkan lagi kapan saja.
            </>
          }
          confirmLabel="Nonaktifkan"
          danger
          onClose={() => setToDisable(null)}
          onConfirm={() => {
            const p = toDisable;
            setToDisable(null);
            run(() => setProductActive(store, p.id, false), `${p.name} dinonaktifkan.`);
          }}
        />
      )}
    </>
  );
}
