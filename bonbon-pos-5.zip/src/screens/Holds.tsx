import { useMemo, useState } from 'react';
import { LuPlay, LuTrash2 } from 'react-icons/lu';
import { formatRupiah, formatTime } from '../core/format';
import { deleteHold, holdCart, resumeHold } from '../core/holds';
import { calcCart, resolveLine } from '../core/services';
import type { HeldCart, HeldLine } from '../core/types';
import { type CartLine, type CartState } from '../app/cart';
import { useAppState, useStore } from '../app/state';
import { EmptyState, Field, Modal, cx, useAction } from '../app/ui';

/** The cart as the lines the hold shelf stores (no screen-only keys). */
export function toHeld(cart: CartState): { lines: HeldLine[]; discount?: HeldCart['discount'] } {
  return {
    lines: cart.lines.map(({ key: _k, ...l }) => ({ productId: l.productId, unitName: l.unitName, unitQty: l.unitQty, discount: l.discount, note: l.note })),
    discount: cart.discount,
  };
}

export function HoldDialog({ cart, onClose, onDone }: { cart: CartState; onClose: () => void; onDone: () => void }) {
  const store = useStore();
  const { busy, run } = useAction();
  const [label, setLabel] = useState('');
  const submit = async () => {
    const h = await run(() => holdCart(store, { ...toHeld(cart), label }), 'Keranjang ditahan. Lanjutkan lewat tombol Tertahan.');
    if (h) onDone();
  };
  return (
    <Modal
      title="Tahan keranjang"
      size="sm"
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>
            Batal
          </button>
          <button type="button" className="btn btn-primary" onClick={submit} disabled={busy}>
            Tahan
          </button>
        </>
      }
    >
      <p className="mb-3 text-sm text-muted">Keranjang disimpan dulu supaya kamu bisa melayani pelanggan lain. Stok belum dikurangi dan belum tercatat sebagai penjualan.</p>
      <Field label="Nama atau ciri pelanggan (boleh kosong)">
        <input className="input" value={label} maxLength={40} placeholder="Mis. Bu Ani, baju merah" onChange={(e) => setLabel(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && submit()} />
      </Field>
    </Modal>
  );
}

export function HeldListDialog({ cart, onResume, onClose }: { cart: CartState; onResume: (h: HeldCart) => void; onClose: () => void }) {
  const state = useAppState();
  const store = useStore();
  const { busy, run } = useAction();
  const [askDelete, setAskDelete] = useState<string | null>(null);
  const currentFilled = cart.lines.length > 0;

  const rows = useMemo(
    () =>
      state.holds.map((h) => {
        const resolved = h.lines.map((l) => resolveLine(state.productsById.get(l.productId), state.unitsByProduct.get(l.productId) ?? [], l));
        const ok = resolved.filter((r): r is NonNullable<typeof r> => r !== null && r.product.active);
        const total = calcCart(ok, h.discount, state.settings).total;
        return { h, total, missing: h.lines.length - ok.length };
      }),
    [state],
  );

  const resume = async (h: HeldCart) => {
    const got = await run(() => resumeHold(store, h.id, currentFilled ? { ...toHeld(cart), label: 'Keranjang sebelumnya' } : undefined));
    if (got) onResume(got);
  };

  return (
    <Modal title={`Keranjang tertahan (${state.holds.length})`} onClose={onClose}>
      {rows.length === 0 ? (
        <EmptyState icon={<LuPlay size={22} />} title="Tidak ada keranjang tertahan">
          Tekan Tahan di keranjang untuk menyimpan pesanan sementara.
        </EmptyState>
      ) : (
        <>
          {currentFilled && <p className="mb-3 rounded-md bg-warnsoft px-3 py-2 text-sm text-warn">Keranjang yang sedang dibuka ikut ditahan otomatis saat kamu melanjutkan yang lain.</p>}
          <ul className="divide-y divide-line">
            {rows.map(({ h, total, missing }) => (
              <li key={h.id} className="py-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">{h.label || `Ditahan ${formatTime(h.createdAt)}`}</p>
                    <p className="text-xs text-muted">
                      {h.lines.length} item · {formatTime(h.createdAt)}
                    </p>
                    {missing > 0 && <p className="text-xs text-warn">{missing} produk sudah tidak tersedia.</p>}
                  </div>
                  <p className="money shrink-0 text-sm font-bold">{formatRupiah(total)}</p>
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <button type="button" className="btn btn-primary btn-sm" disabled={busy} onClick={() => resume(h)}>
                    <LuPlay size={14} /> Lanjutkan
                  </button>
                  {askDelete === h.id ? (
                    <>
                      <button type="button" className="btn btn-danger btn-sm" disabled={busy} onClick={async () => { await run(() => deleteHold(store, h.id), 'Keranjang tertahan dihapus.'); setAskDelete(null); }}>
                        Ya, hapus
                      </button>
                      <button type="button" className="btn btn-ghost btn-sm" onClick={() => setAskDelete(null)}>
                        Batal
                      </button>
                    </>
                  ) : (
                    <button type="button" className={cx('btn btn-ghost btn-sm text-bad')} aria-label={`Hapus ${h.label || 'keranjang tertahan'}`} onClick={() => setAskDelete(h.id)}>
                      <LuTrash2 size={14} /> Hapus
                    </button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </>
      )}
    </Modal>
  );
}

export function loadHeld(h: HeldCart, nextKey: () => string): { lines: CartLine[]; discount?: HeldCart['discount'] } {
  return { lines: h.lines.map((l) => ({ ...l, key: nextKey() })), discount: h.discount };
}
