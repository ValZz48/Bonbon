import { type ReactNode, useMemo, useState } from 'react';
import { LuBan, LuChevronRight, LuHandCoins, LuMessageCircle, LuNotebookPen, LuPencil, LuPlus, LuReceiptText, LuSearch, LuUsers } from 'react-icons/lu';
import { daysBetweenKeys, formatDateKey, formatDateTime, formatRupiah, todayKey } from '../core/format';
import { debtSummary, debtorRows, debtSince } from '../core/queries';
import { addManualDebt, receiveDebtPayment, setCustomerActive, writeOffDebt } from '../core/services';
import type { Customer, DebtEntry, PaymentMethod } from '../core/types';
import { DEBT_LABEL, METHOD_LABEL, debtDelta } from '../core/types';
import { debtPaymentWhatsApp, debtReminderWhatsApp, formatPhoneID } from '../core/whatsapp';
import { ReceiptModal } from '../app/Receipt';
import { useAppState, useStore } from '../app/state';
import { WaShareDialog } from '../app/WaShare';
import { Avatar, EmptyState, Field, Modal, MoneyInput, PageHeader, Tabs, cx, errorMessage, useAction } from '../app/ui';
import { CustomerForm } from './CustomerParts';

function Stat({ label, value, children, tone }: { label: string; value: string; children?: ReactNode; tone?: 'warn' | 'bad' }) {
  return (
    <div className="card min-w-0 p-4">
      <p className="text-[13px] font-semibold text-muted">{label}</p>
      <p className={cx('money mt-1 text-[24px] leading-tight font-extrabold break-words', tone === 'bad' && 'text-bad', tone === 'warn' && 'text-warn')}>{value}</p>
      {children && <div className="mt-1 text-xs text-muted">{children}</div>}
    </div>
  );
}

function ageTone(days: number): 'pill-bad' | 'pill-warn' | 'pill-plain' {
  return days >= 30 ? 'pill-bad' : days >= 14 ? 'pill-warn' : 'pill-plain';
}

function sinceText(since: string | null, days: number): string {
  if (!since) return 'Tidak ada kasbon';
  return days === 0 ? 'Berutang sejak hari ini' : `Berutang sejak ${formatDateKey(since)} (${days} hari)`;
}

function entryTitle(e: DebtEntry): string {
  if (e.type === 'kasbon') return e.txId ? `Kasbon ${e.receiptNo ?? ''}`.trim() : 'Kasbon manual';
  if (e.type === 'payment') return `Pembayaran ${e.method ? METHOD_LABEL[e.method] : ''}`.trim();
  if (e.type === 'void') return `Void ${e.receiptNo ?? 'transaksi'}`;
  if (e.type === 'return') return `Retur ${e.receiptNo ?? 'barang'}`;
  return DEBT_LABEL.writeoff;
}

function entryDetail(e: DebtEntry): string {
  return [e.reference ? `Ref ${e.reference}` : '', e.note ?? ''].filter(Boolean).join(' · ');
}

// ---- dialogs ----------------------------------------------------------------------------

function PayDebtDialog({ customer, balance, onClose }: { customer: Customer; balance: number; onClose: () => void }) {
  const store = useStore();
  const state = useAppState();
  const [amount, setAmount] = useState<number | null>(balance);
  const [method, setMethod] = useState<PaymentMethod>(state.settings.enabledMethods.includes('cash') ? 'cash' : state.settings.enabledMethods[0]);
  const [reference, setReference] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<DebtEntry | null>(null);
  const [sharing, setSharing] = useState(false);

  const value = amount ?? 0;
  const invalid = value <= 0 || value > balance;

  const submit = async () => {
    if (busy || invalid) return;
    setBusy(true);
    setError(null);
    try {
      const entry = await receiveDebtPayment(store, { customerId: customer.id, amount: value, method, reference, note });
      setDone(entry);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  if (done) {
    return (
      <>
        <Modal
          title="Pembayaran dicatat"
          size="sm"
          onClose={onClose}
          footer={
            <>
              <button type="button" className="btn btn-ghost" onClick={() => setSharing(true)}>
                <LuMessageCircle size={16} /> Kirim bukti via WhatsApp
              </button>
              <button type="button" data-autofocus className="btn btn-primary" onClick={onClose}>
                Selesai
              </button>
            </>
          }
        >
          <div className="rounded-lg bg-sunken px-4 py-3">
            <div className="flex items-baseline justify-between gap-3">
              <span className="text-sm text-muted">Dibayar ({METHOD_LABEL[done.method ?? method]})</span>
              <span className="money text-xl font-extrabold">{formatRupiah(done.amount)}</span>
            </div>
            <div className="mt-2 flex items-baseline justify-between gap-3 border-t border-line pt-2">
              <span className="text-sm text-muted">Sisa kasbon {customer.name}</span>
              <span className={cx('money text-lg font-bold', done.balanceAfter === 0 ? 'text-good' : 'text-accent')}>{done.balanceAfter === 0 ? 'Lunas' : formatRupiah(done.balanceAfter)}</span>
            </div>
          </div>
        </Modal>
        {sharing && <WaShareDialog title="Kirim bukti pembayaran" phone={customer.phone} message={debtPaymentWhatsApp({ settings: state.settings, customerName: customer.name, entry: done })} onClose={() => setSharing(false)} />}
      </>
    );
  }

  return (
    <Modal
      title={`Terima pembayaran ${customer.name}`}
      size="sm"
      onClose={busy ? () => undefined : onClose}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>
            Batal
          </button>
          <button type="button" className="btn btn-primary min-w-40" onClick={submit} disabled={busy || invalid}>
            {busy ? 'Menyimpan...' : value === balance ? 'Lunasi kasbon' : 'Catat pembayaran'}
          </button>
        </>
      }
    >
      <div className="mb-4 flex items-baseline justify-between gap-3 rounded-lg bg-sunken px-4 py-3">
        <span className="text-sm text-muted">Kasbon saat ini</span>
        <span className="money text-xl font-extrabold">{formatRupiah(balance)}</span>
      </div>
      <span className="label">Jumlah dibayar</span>
      <MoneyInput autoFocus value={amount} onChange={setAmount} onEnter={submit} invalid={value > balance} aria-label="Jumlah dibayar" />
      <div className="mt-2 flex flex-wrap gap-2">
        <button type="button" className="btn btn-soft btn-sm" onClick={() => setAmount(balance)}>
          Lunas
        </button>
        {[10000, 20000, 50000, 100000].map((v) => (
          <button key={v} type="button" className="btn btn-ghost btn-sm" disabled={v > balance} onClick={() => setAmount(v)}>
            {v / 1000}rb
          </button>
        ))}
      </div>
      {value > balance && <p className="err mt-1.5 text-sm">Melebihi kasbon ({formatRupiah(balance)}).</p>}
      {value > 0 && value < balance && <p className="hint mt-1.5">Sisa kasbon setelah ini {formatRupiah(balance - value)}.</p>}

      <span className="label mt-4">Metode</span>
      <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label="Metode pembayaran kasbon">
        {state.settings.enabledMethods.map((m) => (
          <button
            key={m}
            type="button"
            role="radio"
            aria-checked={m === method}
            onClick={() => setMethod(m)}
            className={cx('min-h-11 rounded-md border px-2 text-[13px] font-semibold transition-colors', m === method ? 'border-accent bg-accentsoft text-accent' : 'border-line bg-panel hover:bg-sunken')}
          >
            {METHOD_LABEL[m]}
          </button>
        ))}
      </div>
      <div className="mt-4 grid gap-4">
        {method !== 'cash' && (
          <Field label="Nomor referensi (opsional)">
            <input className="input" value={reference} onChange={(e) => setReference(e.target.value)} placeholder="Kode transaksi atau 4 digit akhir" />
          </Field>
        )}
        <Field label="Catatan (opsional)">
          <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Mis. cicilan pertama" onKeyDown={(e) => e.key === 'Enter' && submit()} />
        </Field>
      </div>
      {error && (
        <p role="alert" className="err mt-3 text-sm">
          {error}
        </p>
      )}
    </Modal>
  );
}

function ManualDebtDialog({ customer, onClose }: { customer: Customer; onClose: () => void }) {
  const store = useStore();
  const [amount, setAmount] = useState<number | null>(null);
  const [note, setNote] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (busy || !amount) return;
    setBusy(true);
    setError(null);
    try {
      await addManualDebt(store, { customerId: customer.id, amount, note });
      onClose();
    } catch (e) {
      setError(errorMessage(e));
      setBusy(false);
    }
  };

  return (
    <Modal
      title={`Catat kasbon ${customer.name}`}
      size="sm"
      onClose={busy ? () => undefined : onClose}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Batal
          </button>
          <button type="button" className="btn btn-primary" onClick={submit} disabled={busy || !amount}>
            {busy ? 'Menyimpan...' : 'Simpan kasbon'}
          </button>
        </>
      }
    >
      <p className="mb-3 text-sm text-muted">Untuk utang yang tidak lewat kasir, misalnya utang lama dari buku catatan. Stok tidak berubah.</p>
      <div className="grid gap-4">
        <div>
          <span className="label">Jumlah</span>
          <MoneyInput autoFocus value={amount} onChange={setAmount} onEnter={submit} aria-label="Jumlah kasbon" />
        </div>
        <Field label="Keterangan (opsional)">
          <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Mis. utang lama dari buku" onKeyDown={(e) => e.key === 'Enter' && submit()} />
        </Field>
      </div>
      {error && (
        <p role="alert" className="err mt-3 text-sm">
          {error}
        </p>
      )}
    </Modal>
  );
}

const WRITEOFF_REASONS = ['Pelanggan pindah', 'Tidak bisa ditagih', 'Diikhlaskan'];

function WriteOffDialog({ customer, balance, onClose }: { customer: Customer; balance: number; onClose: () => void }) {
  const store = useStore();
  const [amount, setAmount] = useState<number | null>(balance);
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (busy || !amount) return;
    setBusy(true);
    setError(null);
    try {
      await writeOffDebt(store, { customerId: customer.id, amount, reason });
      onClose();
    } catch (e) {
      setError(errorMessage(e));
      setBusy(false);
    }
  };

  return (
    <Modal
      title={`Hapus utang ${customer.name}`}
      size="sm"
      onClose={busy ? () => undefined : onClose}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>
            Batal
          </button>
          <button type="button" className="btn btn-danger" onClick={submit} disabled={busy || !amount || !reason.trim()}>
            {busy ? 'Memproses...' : 'Hapus utang'}
          </button>
        </>
      }
    >
      <p className="mb-3 text-sm text-muted">
        Utang dihapus tanpa pembayaran (tidak ada uang masuk). Catatannya tetap tersimpan di buku kasbon. Kasbon saat ini <strong className="money text-ink">{formatRupiah(balance)}</strong>.
      </p>
      <span className="label">Jumlah dihapus</span>
      <MoneyInput value={amount} onChange={setAmount} invalid={(amount ?? 0) > balance} aria-label="Jumlah dihapus" />
      <div className="mt-3 mb-2 flex flex-wrap gap-2">
        {WRITEOFF_REASONS.map((r) => (
          <button key={r} type="button" onClick={() => setReason(r)} className={cx('min-h-9 rounded-full border px-3 text-[13px] font-semibold', reason === r ? 'border-accent bg-accentsoft text-accent' : 'border-line bg-panel text-muted hover:text-ink')}>
            {r}
          </button>
        ))}
      </div>
      <Field label="Alasan (wajib)">
        <input className="input" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Tulis alasan" onKeyDown={(e) => e.key === 'Enter' && submit()} />
      </Field>
      {error && (
        <p role="alert" className="err mt-2 text-sm">
          {error}
        </p>
      )}
    </Modal>
  );
}

// ---- customer detail -------------------------------------------------------------------------

function CustomerDetail({ id, onClose }: { id: string; onClose: () => void }) {
  const state = useAppState();
  const store = useStore();
  const { run } = useAction();
  const [paying, setPaying] = useState(false);
  const [manual, setManual] = useState(false);
  const [writing, setWriting] = useState(false);
  const [editing, setEditing] = useState(false);
  const [reminding, setReminding] = useState(false);
  const [receiptId, setReceiptId] = useState<string | null>(null);

  const customer = state.customersById.get(id);
  if (!customer) return null;
  const entries = state.debtByCustomer.get(id) ?? [];
  const balance = state.balanceByCustomer.get(id) ?? 0;
  const since = debtSince(entries);
  const today = todayKey();
  const days = since ? Math.max(0, daysBetweenKeys(since, today)) : 0;
  const ledger = [...entries].reverse();
  const receiptTx = receiptId ? state.txById.get(receiptId) : undefined;
  const limit = customer.creditLimit ?? 0;

  return (
    <>
      <Modal
        title={customer.name}
        size="lg"
        onClose={onClose}
        footer={
          <>
            <button
              type="button"
              className="btn btn-ghost mr-auto"
              onClick={() => run(() => setCustomerActive(store, customer.id, !customer.active), customer.active ? 'Pelanggan dinonaktifkan.' : 'Pelanggan diaktifkan.')}
            >
              {customer.active ? 'Nonaktifkan pelanggan' : 'Aktifkan lagi'}
            </button>
            <button type="button" data-autofocus className="btn btn-primary" onClick={onClose}>
              Tutup
            </button>
          </>
        }
      >
        <div className="mb-4 rounded-lg bg-sunken px-4 py-3">
          <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
            <span className="text-sm text-muted">{balance < 0 ? 'Kelebihan bayar' : 'Kasbon saat ini'}</span>
            <span className={cx('money text-[28px] leading-tight font-extrabold', balance > 0 && 'text-warn', balance < 0 && 'text-good')}>{formatRupiah(Math.abs(balance))}</span>
          </div>
          <p className="mt-1 text-xs text-muted">
            {balance > 0 ? sinceText(since, days) : balance === 0 ? 'Tidak ada kasbon.' : 'Akan dipakai lebih dulu untuk kasbon berikutnya.'}
            {limit > 0 && ` · Batas ${formatRupiah(limit)}${balance > 0 ? `, sisa ruang ${formatRupiah(Math.max(0, limit - balance))}` : ''}`}
          </p>
          <p className="mt-1 text-xs text-muted">
            {customer.phone ? `WhatsApp ${formatPhoneID(customer.phone)}` : 'Belum ada nomor WhatsApp'}
            {customer.note ? ` · ${customer.note}` : ''}
          </p>
        </div>

        <div className="mb-5 flex flex-wrap gap-2">
          <button type="button" className="btn btn-primary" disabled={balance <= 0} onClick={() => setPaying(true)}>
            <LuHandCoins size={16} /> Terima pembayaran
          </button>
          <button type="button" className="btn btn-ghost" disabled={balance <= 0} onClick={() => setReminding(true)}>
            <LuMessageCircle size={16} /> Ingatkan via WhatsApp
          </button>
          <button type="button" className="btn btn-ghost" disabled={!customer.active} onClick={() => setManual(true)}>
            <LuNotebookPen size={16} /> Catat kasbon manual
          </button>
          <button type="button" className="btn btn-ghost" onClick={() => setEditing(true)}>
            <LuPencil size={16} /> Ubah
          </button>
          {balance > 0 && (
            <button type="button" className="btn btn-ghost text-bad" onClick={() => setWriting(true)}>
              <LuBan size={16} /> Hapus utang
            </button>
          )}
        </div>

        <h3 className="mb-2 text-sm font-bold">Buku kasbon</h3>
        {ledger.length === 0 ? (
          <p className="rounded-md border border-dashed border-line px-3 py-6 text-center text-sm text-muted">Belum ada catatan. Kasbon dari kasir atau catatan manual akan muncul di sini.</p>
        ) : (
          <ul className="divide-y divide-line overflow-hidden rounded-md border border-line">
            {ledger.map((e) => {
              const delta = debtDelta(e);
              const tx = e.txId ? state.txById.get(e.txId) : undefined;
              const detail = entryDetail(e);
              return (
                <li key={e.id} className="flex items-start justify-between gap-3 bg-panel px-3 py-2.5">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold">
                      {entryTitle(e)}
                      {tx && (
                        <button type="button" className="ml-2 inline-flex items-center gap-1 align-middle text-xs font-semibold text-accent" onClick={() => setReceiptId(tx.id)}>
                          <LuReceiptText size={13} /> Struk
                        </button>
                      )}
                    </p>
                    <p className="text-xs text-muted">
                      {formatDateTime(e.createdAt)}
                      {detail ? ` · ${detail}` : ''}
                    </p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className={cx('money text-sm font-bold', delta > 0 ? 'text-warn' : 'text-good')}>
                      {delta > 0 ? '+' : '-'}
                      {formatRupiah(e.amount)}
                    </p>
                    <p className="money text-xs text-muted">Sisa {formatRupiah(e.balanceAfter)}</p>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </Modal>

      {paying && <PayDebtDialog customer={customer} balance={balance} onClose={() => setPaying(false)} />}
      {manual && <ManualDebtDialog customer={customer} onClose={() => setManual(false)} />}
      {writing && <WriteOffDialog customer={customer} balance={balance} onClose={() => setWriting(false)} />}
      {editing && <CustomerForm customer={customer} onClose={() => setEditing(false)} onSaved={() => setEditing(false)} />}
      {reminding && (
        <WaShareDialog
          title={`Ingatkan ${customer.name}`}
          phone={customer.phone}
          message={debtReminderWhatsApp({ settings: state.settings, customerName: customer.name, balance, since, today })}
          onClose={() => setReminding(false)}
        />
      )}
      {receiptTx && <ReceiptModal tx={receiptTx} settings={state.settings} onClose={() => setReceiptId(null)} />}
    </>
  );
}

// ---- screen --------------------------------------------------------------------------------------

type View = 'debt' | 'all';

export function KasbonScreen() {
  const state = useAppState();
  const [q, setQ] = useState('');
  const [view, setView] = useState<View>('debt');
  const [openId, setOpenId] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);

  const today = todayKey();
  const rows = useMemo(() => debtorRows(state, today), [state, today]);
  const summary = useMemo(() => debtSummary(state, today), [state, today]);
  const debtorCount = rows.filter((r) => r.balance > 0).length;

  const shown = useMemo(() => {
    const s = q.trim().toLowerCase();
    const digits = s.replace(/\D/g, '');
    return rows.filter((r) => {
      if (view === 'debt' && r.balance <= 0) return false;
      if (!s) return true;
      return r.customer.name.toLowerCase().includes(s) || (digits.length >= 3 && (r.customer.phone ?? '').includes(digits.replace(/^0/, '62')));
    });
  }, [rows, q, view]);

  return (
    <>
      <PageHeader
        title="Kasbon"
        subtitle="Catatan utang pelanggan. Kasbon dibuat dari layar Kasir dengan metode Kasbon, lalu dicicil di sini."
        actions={
          <button type="button" className="btn btn-primary" onClick={() => setAdding(true)}>
            <LuPlus size={17} /> Pelanggan baru
          </button>
        }
      />

      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-3">
        <Stat label="Total kasbon" value={formatRupiah(summary.total)} tone={summary.total > 0 ? 'warn' : undefined}>
          Belum dibayar semua pelanggan
        </Stat>
        <Stat label="Pelanggan berutang" value={String(summary.debtors)}>
          dari {state.customers.length} pelanggan
        </Stat>
        <div className="col-span-2 lg:col-span-1">
          <Stat label="Utang terlama" value={summary.debtors > 0 ? `${summary.oldestDays} hari` : '-'} tone={summary.oldestDays >= 30 ? 'bad' : summary.oldestDays >= 14 ? 'warn' : undefined}>
            {summary.oldestName ?? 'Tidak ada utang'}
          </Stat>
        </div>
      </div>

      <div className="mb-3 grid gap-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-start">
        <div className="relative">
          <LuSearch className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-faint" size={16} />
          <input className="input pl-9" placeholder="Cari nama atau nomor pelanggan" aria-label="Cari pelanggan" autoComplete="off" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="sm:w-72">
          <Tabs
            tabs={[
              { id: 'debt' as View, label: `Berutang (${debtorCount})` },
              { id: 'all' as View, label: `Semua (${rows.length})` },
            ]}
            value={view}
            onChange={setView}
          />
        </div>
      </div>

      <div className="card overflow-hidden">
        {shown.length === 0 ? (
          rows.length === 0 ? (
            <EmptyState
              icon={<LuUsers size={22} />}
              title="Belum ada pelanggan"
              action={
                <button type="button" className="btn btn-primary" onClick={() => setAdding(true)}>
                  <LuPlus size={17} /> Tambah pelanggan
                </button>
              }
            >
              Tambahkan pelanggan di sini, atau langsung dari layar pembayaran saat memilih Kasbon.
            </EmptyState>
          ) : (
            <EmptyState icon={<LuHandCoins size={22} />} title={q.trim() ? 'Pelanggan tidak ditemukan' : 'Tidak ada yang berutang'}>
              {q.trim() ? 'Coba nama atau nomor lain.' : 'Semua kasbon sudah lunas. Pilih tab Semua untuk melihat seluruh pelanggan.'}
            </EmptyState>
          )
        ) : (
          <ul className="divide-y divide-line">
            {shown.map((r) => (
              <li key={r.customer.id}>
                <button type="button" onClick={() => setOpenId(r.customer.id)} className="flex w-full items-center gap-3 px-4 py-3.5 text-left transition-colors hover:bg-sunken/70">
                  <Avatar name={r.customer.name} className={cx('size-11', r.balance > 0 && 'bg-warnsoft text-warn', r.balance < 0 && 'bg-goodsoft text-good')} />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-bold">
                      {r.customer.name}
                      {!r.customer.active && <span className="pill pill-plain ml-2 align-middle">Nonaktif</span>}
                    </span>
                    <span className="block text-xs text-muted">{r.customer.phone ? formatPhoneID(r.customer.phone) : 'Tanpa nomor'}</span>
                    <span className="block text-xs text-muted">{sinceText(r.since, r.days)}</span>
                  </span>
                  <span className="flex shrink-0 flex-col items-end gap-1 text-right">
                    <span className={cx('money text-[15px] font-extrabold', r.balance > 0 && 'text-warn', r.balance < 0 && 'text-good')}>
                      {r.balance < 0 ? `Lebih ${formatRupiah(-r.balance)}` : formatRupiah(r.balance)}
                    </span>
                    {r.balance > 0 && r.days >= 14 && <span className={cx('pill', ageTone(r.days))}>{r.days} hari</span>}
                  </span>
                  <LuChevronRight size={16} className="shrink-0 text-faint" aria-hidden="true" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {openId && <CustomerDetail id={openId} onClose={() => setOpenId(null)} />}
      {adding && (
        <CustomerForm
          onClose={() => setAdding(false)}
          onSaved={(c) => {
            setAdding(false);
            setView('all');
            setOpenId(c.id);
          }}
        />
      )}
    </>
  );
}
