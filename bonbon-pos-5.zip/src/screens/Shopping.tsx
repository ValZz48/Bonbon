import { useMemo, useState } from 'react';
import { LuCopy, LuDownload, LuPackageCheck, LuShieldCheck } from 'react-icons/lu';
import { STATUS_LABEL } from '../core/calc';
import type { ShoppingRow } from '../core/export';
import { shoppingCsv, shoppingText } from '../core/export';
import { formatQty, formatRupiah, todayKey } from '../core/format';
import { stockAlerts } from '../core/queries';
import { useNav } from '../app/nav';
import { CAN_DOWNLOAD, downloadText } from '../app/runtime';
import { useAppState } from '../app/state';
import { EmptyState, NumberInput, PageHeader, StatusPill, cx, useCopy } from '../app/ui';

export function ShoppingScreen() {
  const state = useAppState();
  const nav = useNav();
  const copy = useCopy();
  const alerts = useMemo(() => stockAlerts(state), [state]);
  const [qtyOverride, setQtyOverride] = useState<Record<string, number | null>>({});
  const [skipped, setSkipped] = useState<Record<string, boolean>>({});

  const qtyOf = (id: string, suggested: number) => (id in qtyOverride ? qtyOverride[id] : suggested);

  const rows: ShoppingRow[] = alerts
    .filter((a) => !skipped[a.product.id])
    .map((a) => ({
      name: a.product.name,
      sku: a.product.sku,
      unit: a.product.baseUnit,
      stock: a.product.stock,
      minStock: a.product.minStock,
      qty: qtyOf(a.product.id, a.suggested) ?? 0,
      status: STATUS_LABEL[a.status],
    }));
  const buyRows = rows.filter((r) => r.qty > 0);
  const estimate = alerts
    .filter((a) => !skipped[a.product.id])
    .reduce((s, a) => s + Math.round((qtyOf(a.product.id, a.suggested) ?? 0) * a.product.costPrice), 0);
  const outCount = alerts.filter((a) => a.status === 'out').length;

  if (alerts.length === 0) {
    return (
      <>
        <PageHeader title="Perlu Belanja" />
        <div className="card">
          <EmptyState icon={<LuShieldCheck size={24} />} title="Semua stok aman">
            Belum ada produk yang menipis atau habis. Produk yang stoknya sama dengan atau di bawah stok minimum akan muncul di sini.
          </EmptyState>
        </div>
      </>
    );
  }

  return (
    <>
      <PageHeader
        title="Perlu Belanja"
        subtitle={`${outCount} habis, ${alerts.length - outCount} menipis. Saran jumlah beli = stok minimum × 2 dikurangi stok sekarang.`}
        actions={
          <>
            <button type="button" className="btn btn-ghost" disabled={buyRows.length === 0} onClick={() => copy(shoppingText(state.settings.storeName, todayKey(), buyRows), 'Daftar belanja disalin.')}>
              <LuCopy size={16} /> Salin daftar
            </button>
            {CAN_DOWNLOAD ? (
              <button type="button" className="btn btn-ghost" disabled={buyRows.length === 0} onClick={() => downloadText(`daftar-belanja-${todayKey()}.csv`, shoppingCsv(buyRows))}>
                <LuDownload size={16} /> Unduh CSV
              </button>
            ) : (
              <button type="button" className="btn btn-ghost" disabled={buyRows.length === 0} onClick={() => copy(shoppingCsv(buyRows), 'CSV disalin. Tempel ke spreadsheet.')}>
                <LuDownload size={16} /> Salin CSV
              </button>
            )}
          </>
        }
      />

      <div className="card overflow-hidden">
        <div className="th hidden gap-3 border-b border-line bg-sunken px-4 py-2.5 md:grid md:grid-cols-[28px_minmax(0,2fr)_130px_150px_130px]">
          <span />
          <span>Produk</span>
          <span>Stok / minimum</span>
          <span>Jumlah beli</span>
          <span />
        </div>
        <ul className="divide-y divide-line">
          {alerts.map((a) => {
            const p = a.product;
            const off = Boolean(skipped[p.id]);
            const qty = qtyOf(p.id, a.suggested);
            return (
              <li key={p.id} className={cx('grid items-center gap-x-3 gap-y-2 px-4 py-3 md:grid-cols-[28px_minmax(0,2fr)_130px_150px_130px]', off && 'opacity-50')}>
                <input
                  type="checkbox"
                  className="size-5 accent-[var(--accent)]"
                  aria-label={`Ikutkan ${p.name} dalam daftar belanja`}
                  checked={!off}
                  onChange={(e) => setSkipped((s) => ({ ...s, [p.id]: !e.target.checked }))}
                />
                <div className="min-w-0">
                  <p className="flex flex-wrap items-center gap-2 text-sm font-semibold">
                    {p.name} <StatusPill status={a.status} />
                  </p>
                  <p className="text-xs text-muted">
                    {p.sku} · {p.category}
                  </p>
                </div>
                <p className="money text-sm">
                  <span className={cx('font-bold', a.status === 'out' ? 'text-bad' : 'text-warn')}>{formatQty(p.stock)}</span>
                  <span className="text-muted"> / {formatQty(p.minStock)} {p.baseUnit}</span>
                </p>
                <div className="flex items-center gap-2">
                  <NumberInput
                    className="min-h-10 w-24"
                    aria-label={`Jumlah beli ${p.name}`}
                    value={qty}
                    onChange={(n) => setQtyOverride((m) => ({ ...m, [p.id]: n }))}
                    placeholder="0"
                  />
                  <span className="text-sm text-muted">{p.baseUnit}</span>
                </div>
                <div className="md:text-right">
                  <button type="button" className="btn btn-soft btn-sm" onClick={() => nav.go('stok', { productId: p.id, tab: 'masuk' })}>
                    <LuPackageCheck size={15} /> Catat masuk
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
        <div className="flex flex-wrap items-baseline justify-between gap-2 border-t border-line bg-sunken px-4 py-3 text-sm">
          <span className="text-muted">{buyRows.length} produk akan dibeli</span>
          <span>
            Perkiraan modal <strong className="money text-base">{formatRupiah(estimate)}</strong>
            <span className="text-xs text-muted"> (berdasarkan HPP saat ini)</span>
          </span>
        </div>
      </div>
    </>
  );
}
