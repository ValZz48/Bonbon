import { useEffect, useState } from 'react';
import { LuBanknote, LuCreditCard, LuHandCoins, LuLandmark, LuQrCode, LuWallet, LuX } from 'react-icons/lu';
import type { IconType } from 'react-icons';
import { formatNumber, formatRupiah } from '../core/format';
import type { PaymentInput } from '../core/services';
import type { PaymentMethod, PaymentStatus } from '../core/types';
import { METHOD_LABEL } from '../core/types';
import { useAppState } from '../app/state';
import { Modal, MoneyInput, cx, errorMessage } from '../app/ui';
import { CustomerPicker } from './CustomerParts';

const ICON: Record<PaymentMethod, IconType> = {
  cash: LuBanknote,
  qris: LuQrCode,
  transfer: LuLandmark,
  ewallet: LuWallet,
  debit: LuCreditCard,
  credit: LuCreditCard,
  kasbon: LuHandCoins,
};

const QUICK_CASH = [20000, 50000, 100000, 200000];

export function PaymentModal({
  total,
  methods,
  onClose,
  onSubmit,
}: {
  total: number;
  methods: PaymentMethod[];
  onClose: () => void;
  /** Must throw (DomainError) when the sale cannot be saved. */
  onSubmit: (payments: PaymentInput[]) => Promise<void>;
}) {
  const state = useAppState();
  const [payments, setPayments] = useState<PaymentInput[]>([]);
  const [method, setMethod] = useState<PaymentMethod>(methods.includes('cash') ? 'cash' : methods[0]);
  const [customerId, setCustomerId] = useState<string | null>(null); // kasbon only
  const [amount, setAmount] = useState<number | null>(null); // non-cash only; null = whole remainder
  const [tendered, setTendered] = useState<number | null>(null); // cash only; null = exact
  const [reference, setReference] = useState('');
  const [status, setStatus] = useState<PaymentStatus>('success');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const paid = payments.reduce((s, p) => s + p.amount, 0);
  const remaining = total - paid;
  const isCash = method === 'cash';
  const isKasbon = method === 'kasbon';
  // kasbon can be used once per sale
  const usable = methods.filter((m) => !(m === 'kasbon' && payments.some((p) => p.method === 'kasbon')));

  // what the current entry would add
  const entryAmount = isCash ? Math.min(tendered ?? remaining, remaining) : (amount ?? remaining);
  const cashReceived = isCash ? (tendered ?? remaining) : 0;
  const change = isCash ? Math.max(0, cashReceived - remaining) : 0;
  const finalizes = entryAmount === remaining;

  const customer = customerId ? state.customersById.get(customerId) : undefined;
  const owed = customer ? (state.balanceByCustomer.get(customer.id) ?? 0) : 0;
  const limit = customer?.creditLimit ?? 0;
  const overLimit = isKasbon && !!customer && limit > 0 && owed + entryAmount > limit;
  const kasbonProblem = !isKasbon ? null : !customer ? 'Pilih pelanggan untuk kasbon.' : overLimit ? `Melebihi batas kasbon ${customer.name} (${formatRupiah(limit)}). Kurangi jumlahnya atau bayar sebagian dengan metode lain.` : null;

  const entryInvalid =
    remaining > 0 && (entryAmount <= 0 || entryAmount > remaining || (isCash && cashReceived <= 0) || kasbonProblem !== null);

  useEffect(() => {
    setError(null);
  }, [method, amount, tendered, payments.length, customerId]);

  const resetEntry = () => {
    setAmount(null);
    setTendered(null);
    setReference('');
    setStatus('success');
    setCustomerId(null);
    if (method === 'kasbon') setMethod(methods.includes('cash') ? 'cash' : (methods.find((m) => m !== 'kasbon') ?? methods[0]));
  };

  const finish = async (list: PaymentInput[]) => {
    setBusy(true);
    setError(null);
    try {
      await onSubmit(list);
    } catch (e) {
      setError(errorMessage(e));
      setBusy(false);
    }
  };

  const confirm = async () => {
    if (busy) return;
    if (total === 0) return finish([]);
    if (remaining === 0) return finish(payments);
    if (entryInvalid) {
      setError(kasbonProblem ?? (entryAmount > remaining ? 'Jumlah melebihi sisa tagihan.' : 'Isi jumlah pembayaran.'));
      return;
    }
    const entry: PaymentInput = isCash
      ? { method, amount: entryAmount, tendered: cashReceived }
      : isKasbon
        ? { method, amount: entryAmount, customerId: customerId as string }
        : { method, amount: entryAmount, reference: reference.trim() || undefined, status };
    const next = [...payments, entry];
    if (finalizes) return finish(next);
    setPayments(next);
    resetEntry();
  };

  const label =
    total === 0 || remaining === 0
      ? 'Selesaikan transaksi'
      : isKasbon
        ? finalizes
          ? 'Catat sebagai kasbon'
          : `Tambah kasbon ${formatRupiah(entryAmount)}`
        : finalizes
          ? `Bayar ${METHOD_LABEL[method]}`
          : `Tambah ${METHOD_LABEL[method].toLowerCase()} ${formatRupiah(entryAmount)}`;

  return (
    <Modal
      title="Pembayaran"
      onClose={busy ? () => undefined : onClose}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>
            Kembali
          </button>
          <button type="button" className="btn btn-primary min-w-44" onClick={confirm} disabled={busy || (remaining > 0 && entryInvalid)}>
            {busy ? 'Menyimpan...' : label}
          </button>
        </>
      }
    >
      <div className="mb-4 rounded-lg bg-sunken px-4 py-3">
        <div className="flex items-baseline justify-between gap-3">
          <span className="text-sm text-muted">Total tagihan</span>
          <span className="money text-2xl font-extrabold">{formatRupiah(total)}</span>
        </div>
        {payments.length > 0 && (
          <div className="mt-2 flex items-baseline justify-between gap-3 border-t border-line pt-2">
            <span className="text-sm text-muted">Sisa</span>
            <span className={cx('money text-lg font-bold', remaining === 0 ? 'text-good' : 'text-accent')}>{formatRupiah(remaining)}</span>
          </div>
        )}
      </div>

      {payments.length > 0 && (
        <ul className="mb-4 divide-y divide-line rounded-md border border-line">
          {payments.map((p, i) => (
            <li key={i} className="flex items-center justify-between gap-3 px-3 py-2 text-sm">
              <span className="min-w-0">
                <span className="font-semibold">{METHOD_LABEL[p.method]}</span>
                {p.method === 'kasbon' && p.customerId && <span className="ml-2 text-xs text-muted">{state.customersById.get(p.customerId)?.name}</span>}
                {p.status === 'pending' && <span className="pill pill-warn ml-2">Menunggu</span>}
                {p.reference && <span className="ml-2 text-xs text-muted">Ref {p.reference}</span>}
              </span>
              <span className="flex items-center gap-2">
                <span className="money font-semibold">{formatRupiah(p.amount)}</span>
                <button
                  type="button"
                  className="btn-icon size-8 border-transparent"
                  aria-label={`Hapus pembayaran ${METHOD_LABEL[p.method]}`}
                  onClick={() => setPayments((l) => l.filter((_, j) => j !== i))}
                  disabled={busy}
                >
                  <LuX size={15} />
                </button>
              </span>
            </li>
          ))}
        </ul>
      )}

      {total === 0 ? (
        <p className="text-sm text-muted">Total Rp 0, tidak perlu pembayaran. Transaksi tetap dicatat dan stok berkurang.</p>
      ) : remaining === 0 ? (
        <p className="text-sm text-muted">Tagihan sudah terpenuhi. Tekan Selesaikan transaksi.</p>
      ) : (
        <>
          <span className="label">Metode</span>
          <div className="mb-4 grid grid-cols-3 gap-2" role="radiogroup" aria-label="Metode pembayaran">
            {usable.map((m) => {
              const Icon = ICON[m];
              const active = m === method;
              return (
                <button
                  key={m}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  onClick={() => {
                    setMethod(m);
                    setAmount(null);
                    setTendered(null);
                  }}
                  className={cx(
                    'flex min-h-16 flex-col items-center justify-center gap-1 rounded-md border px-2 py-2 text-[13px] font-semibold transition-colors',
                    active ? 'border-accent bg-accentsoft text-accent' : 'border-line bg-panel text-ink hover:bg-sunken',
                  )}
                >
                  <Icon size={20} aria-hidden="true" />
                  {METHOD_LABEL[m]}
                </button>
              );
            })}
          </div>

          {isCash ? (
            <div>
              <span className="label">Uang diterima</span>
              <MoneyInput
                autoFocus
                value={tendered}
                placeholder={formatNumber(remaining)}
                onChange={setTendered}
                onEnter={confirm}
                aria-label="Uang diterima"
              />
              <div className="mt-2 flex flex-wrap gap-2">
                <button type="button" className="btn btn-soft btn-sm" onClick={() => setTendered(remaining)}>
                  Uang pas
                </button>
                {QUICK_CASH.map((v) => (
                  <button key={v} type="button" className="btn btn-ghost btn-sm" disabled={v < remaining} onClick={() => setTendered(v)}>
                    {formatNumber(v / 1000)}rb
                  </button>
                ))}
              </div>
              <div className="mt-3 flex items-baseline justify-between rounded-md border border-dashed border-line px-3 py-2.5">
                <span className="text-sm text-muted">{cashReceived < remaining ? 'Kurang' : 'Kembalian'}</span>
                <span className={cx('money text-xl font-extrabold', cashReceived < remaining ? 'text-warn' : 'text-good')}>
                  {formatRupiah(cashReceived < remaining ? remaining - cashReceived : change)}
                </span>
              </div>
              {cashReceived < remaining && cashReceived > 0 && (
                <p className="hint">Uang kurang dari sisa tagihan. Tombol di bawah akan mencatatnya sebagai pembayaran sebagian, sisanya bisa dibayar dengan metode lain.</p>
              )}
            </div>
          ) : isKasbon ? (
            <div className="grid gap-3">
              <CustomerPicker value={customerId} onChange={setCustomerId} />
              <div>
                <span className="label">Jumlah dikasbonkan</span>
                <MoneyInput
                  value={amount}
                  placeholder={formatNumber(remaining)}
                  onChange={setAmount}
                  onEnter={confirm}
                  invalid={entryAmount > remaining || overLimit}
                  aria-label="Jumlah kasbon"
                />
                <p className="hint">Kosongkan untuk mengkasbonkan seluruh sisa. Isi sebagian jika pelanggan membayar sisanya dengan metode lain.</p>
              </div>
              {customer && (
                <div className="rounded-md border border-dashed border-line px-3 py-2.5 text-sm">
                  <div className="flex items-baseline justify-between gap-3">
                    <span className="text-muted">Kasbon {customer.name}</span>
                    <span className="money font-semibold">
                      {formatRupiah(owed)} <span className="text-muted">→</span> <span className={overLimit ? 'text-bad' : 'text-warn'}>{formatRupiah(owed + entryAmount)}</span>
                    </span>
                  </div>
                  {limit > 0 && (
                    <p className={cx('mt-1 text-xs', overLimit ? 'text-bad' : 'text-muted')}>
                      {overLimit
                        ? `Melebihi batas kasbon ${customer.name} (${formatRupiah(limit)}). Kurangi jumlahnya atau bayar sebagian dengan metode lain.`
                        : `Batas kasbon ${formatRupiah(limit)}, masih tersedia ${formatRupiah(Math.max(0, limit - owed))}.`}
                    </p>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div className="grid gap-3">
              <div>
                <span className="label">Jumlah</span>
                <MoneyInput
                  autoFocus
                  value={amount}
                  placeholder={formatNumber(remaining)}
                  onChange={setAmount}
                  onEnter={confirm}
                  invalid={entryAmount > remaining}
                  aria-label="Jumlah pembayaran"
                />
                <p className="hint">Kosongkan untuk membayar seluruh sisa. Isi sebagian jika dibagi dengan metode lain.</p>
              </div>
              <label className="block">
                <span className="label">Nomor referensi (opsional)</span>
                <input className="input" value={reference} onChange={(e) => setReference(e.target.value)} placeholder="Mis. 4 digit akhir atau kode transaksi" onKeyDown={(e) => e.key === 'Enter' && confirm()} />
              </label>
              <div>
                <span className="label">Status pembayaran</span>
                <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label="Status pembayaran">
                  {(
                    [
                      ['success', 'Sukses'],
                      ['pending', 'Menunggu konfirmasi'],
                    ] as const
                  ).map(([v, text]) => (
                    <button
                      key={v}
                      type="button"
                      role="radio"
                      aria-checked={status === v}
                      onClick={() => setStatus(v)}
                      className={cx(
                        'min-h-11 rounded-md border px-3 text-[13px] font-semibold transition-colors',
                        status === v ? 'border-accent bg-accentsoft text-accent' : 'border-line bg-panel hover:bg-sunken',
                      )}
                    >
                      {text}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {error && (
        <p role="alert" className="err mt-3 text-sm">
          {error}
        </p>
      )}
    </Modal>
  );
}
