import { useMemo, useState } from 'react';
import { LuClipboardCheck, LuSearch } from 'react-icons/lu';
import { formatDate, formatQty, formatRupiah } from '../core/format';
import { OPNAME_ALL, cancelOpname, finishOpname, lineDiff, saveOpnameCount, startOpname, summarizeOpname } from '../core/opname';
import type { OpnameLine, OpnameSession } from '../core/types';
import { useAppState, useStore } from '../app/state';
import { ConfirmDialog, EmptyState, Field, Modal, NumberInput, cx, errorMessage, useAction, useToast } from '../app/ui';

function signed(n: number): string {
  return `${n > 0 ? '+' : n < 0 ? '-' : ''}${formatQty(Math.abs(n))}`;
}

function DiffText({ line }: { line: OpnameLine }) {
  const d = lineDiff(line);
  if (d === null) return null;
  if (d === 0) return <span className="text-xs font-semibold text-good">Sesuai</span>;
  return (
    <span className={cx('money text-xs font-semibold', d > 0 ? 'text-warn' : 'text-bad')}>
      Selisih {signed(d)} {line.unit}
    </span>
  );
}

/** One product in the counting list. Saves when the field loses focus or Enter is pressed. */
function CountRow({ session, line }: { session: OpnameSession; line: OpnameLine }) {
  const state = useAppState();
  const store = useStore();
  const toast = useToast();
  const [val, setVal] = useState<number | null>(line.countedQty);
  const [error, setError] = useState<string | null>(null);
  const live = state.productsById.get(line.productId)?.stock ?? line.systemQty;
  const systemShown = line.countedQty === null ? live : line.systemQty;

  const save = async () => {
    if (val === line.countedQty) return;
    try {
      setError(null);
      await saveOpnameCount(store, { sessionId: session.id, productId: line.productId, countedQty: val });
    } catch (e) {
      setError(errorMessage(e));
      toast(errorMessage(e), 'err');
    }
  };

  return (
    <li className="px-4 py-3">
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold">{line.name}</p>
          <p className="text-xs text-muted">
            Sistem: <span className="money">{formatQty(systemShown)}</span> {line.unit}
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-2" onBlur={save}>
          <NumberInput
            className={cx('min-h-10 w-24 text-right', error && 'input-invalid')}
            aria-label={`Jumlah dihitung ${line.name}`}
            placeholder="Hitung"
            value={val}
            onChange={setVal}
            onEnter={save}
            invalid={Boolean(error)}
          />
          <span className="w-9 text-xs text-muted">{line.unit}</span>
        </div>
      </div>
      <div className="mt-1 min-h-4 text-right">{error ? <span className="err">{error}</span> : <DiffText line={line} />}</div>
    </li>
  );
}

function DraftView({ session }: { session: OpnameSession }) {
  const state = useAppState();
  const store = useStore();
  const { busy, run } = useAction();
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState<'all' | 'todo' | 'diff'>('all');
  const [limit, setLimit] = useState(60);
  const [finishing, setFinishing] = useState(false);
  const [cancelling, setCancelling] = useState(false);

  const costOf = (id: string) => state.productsById.get(id)?.costPrice ?? 0;
  const counted = session.lines.filter((l) => l.countedQty !== null).length;
  const preview = summarizeOpname(session.lines, costOf);

  const shown = useMemo(() => {
    const s = q.trim().toLowerCase();
    return session.lines.filter((l) => {
      if (s && !l.name.toLowerCase().includes(s)) return false;
      if (filter === 'todo') return l.countedQty === null;
      if (filter === 'diff') return (lineDiff(l) ?? 0) !== 0;
      return true;
    });
  }, [session.lines, q, filter]);

  const finish = async () => {
    const done = await run(() => finishOpname(store, session.id), 'Opname selesai. Stok sudah disesuaikan.');
    if (done) setFinishing(false);
  };

  return (
    <>
      <div className="card mb-3 p-4">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <p className="text-sm font-bold">
            Opname {session.scope === OPNAME_ALL ? 'semua produk' : session.scope}
            <span className="ml-2 text-xs font-normal text-muted">mulai {formatDate(session.startedAt)}</span>
          </p>
          <p className="money text-sm" aria-live="polite">
            <strong>{counted}</strong> / {session.lines.length} dihitung
          </p>
        </div>
        <div className="mt-2 h-2 overflow-hidden rounded-full bg-sunken" role="progressbar" aria-valuemin={0} aria-valuemax={session.lines.length} aria-valuenow={counted} aria-label="Kemajuan menghitung">
          <div className="h-full bg-accent transition-[width]" style={{ width: `${session.lines.length ? (counted / session.lines.length) * 100 : 0}%` }} />
        </div>
        {session.note && <p className="mt-2 text-xs text-muted">{session.note}</p>}
        <div className="mt-3 flex flex-wrap gap-2">
          <button type="button" className="btn btn-primary" disabled={counted === 0 || busy} onClick={() => setFinishing(true)}>
            Selesai dan terapkan
          </button>
          <button type="button" className="btn btn-ghost text-bad" disabled={busy} onClick={() => setCancelling(true)}>
            Batalkan
          </button>
        </div>
      </div>

      <div className="mb-3 flex flex-wrap items-center gap-2">
        <div className="relative min-w-0 flex-1 basis-48">
          <LuSearch className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-faint" size={16} />
          <input className="input pl-9" placeholder="Cari produk" aria-label="Cari produk yang dihitung" value={q} onChange={(e) => { setQ(e.target.value); setLimit(60); }} />
        </div>
        <div className="inline-flex rounded-lg bg-sunken p-1" role="group" aria-label="Filter hitungan">
          {(
            [
              ['all', 'Semua'],
              ['todo', 'Belum'],
              ['diff', 'Selisih'],
            ] as const
          ).map(([id, text]) => (
            <button key={id} type="button" aria-pressed={filter === id} onClick={() => { setFilter(id); setLimit(60); }} className={cx('min-h-9 rounded-md px-3 text-[13px] font-semibold', filter === id ? 'bg-panel text-ink shadow-sm' : 'text-muted hover:text-ink')}>
              {text}
            </button>
          ))}
        </div>
      </div>

      <div className="card overflow-hidden">
        {shown.length === 0 ? (
          <p className="px-4 py-6 text-center text-sm text-muted">{filter === 'todo' ? 'Semua produk sudah dihitung.' : 'Tidak ada produk yang cocok.'}</p>
        ) : (
          <ul className="divide-y divide-line">
            {shown.slice(0, limit).map((l) => (
              <CountRow key={l.productId} session={session} line={l} />
            ))}
          </ul>
        )}
      </div>
      {shown.length > limit && (
        <div className="mt-3 text-center">
          <button type="button" className="btn btn-ghost" onClick={() => setLimit((n) => n + 100)}>
            Tampilkan lebih banyak ({shown.length - limit} lagi)
          </button>
        </div>
      )}

      {finishing && (
        <ConfirmDialog
          title="Selesaikan opname?"
          confirmLabel="Terapkan ke stok"
          busy={busy}
          onClose={() => setFinishing(false)}
          onConfirm={finish}
          message={
            <>
              <p>
                {preview.counted} produk dihitung, <strong>{preview.withDiff} berbeda</strong> dari sistem.
              </p>
              {preview.withDiff > 0 && (
                <p className="mt-2">
                  Stok akan disesuaikan: {preview.plusQty > 0 ? `lebih ${formatQty(preview.plusQty)}` : ''}
                  {preview.plusQty > 0 && preview.minusQty > 0 ? ', ' : ''}
                  {preview.minusQty > 0 ? `kurang ${formatQty(preview.minusQty)}` : ''} (nilai {preview.diffValue < 0 ? 'rugi ' : 'untung '}
                  <span className="money">{formatRupiah(Math.abs(preview.diffValue))}</span> menurut harga modal).
                </p>
              )}
              <p className="mt-2">Produk yang belum dihitung tidak diubah.</p>
            </>
          }
        />
      )}
      {cancelling && (
        <ConfirmDialog
          title="Batalkan opname?"
          message="Semua hitungan yang sudah diisi dihapus. Stok tidak berubah."
          confirmLabel="Batalkan opname"
          danger
          busy={busy}
          onClose={() => setCancelling(false)}
          onConfirm={async () => {
            await run(() => cancelOpname(store, session.id), 'Opname dibatalkan.');
            setCancelling(false);
          }}
        />
      )}
    </>
  );
}

function StartView() {
  const state = useAppState();
  const store = useStore();
  const { busy, run } = useAction();
  const [scope, setScope] = useState(OPNAME_ALL);
  const [note, setNote] = useState('');
  const categories = useMemo(() => [...new Set(state.products.filter((p) => p.active).map((p) => p.category))].sort((a, b) => a.localeCompare(b, 'id')), [state.products]);
  const activeCount = state.products.filter((p) => p.active && (scope === OPNAME_ALL || p.category === scope)).length;

  return (
    <div className="card mb-5 p-4">
      <h2 className="text-sm font-bold">Hitung stok di rak</h2>
      <p className="mt-1 mb-3 text-sm text-muted">
        Hitung barang yang benar-benar ada, isi jumlahnya, lalu bandingkan dengan catatan sistem. Stok baru berubah saat kamu menekan Selesai.
      </p>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Yang dihitung">
          <select className="input" value={scope} onChange={(e) => setScope(e.target.value)} aria-label="Cakupan opname">
            <option value={OPNAME_ALL}>Semua produk</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                Kategori {c}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Catatan (boleh kosong)">
          <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Mis. cek akhir bulan" />
        </Field>
      </div>
      <button type="button" className="btn btn-primary mt-3" disabled={busy || activeCount === 0} onClick={() => run(() => startOpname(store, { scope, note }))}>
        <LuClipboardCheck size={16} /> Mulai opname ({activeCount} produk)
      </button>
    </div>
  );
}

function SessionDetail({ session, onClose }: { session: OpnameSession; onClose: () => void }) {
  const rows = session.lines.filter((l) => (lineDiff(l) ?? 0) !== 0);
  const s = session.summary;
  return (
    <Modal title={`Opname ${formatDate(session.startedAt)}`} onClose={onClose}>
      <p className="mb-3 text-sm text-muted">
        {session.scope === OPNAME_ALL ? 'Semua produk' : `Kategori ${session.scope}`}
        {session.note ? ` · ${session.note}` : ''}
        {session.finishedAt ? ` · selesai ${formatDate(session.finishedAt)}` : ''}
      </p>
      {s && (
        <p className="mb-3 text-sm">
          {s.counted} dihitung, {s.withDiff} berbeda. Nilai selisih{' '}
          <strong className={cx('money', s.diffValue < 0 ? 'text-bad' : s.diffValue > 0 ? 'text-warn' : '')}>
            {s.diffValue < 0 ? '-' : ''}
            {formatRupiah(Math.abs(s.diffValue))}
          </strong>
          .
        </p>
      )}
      {rows.length === 0 ? (
        <p className="text-sm text-muted">Semua hitungan sesuai dengan sistem.</p>
      ) : (
        <ul className="divide-y divide-line text-sm">
          {rows.map((l) => (
            <li key={l.productId} className="flex items-start justify-between gap-3 py-2">
              <span className="min-w-0">
                <span className="block truncate font-semibold">{l.name}</span>
                <span className="money block text-xs text-muted">
                  Sistem {formatQty(l.systemQty)}, dihitung {formatQty(l.countedQty ?? 0)} {l.unit}
                </span>
              </span>
              <span className={cx('money shrink-0 font-semibold', (lineDiff(l) ?? 0) > 0 ? 'text-warn' : 'text-bad')}>{signed(lineDiff(l) ?? 0)}</span>
            </li>
          ))}
        </ul>
      )}
    </Modal>
  );
}

export function OpnameTab() {
  const state = useAppState();
  const [open, setOpen] = useState<string | null>(null);
  const [limit, setLimit] = useState(30);
  const draft = state.opnames.find((o) => o.status === 'draft');
  const done = state.opnames.filter((o) => o.status === 'done');
  const detail = open ? state.opnames.find((o) => o.id === open) : undefined;

  return (
    <>
      {draft ? <DraftView key={draft.id} session={draft} /> : <StartView />}
      {!draft && (
        <section aria-label="Riwayat opname">
          <h2 className="mb-2 text-sm font-bold">Riwayat opname</h2>
          <div className="card overflow-hidden">
            {done.length === 0 ? (
              <EmptyState icon={<LuClipboardCheck size={22} />} title="Belum ada opname">
                Hasil hitungan yang sudah selesai akan tercatat di sini.
              </EmptyState>
            ) : (
              <ul className="divide-y divide-line">
                {done.slice(0, limit).map((o) => (
                  <li key={o.id}>
                    <button type="button" onClick={() => setOpen(o.id)} className="flex min-h-14 w-full items-center justify-between gap-3 px-4 py-2.5 text-left hover:bg-sunken">
                      <span className="min-w-0">
                        <span className="block text-sm font-semibold">{formatDate(o.startedAt)}</span>
                        <span className="block truncate text-xs text-muted">{o.scope === OPNAME_ALL ? 'Semua produk' : `Kategori ${o.scope}`}</span>
                      </span>
                      <span className="shrink-0 text-right text-xs text-muted">
                        {o.summary?.counted ?? 0} dihitung
                        <span className="block">{o.summary?.withDiff ?? 0} berbeda</span>
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
          {done.length > limit && (
            <div className="mt-3 text-center">
              <button type="button" className="btn btn-ghost" onClick={() => setLimit((n) => n + 30)}>
                Tampilkan lebih banyak ({done.length - limit} lagi)
              </button>
            </div>
          )}
        </section>
      )}
      {detail && <SessionDetail session={detail} onClose={() => setOpen(null)} />}
    </>
  );
}
