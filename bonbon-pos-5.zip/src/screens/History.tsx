import { useMemo, useState } from 'react';
import { LuBan, LuBanknote, LuCircleCheck, LuCreditCard, LuHandCoins, LuLandmark, LuQrCode, LuReceiptText, LuUndo2 } from 'react-icons/lu';
import { addDaysKey, formatDateKey, formatDateTime, formatQty, formatRupiah, formatTime, todayKey } from '../core/format';
import { revenueOf } from '../core/queries';
import { refundMethodLabel } from '../core/returns';
import { confirmPayment, voidTransaction } from '../core/services';
import type { PaymentMethod, Transaction } from '../core/types';
import { METHOD_LABEL } from '../core/types';
import { ReceiptModal } from '../app/Receipt';
import { useAppState, useStore } from '../app/state';
import { ReturnDialog } from './ReturnDialog';
import { EmptyState, Field, Modal, PageHeader, cx, errorMessage, useToast } from '../app/ui';

type Range = 'today' | '7' | '30' | 'date' | 'all';
type StatusFilter = '' | 'completed' | 'voided' | 'pending' | 'returned';

const VOID_REASONS = ['Salah input', 'Salah produk', 'Pelanggan batal', 'Pembayaran gagal'];

function hasPending(t: Transaction) {
  return t.status === 'completed' && t.payments.some((p) => p.status === 'pending');
}

function MethodIcon({ m, size = 20 }: { m: PaymentMethod; size?: number }) {
  const Icon = m === 'cash' ? LuBanknote : m === 'qris' ? LuQrCode : m === 'transfer' ? LuLandmark : m === 'kasbon' ? LuHandCoins : LuCreditCard;
  return <Icon size={size} aria-hidden="true" />;
}

function StatusBadge({ t, partial = false }: { t: Transaction; partial?: boolean }) {
  if (t.status === 'voided') return <span className="pill pill-bad">Dibatalkan</span>;
  if (t.status === 'returned') return <span className="pill pill-warn">Diretur</span>;
  if (partial) return <span className="pill pill-warn">Retur sebagian</span>;
  if (hasPending(t)) return <span className="pill pill-warn">Menunggu konfirmasi</span>;
  return <span className="pill pill-good">Selesai</span>;
}

function VoidDialog({ tx, onClose, onDone }: { tx: Transaction; onClose: () => void; onDone: () => void }) {
  const store = useStore();
  const toast = useToast();
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const kasbon = tx.payments.find((p) => p.method === 'kasbon');

  const submit = async () => {
    setBusy(true);
    setError(null);
    try {
      await voidTransaction(store, tx.id, reason);
      toast(`${tx.receiptNo} dibatalkan. Stok dikembalikan.`);
      onDone();
    } catch (e) {
      setError(errorMessage(e));
      setBusy(false);
    }
  };

  return (
    <Modal
      title={`Void ${tx.receiptNo}`}
      size="sm"
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>
            Batal
          </button>
          <button type="button" className="btn btn-danger" onClick={submit} disabled={busy}>
            {busy ? 'Memproses...' : 'Void transaksi'}
          </button>
        </>
      }
    >
      <p className="mb-3 text-sm text-muted">
        Transaksi senilai <strong className="money text-ink">{formatRupiah(tx.total)}</strong> akan ditandai dibatalkan dan stok setiap item dikembalikan. Datanya tidak dihapus.
      </p>
      {kasbon && (
        <p className="mb-3 rounded-md bg-warnsoft px-3 py-2 text-sm text-warn">
          Kasbon {tx.customerName} sebesar <strong className="money">{formatRupiah(kasbon.amount)}</strong> dari transaksi ini ikut dibatalkan (dikurangi dari buku kasbon).
        </p>
      )}
      <div className="mb-2 flex flex-wrap gap-2">
        {VOID_REASONS.map((r) => (
          <button key={r} type="button" onClick={() => setReason(r)} className={cx('min-h-9 rounded-full border px-3 text-[13px] font-semibold', reason === r ? 'border-accent bg-accentsoft text-accent' : 'border-line bg-panel text-muted hover:text-ink')}>
            {r}
          </button>
        ))}
      </div>
      <Field label="Alasan (wajib)">
        <input className="input" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Tulis alasan void" onKeyDown={(e) => e.key === 'Enter' && submit()} />
      </Field>
      {error && (
        <p role="alert" className="err mt-2 text-sm">
          {error}
        </p>
      )}
    </Modal>
  );
}

function TransactionDetail({ id, onClose }: { id: string; onClose: () => void }) {
  const state = useAppState();
  const store = useStore();
  const toast = useToast();
  const [voiding, setVoiding] = useState(false);
  const [returning, setReturning] = useState(false);
  const tx = state.txById.get(id);
  if (!tx) return null;

  const returns = state.returnsByTx.get(tx.id) ?? [];
  const canVoid = tx.status === 'completed' && tx.dateKey === todayKey() && returns.length === 0;
  const canReturn = tx.status === 'completed' && !tx.payments.some((p) => p.status === 'pending');
  const pending = tx.status === 'completed' ? tx.payments.map((p, i) => ({ p, i })).filter((x) => x.p.status === 'pending') : [];

  return (
    <>
      <ReceiptModal
        tx={tx}
        settings={state.settings}
        onClose={onClose}
        before={
          <>
            <div className="mb-3 flex flex-wrap items-center gap-2 text-sm">
              <StatusBadge t={tx} partial={returns.length > 0} />
              {tx.status === 'voided' && tx.voidReason && <span className="text-muted">Alasan: {tx.voidReason}</span>}
              {tx.status === 'completed' && tx.dateKey !== todayKey() && <span className="text-xs text-muted">Void hanya untuk transaksi hari ini.</span>}
            </div>
            {returns.length > 0 && (
              <div className="mb-3 rounded-lg border border-line bg-warnsoft p-3 text-sm text-warn">
                <p className="mb-1 font-semibold">Retur</p>
                <ul className="grid gap-1.5">
                  {returns.map((r) => (
                    <li key={r.id}>
                      {r.lines.map((l) => `${formatQty(l.unitQty)} ${l.unitName} ${l.name}`).join(', ')}
                      <span className="block text-xs">
                        {formatDateTime(r.createdAt)} · {r.reason} · uang kembali <span className="money">{formatRupiah(r.refund)}</span> ({refundMethodLabel(r.refundMethod)}){r.restock ? '' : ' · tidak masuk stok'}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {pending.length > 0 && (
              <div className="mb-3 grid gap-2 rounded-lg border border-line bg-warnsoft p-3">
                {pending.map(({ p, i }) => (
                  <div key={i} className="flex flex-wrap items-center justify-between gap-2 text-sm text-warn">
                    <span>
                      {METHOD_LABEL[p.method]} {formatRupiah(p.amount)} belum dikonfirmasi{p.reference ? ` (ref ${p.reference})` : ''}
                    </span>
                    <button
                      type="button"
                      className="btn btn-primary btn-sm"
                      onClick={async () => {
                        try {
                          await confirmPayment(store, tx.id, i);
                          toast('Pembayaran dikonfirmasi.');
                        } catch (e) {
                          toast(errorMessage(e), 'err');
                        }
                      }}
                    >
                      <LuCircleCheck size={15} /> Sudah diterima
                    </button>
                  </div>
                ))}
              </div>
            )}
          </>
        }
        extra={
          <>
            {canReturn && (
              <button type="button" className="btn btn-ghost" onClick={() => setReturning(true)}>
                <LuUndo2 size={16} /> Retur
              </button>
            )}
            {canVoid && (
              <button type="button" className="btn btn-ghost text-bad" onClick={() => setVoiding(true)}>
                <LuBan size={16} /> Void
              </button>
            )}
          </>
        }
      />
      {returning && <ReturnDialog tx={tx} onClose={() => setReturning(false)} onDone={() => { setReturning(false); toast('Retur dicatat.'); }} />}
      {voiding && <VoidDialog tx={tx} onClose={() => setVoiding(false)} onDone={() => { setVoiding(false); onClose(); }} />}
    </>
  );
}

export function HistoryScreen() {
  const state = useAppState();
  const [range, setRange] = useState<Range>('today');
  const [date, setDate] = useState(todayKey());
  const [method, setMethod] = useState<PaymentMethod | ''>('');
  const [status, setStatus] = useState<StatusFilter>('');
  const [openId, setOpenId] = useState<string | null>(null);

  const today = todayKey();
  const filtered = useMemo(() => {
    const from = range === 'today' ? today : range === '7' ? addDaysKey(today, -6) : range === '30' ? addDaysKey(today, -29) : range === 'date' ? date : '';
    const to = range === 'date' ? date : today;
    return state.transactions.filter((t) => {
      if (from && (t.dateKey < from || t.dateKey > to)) return false;
      if (method && !t.payments.some((p) => p.method === method)) return false;
      if (status === 'completed' && t.status !== 'completed') return false;
      if (status === 'voided' && t.status !== 'voided') return false;
      if (status === 'pending' && !hasPending(t)) return false;
      if (status === 'returned' && !state.returnsByTx.has(t.id)) return false;
      return true;
    });
  }, [state.transactions, state.returnsByTx, range, date, method, status, today]);

  const totals = useMemo(() => {
    let count = 0;
    let total = 0;
    let net = 0;
    let refunds = 0;
    for (const t of filtered) {
      if (t.status === 'voided') continue;
      count += 1;
      total += t.total;
      net += revenueOf(t);
      for (const r of state.returnsByTx.get(t.id) ?? []) refunds += r.refund;
    }
    return { count, total, net, refunds };
  }, [filtered, state.returnsByTx]);

  const groups = useMemo(() => {
    const out: { key: string; list: Transaction[] }[] = [];
    for (const t of filtered) {
      const last = out[out.length - 1];
      if (last && last.key === t.dateKey) last.list.push(t);
      else out.push({ key: t.dateKey, list: [t] });
    }
    return out;
  }, [filtered]);

  const ranges: [Range, string][] = [
    ['today', 'Hari ini'],
    ['7', '7 hari'],
    ['30', '30 hari'],
    ['date', 'Pilih tanggal'],
    ['all', 'Semua'],
  ];

  return (
    <>
      <PageHeader title="Riwayat" subtitle="Daftar transaksi. Klik satu transaksi untuk melihat struk, void, atau konfirmasi pembayaran." />

      <div className="mb-4 grid grid-cols-2 items-center gap-2 sm:flex sm:flex-wrap">
        <div className="scroll-x -mx-1 col-span-2 flex w-full gap-2 px-1 pb-1" role="group" aria-label="Rentang tanggal">
          {ranges.map(([r, text]) => (
            <button key={r} type="button" aria-pressed={range === r} onClick={() => setRange(r)} className={cx('chip', range === r && 'chip-on')}>
              {text}
            </button>
          ))}
        </div>
        {range === 'date' && <input type="date" className="input w-auto" aria-label="Tanggal" value={date} max={today} onChange={(e) => e.target.value && setDate(e.target.value)} />}
        <select className="input w-auto" aria-label="Filter metode" value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod | '')}>
          <option value="">Semua metode</option>
          {[...state.settings.enabledMethods, 'kasbon' as const].map((m) => (
            <option key={m} value={m}>
              {METHOD_LABEL[m]}
            </option>
          ))}
        </select>
        <select className="input w-auto" aria-label="Filter status" value={status} onChange={(e) => setStatus(e.target.value as StatusFilter)}>
          <option value="">Semua status</option>
          <option value="completed">Selesai</option>
          <option value="pending">Menunggu konfirmasi</option>
          <option value="returned">Ada retur</option>
          <option value="voided">Dibatalkan</option>
        </select>
      </div>

      <div className="card overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1 border-b border-line bg-accentsoft/60 px-4 py-3.5 text-sm">
          <span className="font-semibold text-muted">
            {totals.count} transaksi{filtered.length !== totals.count ? ` (+${filtered.length - totals.count} dibatalkan)` : ''}
          </span>
          <span className="text-muted">
            Total <strong className="money text-lg font-extrabold text-ink">{formatRupiah(totals.total)}</strong>
            {totals.refunds > 0 && <span className="money ml-2 text-warn">retur -{formatRupiah(totals.refunds)}</span>}
          </span>
        </div>
        {filtered.length === 0 ? (
          <EmptyState icon={<LuReceiptText size={22} />} title="Belum ada transaksi">
            Transaksi yang dibuat di layar Kasir akan muncul di sini. Coba ubah rentang tanggal atau filter.
          </EmptyState>
        ) : (
          groups.map((g) => (
            <div key={g.key}>
              {(range !== 'today' || groups.length > 1) && (
                <p className="border-b border-line bg-canvas px-4 py-1.5 text-xs font-semibold text-muted">{g.key === today ? `Hari ini, ${formatDateKey(g.key)}` : formatDateKey(g.key)}</p>
              )}
              <ul className="divide-y divide-line">
                {g.list.map((t) => {
                  const first = t.items[0];
                  const more = t.items.length - 1;
                  const methods = [...new Set(t.payments.map((p) => p.method))];
                  const lead = methods.includes('kasbon') ? 'kasbon' : (methods[0] ?? 'cash');
                  const tone = t.status === 'voided' ? 'icon-box-bad' : hasPending(t) || t.status === 'returned' ? 'icon-box-warn' : lead === 'kasbon' ? 'icon-box-warn' : '';
                  return (
                    <li key={t.id}>
                      <button
                        type="button"
                        onClick={() => setOpenId(t.id)}
                        className={cx(
                          'grid w-full grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-x-3 gap-y-1 px-4 py-3.5 text-left transition-colors hover:bg-sunken/70 md:grid-cols-[auto_170px_minmax(0,1.6fr)_minmax(0,1fr)_120px_150px]',
                          t.status === 'voided' && 'opacity-60',
                        )}
                      >
                        <span className={cx('icon-box', tone)}>
                          <MethodIcon m={lead} />
                        </span>
                        <span className="min-w-0">
                          <span className="money block text-[13px] font-bold">{t.receiptNo}</span>
                          <span className="block text-xs text-muted">
                            {formatTime(t.createdAt)} · {t.cashierName}
                          </span>
                          <span className="mt-0.5 block truncate text-sm md:hidden">
                            {first?.name}
                            {more > 0 && <span className="text-muted"> +{more} lainnya</span>}
                          </span>
                        </span>
                        <span className="hidden truncate text-sm md:block">
                          {first?.name}
                          {more > 0 && <span className="text-muted"> +{more} lainnya</span>}
                        </span>
                        <span className="hidden flex-wrap gap-1 md:flex">
                          {methods.map((m) => (
                            <span key={m} className="pill pill-plain">
                              {m === 'kasbon' && t.customerName ? `Kasbon · ${t.customerName}` : METHOD_LABEL[m]}
                            </span>
                          ))}
                        </span>
                        <span className="flex flex-col items-end gap-1 md:contents">
                          <span className={cx('money text-[15px] font-extrabold md:text-right md:text-sm md:font-bold', t.status === 'voided' && 'line-through')}>{formatRupiah(t.total)}</span>
                          <span className="md:text-right">
                            <StatusBadge t={t} partial={state.returnsByTx.has(t.id)} />
                          </span>
                        </span>
                        <span className="col-span-3 flex flex-wrap gap-1 md:hidden">
                          {methods.map((m) => (
                            <span key={m} className="pill pill-plain">
                              {m === 'kasbon' && t.customerName ? `Kasbon · ${t.customerName}` : METHOD_LABEL[m]}
                            </span>
                          ))}
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))
        )}
      </div>

      {openId && <TransactionDetail id={openId} onClose={() => setOpenId(null)} />}
    </>
  );
}
