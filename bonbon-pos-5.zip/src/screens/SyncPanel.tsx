import { useState } from 'react';
import { LuCloud, LuCloudOff, LuLoaderCircle, LuRefreshCw, LuTriangleAlert } from 'react-icons/lu';
import { formatDateTime } from '../core/format';
import type { FirstSyncChoice } from '../core/sync/engine';
import { IS_ARTIFACT, IS_NATIVE } from '../app/runtime';
import { useSyncEngine, useSyncStatus } from '../app/sync';
import { Field, Modal, Tabs, cx, useAction } from '../app/ui';

type Way = 'masuk' | 'daftar' | 'kode' | 'google';

function SignedOut() {
  const engine = useSyncEngine();
  const status = useSyncStatus();
  const { busy, run } = useAction();
  const [way, setWay] = useState<Way>('masuk');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [sent, setSent] = useState(false);
  if (!engine) return null;
  const api = engine.api;

  const canPassword = email.trim().length > 3 && password.length >= 6;
  const tabs: { id: Way; label: string }[] = [
    { id: 'masuk', label: 'Masuk' },
    { id: 'daftar', label: 'Daftar' },
    { id: 'kode', label: 'Kode email' },
    { id: 'google', label: 'Google' },
  ];

  return (
    <div className="grid gap-3">
      <p className="hint">Masuk dengan akun yang sama di semua HP. Datamu tetap tersimpan di HP dan jalan tanpa internet; sinkron hanya terjadi saat ada koneksi. Login ini opsional.</p>
      {status.error && (
        <p className="err" role="alert">
          {status.error}
        </p>
      )}
      <Tabs
        tabs={tabs}
        value={way}
        onChange={(w) => {
          setWay(w);
          setSent(false);
        }}
      />

      {(way === 'masuk' || way === 'daftar') && (
        <form
          className="grid gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            if (!canPassword) return;
            void run(async () => {
              const s = way === 'daftar' ? await api.signUp(email, password) : await api.signIn(email, password);
              await engine.afterSignIn(s);
            });
          }}
        >
          <Field label="Email">
            <input className="input" type="email" autoComplete="email" inputMode="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label="Kata sandi" hint={way === 'daftar' ? 'Minimal 6 karakter.' : undefined}>
            <input className="input" type="password" autoComplete={way === 'daftar' ? 'new-password' : 'current-password'} value={password} onChange={(e) => setPassword(e.target.value)} />
          </Field>
          <button type="submit" className="btn btn-primary" disabled={busy || !canPassword}>
            {way === 'daftar' ? 'Buat akun' : 'Masuk'}
          </button>
        </form>
      )}

      {way === 'kode' && (
        <div className="grid gap-3">
          <Field label="Email">
            <input className="input" type="email" autoComplete="email" inputMode="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          {!sent ? (
            <button
              type="button"
              className="btn btn-primary"
              disabled={busy || email.trim().length < 4}
              onClick={() => void run(async () => {
                await api.sendCode(email);
                setSent(true);
              }, 'Kode dikirim. Cek emailmu.')}
            >
              Kirim kode ke email
            </button>
          ) : (
            <form
              className="grid gap-3"
              onSubmit={(e) => {
                e.preventDefault();
                void run(async () => engine.afterSignIn(await api.verifyCode(email, code)));
              }}
            >
              <Field label="Kode dari email" hint="Ketik kode angka yang dikirim ke emailmu. Bisa berlaku beberapa menit saja.">
                <input className="input" inputMode="numeric" autoComplete="one-time-code" value={code} onChange={(e) => setCode(e.target.value.replace(/\s/g, ''))} />
              </Field>
              <div className="flex gap-2">
                <button type="submit" className="btn btn-primary flex-1" disabled={busy || code.length < 4}>
                  Masuk
                </button>
                <button type="button" className="btn btn-ghost" disabled={busy} onClick={() => setSent(false)}>
                  Ganti email
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {way === 'google' && (
        <div className="grid gap-3">
          {IS_NATIVE ? (
            <p className="hint">Masuk dengan Google belum tersedia di aplikasi Android. Pakai tab Masuk atau Kode email; akunnya tetap sama di semua HP.</p>
          ) : (
            <>
              <p className="hint">Kamu akan diarahkan ke Google, lalu kembali ke sini.</p>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => {
                  window.location.href = api.googleUrl(window.location.origin + window.location.pathname);
                }}
              >
                Lanjut dengan Google
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}

function ago(iso?: string): string {
  return iso ? formatDateTime(iso) : 'belum pernah';
}

function SignedIn() {
  const engine = useSyncEngine();
  const status = useSyncStatus();
  const { busy, run } = useAction();
  if (!engine) return null;
  const syncing = status.phase === 'syncing';
  const tone = status.phase === 'error' ? 'text-bad' : status.phase === 'offline' ? 'text-warn' : 'text-good';
  const label =
    status.phase === 'syncing' ? 'Menyinkronkan...' : status.phase === 'offline' ? 'Offline. Perubahan menunggu internet.' : status.phase === 'error' ? 'Sinkron bermasalah' : status.phase === 'choice' ? 'Menunggu pilihanmu' : 'Tersambung';
  return (
    <div className="grid gap-3">
      <div className="flex items-start gap-3">
        <span className={cx('mt-0.5', tone)} aria-hidden="true">
          {syncing ? <LuLoaderCircle className="animate-spin" size={22} /> : status.phase === 'offline' ? <LuCloudOff size={22} /> : status.phase === 'error' ? <LuTriangleAlert size={22} /> : <LuCloud size={22} />}
        </span>
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold">{status.email || 'Akun'}</p>
          <p className={cx('text-sm font-medium', tone)} role="status">
            {label}
          </p>
          <p className="hint">
            Terakhir sinkron: {ago(status.lastSyncAt)}
            {status.pending > 0 ? ` · ${status.pending} perubahan menunggu dikirim` : ''}
          </p>
          {status.error && (
            <p className="err" role="alert">
              {status.error}
            </p>
          )}
        </div>
      </div>
      <div className="flex flex-wrap gap-2">
        <button type="button" className="btn btn-ghost" disabled={busy || syncing || status.phase === 'choice'} onClick={() => void run(() => engine.sync())}>
          <LuRefreshCw size={17} /> Sinkronkan sekarang
        </button>
        <button type="button" className="btn btn-ghost" disabled={busy} onClick={() => void run(() => engine.signOut(), 'Keluar. Data di HP ini tetap ada.')}>
          Keluar
        </button>
      </div>
    </div>
  );
}

function FirstSyncDialog() {
  const engine = useSyncEngine();
  const status = useSyncStatus();
  const { busy, run } = useAction();
  if (!engine || status.phase !== 'choice' || !status.choice) return null;
  const { local, remote } = status.choice;
  const pick = (c: FirstSyncChoice) => void run(() => engine.resolveFirstSync(c));
  const opt = 'flex w-full flex-col items-start gap-0.5 rounded-xl border border-line bg-panel p-3 text-left hover:bg-sunken disabled:opacity-50';
  return (
    <Modal title="HP ini dan cloud sama-sama berisi data" size="sm" onClose={() => {}}>
      <p className="mb-3 text-sm text-muted">
        HP ini punya {local.toLocaleString('id-ID')} catatan, cloud punya {remote.toLocaleString('id-ID')}. Pilih apa yang terjadi, supaya tidak ada yang hilang tanpa sengaja.
      </p>
      <div className="grid gap-2">
        <button type="button" className={opt} disabled={busy} onClick={() => pick('merge')}>
          <span className="text-sm font-semibold">Gabungkan keduanya</span>
          <span className="hint">Semua data dari HP ini dan cloud disatukan. Pilih ini kalau dua-duanya data asli. Barang yang sama-sama diketik di dua HP bisa muncul dobel.</span>
        </button>
        <button type="button" className={opt} disabled={busy} onClick={() => pick('cloud')}>
          <span className="text-sm font-semibold">Pakai data cloud</span>
          <span className="hint">Data di HP ini dihapus dan diganti isi cloud. Cocok untuk HP baru.</span>
        </button>
        <button type="button" className={opt} disabled={busy} onClick={() => pick('local')}>
          <span className="text-sm font-semibold text-bad">Pakai data HP ini</span>
          <span className="hint">Isi cloud ditimpa data HP ini, dan HP lain ikut menghapus data yang tidak ada di sini.</span>
        </button>
      </div>
    </Modal>
  );
}

export function SyncPanel() {
  const engine = useSyncEngine();
  const status = useSyncStatus();
  if (IS_ARTIFACT || !engine) {
    return <p className="hint">Sinkron antar HP tidak tersedia di pratinjau ini. Buka lewat situs atau aplikasi Android Bonbon.</p>;
  }
  const signedIn = status.phase !== 'signedout';
  return (
    <>
      {signedIn ? <SignedIn /> : <SignedOut />}
      <FirstSyncDialog />
    </>
  );
}
