import { useMemo, useState } from 'react';
import { LuMinus, LuPlus } from 'react-icons/lu';
import { roundQty } from '../core/calc';
import { formatQty, formatRupiah } from '../core/format';
import { RETURN_REASONS, previewReturn, refundMethodLabel, returnItems, returnableQty } from '../core/returns';
import type { PaymentMethod, Transaction } from '../core/types';
import { useAppState, useStore } from '../app/state';
import { Field, Modal, NumberInput, cx, errorMessage, useAction } from '../app/ui';

export function ReturnDialog({ tx, onClose, onDone }: { tx: Transaction; onClose: () => void; onDone: () => void }) {
  const state = useAppState();
  const store = useStore();
  const { busy, run } = useAction();

  const prior = useMemo(() => state.returnsByTx.get(tx.id) ?? [], [state.returnsByTx, tx.id]);
  const left = useMemo(() => returnableQty(tx, prior), [tx, prior]);
  const owed = tx.customerId ? (state.balanceByCustomer.get(tx.customerId) ?? 0) : 0;

  const methods: PaymentMethod[] = useMemo(() => {
    const list: PaymentMethod[] = ['cash', ...state.settings.enabledMethods.filter((m) => m !== 'cash')];
    if (tx.customerId && owed > 0) list.push('kasbon');
    return list;
  }, [state.settings.enabledMethods, tx.customerId, owed]);

  const paidWith = tx.payments.filter((p) => p.method !== 'kasbon').sort((a, b) => b.amount - a.amount)[0]?.method;
  const [method, setMethod] = useState<PaymentMethod>(paidWith && methods.includes(paidWith) ? paidWith : methods.includes('kasbon') && !paidWith ? 'kasbon' : 'cash');
  const [qty, setQty] = useState<Record<number, number>>({});
  const [restock, setRestock] = useState(true);
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);

  const selection = tx.items.map((_, i) => ({ itemIndex: i, unitQty: qty[i] ?? 0 })).filter((s) => s.unitQty > 0);
  const preview = useMemo(() => {
    if (selection.length === 0) return null;
    try {
      return previewReturn(tx, prior, selection, restock);
    } catch (e) {
      return { error: errorMessage(e) } as const;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tx, prior, qty, restock]);
  const previewErr = preview && 'error' in preview ? preview.error : null;
  const ok = preview && !('error' in preview) ? preview : null;
  const kasbonShort = method === 'kasbon' && ok !== null && ok.refund > owed;

  const setItem = (i: number, v: number) => setQty((q) => ({ ...q, [i]: Math.max(0, Math.min(roundQty(v), left[i])) }));

  const submit = async () => {
    setError(null);
    if (selection.length === 0) return setError('Pilih barang yang diretur.');
    if (!reason.trim()) return setError('Alasan retur wajib diisi.');
    const r = await run(() => returnItems(store, { txId: tx.id, lines: selection, refundMethod: method, restock, reason }));
    if (r) onDone();
  };

  return (
    <Modal
      title={`Retur ${tx.receiptNo}`}
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>
            Batal
          </button>
          <button type="button" className="btn btn-primary" onClick={submit} disabled={busy || !ok || kasbonShort}>
            {busy ? 'Memproses...' : ok ? (ok.refund > 0 ? `Retur, kembalikan ${formatRupiah(ok.refund)}` : 'Retur (tanpa uang kembali)') : 'Retur'}
          </button>
        </>
      }
    >
      <p className="mb-3 text-sm text-muted">Pilih barang yang dikembalikan pelanggan dan berapa banyak. Transaksi lainnya tetap tercatat seperti semula.</p>

      <ul className="mb-4 divide-y divide-line rounded-md border border-line">
        {tx.items.map((item, i) => (
          <li key={i} className="flex items-center justify-between gap-3 px-3 py-2.5">
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold">{item.name}</p>
              <p className="text-xs text-muted">
                Dibeli {formatQty(item.unitQty)} {item.unitName}
                {left[i] !== item.unitQty ? ` · bisa diretur ${formatQty(left[i])}` : ''}
              </p>
            </div>
            {left[i] > 0 ? (
              <div className="flex shrink-0 items-center gap-1">
                <button type="button" className="btn-icon size-9" aria-label={`Kurangi retur ${item.name}`} onClick={() => setItem(i, (qty[i] ?? 0) - 1)}>
                  <LuMinus size={15} />
                </button>
                <NumberInput className="min-h-9 w-16 px-1 py-1 text-center" aria-label={`Jumlah retur ${item.name}`} placeholder="0" value={qty[i] ? qty[i] : null} onChange={(n) => setItem(i, n ?? 0)} />
                <button type="button" className="btn-icon size-9" aria-label={`Tambah retur ${item.name}`} onClick={() => setItem(i, (qty[i] ?? 0) + 1)}>
                  <LuPlus size={15} />
                </button>
              </div>
            ) : (
              <span className="text-xs font-semibold text-muted">Sudah diretur</span>
            )}
          </li>
        ))}
      </ul>

      <Field label="Uang dikembalikan lewat" className="mb-3">
        <select className="input" value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)} aria-label="Cara uang kembali">
          {methods.map((m) => (
            <option key={m} value={m}>
              {refundMethodLabel(m)}
              {m === 'kasbon' ? ` (utang ${formatRupiah(owed)})` : ''}
            </option>
          ))}
        </select>
      </Field>
      {kasbonShort && ok && <p className="err mb-3">Kasbon pelanggan tinggal {formatRupiah(owed)}, kurang dari nilai retur. Pilih tunai.</p>}

      <label className="mb-3 flex items-start gap-3 text-sm">
        <input type="checkbox" className="mt-1 size-5 shrink-0 accent-[var(--accent)]" checked={restock} onChange={(e) => setRestock(e.target.checked)} />
        <span>
          <span className="block font-semibold">Barang masih bagus, masukkan lagi ke stok</span>
          <span className="block text-xs text-muted">Matikan untuk barang rusak atau kadaluarsa: stok tidak bertambah dan modalnya dihitung rugi.</span>
        </span>
      </label>

      <div className="mb-2 flex flex-wrap gap-2">
        {RETURN_REASONS.map((r) => (
          <button
            key={r}
            type="button"
            onClick={() => {
              setReason(r);
              if (r === 'Barang rusak' || r === 'Kadaluarsa') setRestock(false);
            }}
            className={cx('min-h-9 rounded-full border px-3 text-[13px] font-semibold', reason === r ? 'border-accent bg-accentsoft text-accent' : 'border-line bg-panel text-muted hover:text-ink')}
          >
            {r}
          </button>
        ))}
      </div>
      <Field label="Alasan (wajib)">
        <input className="input" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Tulis alasan retur" />
      </Field>

      {ok && (
        <div className="mt-4 rounded-md bg-sunken px-3 py-2.5 text-sm" aria-live="polite">
          <div className="flex justify-between">
            <span className="text-muted">Uang dikembalikan</span>
            <strong className="money">{formatRupiah(ok.refund)}</strong>
          </div>
          {ok.complete && <p className="mt-1 text-xs text-muted">Semua barang di transaksi ini kembali, transaksi akan ditandai Diretur.</p>}
        </div>
      )}
      {previewErr && <p className="err mt-3">{previewErr}</p>}
      {error && (
        <p role="alert" className="err mt-3">
          {error}
        </p>
      )}
    </Modal>
  );
}
