import { useMemo, useState } from 'react';
import { LuHistory, LuMinus, LuPackageCheck, LuPlus } from 'react-icons/lu';
import { costPerBase, nextCost, roundQty, toBaseQty } from '../core/calc';
import { formatDateTime, formatNumber, formatQty, formatRupiah } from '../core/format';
import { adjustStock, qtyError, receiveStock } from '../core/services';
import type { StockMovementType } from '../core/types';
import { MOVEMENT_LABEL } from '../core/types';
import { useNav } from '../app/nav';
import { useAppState, useStore } from '../app/state';
import { OpnameTab } from './Opname';
import { EmptyState, Field, MoneyInput, NumberInput, PageHeader, ProductPicker, Tabs, cx, errorMessage, useToast } from '../app/ui';

type Tab = 'masuk' | 'sesuaikan' | 'opname' | 'log';

// ---- Stok masuk -----------------------------------------------------------------

function ReceiveForm({ initialProductId }: { initialProductId?: string }) {
  const state = useAppState();
  const store = useStore();
  const toast = useToast();
  const active = useMemo(() => state.products.filter((p) => p.active), [state.products]);

  const [productId, setProductId] = useState<string | null>(initialProductId ?? null);
  const [unitName, setUnitName] = useState('');
  const [qty, setQty] = useState<number | null>(null);
  const [cost, setCost] = useState<number | null>(null);
  const [supplier, setSupplier] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const product = productId ? state.productsById.get(productId) : undefined;
  const units = product ? (state.unitsByProduct.get(product.id) ?? []) : [];
  const unit = product ? (unitName && unitName !== product.baseUnit ? units.find((u) => u.unitName === unitName) : undefined) : undefined;
  const conversion = unit?.conversion ?? 1;
  const effectiveUnit = unit?.unitName ?? product?.baseUnit ?? '';
  const defaultCost = product ? product.costPrice * conversion : null;

  const baseQty = qty !== null && qty > 0 ? toBaseQty(qty, conversion) : null;
  const unitCost = cost ?? defaultCost;
  const newCost =
    product && baseQty !== null && unitCost !== null
      ? nextCost(state.settings.costMethod, product.stock, product.costPrice, baseQty, costPerBase(unitCost, conversion))
      : null;

  const pick = (id: string | null) => {
    setProductId(id);
    setUnitName('');
    setCost(null);
    setError(null);
  };

  const submit = async () => {
    if (!product) return setError('Pilih produk terlebih dahulu.');
    if (qty === null) return setError('Isi jumlah barang yang masuk.');
    if (unitCost === null) return setError('Isi harga beli.');
    setBusy(true);
    setError(null);
    try {
      const r = await receiveStock(store, { productId: product.id, unitName: effectiveUnit, unitQty: qty, unitCost, supplier, note });
      toast(`Stok ${product.name} bertambah ${formatQty(r.baseQty)} ${product.baseUnit}. Stok sekarang ${formatQty(r.product.stock)}.`);
      setProductId(null);
      setQty(null);
      setCost(null);
      setSupplier('');
      setNote('');
      setUnitName('');
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form
      className="card grid max-w-2xl grid-cols-1 gap-4 p-5"
      onSubmit={(e) => {
        e.preventDefault();
        submit();
      }}
    >
      <ProductPicker products={active} value={productId} onChange={pick} />

      {product && (
        <>
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="Satuan">
              <select
                className="input"
                value={unitName || product.baseUnit}
                onChange={(e) => {
                  setUnitName(e.target.value);
                  setCost(null);
                }}
              >
                <option value={product.baseUnit}>{product.baseUnit}</option>
                {units.map((u) => (
                  <option key={u.id} value={u.unitName}>
                    {u.unitName} (isi {formatQty(u.conversion)})
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Jumlah masuk">
              <NumberInput value={qty} onChange={setQty} placeholder="0" autoFocus />
            </Field>
            <Field label={`Harga beli per ${effectiveUnit}`}>
              <MoneyInput value={cost} onChange={setCost} placeholder={defaultCost ? formatNumber(defaultCost) : '0'} />
            </Field>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Supplier (opsional)">
              <input className="input" value={supplier} onChange={(e) => setSupplier(e.target.value)} placeholder="Mis. Agen Jaya" />
            </Field>
            <Field label="Catatan (opsional)">
              <input className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Mis. nota 0231" />
            </Field>
          </div>

          <div className="rounded-lg bg-sunken px-4 py-3 text-sm">
            {baseQty !== null ? (
              <div className="grid gap-1">
                <p>
                  Masuk <strong className="money">{formatQty(baseQty)}</strong> {product.baseUnit}
                  {conversion !== 1 && <span className="text-muted"> ({formatQty(qty ?? 0)} {effectiveUnit} × {formatQty(conversion)})</span>}
                </p>
                <p>
                  Stok jadi <strong className="money">{formatQty(roundQty(product.stock + baseQty))}</strong> {product.baseUnit}
                </p>
                {newCost !== null && (
                  <p className="text-muted">
                    HPP {state.settings.costMethod === 'average' ? 'rata-rata' : 'terakhir'}: {formatRupiah(product.costPrice)} → <strong className="money text-ink">{formatRupiah(newCost)}</strong> per {product.baseUnit}
                  </p>
                )}
              </div>
            ) : (
              <p className="text-muted">
                Stok sekarang {formatQty(product.stock)} {product.baseUnit}. Isi jumlah untuk melihat hasilnya.
              </p>
            )}
          </div>
        </>
      )}

      {error && (
        <p role="alert" className="err text-sm">
          {error}
        </p>
      )}
      <div>
        <button type="submit" className="btn btn-primary" disabled={busy || !product}>
          <LuPackageCheck size={18} /> {busy ? 'Menyimpan...' : 'Catat stok masuk'}
        </button>
      </div>
    </form>
  );
}

// ---- Penyesuaian -----------------------------------------------------------------

const REASONS = ['Rusak', 'Hilang', 'Kadaluarsa', 'Salah hitung', 'Sampel / dipakai sendiri'];

function AdjustForm() {
  const state = useAppState();
  const store = useStore();
  const toast = useToast();
  const active = useMemo(() => state.products.filter((p) => p.active), [state.products]);
  const [productId, setProductId] = useState<string | null>(null);
  const [dir, setDir] = useState<'add' | 'sub'>('sub');
  const [qty, setQty] = useState<number | null>(null);
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const product = productId ? state.productsById.get(productId) : undefined;
  const change = qty !== null && qty > 0 ? (dir === 'add' ? qty : -qty) : null;
  const after = product && change !== null ? roundQty(product.stock + change) : null;

  const submit = async () => {
    if (!product) return setError('Pilih produk terlebih dahulu.');
    if (change === null) return setError('Isi jumlah penyesuaian.');
    const qe = qtyError(product.baseUnit, qty as number);
    if (qe) return setError(qe);
    setBusy(true);
    setError(null);
    try {
      const p = await adjustStock(store, { productId: product.id, qtyChange: change, reason });
      toast(`Stok ${p.name} disesuaikan menjadi ${formatQty(p.stock)} ${p.baseUnit}.`);
      setProductId(null);
      setQty(null);
      setReason('');
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form
      className="card grid max-w-2xl grid-cols-1 gap-4 p-5"
      onSubmit={(e) => {
        e.preventDefault();
        submit();
      }}
    >
      <ProductPicker products={active} value={productId} onChange={(id) => { setProductId(id); setError(null); }} />
      {product && (
        <>
          <div className="grid gap-4 sm:grid-cols-[auto_1fr]">
            <div>
              <span className="label">Arah</span>
              <div className="inline-flex overflow-hidden rounded-md border border-line" role="group" aria-label="Arah penyesuaian">
                {(
                  [
                    ['sub', 'Kurangi', LuMinus],
                    ['add', 'Tambah', LuPlus],
                  ] as const
                ).map(([v, text, Icon]) => (
                  <button
                    key={v}
                    type="button"
                    aria-pressed={dir === v}
                    onClick={() => setDir(v)}
                    className={cx('inline-flex min-h-11 items-center gap-1.5 px-4 text-sm font-semibold', dir === v ? 'bg-accent text-onaccent' : 'bg-panel text-muted hover:bg-sunken')}
                  >
                    <Icon size={15} /> {text}
                  </button>
                ))}
              </div>
            </div>
            <Field label={`Jumlah (${product.baseUnit})`}>
              <NumberInput value={qty} onChange={setQty} placeholder="0" autoFocus />
            </Field>
          </div>
          <div>
            <span className="label">Alasan (wajib)</span>
            <div className="mb-2 flex flex-wrap gap-2">
              {REASONS.map((r) => (
                <button key={r} type="button" onClick={() => setReason(r)} className={cx('min-h-9 rounded-full border px-3 text-[13px] font-semibold', reason === r ? 'border-accent bg-accentsoft text-accent' : 'border-line bg-panel text-muted hover:text-ink')}>
                  {r}
                </button>
              ))}
            </div>
            <input className="input" aria-label="Alasan penyesuaian" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Tulis alasan penyesuaian" />
          </div>
          <div className="rounded-lg bg-sunken px-4 py-3 text-sm">
            Stok sekarang <strong className="money">{formatQty(product.stock)}</strong> {product.baseUnit}
            {after !== null && (
              <>
                {' '}
                → jadi <strong className={cx('money', after < 0 && 'text-bad')}>{formatQty(after)}</strong> {product.baseUnit}
              </>
            )}
          </div>
        </>
      )}
      {error && (
        <p role="alert" className="err text-sm">
          {error}
        </p>
      )}
      <div>
        <button type="submit" className="btn btn-primary" disabled={busy || !product}>
          {busy ? 'Menyimpan...' : 'Simpan penyesuaian'}
        </button>
      </div>
    </form>
  );
}

// ---- Log pergerakan -----------------------------------------------------------------

const TYPE_PILL: Record<StockMovementType, string> = {
  purchase: 'pill-good',
  sale: 'pill-info',
  void: 'pill-warn',
  return: 'pill-warn',
  adjustment: 'pill-plain',
  opname: 'pill-plain',
  expired: 'pill-bad',
};

function MovementLog() {
  const state = useAppState();
  const [productId, setProductId] = useState('');
  const [type, setType] = useState<StockMovementType | ''>('');
  const [limit, setLimit] = useState(100);

  const filtered = useMemo(
    () => state.movements.filter((m) => (!productId || m.productId === productId) && (!type || m.type === type)),
    [state.movements, productId, type],
  );
  const shown = filtered.slice(0, limit);

  return (
    <>
      <div className="mb-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-[minmax(0,320px)_220px]">
        <select className="input" aria-label="Filter produk" value={productId} onChange={(e) => { setProductId(e.target.value); setLimit(100); }}>
          <option value="">Semua produk</option>
          {state.products.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name}
            </option>
          ))}
        </select>
        <select className="input" aria-label="Filter tipe" value={type} onChange={(e) => { setType(e.target.value as StockMovementType | ''); setLimit(100); }}>
          <option value="">Semua tipe</option>
          {(Object.keys(MOVEMENT_LABEL) as StockMovementType[]).map((t) => (
            <option key={t} value={t}>
              {MOVEMENT_LABEL[t]}
            </option>
          ))}
        </select>
      </div>
      <div className="card overflow-hidden">
        <div className="th hidden gap-3 border-b border-line bg-sunken px-4 py-2.5 md:grid md:grid-cols-[130px_minmax(0,1.6fr)_110px_90px_90px_minmax(0,1.4fr)]">
          <span>Waktu</span>
          <span>Produk</span>
          <span>Tipe</span>
          <span className="text-right">Perubahan</span>
          <span className="text-right">Saldo</span>
          <span>Keterangan</span>
        </div>
        {shown.length === 0 ? (
          <EmptyState icon={<LuHistory size={22} />} title="Belum ada pergerakan stok">
            Setiap penjualan, stok masuk, void, dan penyesuaian akan tercatat di sini.
          </EmptyState>
        ) : (
          <ul className="divide-y divide-line">
            {shown.map((m) => {
              const p = state.productsById.get(m.productId);
              const tx = m.refId ? state.txById.get(m.refId) : undefined;
              const note = [tx?.receiptNo, m.reason].filter(Boolean).join(' · ');
              return (
                <li key={m.id} className="grid items-center gap-x-3 gap-y-1 px-4 py-2.5 text-sm md:grid-cols-[130px_minmax(0,1.6fr)_110px_90px_90px_minmax(0,1.4fr)]">
                  <span className="text-xs text-muted">{formatDateTime(m.createdAt)}</span>
                  <span className="truncate font-semibold">{p?.name ?? 'Produk dihapus'}</span>
                  <span>
                    <span className={cx('pill', TYPE_PILL[m.type])}>{MOVEMENT_LABEL[m.type]}</span>
                  </span>
                  <span className={cx('money font-semibold md:text-right', m.qtyChange > 0 ? 'text-good' : 'text-ink')}>
                    {m.qtyChange > 0 ? '+' : '−'}
                    {formatQty(Math.abs(m.qtyChange))}
                  </span>
                  <span className="money text-muted md:text-right">
                    <span className="mr-1 font-sans text-xs md:hidden">Saldo</span>
                    {formatQty(m.balanceAfter)}
                  </span>
                  <span className="truncate text-xs text-muted">{note || '—'}</span>
                </li>
              );
            })}
          </ul>
        )}
      </div>
      {filtered.length > shown.length && (
        <div className="mt-3 text-center">
          <button type="button" className="btn btn-ghost" onClick={() => setLimit((n) => n + 200)}>
            Tampilkan lebih banyak ({filtered.length - shown.length} lagi)
          </button>
        </div>
      )}
    </>
  );
}

export function StockScreen() {
  const nav = useNav();
  const [tab, setTab] = useState<Tab>(nav.params.tab ?? 'masuk');
  return (
    <>
      <PageHeader title="Stok" subtitle="Catat barang masuk, koreksi stok, hitung stok (opname), dan lihat riwayat pergerakannya." />
      <Tabs<Tab>
        tabs={[
          { id: 'masuk', label: 'Stok masuk' },
          { id: 'sesuaikan', label: 'Penyesuaian' },
          { id: 'opname', label: 'Opname' },
          { id: 'log', label: 'Pergerakan stok' },
        ]}
        value={tab}
        onChange={setTab}
      />
      {tab === 'masuk' && <ReceiveForm initialProductId={nav.params.productId} />}
      {tab === 'sesuaikan' && <AdjustForm />}
      {tab === 'opname' && <OpnameTab />}
      {tab === 'log' && <MovementLog />}
    </>
  );
}
