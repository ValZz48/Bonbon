import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { bytesToBase64, rawbtNativeUrl } from '../src/core/escpos';
import { MemoryPersistence } from '../src/core/persistence';
import { stockAlerts } from '../src/core/queries';
import { receiveStock, saveProduct, saveSettings } from '../src/core/services';
import { dailySummary, levelMap, toastText, worsened } from '../src/core/stockNotify';
import { Store } from '../src/core/store';

const NOW = new Date('2026-10-24T05:00:00Z');

async function shop() {
  const store = new Store(new MemoryPersistence());
  await store.init();
  const mk = (name: string, stock: number, min: number, unit = 'pcs') =>
    saveProduct(store, { name, category: 'X', baseUnit: unit, costPrice: 1000, sellPrice: 1500, minStock: min, initialStock: stock } as never, NOW);
  return { store, mk };
}

describe('notifikasi stok', () => {
  it('worsened: hanya yang memburuk (aman -> menipis -> habis) yang dianggap kabar baru', async () => {
    const { store, mk } = await shop();
    const a = await mk('Gula', 0, 5);
    const b = await mk('Kopi', 0, 5);
    await receiveStock(store, { productId: a.id, unitQty: 3, unitCost: 1000 }, NOW); // menipis
    await receiveStock(store, { productId: b.id, unitQty: 50, unitCost: 1000 }, NOW); // aman
    const first = stockAlerts(store.getState());
    assert.deepEqual(first.map((i) => [i.product.name, i.status]), [['Gula', 'low']]);

    // tidak ada perubahan: bukan kabar baru
    assert.equal(worsened(levelMap(first), first).length, 0);

    // Kopi aman -> habis dan Gula tetap menipis: hanya Kopi
    const before = levelMap(first);
    await receiveStock(store, { productId: b.id, unitQty: -50, unitCost: 1000 } as never, NOW).catch(() => undefined);
    const blank = new Map(before);
    const now = [...first, { product: { ...b, stock: 0 }, status: 'out' as const, suggested: 10 }];
    assert.deepEqual(worsened(blank, now).map((i) => i.product.name), ['Kopi']);

    // Gula menipis -> habis: kabar baru; membaik (habis -> menipis) bukan
    const worse = [{ ...first[0], status: 'out' as const }];
    assert.equal(worsened(levelMap(first), worse).length, 1);
    assert.equal(worsened(levelMap(worse), first).length, 0);
  });

  it('teks toast dan ringkasan harian', async () => {
    const { store, mk } = await shop();
    await mk('Indomie', 0, 5);
    await mk('Telur', 0, 5);
    const gula = await mk('Gula', 0, 5, 'kg');
    await receiveStock(store, { productId: gula.id, unitQty: 2.5, unitCost: 1000 }, NOW);
    const items = stockAlerts(store.getState());
    assert.equal(items.length, 3);
    assert.equal(toastText(items), 'Stok habis: Indomie, Telur. Menipis: Gula.');
    const s = dailySummary(items)!;
    assert.equal(s.title, 'Stok perlu perhatian');
    assert.equal(s.body, '2 habis, 1 menipis. Indomie, Telur, Gula.');
    assert.deepEqual(s.detail.split('\n'), ['Habis: Indomie (sisa 0 pcs)', 'Habis: Telur (sisa 0 pcs)', 'Menipis: Gula (sisa 2,5 kg)']);
    assert.equal(dailySummary([]), null);
  });

  it('banyak produk: nama dipotong dengan "dan N lainnya" dan rincian maksimal 10 baris', async () => {
    const { store, mk } = await shop();
    for (let i = 1; i <= 14; i++) await mk(`Barang ${String(i).padStart(2, '0')}`, 0, 5);
    const items = stockAlerts(store.getState());
    assert.equal(items.length, 14);
    assert.ok(toastText(items).endsWith('dan 11 lainnya.'));
    const s = dailySummary(items)!;
    assert.ok(s.body.startsWith('14 habis. Barang 01, Barang 02, Barang 03 dan 11 lainnya'));
    const lines = s.detail.split('\n');
    assert.equal(lines.length, 11);
    assert.equal(lines[10], 'dan 4 produk lainnya');
  });

  it('produk nonaktif tidak ikut diingatkan', async () => {
    const { store, mk } = await shop();
    const p = await mk('Lama', 0, 5);
    assert.equal(stockAlerts(store.getState()).length, 1);
    const { setProductActive } = await import('../src/core/services');
    await setProductActive(store, p.id, false, NOW);
    assert.equal(stockAlerts(store.getState()).length, 0);
    assert.equal(dailySummary(stockAlerts(store.getState())), null);
  });
});

describe('pengaturan notifikasi dan RawBT di aplikasi', () => {
  it('jam pengingat divalidasi dan saklar disimpan', async () => {
    const { store } = await shop();
    assert.equal(store.getState().settings.stockNotify, false);
    assert.equal(store.getState().settings.stockNotifyHour, 8);
    const s = await saveSettings(store, { stockNotify: true, stockNotifyHour: 19 });
    assert.equal(s.stockNotify, true);
    assert.equal(s.stockNotifyHour, 19);
    for (const bad of [24, -1, 7.5, Number.NaN]) assert.equal((await saveSettings(store, { stockNotifyHour: bad })).stockNotifyHour, 8, `jam ${bad}`);
    assert.equal((await saveSettings(store, { stockNotify: 'ya' as never })).stockNotify, false);
  });

  it('pengaturan lama tanpa kolom baru mendapat nilai bawaan', async () => {
    const persistence = new MemoryPersistence();
    await persistence.commit({ put: { settings: [{ id: 'main', storeName: 'Toko Lama' } as never] }, del: {} });
    const store = new Store(persistence);
    await store.init();
    const s = store.getState().settings;
    assert.equal(s.storeName, 'Toko Lama');
    assert.equal(s.stockNotify, false);
    assert.equal(s.stockNotifyHour, 8);
  });

  it('tautan RawBT untuk WebView memakai skema rawbt: dengan base64 yang sama', () => {
    const data = Uint8Array.from([0x1b, 0x40, 0x41, 0x0a]);
    assert.equal(rawbtNativeUrl(data), `rawbt:base64,${bytesToBase64(data)}`);
    assert.equal(rawbtNativeUrl(data), 'rawbt:base64,G0BBCg==');
  });
});
