import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import {
  CODE128_TABLE,
  ScanGate,
  decodeFrame,
  decodeRow,
  eanCheckDigit,
  isValidEan,
  rgbaToGray,
  sameCode,
} from '../src/core/barcode';
import { MemoryPersistence } from '../src/core/persistence';
import { seedDemo } from '../src/core/demo';
import { Store } from '../src/core/store';
import { findByCode } from '../src/core/queries';

// ---- an independent encoder: the standard binary module tables (not the run-width tables the decoder uses) ----

const L = ['0001101', '0011001', '0010011', '0111101', '0100011', '0110001', '0101111', '0111011', '0110111', '0001011'];
const G = ['0100111', '0110011', '0011011', '0100001', '0011101', '0111001', '0000101', '0010001', '0001001', '0010111'];
const R = ['1110010', '1100110', '1101100', '1000010', '1011100', '1001110', '1010000', '1000100', '1001000', '1110100'];
const PARITY = ['LLLLLL', 'LLGLGG', 'LLGGLG', 'LLGGGL', 'LGLLGG', 'LGGLLG', 'LGGGLL', 'LGLGLG', 'LGLGGL', 'LGGLGL'];

function eanModules(code: string): string {
  const d = [...code].map(Number);
  if (code.length === 13) {
    const pat = PARITY[d[0]];
    let s = '101';
    for (let i = 0; i < 6; i++) s += (pat[i] === 'L' ? L : G)[d[1 + i]];
    s += '01010';
    for (let i = 0; i < 6; i++) s += R[d[7 + i]];
    return s + '101';
  }
  let s = '101';
  for (let i = 0; i < 4; i++) s += L[d[i]];
  s += '01010';
  for (let i = 0; i < 4; i++) s += R[d[4 + i]];
  return s + '101';
}

/** Code 128 from our own width table (consistency is checked separately below). */
function code128Modules(text: string, set: 'B' | 'C' = 'B'): string {
  const values: number[] = [];
  if (set === 'C') {
    values.push(105);
    for (let i = 0; i < text.length; i += 2) values.push(Number(text.slice(i, i + 2)));
  } else {
    values.push(104);
    for (const ch of text) values.push(ch.charCodeAt(0) - 32);
  }
  let sum = values[0];
  for (let i = 1; i < values.length; i++) sum += i * values[i];
  values.push(sum % 103);
  let s = '';
  for (const v of values) s += widthsToModules(CODE128_TABLE[v]);
  return s + widthsToModules([2, 3, 3, 1, 1, 1, 2]);
}

function widthsToModules(w: number[]): string {
  return w.map((n, i) => (i % 2 === 0 ? '1' : '0').repeat(n)).join('');
}

// deterministic noise
function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface RenderOpts {
  px?: number; // pixels per module (may be fractional)
  quiet?: number; // quiet zone in modules
  blur?: number; // box blur radius in px
  noise?: number; // +- gray levels
  gradient?: number; // linear light falloff across the row, gray levels
  reverse?: boolean;
  seed?: number;
  dark?: number;
  light?: number;
}

function renderRow(modules: string, o: RenderOpts = {}): number[] {
  const px = o.px ?? 3;
  const quiet = o.quiet ?? 10;
  const dark = o.dark ?? 30;
  const light = o.light ?? 225;
  const m = '0'.repeat(quiet) + (o.reverse ? [...modules].reverse().join('') : modules) + '0'.repeat(quiet);
  const n = Math.round(m.length * px);
  const row: number[] = new Array(n);
  for (let x = 0; x < n; x++) row[x] = m[Math.min(m.length - 1, Math.floor(x / px))] === '1' ? dark : light;
  let out = row;
  const r = Math.round(o.blur ?? 0);
  if (r > 0) {
    out = row.map((_, x) => {
      let s = 0;
      let c = 0;
      for (let k = -r; k <= r; k++) {
        const j = x + k;
        if (j >= 0 && j < n) {
          s += row[j];
          c++;
        }
      }
      return s / c;
    });
  }
  const rand = rng(o.seed ?? 1);
  return out.map((v, x) => {
    const g = (o.gradient ?? 0) * (x / n - 0.5);
    const noise = ((rand() - 0.5) * 2 * (o.noise ?? 0));
    return Math.max(0, Math.min(255, v - g + noise));
  });
}

const CODES13 = ['8998866200301', '8998866200318', '4006381333931', '5901234123457', '9780201379624', '0012345678905'];
const CODES8 = ['96385074', '73513537'];

describe('EAN check digit', () => {
  it('fixtures are valid codes (so the tests below really test decoding)', () => {
    for (const c of [...CODES13, ...CODES8]) assert.equal(isValidEan(c), true, c);
    assert.equal(eanCheckDigit('400638133393'), 1);
    assert.equal(eanCheckDigit('9638507'), 4);
    assert.equal(isValidEan('8998866200302'), false);
    assert.equal(isValidEan('12345'), false);
  });

  it('every barcode in the demo data is a valid EAN-13 and is found by the scanner lookup', async () => {
    const store = new Store(new MemoryPersistence());
    await store.init();
    await seedDemo(store, new Date('2026-10-19T05:00:00Z'));
    const withCode = store.getState().products.filter((p) => p.barcode);
    assert.ok(withCode.length >= 6);
    for (const p of withCode) {
      assert.equal(isValidEan(p.barcode!), true, `${p.name}: ${p.barcode}`);
      assert.equal(findByCode(store.getState(), p.barcode!)?.id, p.id);
    }
  });
});

describe('decodeRow: EAN-13 / EAN-8', () => {
  it('reads real codes at several print sizes', () => {
    for (const code of [...CODES13, ...CODES8]) {
      for (const px of [2, 2.5, 3, 4.37, 6, 9.2]) {
        const got = decodeRow(renderRow(eanModules(code), { px }));
        assert.equal(got?.text, code, `${code} @ ${px}px/module`);
        assert.equal(got?.format, code.length === 13 ? 'ean_13' : 'ean_8');
      }
    }
  });

  it('reads an upside-down barcode', () => {
    for (const code of ['8998866200301', '96385074']) {
      assert.equal(decodeRow(renderRow(eanModules(code), { px: 3.3, reverse: true }))?.text, code);
    }
  });

  it('survives blur, sensor noise and uneven light', () => {
    for (const code of CODES13) {
      for (let seed = 1; seed <= 6; seed++) {
        const row = renderRow(eanModules(code), { px: 4, blur: 1, noise: 22, gradient: 70, seed });
        assert.equal(decodeRow(row)?.text, code, `${code} seed ${seed}`);
      }
    }
  });

  it('works on dim, low-contrast prints', () => {
    const row = renderRow(eanModules('8998866200301'), { px: 3, dark: 90, light: 150, noise: 4, blur: 1 });
    assert.equal(decodeRow(row)?.text, '8998866200301');
  });

  it('rejects a barcode with a damaged digit instead of guessing', () => {
    const mod = eanModules('8998866200301');
    // flip one module inside the left half: the check digit no longer matches (or the pattern is invalid)
    const bad = mod.slice(0, 20) + (mod[20] === '1' ? '0' : '1') + mod.slice(21);
    assert.equal(decodeRow(renderRow(bad, { px: 4 })), null);
  });

  it('a UPC-A code comes out as EAN-13 with a leading zero and still matches the 12-digit form', () => {
    const got = decodeRow(renderRow(eanModules('0012345678905'), { px: 4 }));
    assert.equal(got?.text, '0012345678905');
    assert.equal(sameCode('012345678905', got!.text), true);
  });

  it('returns nothing for blank paper, flat gray and pure noise', () => {
    assert.equal(decodeRow(new Array(800).fill(240)), null);
    const rand = rng(7);
    assert.equal(decodeRow(Array.from({ length: 800 }, () => 120 + rand() * 6)), null);
    assert.equal(decodeRow(Array.from({ length: 800 }, () => rand() * 255)), null);
  });

  it('does not invent codes from random bar patterns or random textures', () => {
    const rand = rng(99);
    let hits = 0;
    // (a) random bar widths
    for (let t = 0; t < 12000; t++) {
      const row: number[] = [];
      let dark = false;
      while (row.length < 700) {
        const w = 2 + Math.floor(rand() * 12);
        for (let i = 0; i < w; i++) row.push(dark ? 30 : 225);
        dark = !dark;
      }
      if (decodeRow(row)) hits++;
    }
    // (b) random modules at a print-like scale: the hardest look-alike for a barcode (text, fabric, grids)
    for (let t = 0; t < 12000; t++) {
      const px = 2 + Math.floor(rand() * 4);
      const row: number[] = [];
      for (let i = 0; i < 40; i++) row.push(225); // paper
      for (let m = 0; m < 150; m++) {
        const v = rand() < 0.5 ? 30 : 225;
        for (let i = 0; i < px; i++) row.push(v);
      }
      for (let i = 0; i < 40; i++) row.push(225);
      if (decodeRow(row)) hits++;
    }
    assert.equal(hits, 0);
  });
});

describe('Code 128', () => {
  it('table is internally consistent (guards against typos)', () => {
    assert.equal(CODE128_TABLE.length, 106);
    const seen = new Set<string>();
    CODE128_TABLE.forEach((w, v) => {
      assert.equal(w.length, 6, `value ${v}`);
      assert.equal(w.reduce((a, b) => a + b, 0), 11, `value ${v} must be 11 modules wide`);
      assert.equal((w[0] + w[2] + w[4]) % 2, 0, `value ${v}: dark modules must be even`);
      assert.ok(w.every((n) => n >= 1 && n <= 4), `value ${v} widths 1..4`);
      const key = w.join('');
      assert.equal(seen.has(key), false, `value ${v} is a duplicate`);
      seen.add(key);
    });
    // a few well-known encodings
    assert.equal(widthsToModules(CODE128_TABLE[0]), '11011001100'); // space
    assert.equal(widthsToModules(CODE128_TABLE[104]), '11010010000'); // Start B
    assert.equal(widthsToModules(CODE128_TABLE[105]), '11010011100'); // Start C
    assert.equal(widthsToModules(CODE128_TABLE[103]), '11010000100'); // Start A
  });

  it('reads set B text and set C digits', () => {
    for (const text of ['MKN-001', 'ABC-12345', 'Warung-Manop', 'a1b2c3']) {
      for (const px of [2, 3, 4.4]) {
        assert.equal(decodeRow(renderRow(code128Modules(text), { px }))?.text, text, `${text} @ ${px}`);
      }
    }
    assert.equal(decodeRow(renderRow(code128Modules('12345678', 'C'), { px: 3 }))?.text, '12345678');
    assert.equal(decodeRow(renderRow(code128Modules('MKN-001'), { px: 3, reverse: true }))?.format, 'code_128');
  });

  it('rejects a Code 128 symbol whose check character is wrong', () => {
    const mod = code128Modules('MKN-001');
    // swap the check character for a different valid symbol
    const checkStart = mod.length - 13 - 11;
    const other = widthsToModules(CODE128_TABLE[5]);
    const bad = mod.slice(0, checkStart) + other + mod.slice(checkStart + 11);
    assert.equal(decodeRow(renderRow(bad, { px: 3 })), null);
  });
});

describe('decodeFrame', () => {
  function frame(w: number, h: number, paint: (x: number, y: number) => number | null, noise = 0, seed = 3) {
    const rand = rng(seed);
    const g = new Uint8Array(w * h);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const v = paint(x, y) ?? 205 - 25 * Math.sin(x / 90) + 12 * Math.cos(y / 70);
        g[y * w + x] = Math.max(0, Math.min(255, v + (rand() - 0.5) * 2 * noise));
      }
    }
    return g;
  }

  it('finds a horizontal barcode in the middle of a noisy frame and counts agreeing lines', () => {
    const mod = eanModules('8998866200301');
    const px = 4;
    const w = 640;
    const h = 480;
    const x0 = 120;
    const g = frame(w, h, (x, y) => {
      if (y < 190 || y > 300) return null;
      const m = Math.floor((x - x0) / px);
      return m >= 0 && m < mod.length ? (mod[m] === '1' ? 35 : 225) : null;
    }, 14);
    const got = decodeFrame(g, w, h);
    assert.equal(got?.text, '8998866200301');
    assert.ok(got!.votes >= 4, `votes ${got!.votes}`);
  });

  it('finds a barcode turned 90 degrees', () => {
    const mod = eanModules('4006381333931');
    const px = 4;
    const w = 480;
    const h = 640;
    const y0 = 120;
    const g = frame(w, h, (x, y) => {
      if (x < 150 || x > 330) return null;
      const m = Math.floor((y - y0) / px);
      return m >= 0 && m < mod.length ? (mod[m] === '1' ? 35 : 225) : null;
    }, 10);
    assert.equal(decodeFrame(g, w, h)?.text, '4006381333931');
  });

  it('returns null for a frame without a barcode (text, shapes and noise only)', () => {
    const g = frame(640, 480, (x, y) => ((Math.floor(x / 7) + Math.floor(y / 11)) % 3 === 0 ? 60 : null), 20);
    assert.equal(decodeFrame(g, 640, 480), null);
  });

  it('converts RGBA to gray', () => {
    const rgba = new Uint8ClampedArray([255, 255, 255, 255, 0, 0, 0, 255, 255, 0, 0, 255]);
    const g = rgbaToGray(rgba, 3);
    assert.equal(g[0] >= 253, true);
    assert.equal(g[1], 0);
    assert.ok(g[2] > 60 && g[2] < 80);
  });
});

describe('ScanGate', () => {
  it('counts a new code immediately but ignores the same code while it stays in view', () => {
    const gate = new ScanGate();
    assert.equal(gate.accept('A', 0), true);
    for (let t = 100; t <= 3000; t += 100) assert.equal(gate.accept('A', t), false, `still in view at ${t}`);
  });

  it('counts the same code again once it left the view and came back', () => {
    const gate = new ScanGate();
    assert.equal(gate.accept('A', 0), true);
    assert.equal(gate.accept('A', 100), false);
    assert.equal(gate.accept('A', 1200), true); // gap of 1.1 s without any read
    assert.equal(gate.accept('A', 1300), false);
  });

  it('a different code counts at once, and going back to the first code counts too', () => {
    const gate = new ScanGate();
    assert.equal(gate.accept('A', 0), true);
    assert.equal(gate.accept('B', 150), true);
    assert.equal(gate.accept('B', 250), false);
    assert.equal(gate.accept('A', 400), true);
  });

  it('reset forgets everything', () => {
    const gate = new ScanGate();
    gate.accept('A', 0);
    gate.reset();
    assert.equal(gate.accept('A', 10), true);
  });
});

describe('findByCode with UPC-A / EAN-13 forms', () => {
  it('finds a product stored as 12-digit UPC-A when the camera reports 13 digits, and the reverse', async () => {
    const { saveProduct } = await import('../src/core/services');
    const store = new Store(new MemoryPersistence());
    await store.init();
    const a = await saveProduct(store, { name: 'Impor A', category: 'Umum', baseUnit: 'pcs', costPrice: 1000, sellPrice: 2000, minStock: 1, barcode: '012345678905' });
    const b = await saveProduct(store, { name: 'Impor B', category: 'Umum', baseUnit: 'pcs', costPrice: 1000, sellPrice: 2000, minStock: 1, barcode: '0036000291452' });
    assert.equal(findByCode(store.getState(), '0012345678905')?.id, a.id);
    assert.equal(findByCode(store.getState(), '036000291452')?.id, b.id);
    assert.equal(findByCode(store.getState(), '012345678906'), undefined, 'a different number is not a match');
    assert.equal(findByCode(store.getState(), '2345678905'), undefined, 'digits cut from the front are not a match');
  });
});

describe('sameCode', () => {
  it('matches exact text ignoring case and spaces, and numeric codes ignoring leading zeros', () => {
    assert.equal(sameCode(' MKN-001 ', 'mkn-001'), true);
    assert.equal(sameCode('012345678905', '0012345678905'), true);
    assert.equal(sameCode('8998866200301', '8998866200318'), false);
    assert.equal(sameCode('123', '0123'), false); // short numbers are not treated as barcodes
    assert.equal(sameCode('', ''), false);
  });
});
