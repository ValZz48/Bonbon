import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { MemoryPersistence } from '../src/core/persistence';
import { addManualDebt, checkout, receiveStock, saveCustomer, saveProduct, receiveDebtPayment } from '../src/core/services';
import { Store } from '../src/core/store';
import { SyncApi, type SessionStorageLike } from '../src/core/sync/api';
import { SyncEngine } from '../src/core/sync/engine';
import { reconcile, isEmptyChanges, planRemote } from '../src/core/sync/merge';
import { MemoryOutbox } from '../src/core/sync/outbox';
import { SyncedPersistence } from '../src/core/sync/persistence';

// ---- a tiny fake of the cloud: the same two calls the app uses (pull rows, upsert rows) -------------------

interface Row {
  user_id: string;
  tbl: string;
  id: string;
  data: unknown;
  deleted: boolean;
  client_ts: string;
  device_id: string | null;
  seq: number;
}

class FakeCloud {
  rows = new Map<string, Row>();
  seq = 0;
  online = true;
  pushes = 0;

  fetch: typeof fetch = async (input, init) => {
    if (!this.online) throw new TypeError('offline');
    const url = new URL(String(input));
    const auth = new Headers(init?.headers).get('Authorization') ?? '';
    const user = auth.replace('Bearer tok-', '');
    const json = (b: unknown, status = 200, headers: Record<string, string> = {}) => new Response(JSON.stringify(b), { status, headers });
    if (url.pathname === '/auth/v1/token') {
      const { email } = JSON.parse(String(init?.body));
      return json({ access_token: 'tok-' + email, refresh_token: 'r', expires_in: 3600, user: { id: email, email } });
    }
    if (url.pathname === '/rest/v1/sync_rows' && (init?.method ?? 'GET') === 'GET') {
      const mine = [...this.rows.values()].filter((r) => r.user_id === user).sort((a, b) => a.seq - b.seq);
      if (new Headers(init?.headers).get('Prefer') === 'count=exact') return json([], 200, { 'content-range': `*/${mine.length}` });
      const after = Number(url.searchParams.get('seq')?.replace('gt.', '') ?? 0);
      const limit = Number(url.searchParams.get('limit') ?? 1000);
      return json(mine.filter((r) => r.seq > after).slice(0, limit));
    }
    if (url.pathname === '/rest/v1/sync_rows' && init?.method === 'POST') {
      this.pushes += 1;
      for (const r of JSON.parse(String(init.body)) as Row[]) {
        assert.equal(r.user_id, user, 'rows are written for the signed-in account only');
        this.rows.set(`${r.user_id}|${r.tbl}|${r.id}`, { ...r, seq: ++this.seq });
      }
      return new Response(null, { status: 201 });
    }
    return json({}, 404);
  };
}

const memStorage = (): SessionStorageLike => {
  let v: string | null = null;
  return { get: () => v, set: (x) => void (v = x) };
};

const T0 = new Date('2026-10-19T05:00:00Z');
const min = (n: number) => new Date(T0.getTime() + n * 60_000);

async function phone(cloud: FakeCloud, email = 'noval@x.id') {
  const outbox = new MemoryOutbox();
  const persistence = new SyncedPersistence(new MemoryPersistence(), outbox);
  const store = new Store(persistence);
  await store.init();
  const api = new SyncApi(memStorage(), cloud.fetch, 'https://x.supabase.co', 'key');
  const engine = new SyncEngine(store, outbox, persistence, api);
  await engine.init();
  const login = async () => engine.afterSignIn(await api.signIn(email, 'pw'));
  return { store, outbox, engine, api, login };
}
type Phone = Awaited<ReturnType<typeof phone>>;

/** Phone with a product (200 in stock) and a customer, as the owner would have before switching sync on. */
async function seeded(cloud: FakeCloud) {
  const p = await phone(cloud);
  const prod = await saveProduct(p.store, { name: 'Indomie Goreng', category: 'Mi', baseUnit: 'pcs', costPrice: 2800, sellPrice: 3500, minStock: 5 }, T0);
  await receiveStock(p.store, { productId: prod.id, unitQty: 200, unitCost: 2800 }, T0);
  const budi = await saveCustomer(p.store, { name: 'Pak Budi' }, T0);
  return { ...p, prod, budi };
}

const sell = (p: Phone, productId: string, qty: number, at: Date) =>
  checkout(p.store, { lines: [{ productId, unitName: 'pcs', unitQty: qty }], payments: [{ method: 'cash', amount: 3500 * qty, tendered: 3500 * qty }] }, at);
const stockOf = (p: Phone, id: string) => p.store.getState().productsById.get(id)?.stock;
const balOf = (p: Phone, id: string) => p.store.getState().balanceByCustomer.get(id) ?? 0;

describe('sinkron: sambung pertama', () => {
  it('HP pertama mengunggah semuanya, HP kedua yang masih kosong mengambilnya', async () => {
    const cloud = new FakeCloud();
    const a = await seeded(cloud);
    await sell(a, a.prod.id, 5, min(1));
    await a.login();
    assert.equal(a.engine.getStatus().phase, 'idle');
    assert.equal(a.engine.getStatus().pending, 0);

    const b = await phone(cloud); // fresh install: it holds the sample products
    await b.login();
    assert.equal(b.engine.getStatus().phase, 'idle');
    assert.equal(b.store.getState().products.length, 1, 'sample data was replaced by the cloud copy');
    assert.equal(stockOf(b, a.prod.id), 195);
    assert.equal(b.store.getState().transactions.length, 1);
    assert.equal(b.store.getState().customers[0]?.name, 'Pak Budi');
  });

  it('data lama di HP tetap utuh walau stok pernah diubah tanpa catatan (saldo awal)', async () => {
    const cloud = new FakeCloud();
    const a = await seeded(cloud);
    // old data: stock typed in directly, with no history line behind it
    await a.store.mutate((tx) => {
      const p = tx.get('products', a.prod.id)!;
      tx.put('products', { ...p, stock: 150 });
    });
    await a.login();
    assert.equal(stockOf(a, a.prod.id), 150);
    const b = await phone(cloud);
    await b.login();
    assert.equal(stockOf(b, a.prod.id), 150);
  });

  it('kedua HP sudah punya data: menunggu pilihan, lalu "gabungkan" menyatukan keduanya', async () => {
    const cloud = new FakeCloud();
    const a = await seeded(cloud);
    await a.login();
    const b = await phone(cloud);
    const other = await saveProduct(b.store, { name: 'Teh Botol', category: 'Minum', baseUnit: 'pcs', costPrice: 3000, sellPrice: 4500, minStock: 5 }, T0);
    await receiveStock(b.store, { productId: other.id, unitQty: 20, unitCost: 3000 }, min(2));
    await b.login();
    assert.equal(b.engine.getStatus().phase, 'choice');
    assert.ok(b.engine.getStatus().choice!.local > 0 && b.engine.getStatus().choice!.remote > 0);
    await b.engine.resolveFirstSync('merge');
    assert.equal(b.engine.getStatus().phase, 'idle');
    assert.equal(b.store.getState().products.length, 2);
    await a.engine.sync();
    assert.equal(a.store.getState().products.length, 2);
  });

  it('pilihan "pakai data cloud" menghapus data di HP ini', async () => {
    const cloud = new FakeCloud();
    const a = await seeded(cloud);
    await a.login();
    const b = await phone(cloud);
    await saveProduct(b.store, { name: 'Barang Lain', category: 'X', baseUnit: 'pcs', costPrice: 1000, sellPrice: 2000, minStock: 1 }, T0);
    await b.login();
    await b.engine.resolveFirstSync('cloud');
    assert.deepEqual(b.store.getState().products.map((p) => p.name), ['Indomie Goreng']);
  });

  it('pilihan "pakai data HP ini" membuat HP lain ikut menghapus data yang tak ada di sini', async () => {
    const cloud = new FakeCloud();
    const a = await seeded(cloud);
    await a.login();
    const b = await phone(cloud);
    await saveProduct(b.store, { name: 'Barang B', category: 'X', baseUnit: 'pcs', costPrice: 1000, sellPrice: 2000, minStock: 1 }, T0);
    await b.login();
    await b.engine.resolveFirstSync('local');
    await a.engine.sync();
    assert.deepEqual(a.store.getState().products.map((p) => p.name), ['Barang B']);
  });
});

describe('sinkron: dua HP berjualan bersamaan', () => {
  it('stok dihitung dari riwayat, jadi dua penjualan barang yang sama tidak saling menimpa', async () => {
    const cloud = new FakeCloud();
    const a = await seeded(cloud);
    await a.login();
    const b = await phone(cloud);
    await b.login();

    cloud.online = false; // both shops are offline for a while
    await sell(a, a.prod.id, 10, min(5));
    await sell(b, a.prod.id, 7, min(6));
    await a.engine.sync();
    assert.ok(a.engine.getStatus().pending > 0, 'changes wait in the queue while offline');
    assert.equal(a.engine.getStatus().phase, 'offline');

    cloud.online = true;
    await a.engine.sync();
    await b.engine.sync();
    await a.engine.sync();
    assert.equal(stockOf(a, a.prod.id), 183);
    assert.equal(stockOf(b, a.prod.id), 183);
    assert.equal(a.engine.getStatus().pending, 0);
    assert.equal(b.store.getState().transactions.length, 2);
  });

  it('nomor struk dari dua HP tidak pernah sama', async () => {
    const cloud = new FakeCloud();
    const a = await seeded(cloud);
    await a.login();
    const b = await phone(cloud);
    await b.login();
    const t1 = await sell(a, a.prod.id, 1, min(1));
    const t2 = await sell(b, a.prod.id, 1, min(1));
    assert.notEqual(t1.receiptNo, t2.receiptNo);
    assert.match(t1.receiptNo, /^INV-20261019-[A-Z0-9]{2}-0001$/);
    assert.match(t2.receiptNo, /^INV-20261019-[A-Z0-9]{2}-0001$/);
  });

  it('kasbon pelanggan yang sama dari dua HP: saldo dan urutan buku jadi sama di keduanya', async () => {
    const cloud = new FakeCloud();
    const a = await seeded(cloud);
    await a.login();
    const b = await phone(cloud);
    await b.login();

    await addManualDebt(a.store, { customerId: a.budi.id, amount: 50_000 }, min(10));
    await addManualDebt(b.store, { customerId: a.budi.id, amount: 20_000 }, min(11));
    await receiveDebtPayment(b.store, { customerId: a.budi.id, amount: 5_000, method: 'cash' }, min(12));
    for (const p of [a, b, a, b]) await p.engine.sync();

    assert.equal(balOf(a, a.budi.id), 65_000);
    assert.equal(balOf(b, a.budi.id), 65_000);
    const seqs = (p: Phone) => (p.store.getState().debtByCustomer.get(a.budi.id) ?? []).map((e) => [e.seq, e.balanceAfter]);
    assert.deepEqual(seqs(a), seqs(b));
    assert.deepEqual(seqs(a), [[1, 50_000], [2, 70_000], [3, 65_000]]);
  });

  it('edit terbaru yang menang untuk data biasa, misalnya nama produk', async () => {
    const cloud = new FakeCloud();
    const a = await seeded(cloud);
    await a.login();
    const b = await phone(cloud);
    await b.login();

    const rename = (p: Phone, name: string) => p.store.mutate((tx) => tx.put('products', { ...tx.get('products', a.prod.id)!, name }));
    await rename(a, 'Nama dari A');
    await new Promise((r) => setTimeout(r, 5)); // B edits later
    await rename(b, 'Nama dari B');
    for (const p of [a, b, a, b]) await p.engine.sync();
    assert.equal(a.store.getState().productsById.get(a.prod.id)?.name, 'Nama dari B');
    assert.equal(b.store.getState().productsById.get(a.prod.id)?.name, 'Nama dari B');
  });

  it('pengaturan printer dan notifikasi tidak ikut tertimpa HP lain', async () => {
    const cloud = new FakeCloud();
    const a = await seeded(cloud);
    await a.login();
    const b = await phone(cloud);
    await b.login();
    await a.store.mutate((tx) => tx.put('settings', { ...tx.settings, paperWidth: 80, storeName: 'Warung Baru' }));
    await b.store.mutate((tx) => tx.put('settings', { ...tx.settings, paperWidth: 58, stockNotify: true }));
    for (const p of [a, b, a, b]) await p.engine.sync();
    assert.equal(a.store.getState().settings.paperWidth, 80);
    assert.equal(b.store.getState().settings.paperWidth, 58);
    assert.equal(b.store.getState().settings.stockNotify, true);
    assert.equal(a.store.getState().settings.stockNotify, false);
    assert.equal(a.store.getState().settings.storeName, b.store.getState().settings.storeName);
  });

  it('hapus data di satu HP ikut menghapus di HP lain', async () => {
    const cloud = new FakeCloud();
    const a = await seeded(cloud);
    await a.login();
    const b = await phone(cloud);
    await b.login();
    await b.store.mutate((tx) => tx.del('customers', a.budi.id));
    for (const p of [b, a]) await p.engine.sync();
    assert.equal(a.store.getState().customers.length, 0);
  });
});

describe('sinkron: aturan gabung (murni)', () => {
  it('reconcile tidak mengubah apa pun kalau data sudah konsisten, dan hasilnya sama kalau diulang', async () => {
    const cloud = new FakeCloud();
    const a = await seeded(cloud);
    await sell(a, a.prod.id, 3, min(1));
    await addManualDebt(a.store, { customerId: a.budi.id, amount: 1000 }, min(2));
    assert.ok(isEmptyChanges(reconcile(a.store.snapshot())));
  });

  it('baris dari HP sendiri yang kembali dari cloud diabaikan, dan edit lokal yang lebih baru dipertahankan', () => {
    const row = (device: string | null, ts: string) => ({ tbl: 'customers', id: 'c1', data: { id: 'c1', name: 'X' }, deleted: false, client_ts: ts, device_id: device, seq: 1 });
    const dirty = new Map([['customers:c1', { tbl: 'customers' as const, id: 'c1', ts: '2026-10-19T05:00:10Z' }]]);
    assert.equal(planRemote([row('me', '2026-10-19T05:00:00Z')], () => undefined, new Map(), 'me').applied, 0);
    assert.equal(planRemote([row('other', '2026-10-19T05:00:00Z')], () => undefined, dirty, 'me').applied, 0);
    assert.equal(planRemote([row('other', '2026-10-19T05:00:20Z')], () => undefined, dirty, 'me').applied, 1);
  });

  it('baris rusak dari cloud diabaikan, bukan menjatuhkan aplikasi', () => {
    const bad = [
      { tbl: 'customers', id: 'c1', data: 'oops', deleted: false, client_ts: 'z', device_id: null, seq: 1 },
      { tbl: 'unknown', id: 'u', data: { id: 'u' }, deleted: false, client_ts: 'z', device_id: null, seq: 2 },
      { tbl: 'customers', id: 'c2', data: { id: 'beda' }, deleted: false, client_ts: 'z', device_id: null, seq: 3 },
    ];
    assert.equal(planRemote(bad, () => undefined, new Map(), 'me').applied, 0);
  });
});
