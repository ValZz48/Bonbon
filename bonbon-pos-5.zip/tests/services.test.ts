import assert from 'node:assert/strict';
import { beforeEach, describe, it } from 'node:test';
import { alertCounts, stockAlerts, summarizeDay } from '../src/core/queries';
import { seedDemo } from '../src/core/demo';
import { dateKeyOf } from '../src/core/format';
import { MemoryPersistence } from '../src/core/persistence';
import {
  adjustStock,
  checkout,
  confirmPayment,
  receiveStock,
  saveProduct,
  saveSettings,
  voidTransaction,
} from '../src/core/services';
import { Store } from '../src/core/store';
import { DEFAULT_SETTINGS, DomainError } from '../src/core/types';

const NOW = new Date('2026-10-19T05:00:00Z'); // 12.00 WIB, Senin 19 Okt 2026

async function makeStore() {
  const persistence = new MemoryPersistence();
  const store = new Store(persistence);
  await store.init();
  return { store, persistence };
}

async function mie(store: Store, stock = 100) {
  const p = await saveProduct(
    store,
    {
      name: 'Indomie Goreng',
      category: 'Mi Instan',
      baseUnit: 'pcs',
      costPrice: 2800,
      sellPrice: 3500,
      minStock: 20,
      units: [{ unitName: 'dus', conversion: 40, sellPrice: 135000 }],
    },
    NOW,
  );
  if (stock > 0) await receiveStock(store, { productId: p.id, unitQty: stock, unitCost: 2800 }, NOW);
  return store.getState().productsById.get(p.id)!;
}

const cash = (amount: number, tendered = amount) => ({ method: 'cash' as const, amount, tendered });

describe('produk', () => {
  let store: Store;
  beforeEach(async () => ({ store } = await makeStore()));

  it('SKU otomatis berurutan dan barcode harus unik', async () => {
    const a = await saveProduct(store, { name: 'A', category: 'X', baseUnit: 'pcs', costPrice: 1, sellPrice: 2, barcode: '123' }, NOW);
    const b = await saveProduct(store, { name: 'B', category: 'X', baseUnit: 'pcs', costPrice: 1, sellPrice: 2 }, NOW);
    assert.equal(a.sku, 'SKU-0001');
    assert.equal(b.sku, 'SKU-0002');
    await assert.rejects(
      saveProduct(store, { name: 'C', category: 'X', baseUnit: 'pcs', costPrice: 1, sellPrice: 2, barcode: '123' }, NOW),
      /Barcode 123 sudah dipakai A/,
    );
    await assert.rejects(saveProduct(store, { name: 'D', sku: 'sku-0001', category: 'X', baseUnit: 'pcs', costPrice: 1, sellPrice: 2 }, NOW), /SKU/);
  });

  it('menolak data tidak valid tanpa mengubah apa pun', async () => {
    await assert.rejects(saveProduct(store, { name: ' ', category: 'X', baseUnit: 'pcs', costPrice: 1, sellPrice: 2 }, NOW), /Nama/);
    await assert.rejects(saveProduct(store, { name: 'A', category: 'X', baseUnit: 'pcs', costPrice: -1, sellPrice: 2 }, NOW), /HPP/);
    await assert.rejects(
      saveProduct(store, { name: 'A', category: 'X', baseUnit: 'pcs', costPrice: 1, sellPrice: 2, units: [{ unitName: 'PCS', conversion: 2, sellPrice: 5 }] }, NOW),
      /sama dengan satuan dasar/,
    );
    assert.equal(store.getState().products.length, 0);
  });

  it('stok awal tercatat di log pergerakan', async () => {
    const p = await saveProduct(store, { name: 'A', category: 'X', baseUnit: 'pcs', costPrice: 1, sellPrice: 2, initialStock: 12 }, NOW);
    assert.equal(p.stock, 12);
    const m = store.getState().movements;
    assert.equal(m.length, 1);
    assert.equal(m[0].qtyChange, 12);
    assert.equal(m[0].balanceAfter, 12);
  });
});

describe('stok masuk dan penyesuaian', () => {
  let store: Store;
  beforeEach(async () => ({ store } = await makeStore()));

  it('stok masuk per dus dikonversi ke satuan dasar dan HPP dirata-rata', async () => {
    const p = await mie(store, 0);
    // beli 1 dus (40 pcs) Rp 120.000 -> HPP 3.000/pcs; stok kosong sehingga HPP = 3.000
    const r1 = await receiveStock(store, { productId: p.id, unitName: 'dus', unitQty: 1, unitCost: 120000, supplier: 'Agen Jaya' }, NOW);
    assert.equal(r1.baseQty, 40);
    assert.equal(r1.product.stock, 40);
    assert.equal(r1.newCost, 3000);
    // beli 40 pcs lagi @ 2.000 -> rata-rata (40*3000 + 40*2000)/80 = 2.500
    const r2 = await receiveStock(store, { productId: p.id, unitQty: 40, unitCost: 2000 }, NOW);
    assert.equal(r2.product.stock, 80);
    assert.equal(r2.newCost, 2500);
    const log = store.getState().movements.filter((m) => m.type === 'purchase');
    assert.equal(log.length, 2);
    assert.match(log.find((m) => m.qtyChange === 40 && m.reason)?.reason ?? '', /Agen Jaya/);
  });

  it('metode HPP "harga terakhir"', async () => {
    await saveSettings(store, { costMethod: 'last' });
    const p = await mie(store, 10);
    const r = await receiveStock(store, { productId: p.id, unitQty: 10, unitCost: 4000 }, NOW);
    assert.equal(r.newCost, 4000);
  });

  it('penyesuaian wajib alasan dan tidak boleh membuat stok minus', async () => {
    const p = await mie(store, 10);
    await assert.rejects(adjustStock(store, { productId: p.id, qtyChange: -3, reason: ' ' }, NOW), /Alasan/);
    await assert.rejects(adjustStock(store, { productId: p.id, qtyChange: 0, reason: 'x' }, NOW), /0/);
    await assert.rejects(adjustStock(store, { productId: p.id, qtyChange: -11, reason: 'rusak' }, NOW), /minus/);
    const after = await adjustStock(store, { productId: p.id, qtyChange: -3, reason: 'rusak' }, NOW);
    assert.equal(after.stock, 7);
    assert.equal(store.getState().movements[0].reason, 'rusak');
  });

  it('pcs harus bilangan bulat, kg boleh desimal', async () => {
    const p = await mie(store, 10);
    await assert.rejects(receiveStock(store, { productId: p.id, unitQty: 1.5, unitCost: 100 }, NOW), /bilangan bulat/);
    const kg = await saveProduct(store, { name: 'Gula', category: 'Sembako', baseUnit: 'kg', costPrice: 16000, sellPrice: 18000 }, NOW);
    const r = await receiveStock(store, { productId: kg.id, unitQty: 2.5, unitCost: 16000 }, NOW);
    assert.equal(r.product.stock, 2.5);
  });
});

describe('transaksi: pengurangan dan pengembalian stok', () => {
  let store: Store;
  beforeEach(async () => ({ store } = await makeStore()));

  it('penjualan mengurangi stok sebesar jumlah dalam satuan dasar', async () => {
    const p = await mie(store, 100);
    const t = await checkout(
      store,
      {
        lines: [
          { productId: p.id, unitName: 'pcs', unitQty: 3 },
          { productId: p.id, unitName: 'dus', unitQty: 1 },
        ],
        payments: [cash(10500 + 135000, 150000)],
      },
      NOW,
    );
    assert.equal(t.total, 145500);
    assert.equal(t.change, 4500);
    assert.equal(store.getState().productsById.get(p.id)!.stock, 100 - 3 - 40);
    const sales = store.getState().movements.filter((m) => m.type === 'sale');
    assert.equal(sales.length, 2);
    assert.deepEqual(sales.map((m) => m.qtyChange).sort((a, b) => a - b), [-40, -3]);
    assert.ok(sales.every((m) => m.refId === t.id));
  });

  it('menyimpan snapshot harga dan HPP; perubahan harga tidak mengubah transaksi lama', async () => {
    const p = await mie(store, 50);
    const t = await checkout(store, { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 2 }], payments: [cash(7000)] }, NOW);
    await saveProduct(store, { id: p.id, name: 'Indomie Goreng', category: 'Mi Instan', baseUnit: 'pcs', costPrice: 9999, sellPrice: 9999, minStock: 20 }, NOW);
    const saved = store.getState().txById.get(t.id)!;
    assert.equal(saved.items[0].unitPrice, 3500);
    assert.equal(saved.items[0].costPrice, 2800);
    assert.equal(saved.items[0].name, 'Indomie Goreng');
  });

  it('stok kurang ditolak dan tidak ada yang berubah (atomik)', async () => {
    const a = await mie(store, 5);
    const b = await saveProduct(store, { name: 'Teh', category: 'Minuman', baseUnit: 'botol', costPrice: 1, sellPrice: 1000, initialStock: 50 }, NOW);
    const movementsBefore = store.getState().movements.length;
    await assert.rejects(
      checkout(
        store,
        {
          lines: [
            { productId: b.id, unitName: 'botol', unitQty: 2 },
            { productId: a.id, unitName: 'pcs', unitQty: 6 },
          ],
          payments: [cash(2000 + 21000)],
        },
        NOW,
      ),
      (e: unknown) => e instanceof DomainError && /Stok Indomie Goreng tidak cukup/.test(e.message),
    );
    const st = store.getState();
    assert.equal(st.productsById.get(a.id)!.stock, 5);
    assert.equal(st.productsById.get(b.id)!.stock, 50);
    assert.equal(st.transactions.length, 0);
    assert.equal(st.movements.length, movementsBefore);
  });

  it('jumlah item yang sama di dua baris dijumlahkan saat cek stok', async () => {
    const p = await mie(store, 5);
    await assert.rejects(
      checkout(
        store,
        {
          lines: [
            { productId: p.id, unitName: 'pcs', unitQty: 3 },
            { productId: p.id, unitName: 'pcs', unitQty: 3 },
          ],
          payments: [cash(21000)],
        },
        NOW,
      ),
      /tidak cukup/,
    );
  });

  it('stok minus diizinkan hanya jika pengaturan aktif', async () => {
    const p = await mie(store, 2);
    await saveSettings(store, { allowNegativeStock: true });
    await checkout(store, { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 5 }], payments: [cash(17500)] }, NOW);
    assert.equal(store.getState().productsById.get(p.id)!.stock, -3);
  });

  it('pembayaran harus pas; keranjang kosong ditolak; produk nonaktif ditolak', async () => {
    const p = await mie(store, 10);
    await assert.rejects(checkout(store, { lines: [], payments: [] }, NOW), /kosong/);
    await assert.rejects(checkout(store, { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 1 }], payments: [cash(3000)] }, NOW), /kurang/);
    await assert.rejects(
      checkout(store, { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 1 }], payments: [cash(3500), { method: 'qris', amount: 500 }] }, NOW),
      /lebih/,
    );
    assert.equal(store.getState().productsById.get(p.id)!.stock, 10);
    const { setProductActive } = await import('../src/core/services');
    await setProductActive(store, p.id, false, NOW);
    await assert.rejects(checkout(store, { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 1 }], payments: [cash(3500)] }, NOW), /tidak tersedia/);
  });

  it('nomor struk INV-YYYYMMDD-0001 berurutan per hari', async () => {
    const p = await mie(store, 50);
    const line = [{ productId: p.id, unitName: 'pcs', unitQty: 1 }];
    const t1 = await checkout(store, { lines: line, payments: [cash(3500)] }, NOW);
    const t2 = await checkout(store, { lines: line, payments: [cash(3500)] }, NOW);
    const tomorrow = new Date(NOW.getTime() + 86_400_000);
    const t3 = await checkout(store, { lines: line, payments: [cash(3500)] }, tomorrow);
    assert.equal(t1.receiptNo, 'INV-20261019-0001');
    assert.equal(t2.receiptNo, 'INV-20261019-0002');
    assert.equal(t3.receiptNo, 'INV-20261020-0001');
  });

  it('nomor struk tetap berlanjut setelah data dimuat ulang dari penyimpanan', async () => {
    const { store: s1, persistence } = await makeStore();
    const p = await mie(s1, 10);
    await checkout(s1, { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 1 }], payments: [cash(3500)] }, NOW);
    const s2 = new Store(persistence);
    await s2.init();
    const t = await checkout(s2, { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 1 }], payments: [cash(3500)] }, NOW);
    assert.equal(t.receiptNo, 'INV-20261019-0002');
  });

  it('split payment tunai + QRIS dan status menunggu konfirmasi', async () => {
    const p = await mie(store, 50);
    const t = await checkout(
      store,
      {
        lines: [{ productId: p.id, unitName: 'pcs', unitQty: 10 }],
        payments: [cash(15000, 20000), { method: 'qris', amount: 20000, reference: 'QR123', status: 'pending' }],
      },
      NOW,
    );
    assert.equal(t.total, 35000);
    assert.equal(t.change, 5000);
    assert.equal(t.payments[1].status, 'pending');
    const done = await confirmPayment(store, t.id, 1);
    assert.equal(done.payments[1].status, 'success');
  });

  it('pajak, diskon, dan pembulatan masuk ke transaksi', async () => {
    await saveSettings(store, { taxEnabled: true, taxPercent: 11, roundingMode: '100' });
    const p = await mie(store, 50);
    const t = await checkout(
      store,
      {
        lines: [{ productId: p.id, unitName: 'pcs', unitQty: 10 }],
        cartDiscount: { type: 'percent', value: 10 },
        payments: [cash(35000)],
      },
      NOW,
    );
    // 35.000 - 3.500 = 31.500; PPN 11% = 3.465 -> 34.965 -> dibulatkan 35.000
    assert.equal(t.subtotal, 35000);
    assert.equal(t.discount, 3500);
    assert.equal(t.tax, 3465);
    assert.equal(t.rounding, 35);
    assert.equal(t.total, 35000);
    assert.equal(t.taxPercent, 11);
  });

  it('void mengembalikan stok, menulis log, dan tidak menghapus data', async () => {
    const p = await mie(store, 100);
    const t = await checkout(store, { lines: [{ productId: p.id, unitName: 'dus', unitQty: 1 }, { productId: p.id, unitName: 'pcs', unitQty: 2 }], payments: [cash(142000)] }, NOW);
    assert.equal(store.getState().productsById.get(p.id)!.stock, 58);
    await assert.rejects(voidTransaction(store, t.id, '  ', NOW), /Alasan/);
    const v = await voidTransaction(store, t.id, 'Salah input', NOW);
    assert.equal(v.status, 'voided');
    assert.equal(v.voidReason, 'Salah input');
    assert.equal(store.getState().productsById.get(p.id)!.stock, 100);
    assert.equal(store.getState().txById.get(t.id)?.items.length, 2);
    const voids = store.getState().movements.filter((m) => m.type === 'void');
    assert.equal(voids.length, 2);
    assert.deepEqual(voids.map((m) => m.qtyChange).sort((a, b) => a - b), [2, 40]);
    await assert.rejects(voidTransaction(store, t.id, 'lagi', NOW), /sudah dibatalkan/);
  });

  it('void hanya untuk transaksi hari ini', async () => {
    const p = await mie(store, 10);
    const t = await checkout(store, { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 1 }], payments: [cash(3500)] }, NOW);
    const nextDay = new Date(NOW.getTime() + 86_400_000);
    await assert.rejects(voidTransaction(store, t.id, 'telat', nextDay), /hari ini/);
    assert.equal(store.getState().productsById.get(p.id)!.stock, 9);
  });

  it('gagal menyimpan ke penyimpanan membatalkan seluruh operasi', async () => {
    const { store: s, persistence } = await makeStore();
    const p = await mie(s, 10);
    persistence.failNextCommit = true;
    await assert.rejects(checkout(s, { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 4 }], payments: [cash(14000)] }, NOW), /gagal/);
    assert.equal(s.getState().productsById.get(p.id)!.stock, 10);
    assert.equal(s.getState().transactions.length, 0);
    // operasi berikutnya tetap jalan
    const t = await checkout(s, { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 4 }], payments: [cash(14000)] }, NOW);
    assert.equal(t.receiptNo, 'INV-20261019-0001');
  });

  it('dua checkout bersamaan tidak membuat stok menjadi minus', async () => {
    const p = await mie(store, 5);
    const run = () => checkout(store, { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 4 }], payments: [cash(14000)] }, NOW);
    const results = await Promise.allSettled([run(), run()]);
    assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
    assert.equal(results.filter((r) => r.status === 'rejected').length, 1);
    assert.equal(store.getState().productsById.get(p.id)!.stock, 1);
  });
});

describe('peringatan stok dan dashboard', () => {
  let store: Store;
  beforeEach(async () => ({ store } = await makeStore()));

  it('perubahan stok langsung mengubah status dan daftar Perlu Belanja', async () => {
    const p = await mie(store, 25); // min 20
    assert.equal(stockAlerts(store.getState()).length, 0);
    await checkout(store, { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 6 }], payments: [cash(21000)] }, NOW);
    let alerts = stockAlerts(store.getState());
    assert.equal(alerts.length, 1);
    assert.equal(alerts[0].status, 'low');
    assert.equal(alerts[0].suggested, 21); // 20*2 - 19
    await checkout(store, { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 19 }], payments: [cash(66500)] }, NOW);
    alerts = stockAlerts(store.getState());
    assert.equal(alerts[0].status, 'out');
    assert.deepEqual(alertCounts(store.getState()), { low: 0, out: 1 });
  });

  it('produk nonaktif tidak muncul di peringatan', async () => {
    const p = await mie(store, 1);
    const { setProductActive } = await import('../src/core/services');
    await setProductActive(store, p.id, false, NOW);
    assert.equal(stockAlerts(store.getState()).length, 0);
  });

  it('laba kotor memakai HPP snapshot dan mengabaikan transaksi void', async () => {
    const p = await mie(store, 100);
    const t1 = await checkout(store, { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 10 }], payments: [cash(35000)] }, NOW);
    await checkout(store, { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 4 }], payments: [cash(14000)] }, NOW);
    // HPP naik setelah transaksi: laporan lama tidak boleh berubah
    await receiveStock(store, { productId: p.id, unitQty: 100, unitCost: 5000 }, NOW);
    let s = summarizeDay(store.getState(), dateKeyOf(NOW));
    assert.equal(s.count, 2);
    assert.equal(s.revenue, 49000);
    assert.equal(s.cogs, 14 * 2800);
    assert.equal(s.profit, 49000 - 39200);
    await voidTransaction(store, t1.id, 'batal', NOW);
    s = summarizeDay(store.getState(), dateKeyOf(NOW));
    assert.equal(s.count, 1);
    assert.equal(s.voided, 1);
    assert.equal(s.revenue, 14000);
  });
});

describe('data demo', () => {
  it('mengisi 20 produk, transaksi seminggu, dan beberapa peringatan stok', async () => {
    const { store } = await makeStore();
    const r = await seedDemo(store, NOW);
    const st = store.getState();
    assert.equal(r.products, 20);
    assert.equal(r.customers, 4);
    assert.equal(st.products.length, 20);
    assert.ok(r.transactions >= 30, `transaksi demo: ${r.transactions}`);
    assert.ok(st.products.every((p) => p.stock >= 0));
    const c = alertCounts(st);
    assert.ok(c.low >= 3 && c.out >= 2, JSON.stringify(c));
    assert.ok(summarizeDay(st, dateKeyOf(NOW)).count >= 1);
    // stok akhir = jumlah semua pergerakan
    for (const p of st.products) {
      const sum = st.movements.filter((m) => m.productId === p.id).reduce((a, m) => a + m.qtyChange, 0);
      assert.equal(Math.round(sum * 1000) / 1000, p.stock, p.name);
    }
    await assert.rejects(seedDemo(store, NOW), /sudah ada/);
  });

  it('data demo memuat contoh kasbon: ada yang berutang, ada yang lunas, saldo cocok dengan buku', async () => {
    const { store } = await makeStore();
    await seedDemo(store, NOW);
    const st = store.getState();
    const byName = (n: string) => st.customers.find((c) => c.name === n)!;
    const bal = (n: string) => st.balanceByCustomer.get(byName(n).id) ?? 0;
    assert.equal(st.customers.length, 4);
    assert.ok(bal('Pak Budi') > 0, 'Pak Budi berutang');
    assert.ok(bal('Bu Siti') > 0, 'Bu Siti berutang');
    assert.ok(bal('Mas Andi') > 0, 'Mas Andi berutang hari ini');
    assert.equal(bal('Bu Rina'), 0); // sudah lunas
    for (const c of st.customers) {
      const entries = st.debtByCustomer.get(c.id) ?? [];
      assert.equal(entries[entries.length - 1]?.balanceAfter ?? 0, st.balanceByCustomer.get(c.id) ?? 0, c.name);
      for (const e of entries) {
        if (e.txId) assert.ok(st.txById.has(e.txId), 'kasbon menunjuk transaksi yang ada');
      }
    }
    // nomor struk tetap berurutan menurut waktu di tiap hari
    for (const list of st.txByDate.values()) {
      const byTime = [...list].sort((a, b) => (a.createdAt < b.createdAt ? -1 : 1)).map((t) => t.receiptNo);
      assert.deepEqual(byTime, [...byTime].sort());
    }
    assert.ok([...st.transactions].some((t) => t.payments.some((p) => p.method === 'kasbon') && t.payments.some((p) => p.method === 'cash')), 'ada kasbon dengan DP tunai');
  });
});

describe('nama toko', () => {
  it('nama bawaan baru adalah Warung Manop', async () => {
    const { store } = await makeStore();
    assert.equal(store.getState().settings.storeName, 'Warung Manop');
  });

  it('nama bawaan lama "Toko Contoh" yang belum diubah dialihkan ke Warung Manop saat dimuat', async () => {
    const persistence = new MemoryPersistence();
    await persistence.commit({ put: { settings: [{ ...DEFAULT_SETTINGS, storeName: 'Toko Contoh' }] }, del: {} });
    const store = new Store(persistence);
    await store.init();
    assert.equal(store.getState().settings.storeName, 'Warung Manop');
  });

  it('nama yang sudah diubah pemilik tidak ditimpa', async () => {
    const persistence = new MemoryPersistence();
    await persistence.commit({ put: { settings: [{ ...DEFAULT_SETTINGS, storeName: 'Toko Berkah' }] }, del: {} });
    const store = new Store(persistence);
    await store.init();
    assert.equal(store.getState().settings.storeName, 'Toko Berkah');
  });

  it('nama kosong kembali ke nama bawaan', async () => {
    const { store } = await makeStore();
    await saveSettings(store, { ...store.getState().settings, storeName: '   ' });
    assert.equal(store.getState().settings.storeName, 'Warung Manop');
  });
});
