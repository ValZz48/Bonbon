import assert from 'node:assert/strict';
import { beforeEach, describe, it } from 'node:test';
import { debtSince, debtSummary, debtorRows } from '../src/core/queries';
import { receiptText } from '../src/core/export';
import { MemoryPersistence } from '../src/core/persistence';
import {
  addManualDebt,
  checkout,
  receiveDebtPayment,
  saveCustomer,
  saveProduct,
  saveSettings,
  setCustomerActive,
  voidTransaction,
  writeOffDebt,
  receiveStock,
} from '../src/core/services';
import { Store } from '../src/core/store';
import { debtPaymentWhatsApp, debtReminderWhatsApp, formatPhoneID, normalizePhoneID, receiptWhatsApp, waLink } from '../src/core/whatsapp';

const NOW = new Date('2026-10-19T05:00:00Z'); // 12.00 WIB, Senin 19 Okt 2026
const DAY = 86_400_000;
const at = (days: number) => new Date(NOW.getTime() + days * DAY);

async function setup() {
  const persistence = new MemoryPersistence();
  const store = new Store(persistence);
  await store.init();
  const p = await saveProduct(store, { name: 'Indomie Goreng', category: 'Mi', baseUnit: 'pcs', costPrice: 2800, sellPrice: 3500, minStock: 5 }, NOW);
  await receiveStock(store, { productId: p.id, unitQty: 200, unitCost: 2800 }, NOW);
  const budi = await saveCustomer(store, { name: 'Pak Budi', phone: '0812-3456-7890' }, NOW);
  return { store, persistence, product: p, budi };
}

const line = (productId: string, unitQty: number) => ({ productId, unitName: 'pcs', unitQty });
const bal = (store: Store, id: string) => store.getState().balanceByCustomer.get(id) ?? 0;

describe('nomor WhatsApp', () => {
  it('menormalkan berbagai penulisan nomor Indonesia ke 62...', () => {
    for (const raw of ['0812-3456-7890', '+62 812 3456 7890', '62812 3456 7890', '812 3456 7890', '0062 812 3456 7890', ' (0812) 3456.7890 ']) {
      assert.equal(normalizePhoneID(raw), '6281234567890', raw);
    }
  });
  it('menolak nomor yang bukan nomor seluler Indonesia', () => {
    for (const raw of ['', '   ', 'abc', '021 5551234', '+1 415 555 2671', '0812', '08123456789012345']) {
      assert.equal(normalizePhoneID(raw), null, raw);
    }
  });
  it('tautan wa.me memakai nomor atau pemilih kontak, dan teks di-encode', () => {
    assert.equal(waLink('6281234567890', 'Halo & terima kasih\nBaris 2'), 'https://wa.me/6281234567890?text=Halo%20%26%20terima%20kasih%0ABaris%202');
    assert.equal(waLink(null, 'a b'), 'https://wa.me/?text=a%20b');
    assert.equal(formatPhoneID('6281234567890'), '0812 3456 7890');
  });
});

describe('pelanggan', () => {
  let ctx: Awaited<ReturnType<typeof setup>>;
  beforeEach(async () => (ctx = await setup()));

  it('menyimpan nomor dalam bentuk 62... dan nama dirapikan', async () => {
    const c = await saveCustomer(ctx.store, { name: '  Bu   Siti ', phone: '0857 1111 2222', creditLimit: 150000 }, NOW);
    assert.equal(c.name, 'Bu Siti');
    assert.equal(c.phone, '6285711112222');
    assert.equal(c.creditLimit, 150000);
    assert.equal(ctx.budi.phone, '6281234567890');
  });

  it('menolak nama kosong, nama kembar, nomor tidak valid, dan nomor kembar', async () => {
    await assert.rejects(saveCustomer(ctx.store, { name: '  ' }, NOW), /Nama pelanggan wajib/);
    await assert.rejects(saveCustomer(ctx.store, { name: 'pak budi' }, NOW), /sudah ada/);
    await assert.rejects(saveCustomer(ctx.store, { name: 'Bu Siti', phone: '123' }, NOW), /tidak valid/);
    await assert.rejects(saveCustomer(ctx.store, { name: 'Bu Siti', phone: '+62 812 3456 7890' }, NOW), /sudah dipakai Pak Budi/);
  });

  it('mengubah pelanggan tidak membuat duplikat dan boleh mengosongkan batas', async () => {
    const c = await saveCustomer(ctx.store, { id: ctx.budi.id, name: 'Pak Budi', phone: '', creditLimit: null, note: 'RT 3' }, NOW);
    assert.equal(c.id, ctx.budi.id);
    assert.equal(c.phone, undefined);
    assert.equal(c.creditLimit, undefined);
    assert.equal(ctx.store.getState().customers.length, 1);
  });

  it('tidak bisa dinonaktifkan selama masih punya kasbon', async () => {
    await addManualDebt(ctx.store, { customerId: ctx.budi.id, amount: 5000 }, NOW);
    await assert.rejects(setCustomerActive(ctx.store, ctx.budi.id, false, NOW), /masih punya catatan kasbon/);
    await receiveDebtPayment(ctx.store, { customerId: ctx.budi.id, amount: 5000, method: 'cash' }, NOW);
    const c = await setCustomerActive(ctx.store, ctx.budi.id, false, NOW);
    assert.equal(c.active, false);
  });
});

describe('checkout dengan kasbon', () => {
  let ctx: Awaited<ReturnType<typeof setup>>;
  beforeEach(async () => (ctx = await setup()));

  it('seluruh tagihan masuk kasbon: transaksi, stok, dan buku kasbon tercatat bersama', async () => {
    const { store, product, budi } = ctx;
    const t = await checkout(store, { lines: [line(product.id, 10)], payments: [{ method: 'kasbon', amount: 35000, customerId: budi.id }] }, NOW);
    assert.equal(t.customerId, budi.id);
    assert.equal(t.customerName, 'Pak Budi');
    assert.equal(t.change, 0);
    assert.equal(t.payments[0].status, 'success');
    const st = store.getState();
    assert.equal(st.productsById.get(product.id)?.stock, 190);
    assert.equal(bal(store, budi.id), 35000);
    const e = st.debtEntryByTx.get(t.id);
    assert.ok(e);
    assert.equal(e.type, 'kasbon');
    assert.equal(e.amount, 35000);
    assert.equal(e.balanceAfter, 35000);
    assert.equal(e.receiptNo, t.receiptNo);
    assert.equal(e.dateKey, '2026-10-19');
  });

  it('bayar sebagian tunai (DP) dan sisanya kasbon', async () => {
    const { store, product, budi } = ctx;
    const t = await checkout(
      store,
      {
        lines: [line(product.id, 20)], // 70.000
        payments: [
          { method: 'cash', amount: 20000, tendered: 50000 },
          { method: 'kasbon', amount: 50000, customerId: budi.id },
        ],
      },
      NOW,
    );
    assert.equal(t.total, 70000);
    assert.equal(t.change, 30000); // kembalian hanya dari tunai
    assert.equal(bal(store, budi.id), 50000);
  });

  it('kasbon bertambah di atas utang sebelumnya', async () => {
    const { store, product, budi } = ctx;
    await addManualDebt(store, { customerId: budi.id, amount: 85000, note: 'Utang lama dari buku' }, at(-9));
    const t = await checkout(store, { lines: [line(product.id, 2)], payments: [{ method: 'kasbon', amount: 7000, customerId: budi.id }] }, NOW);
    assert.equal(store.getState().debtEntryByTx.get(t.id)?.balanceAfter, 92000);
    assert.equal(bal(store, budi.id), 92000);
  });

  it('ditolak tanpa mengubah apa pun: tanpa pelanggan, dua kali kasbon, pelanggan nonaktif, kasbon dimatikan', async () => {
    const { store, product, budi } = ctx;
    const before = () => `${store.getState().transactions.length}|${store.getState().productsById.get(product.id)?.stock}|${store.getState().balanceByCustomer.size}`;
    const snap = before();
    await assert.rejects(checkout(store, { lines: [line(product.id, 1)], payments: [{ method: 'kasbon', amount: 3500 }] }, NOW), /Pilih pelanggan/);
    await assert.rejects(
      checkout(store, { lines: [line(product.id, 2)], payments: [{ method: 'kasbon', amount: 3500, customerId: budi.id }, { method: 'kasbon', amount: 3500, customerId: budi.id }] }, NOW),
      /hanya boleh satu kali/,
    );
    await assert.rejects(checkout(store, { lines: [line(product.id, 1)], payments: [{ method: 'kasbon', amount: 3500, customerId: 'tidak-ada' }] }, NOW), /tidak ditemukan/);
    await setCustomerActive(store, budi.id, false, NOW);
    await assert.rejects(checkout(store, { lines: [line(product.id, 1)], payments: [{ method: 'kasbon', amount: 3500, customerId: budi.id }] }, NOW), /tidak ditemukan atau sudah dinonaktifkan/);
    await setCustomerActive(store, budi.id, true, NOW);
    await saveSettings(store, { kasbonEnabled: false });
    await assert.rejects(checkout(store, { lines: [line(product.id, 1)], payments: [{ method: 'kasbon', amount: 3500, customerId: budi.id }] }, NOW), /dinonaktifkan di Pengaturan/);
    assert.equal(before(), snap);
  });

  it('kasbon selalu tercatat berstatus sukses (tidak ada "menunggu" untuk kasbon)', async () => {
    const { store, product, budi } = ctx;
    const t = await checkout(store, { lines: [line(product.id, 1)], payments: [{ method: 'kasbon', amount: 3500, customerId: budi.id, status: 'pending' }] }, NOW);
    assert.equal(t.payments[0].status, 'success');
  });

  it('batas kasbon dijaga, termasuk akumulasi dengan utang lama', async () => {
    const { store, product } = ctx;
    const c = await saveCustomer(store, { name: 'Bu Siti', creditLimit: 50000 }, NOW);
    await checkout(store, { lines: [line(product.id, 10)], payments: [{ method: 'kasbon', amount: 35000, customerId: c.id }] }, NOW);
    await assert.rejects(
      checkout(store, { lines: [line(product.id, 5)], payments: [{ method: 'kasbon', amount: 17500, customerId: c.id }] }, NOW),
      /Melebihi batas kasbon Bu Siti. Batas Rp 50.000, kasbon saat ini Rp 35.000/,
    );
    assert.equal(store.getState().productsById.get(product.id)?.stock, 190); // gagal = stok tidak berubah
    await checkout(store, { lines: [line(product.id, 4)], payments: [{ method: 'kasbon', amount: 14000, customerId: c.id }] }, NOW);
    assert.equal(bal(store, c.id), 49000);
  });

  it('dua checkout kasbon bersamaan tidak bisa sama-sama lolos batas', async () => {
    const { store, product } = ctx;
    const c = await saveCustomer(store, { name: 'Mas Andi', creditLimit: 40000 }, NOW);
    const run = () => checkout(store, { lines: [line(product.id, 10)], payments: [{ method: 'kasbon', amount: 35000, customerId: c.id }] }, NOW);
    const results = await Promise.allSettled([run(), run()]);
    assert.deepEqual(results.map((r) => r.status).sort(), ['fulfilled', 'rejected']);
    assert.equal(bal(store, c.id), 35000);
    assert.equal(store.getState().productsById.get(product.id)?.stock, 190);
  });

  it('penyimpanan gagal: tidak ada utang, stok, atau transaksi yang tersisa', async () => {
    const { store, persistence, product, budi } = ctx;
    persistence.failNextCommit = true;
    await assert.rejects(checkout(store, { lines: [line(product.id, 10)], payments: [{ method: 'kasbon', amount: 35000, customerId: budi.id }] }, NOW), /Penyimpanan gagal/);
    assert.equal(bal(store, budi.id), 0);
    assert.equal(store.getState().transactions.length, 0);
    assert.equal(store.getState().productsById.get(product.id)?.stock, 200);
  });
});

describe('pembayaran utang', () => {
  let ctx: Awaited<ReturnType<typeof setup>>;
  beforeEach(async () => {
    ctx = await setup();
    await addManualDebt(ctx.store, { customerId: ctx.budi.id, amount: 100000, note: 'Utang lama' }, at(-5));
  });

  it('cicilan mengurangi utang dan mencatat saldo setelahnya', async () => {
    const { store, budi } = ctx;
    const e1 = await receiveDebtPayment(store, { customerId: budi.id, amount: 30000, method: 'cash' }, at(-2));
    assert.equal(e1.balanceAfter, 70000);
    const e2 = await receiveDebtPayment(store, { customerId: budi.id, amount: 70000, method: 'qris', reference: 'QR-1' }, NOW);
    assert.equal(e2.balanceAfter, 0);
    assert.equal(e2.reference, 'QR-1');
    assert.equal(bal(store, budi.id), 0);
    const seqs = store.getState().debtByCustomer.get(budi.id)?.map((e) => e.seq);
    assert.deepEqual(seqs, [1, 2, 3]);
  });

  it('menolak jumlah nol, melebihi utang, metode kasbon, dan pelanggan tanpa utang', async () => {
    const { store, budi } = ctx;
    await assert.rejects(receiveDebtPayment(store, { customerId: budi.id, amount: 0, method: 'cash' }, NOW), /lebih dari 0/);
    await assert.rejects(receiveDebtPayment(store, { customerId: budi.id, amount: 100001, method: 'cash' }, NOW), /melebihi kasbon. Sisa kasbon Rp 100.000/);
    await assert.rejects(receiveDebtPayment(store, { customerId: budi.id, amount: 1000, method: 'kasbon' }, NOW), /metode pembayaran/);
    await assert.rejects(receiveDebtPayment(store, { customerId: budi.id, amount: 1500.5, method: 'cash' }, NOW), /rupiah utuh/);
    const siti = await saveCustomer(store, { name: 'Bu Siti' }, NOW);
    await assert.rejects(receiveDebtPayment(store, { customerId: siti.id, amount: 1000, method: 'cash' }, NOW), /tidak punya kasbon/);
    assert.equal(bal(store, budi.id), 100000);
  });

  it('hapus utang butuh alasan dan tidak boleh melebihi sisa', async () => {
    const { store, budi } = ctx;
    await assert.rejects(writeOffDebt(store, { customerId: budi.id, amount: 1000, reason: ' ' }, NOW), /Alasan wajib/);
    await assert.rejects(writeOffDebt(store, { customerId: budi.id, amount: 100001, reason: 'pindah' }, NOW), /melebihi kasbon/);
    const e = await writeOffDebt(store, { customerId: budi.id, amount: 40000, reason: 'Pindah kota' }, NOW);
    assert.equal(e.type, 'writeoff');
    assert.equal(e.balanceAfter, 60000);
  });

  it('data tetap sama dan berurutan setelah dimuat ulang dari penyimpanan', async () => {
    const { store, persistence, budi } = ctx;
    await receiveDebtPayment(store, { customerId: budi.id, amount: 25000, method: 'cash' }, NOW);
    const again = new Store(persistence);
    await again.init();
    assert.equal(bal(again, budi.id), 75000);
    assert.deepEqual(again.getState().debtByCustomer.get(budi.id)?.map((e) => e.type), ['kasbon', 'payment']);
  });
});

describe('void transaksi kasbon', () => {
  let ctx: Awaited<ReturnType<typeof setup>>;
  beforeEach(async () => (ctx = await setup()));

  it('void mengurangi utang sebesar kasbon transaksi itu dan mengembalikan stok', async () => {
    const { store, product, budi } = ctx;
    const t = await checkout(
      store,
      { lines: [line(product.id, 20)], payments: [{ method: 'cash', amount: 20000 }, { method: 'kasbon', amount: 50000, customerId: budi.id }] },
      NOW,
    );
    assert.equal(bal(store, budi.id), 50000);
    await voidTransaction(store, t.id, 'Salah input', NOW);
    assert.equal(bal(store, budi.id), 0);
    assert.equal(store.getState().productsById.get(product.id)?.stock, 200);
    const last = store.getState().debtByCustomer.get(budi.id)?.at(-1);
    assert.equal(last?.type, 'void');
    assert.equal(last?.amount, 50000);
    assert.equal(last?.note, 'Salah input');
  });

  it('void setelah pelanggan mencicil membuat saldo negatif (kelebihan bayar), bukan error', async () => {
    const { store, product, budi } = ctx;
    const t = await checkout(store, { lines: [line(product.id, 10)], payments: [{ method: 'kasbon', amount: 35000, customerId: budi.id }] }, NOW);
    await receiveDebtPayment(store, { customerId: budi.id, amount: 30000, method: 'cash' }, NOW);
    await voidTransaction(store, t.id, 'Pelanggan batal', NOW);
    assert.equal(bal(store, budi.id), -30000);
    // kasbon baru memakai kelebihan bayar itu lebih dulu
    await checkout(store, { lines: [line(product.id, 4)], payments: [{ method: 'kasbon', amount: 14000, customerId: budi.id }] }, NOW);
    assert.equal(bal(store, budi.id), -16000);
    assert.equal(debtorRows(store.getState(), '2026-10-19').find((r) => r.customer.id === budi.id)?.since, null);
  });

  it('void transaksi tanpa kasbon tidak menyentuh buku kasbon', async () => {
    const { store, product, budi } = ctx;
    const t = await checkout(store, { lines: [line(product.id, 2)], payments: [{ method: 'cash', amount: 7000 }] }, NOW);
    await voidTransaction(store, t.id, 'x', NOW);
    assert.equal(store.getState().debtByCustomer.get(budi.id)?.length ?? 0, 0);
  });
});

describe('ringkasan kasbon', () => {
  it('umur utang dihitung sejak saldo terakhir kali naik dari nol, dan reset saat lunas', async () => {
    const { store, budi } = await setup();
    await addManualDebt(store, { customerId: budi.id, amount: 50000 }, at(-10));
    await receiveDebtPayment(store, { customerId: budi.id, amount: 20000, method: 'cash' }, at(-6));
    let e = store.getState().debtByCustomer.get(budi.id) ?? [];
    assert.equal(debtSince(e), '2026-10-09');
    await receiveDebtPayment(store, { customerId: budi.id, amount: 30000, method: 'cash' }, at(-3));
    e = store.getState().debtByCustomer.get(budi.id) ?? [];
    assert.equal(debtSince(e), null);
    await addManualDebt(store, { customerId: budi.id, amount: 8000 }, at(-1));
    e = store.getState().debtByCustomer.get(budi.id) ?? [];
    assert.equal(debtSince(e), '2026-10-18');
  });

  it('daftar peminjam: yang berutang di atas (terbesar dulu), total dan jumlah benar', async () => {
    const { store, budi } = await setup();
    const siti = await saveCustomer(store, { name: 'Bu Siti' }, NOW);
    const andi = await saveCustomer(store, { name: 'Mas Andi' }, NOW);
    await saveCustomer(store, { name: 'Zulkifli' }, NOW);
    await addManualDebt(store, { customerId: budi.id, amount: 40000 }, at(-8));
    await addManualDebt(store, { customerId: siti.id, amount: 90000 }, at(-2));
    await addManualDebt(store, { customerId: andi.id, amount: 5000 }, at(-1));
    await receiveDebtPayment(store, { customerId: andi.id, amount: 5000, method: 'cash' }, NOW);
    const rows = debtorRows(store.getState(), '2026-10-19');
    assert.deepEqual(rows.map((r) => r.customer.name), ['Bu Siti', 'Pak Budi', 'Mas Andi', 'Zulkifli']);
    const s = debtSummary(store.getState(), '2026-10-19');
    assert.equal(s.total, 130000);
    assert.equal(s.debtors, 2);
    assert.equal(s.oldestDays, 8);
    assert.equal(s.oldestName, 'Pak Budi');
  });
});

describe('teks struk dan WhatsApp', () => {
  it('struk WhatsApp memuat pelanggan, kasbon, dan total kasbon; struk teks juga', async () => {
    const { store, product, budi } = await setup();
    await saveSettings(store, { storeName: 'Warung Manop', address: 'Jl. Merdeka 10', phone: '0211234567', receiptFooter: 'Terima kasih!' });
    const t = await checkout(
      store,
      { lines: [line(product.id, 20)], payments: [{ method: 'cash', amount: 20000, tendered: 20000 }, { method: 'kasbon', amount: 50000, customerId: budi.id }] },
      NOW,
    );
    const settings = store.getState().settings;
    const debtAfter = store.getState().debtEntryByTx.get(t.id)?.balanceAfter;
    assert.equal(debtAfter, 50000);
    const wa = receiptWhatsApp(t, settings, { debtAfter });
    assert.match(wa, /^\*Warung Manop\*/);
    assert.match(wa, /Struk \*INV-20261019-0001\*/);
    assert.match(wa, /Pelanggan: Pak Budi/);
    assert.match(wa, /Indomie Goreng\n {2}20 pcs x 3\.500 = Rp 70\.000/);
    assert.match(wa, /\*TOTAL: Rp 70\.000\*/);
    assert.match(wa, /Kasbon: Rp 50\.000/);
    assert.match(wa, /\*Total kasbon Pak Budi: Rp 50\.000\*/);
    assert.match(wa, /Terima kasih!$/);
    const txt = receiptText(t, settings, { debtAfter });
    assert.match(txt, /Pelanggan\s+Pak Budi/);
    assert.match(txt, /Kasbon\s+Rp 50\.000/);
    assert.match(txt, /Total kasbon\s+Rp 50\.000/);
    // tanpa kasbon: tidak ada baris pelanggan/kasbon
    const plain = await checkout(store, { lines: [line(product.id, 1)], payments: [{ method: 'cash', amount: 3500 }] }, NOW);
    assert.doesNotMatch(receiptWhatsApp(plain, settings), /Pelanggan|kasbon/i);
  });

  it('bukti pembayaran utang dan pengingat berisi jumlah, sisa, dan lama utang', async () => {
    const { store, budi } = await setup();
    await addManualDebt(store, { customerId: budi.id, amount: 100000 }, at(-8));
    const part = await receiveDebtPayment(store, { customerId: budi.id, amount: 40000, method: 'qris', reference: 'QR-9' }, NOW);
    const settings = store.getState().settings;
    const proof = debtPaymentWhatsApp({ settings, customerName: 'Pak Budi', entry: part });
    assert.match(proof, /Bukti pembayaran kasbon/);
    assert.match(proof, /Dibayar: \*Rp 40\.000\* \(QRIS\)/);
    assert.match(proof, /Ref: QR-9/);
    assert.match(proof, /Sisa kasbon: \*Rp 60\.000\*/);
    const last = await receiveDebtPayment(store, { customerId: budi.id, amount: 60000, method: 'cash' }, NOW);
    assert.match(debtPaymentWhatsApp({ settings, customerName: 'Pak Budi', entry: last }), /Kasbon \*LUNAS\*/);
    const remind = debtReminderWhatsApp({ settings, customerName: 'Pak Budi', balance: 60000, since: '2026-10-11', today: '2026-10-19' });
    assert.match(remind, /^Halo Pak Budi, ini pengingat dari \*Warung Manop\*/);
    assert.match(remind, /\*Rp 60\.000\* \(sejak 11 Okt 2026, 8 hari\)/);
  });
});
