import assert from 'node:assert/strict';
import { beforeEach, describe, it } from 'node:test';
import { MAX_HOLDS, deleteHold, holdCart, resumeHold } from '../src/core/holds';
import { cancelOpname, finishOpname, lineDiff, saveOpnameCount, startOpname, summarizeOpname } from '../src/core/opname';
import { MemoryPersistence } from '../src/core/persistence';
import { summarizeDay } from '../src/core/queries';
import {
  categoryRows,
  dailyRows,
  kasbonReport,
  methodReport,
  periodError,
  presetPeriod,
  productRows,
  salesSummary,
  stockValueByCategory,
  stockValueRows,
  tableCsv,
  productTable,
} from '../src/core/reports';
import { RETURN_REASONS, previewReturn, returnItems, returnableQty } from '../src/core/returns';
import {
  addManualDebt,
  checkout,
  confirmPayment,
  receiveDebtPayment,
  receiveStock,
  saveCustomer,
  saveProduct,
  saveSettings,
  voidTransaction,
} from '../src/core/services';
import { addCashMove, closeShift, openShift, shiftSummaryOf, shiftText, summarizeShift } from '../src/core/shifts';
import { Store } from '../src/core/store';

const NOW = new Date('2026-10-19T05:00:00Z'); // Senin 19 Okt 2026, 12.00 WIB
const TODAY = '2026-10-19';
const at = (minutes: number) => new Date(NOW.getTime() + minutes * 60_000);

async function setup() {
  const persistence = new MemoryPersistence();
  const store = new Store(persistence);
  await store.init();
  const mie = await saveProduct(store, { name: 'Indomie Goreng', category: 'Makanan', baseUnit: 'pcs', costPrice: 2800, sellPrice: 3500, minStock: 5 }, NOW);
  const air = await saveProduct(store, { name: 'Air Mineral', category: 'Minuman', baseUnit: 'botol', costPrice: 2000, sellPrice: 3000, minStock: 5 }, NOW);
  const beras = await saveProduct(store, { name: 'Beras Premium', category: 'Sembako', baseUnit: 'kg', costPrice: 12000, sellPrice: 15500, minStock: 3 }, NOW);
  for (const [p, q, c] of [[mie, 200, 2800], [air, 100, 2000], [beras, 40, 12000]] as const) {
    await receiveStock(store, { productId: p.id, unitQty: q, unitCost: c }, NOW);
  }
  const budi = await saveCustomer(store, { name: 'Pak Budi', phone: '0812-3456-7890' }, NOW);
  return { store, persistence, mie, air, beras, budi };
}
type Ctx = Awaited<ReturnType<typeof setup>>;

const line = (productId: string, unitQty: number, unitName = 'pcs') => ({ productId, unitName, unitQty });
const cash = (amount: number, tendered = amount) => ({ method: 'cash' as const, amount, tendered });
const stockOf = (c: Ctx, id: string) => c.store.getState().productsById.get(id)?.stock;

describe('retur', () => {
  let c: Ctx;
  beforeEach(async () => (c = await setup()));

  it('retur sebagian lalu sisanya: uang kembali, omzet, HPP, dan stok sama persis dengan transaksi aslinya', async () => {
    const t = await checkout(c.store, { lines: [line(c.mie.id, 4)], payments: [cash(14000, 20000)] }, NOW);
    assert.equal(stockOf(c, c.mie.id), 196);
    const r1 = await returnItems(c.store, { txId: t.id, lines: [{ itemIndex: 0, unitQty: 1 }], refundMethod: 'cash', restock: true, reason: 'Salah beli' }, at(10));
    assert.equal(r1.refund, 3500);
    assert.equal(r1.revenue, 3500);
    assert.equal(r1.cogs, 2800);
    assert.equal(stockOf(c, c.mie.id), 197);
    assert.equal(c.store.getState().txById.get(t.id)?.status, 'completed', 'masih sebagian');
    const mv = c.store.getState().movements.find((m) => m.type === 'return');
    assert.equal(mv?.qtyChange, 1);
    assert.match(mv?.reason ?? '', /Retur INV-.*Salah beli/);

    const r2 = await returnItems(c.store, { txId: t.id, lines: [{ itemIndex: 0, unitQty: 3 }], refundMethod: 'cash', restock: true, reason: 'Sisanya juga' }, at(20));
    assert.equal(r2.refund, 10500);
    assert.equal(r1.refund + r2.refund, t.total);
    assert.equal(r1.revenue + r2.revenue, t.subtotal - t.discount);
    assert.equal(r1.cogs + r2.cogs, 4 * 2800);
    assert.equal(stockOf(c, c.mie.id), 200);
    assert.equal(c.store.getState().txById.get(t.id)?.status, 'returned');
  });

  it('diskon transaksi, pajak, dan pembulatan dibagi rata dan jumlahnya tetap pas sampai rupiah terakhir', async () => {
    await saveSettings(c.store, { taxEnabled: true, taxPercent: 11, roundingMode: '500' });
    const t = await checkout(c.store, { lines: [line(c.mie.id, 3), line(c.air.id, 2, 'botol')], cartDiscount: { type: 'nominal', value: 500 }, payments: [cash(18000)] }, NOW);
    assert.equal(t.subtotal, 16500);
    assert.equal(t.total, 18000); // 16000 + 1760 pajak = 17760, dibulatkan ke 18000
    const steps: [number, number][] = [[0, 1], [1, 1], [0, 2], [1, 1]];
    let refund = 0;
    let revenue = 0;
    let cogs = 0;
    for (const [i, [itemIndex, unitQty]] of steps.entries()) {
      const r = await returnItems(c.store, { txId: t.id, lines: [{ itemIndex, unitQty }], refundMethod: 'cash', restock: true, reason: 'Uji' }, at(i + 1));
      assert.ok(r.refund > 0 && r.revenue > 0);
      refund += r.refund;
      revenue += r.revenue;
      cogs += r.cogs;
    }
    assert.equal(refund, 18000, 'seluruh tagihan dikembalikan');
    assert.equal(revenue, 16000, 'omzet bersih kembali ke nol');
    assert.equal(cogs, 3 * 2800 + 2 * 2000);
    assert.equal(c.store.getState().txById.get(t.id)?.status, 'returned');
  });

  it('pembagian pertama dihitung proporsional', async () => {
    await saveSettings(c.store, { taxEnabled: true, taxPercent: 11, roundingMode: '500' });
    const t = await checkout(c.store, { lines: [line(c.mie.id, 3), line(c.air.id, 2, 'botol')], cartDiscount: { type: 'nominal', value: 500 }, payments: [cash(18000)] }, NOW);
    const p = previewReturn(t, [], [{ itemIndex: 0, unitQty: 1 }], true);
    assert.equal(p.refund, Math.round((18000 * 3500) / 16500));
    assert.equal(p.revenue, Math.round((16000 * 3500) / 16500));
    assert.equal(p.complete, false);
  });

  it('tidak boleh meretur lebih dari yang dibeli, termasuk bertahap', async () => {
    const t = await checkout(c.store, { lines: [line(c.mie.id, 4)], payments: [cash(14000)] }, NOW);
    await assert.rejects(returnItems(c.store, { txId: t.id, lines: [{ itemIndex: 0, unitQty: 5 }], refundMethod: 'cash', restock: true, reason: 'x' }, NOW), /tinggal 4 pcs/);
    await returnItems(c.store, { txId: t.id, lines: [{ itemIndex: 0, unitQty: 3 }], refundMethod: 'cash', restock: true, reason: 'x' }, NOW);
    await assert.rejects(returnItems(c.store, { txId: t.id, lines: [{ itemIndex: 0, unitQty: 2 }], refundMethod: 'cash', restock: true, reason: 'x' }, NOW), /tinggal 1 pcs/);
    assert.deepEqual(returnableQty(c.store.getState().txById.get(t.id) as never, c.store.getState().returns), [1]);
  });

  it('menolak jumlah tidak sah, alasan kosong, tanpa pilihan, dan cara kembali yang tidak ada', async () => {
    const t = await checkout(c.store, { lines: [line(c.mie.id, 4)], payments: [cash(14000)] }, NOW);
    const base = { txId: t.id, refundMethod: 'cash' as const, restock: true, reason: 'x' };
    await assert.rejects(returnItems(c.store, { ...base, lines: [{ itemIndex: 0, unitQty: 1.5 }] }, NOW), /bilangan bulat/);
    await assert.rejects(returnItems(c.store, { ...base, lines: [{ itemIndex: 0, unitQty: 0 }] }, NOW), /Pilih barang/);
    await assert.rejects(returnItems(c.store, { ...base, lines: [] }, NOW), /Pilih barang/);
    await assert.rejects(returnItems(c.store, { ...base, reason: '  ', lines: [{ itemIndex: 0, unitQty: 1 }] }, NOW), /Alasan retur wajib/);
    await assert.rejects(returnItems(c.store, { ...base, refundMethod: 'kasbon', lines: [{ itemIndex: 0, unitQty: 1 }] }, NOW), /atas nama pelanggan/);
    await assert.rejects(returnItems(c.store, { ...base, txId: 'tidak-ada', lines: [{ itemIndex: 0, unitQty: 1 }] }, NOW), /tidak ditemukan/);
    assert.equal(c.store.getState().returns.length, 0);
    assert.equal(stockOf(c, c.mie.id), 196, 'tidak ada yang berubah');
  });

  it('barang rusak (tidak masuk stok): stok tetap, HPP tidak dikembalikan sehingga laba turun', async () => {
    const t = await checkout(c.store, { lines: [line(c.mie.id, 2)], payments: [cash(7000)] }, NOW);
    const before = summarizeDay(c.store.getState(), TODAY);
    const r = await returnItems(c.store, { txId: t.id, lines: [{ itemIndex: 0, unitQty: 1 }], refundMethod: 'cash', restock: false, reason: 'Barang rusak' }, at(5));
    assert.equal(r.cogs, 0);
    assert.equal(stockOf(c, c.mie.id), 198, 'stok tidak naik');
    assert.equal(c.store.getState().movements.filter((m) => m.type === 'return').length, 0);
    const after = summarizeDay(c.store.getState(), TODAY);
    assert.equal(after.revenue, before.revenue - 3500);
    assert.equal(after.cogs, before.cogs);
    assert.equal(after.profit, before.profit - 3500);
  });

  it('ringkasan hari: omzet dan HPP dikurangi retur, jumlah transaksi tidak berubah', async () => {
    const t = await checkout(c.store, { lines: [line(c.mie.id, 4)], payments: [cash(14000)] }, NOW);
    await returnItems(c.store, { txId: t.id, lines: [{ itemIndex: 0, unitQty: 1 }], refundMethod: 'cash', restock: true, reason: 'x' }, at(5));
    const d = summarizeDay(c.store.getState(), TODAY);
    assert.equal(d.count, 1);
    assert.equal(d.revenue, 10500);
    assert.equal(d.cogs, 8400);
    assert.equal(d.profit, 2100);
    assert.equal(d.refunds, 3500);
    assert.equal(d.returnCount, 1);
  });

  it('retur dengan satuan desimal (kg) dan satuan besar (dus)', async () => {
    await saveProduct(c.store, { id: c.air.id, name: 'Air Mineral', category: 'Minuman', baseUnit: 'botol', costPrice: 2000, sellPrice: 3000, units: [{ unitName: 'dus', conversion: 24, sellPrice: 60000 }] }, NOW);
    const t = await checkout(c.store, { lines: [line(c.beras.id, 1.5, 'kg'), line(c.air.id, 1, 'dus')], payments: [cash(23250 + 60000)] }, NOW);
    assert.equal(t.total, 83250);
    const r = await returnItems(c.store, { txId: t.id, lines: [{ itemIndex: 0, unitQty: 0.5 }, { itemIndex: 1, unitQty: 1 }], refundMethod: 'cash', restock: true, reason: 'x' }, NOW);
    assert.equal(r.refund, 7750 + 60000);
    assert.equal(r.lines[1].qty, 24, 'satu dus kembali sebagai 24 botol');
    assert.equal(stockOf(c, c.air.id), 100, 'stok air kembali penuh');
    assert.equal(stockOf(c, c.beras.id), 39);
    assert.equal(r.cogs, 6000 + 48000);
  });

  it('potong kasbon: utang pelanggan berkurang dan tercatat sebagai Retur barang; tidak boleh melebihi utang', async () => {
    const t = await checkout(c.store, { lines: [line(c.mie.id, 4)], payments: [{ method: 'kasbon', amount: 14000, customerId: c.budi.id }] }, NOW);
    assert.equal(c.store.getState().balanceByCustomer.get(c.budi.id), 14000);
    const r = await returnItems(c.store, { txId: t.id, lines: [{ itemIndex: 0, unitQty: 1 }], refundMethod: 'kasbon', restock: true, reason: 'Salah beli' }, at(5));
    assert.equal(r.customerId, c.budi.id);
    assert.equal(c.store.getState().balanceByCustomer.get(c.budi.id), 10500);
    const entry = c.store.getState().debtByCustomer.get(c.budi.id)?.at(-1);
    assert.equal(entry?.type, 'return');
    assert.equal(entry?.amount, 3500);
    assert.equal(entry?.balanceAfter, 10500);
    // sebagian utang sudah dibayar: sisa utang 1000 < nilai retur 3500
    await receiveDebtPayment(c.store, { customerId: c.budi.id, amount: 9500, method: 'cash' }, at(6));
    await assert.rejects(returnItems(c.store, { txId: t.id, lines: [{ itemIndex: 0, unitQty: 1 }], refundMethod: 'kasbon', restock: true, reason: 'x' }, at(7)), /tinggal Rp\s?1\.000/);
    await receiveDebtPayment(c.store, { customerId: c.budi.id, amount: 1000, method: 'cash' }, at(8));
    await assert.rejects(returnItems(c.store, { txId: t.id, lines: [{ itemIndex: 0, unitQty: 1 }], refundMethod: 'kasbon', restock: true, reason: 'x' }, at(9)), /tidak punya kasbon/);
  });

  it('transaksi void tidak bisa diretur, transaksi yang sudah diretur tidak bisa di-void, dan pembayaran menunggu harus dikonfirmasi dulu', async () => {
    const a = await checkout(c.store, { lines: [line(c.mie.id, 1)], payments: [cash(3500)] }, NOW);
    await voidTransaction(c.store, a.id, 'Salah input', NOW);
    await assert.rejects(returnItems(c.store, { txId: a.id, lines: [{ itemIndex: 0, unitQty: 1 }], refundMethod: 'cash', restock: true, reason: 'x' }, NOW), /sudah dibatalkan/);

    const b = await checkout(c.store, { lines: [line(c.mie.id, 2)], payments: [cash(7000)] }, NOW);
    await returnItems(c.store, { txId: b.id, lines: [{ itemIndex: 0, unitQty: 1 }], refundMethod: 'cash', restock: true, reason: 'x' }, NOW);
    await assert.rejects(voidTransaction(c.store, b.id, 'Salah input', NOW), /sudah diretur sebagian/);

    const p = await checkout(c.store, { lines: [line(c.mie.id, 1)], payments: [{ method: 'transfer', amount: 3500, status: 'pending', reference: 'TRF-1' }] }, NOW);
    await assert.rejects(returnItems(c.store, { txId: p.id, lines: [{ itemIndex: 0, unitQty: 1 }], refundMethod: 'cash', restock: true, reason: 'x' }, NOW), /Konfirmasi dulu/);
    await confirmPayment(c.store, p.id, 0);
    await returnItems(c.store, { txId: p.id, lines: [{ itemIndex: 0, unitQty: 1 }], refundMethod: 'transfer', restock: true, reason: 'x' }, NOW);
  });

  it('barang gratis (diskon 100%) tetap bisa diretur walau uang kembali Rp 0, sehingga transaksi bisa selesai diretur', async () => {
    const t = await checkout(c.store, { lines: [line(c.mie.id, 2), { ...line(c.air.id, 1, 'botol'), discount: { type: 'percent' as const, value: 100 } }], payments: [cash(7000)] }, NOW);
    assert.equal(t.total, 7000);
    const r1 = await returnItems(c.store, { txId: t.id, lines: [{ itemIndex: 0, unitQty: 2 }], refundMethod: 'cash', restock: true, reason: 'x' }, at(1));
    assert.equal(r1.refund, 7000);
    assert.equal(c.store.getState().txById.get(t.id)?.status, 'completed', 'barang gratis belum kembali');
    const r2 = await returnItems(c.store, { txId: t.id, lines: [{ itemIndex: 1, unitQty: 1 }], refundMethod: 'cash', restock: true, reason: 'x' }, at(2));
    assert.equal(r2.refund, 0);
    assert.equal(r2.revenue, 0);
    assert.equal(stockOf(c, c.air.id), 100, 'stok barang gratis kembali');
    assert.equal(c.store.getState().txById.get(t.id)?.status, 'returned');
  });

  it('alasan bawaan tersedia', () => {
    assert.ok(RETURN_REASONS.length >= 4);
  });
});

describe('shift dan kas', () => {
  let c: Ctx;
  beforeEach(async () => (c = await setup()));
  const data = (cx: Ctx) => {
    const s = cx.store.getState();
    return { transactions: s.transactions, returns: s.returns, debtEntries: [...s.debtByCustomer.values()].flat(), cashMoves: s.cashMoves };
  };

  it('buka shift: satu saja, uang awal harus rupiah utuh', async () => {
    await assert.rejects(openShift(c.store, { openingCash: -1 }, NOW), /rupiah utuh/);
    await assert.rejects(openShift(c.store, { openingCash: 1.5 }, NOW), /rupiah utuh/);
    const s = await openShift(c.store, { openingCash: 100000, note: 'Pagi' }, NOW);
    assert.equal(s.status, 'open');
    assert.equal(c.store.getState().openShift?.id, s.id);
    await assert.rejects(openShift(c.store, { openingCash: 0 }, NOW), /Masih ada shift/);
  });

  it('wajib shift: penjualan ditolak tanpa shift, dan transaksi mencatat shift yang berjalan', async () => {
    await saveSettings(c.store, { requireShift: true });
    await assert.rejects(checkout(c.store, { lines: [line(c.mie.id, 1)], payments: [cash(3500)] }, NOW), /Buka shift dulu/);
    const s = await openShift(c.store, { openingCash: 0 }, NOW);
    const t = await checkout(c.store, { lines: [line(c.mie.id, 1)], payments: [cash(3500)] }, at(1));
    assert.equal(t.shiftId, s.id);
    await saveSettings(c.store, { requireShift: false });
    await closeShift(c.store, { countedCash: 3500 }, at(2));
    const free = await checkout(c.store, { lines: [line(c.mie.id, 1)], payments: [cash(3500)] }, at(3));
    assert.equal(free.shiftId, undefined, 'tanpa shift tetap bisa berjualan bila tidak diwajibkan');
  });

  it('uang tunai yang seharusnya ada: penjualan, kembalian tidak dihitung, cicilan, uang masuk/keluar, void, dan retur', async () => {
    const shift = await openShift(c.store, { openingCash: 100000 }, NOW);
    const a = await checkout(c.store, { lines: [line(c.mie.id, 4)], payments: [cash(14000, 20000)] }, at(1)); // 14.000 diterima, kembalian 6.000
    const b = await checkout(c.store, { lines: [line(c.mie.id, 2)], payments: [cash(7000)] }, at(2)); // akan di-void
    await checkout(c.store, { lines: [line(c.air.id, 2, 'botol')], payments: [{ method: 'qris', amount: 6000, reference: 'QR-1' }] }, at(3));
    await checkout(c.store, { lines: [line(c.mie.id, 2)], payments: [{ method: 'kasbon', amount: 7000, customerId: c.budi.id }] }, at(4));
    await receiveDebtPayment(c.store, { customerId: c.budi.id, amount: 4000, method: 'cash' }, at(5));
    await addCashMove(c.store, { type: 'in', amount: 20000, note: 'Tambah uang kembalian' }, at(6));
    await addCashMove(c.store, { type: 'out', amount: 15000, note: 'Bayar galon' }, at(7));
    await voidTransaction(c.store, b.id, 'Salah input', at(8));
    await returnItems(c.store, { txId: a.id, lines: [{ itemIndex: 0, unitQty: 1 }], refundMethod: 'cash', restock: true, reason: 'Salah beli' }, at(9));

    const sum = summarizeShift(shift, data(c));
    assert.equal(sum.cash.opening, 100000);
    assert.equal(sum.cash.sales, 14000 + 7000);
    assert.equal(sum.cash.debtPayments, 4000);
    assert.equal(sum.cash.moneyIn, 20000);
    assert.equal(sum.cash.moneyOut, 15000);
    assert.equal(sum.cash.refunds, 7000 + 3500);
    assert.equal(sum.cash.expected, 100000 + 21000 + 4000 + 20000 - 10500 - 15000);
    assert.equal(sum.cash.expected, 119500);
    assert.equal(sum.salesCount, 3, 'yang di-void tidak dihitung');
    assert.equal(sum.kasbonSales, 7000);
    assert.equal(sum.voidCount, 1);
    assert.equal(sum.returnCount, 1);
    const byMethod = Object.fromEntries(sum.methods.map((m) => [m.method, m.net]));
    assert.deepEqual(byMethod, { cash: 14500, qris: 6000 });
  });

  it('tutup shift: selisih dihitung dan ringkasan dibekukan; shift berikutnya tidak mengubahnya', async () => {
    const shift = await openShift(c.store, { openingCash: 50000 }, NOW);
    const t = await checkout(c.store, { lines: [line(c.mie.id, 2)], payments: [cash(7000)] }, at(1));
    const closed = await closeShift(c.store, { countedCash: 56500, note: 'Kurang receh' }, at(60));
    assert.equal(closed.status, 'closed');
    assert.equal(closed.expectedCash, 57000);
    assert.equal(closed.difference, -500);
    assert.equal(closed.closeNote, 'Kurang receh');
    assert.equal(c.store.getState().openShift, null);
    await assert.rejects(closeShift(c.store, { countedCash: 0 }, at(61)), /Tidak ada shift/);
    await assert.rejects(addCashMove(c.store, { type: 'in', amount: 1000, note: 'x' }, at(61)), /Buka shift dulu/);

    // shift kedua: void transaksi dari shift pertama (hari yang sama) mengeluarkan uang dari laci SHIFT KEDUA
    const second = await openShift(c.store, { openingCash: 56500 }, at(70));
    await voidTransaction(c.store, t.id, 'Pelanggan batal', at(71));
    const frozen = shiftSummaryOf(c.store.getState().shiftsById.get(shift.id) as never, data(c));
    assert.equal(frozen.cash.expected, 57000, 'shift pertama tetap seperti saat ditutup');
    assert.equal(frozen.cash.refunds, 0);
    const live = summarizeShift(second, data(c));
    assert.equal(live.cash.refunds, 7000);
    assert.equal(live.cash.expected, 56500 - 7000);
  });

  it('shift tidak bisa ditutup selama ada pembayaran menunggu konfirmasi', async () => {
    await openShift(c.store, { openingCash: 0 }, NOW);
    const t = await checkout(c.store, { lines: [line(c.mie.id, 1)], payments: [{ method: 'transfer', amount: 3500, status: 'pending', reference: 'TRF-9' }] }, at(1));
    const live = summarizeShift({ id: c.store.getState().openShift?.id as string, openingCash: 0 }, data(c));
    assert.equal(live.pending, 3500);
    assert.equal(live.cash.expected, 0, 'uang yang belum dikonfirmasi tidak dihitung');
    await assert.rejects(closeShift(c.store, { countedCash: 0 }, at(2)), /1 transaksi.*menunggu konfirmasi/);
    await confirmPayment(c.store, t.id, 0);
    const closed = await closeShift(c.store, { countedCash: 0 }, at(3));
    assert.equal(closed.difference, 0);
    assert.deepEqual(closed.summary?.methods.map((m) => [m.method, m.net]), [['transfer', 3500]]);
  });

  it('uang masuk/keluar: jumlah dan keterangan wajib, harus ada shift', async () => {
    await assert.rejects(addCashMove(c.store, { type: 'in', amount: 1000, note: 'x' }, NOW), /Buka shift dulu/);
    await openShift(c.store, { openingCash: 10000 }, NOW);
    await assert.rejects(addCashMove(c.store, { type: 'in', amount: 0, note: 'x' }, NOW), /lebih dari 0/);
    await assert.rejects(addCashMove(c.store, { type: 'out', amount: 1500.5, note: 'x' }, NOW), /rupiah utuh/);
    await assert.rejects(addCashMove(c.store, { type: 'out', amount: 1000, note: ' ' }, NOW), /Keterangan wajib/);
    const m = await addCashMove(c.store, { type: 'out', amount: 1000, note: 'Beli plastik' }, NOW);
    assert.equal(m.type, 'out');
    assert.equal(c.store.getState().cashMoves.length, 1);
  });

  it('teks rekap memuat selisih dan angka laci', async () => {
    const shift = await openShift(c.store, { openingCash: 50000 }, NOW);
    await checkout(c.store, { lines: [line(c.mie.id, 2)], payments: [cash(7000)] }, at(1));
    const closed = await closeShift(c.store, { countedCash: 58000 }, at(60));
    const txt = shiftText(closed, closed.summary as never, 'Warung Manop');
    assert.match(txt, /Rekap shift - Warung Manop/);
    assert.match(txt, /Seharusnya: Rp 57\.000/);
    assert.match(txt, /Selisih: lebih Rp 1\.000/);
    assert.equal(shift.id, closed.id);
  });
});

describe('opname stok', () => {
  let c: Ctx;
  beforeEach(async () => (c = await setup()));
  const count = (productId: string, countedQty: number | null, when = NOW) => saveOpnameCount(c.store, { sessionId: c.store.getState().opnames[0].id, productId, countedQty }, when);

  it('mulai: semua produk atau satu kategori, hanya satu sesi berjalan', async () => {
    await assert.rejects(startOpname(c.store, { scope: 'Kategori Kosong' }, NOW), /Tidak ada produk aktif/);
    const s = await startOpname(c.store, { scope: 'Minuman', note: 'Rak depan' }, NOW);
    assert.deepEqual(s.lines.map((l) => l.name), ['Air Mineral']);
    assert.equal(s.lines[0].systemQty, 100);
    assert.equal(s.lines[0].countedQty, null);
    await assert.rejects(startOpname(c.store, { scope: 'Semua' }, NOW), /belum selesai/);
    await cancelOpname(c.store, s.id);
    const all = await startOpname(c.store, { scope: 'Semua' }, NOW);
    assert.equal(all.lines.length, 3);
  });

  it('hitung: aturan jumlah per satuan, bisa dikosongkan lagi', async () => {
    await startOpname(c.store, { scope: 'Semua' }, NOW);
    await assert.rejects(count(c.mie.id, -1), /tidak boleh negatif/);
    await assert.rejects(count(c.mie.id, 2.5), /bilangan bulat/);
    await assert.rejects(count(c.beras.id, 1.2345), /3 angka/);
    await count(c.beras.id, 12.5);
    const line = c.store.getState().opnames[0].lines.find((l) => l.productId === c.beras.id);
    assert.equal(line?.countedQty, 12.5);
    assert.equal(lineDiff(line as never), 12.5 - 40);
    await count(c.beras.id, null);
    assert.equal(c.store.getState().opnames[0].lines.find((l) => l.productId === c.beras.id)?.countedQty, null);
    await assert.rejects(saveOpnameCount(c.store, { sessionId: 'x', productId: c.mie.id, countedQty: 1 }, NOW), /tidak ditemukan/);
  });

  it('selesai: hanya selisih yang diterapkan ke stok, penjualan saat menghitung tidak hilang', async () => {
    const s = await startOpname(c.store, { scope: 'Semua' }, NOW);
    await count(c.mie.id, 190, at(1)); // sistem 200 -> selisih -10
    await checkout(c.store, { lines: [line(c.mie.id, 3)], payments: [cash(10500)] }, at(2)); // stok 197 setelah dihitung
    await count(c.air.id, 103, at(3)); // sistem 100 -> +3
    // beras tidak dihitung
    const done = await finishOpname(c.store, s.id, at(10));
    assert.equal(done.status, 'done');
    assert.equal(stockOf(c, c.mie.id), 187, '197 - 10: penjualan 3 pcs tetap terhitung');
    assert.equal(stockOf(c, c.air.id), 103);
    assert.equal(stockOf(c, c.beras.id), 40, 'yang tidak dihitung tidak disentuh');
    const movements = c.store.getState().movements.filter((m) => m.type === 'opname');
    assert.equal(movements.length, 2);
    assert.match(movements.find((m) => m.productId === c.mie.id)?.reason ?? '', /dihitung 190 pcs, sistem 200/);
    assert.deepEqual(done.summary, { counted: 2, withDiff: 2, plusQty: 3, minusQty: 10, diffValue: -10 * 2800 + 3 * 2000 });
    await assert.rejects(finishOpname(c.store, s.id, at(11)), /sudah selesai/);
    await assert.rejects(cancelOpname(c.store, s.id), /sudah selesai/);
    await assert.rejects(count(c.mie.id, 1), /sudah selesai/);
    assert.equal(c.store.getState().opnames.filter((o) => o.status === 'draft').length, 0);
  });

  it('selesai tanpa satu pun yang dihitung ditolak; hitungan yang sama dengan sistem tidak membuat catatan', async () => {
    const s = await startOpname(c.store, { scope: 'Semua' }, NOW);
    await assert.rejects(finishOpname(c.store, s.id, NOW), /Belum ada produk yang dihitung/);
    await count(c.mie.id, 200);
    const done = await finishOpname(c.store, s.id, NOW);
    assert.equal(done.summary?.counted, 1);
    assert.equal(done.summary?.withDiff, 0);
    assert.equal(c.store.getState().movements.filter((m) => m.type === 'opname').length, 0);
  });

  it('jika penjualan setelah dihitung membuat stok minus, selesai ditolak dan tidak ada yang berubah', async () => {
    const s = await startOpname(c.store, { scope: 'Semua' }, NOW);
    await count(c.beras.id, 1); // sistem 40 -> selisih -39
    await checkout(c.store, { lines: [line(c.beras.id, 10, 'kg')], payments: [cash(155000)] }, at(1)); // stok 30
    await count(c.air.id, 90);
    await assert.rejects(finishOpname(c.store, s.id, at(2)), /Hitung ulang/);
    assert.equal(stockOf(c, c.air.id), 100, 'penyesuaian lain ikut dibatalkan');
    assert.equal(c.store.getState().opnames[0].status, 'draft');
  });

  it('ringkasan nilai selisih memakai HPP', () => {
    const lines = [
      { productId: 'a', name: 'A', unit: 'pcs', category: 'X', systemQty: 10, countedQty: 8 },
      { productId: 'b', name: 'B', unit: 'pcs', category: 'X', systemQty: 5, countedQty: 5 },
      { productId: 'c', name: 'C', unit: 'kg', category: 'X', systemQty: 2, countedQty: 2.5 },
      { productId: 'd', name: 'D', unit: 'pcs', category: 'X', systemQty: 7, countedQty: null },
    ];
    const s = summarizeOpname(lines, (id) => ({ a: 1000, b: 500, c: 4000, d: 100 })[id] ?? 0);
    assert.deepEqual(s, { counted: 3, withDiff: 2, plusQty: 0.5, minusQty: 2, diffValue: -2000 + 2000 });
  });
});

describe('laporan', () => {
  let c: Ctx;
  beforeEach(async () => (c = await setup()));

  it('periode bawaan: minggu mulai Senin, bulan lalu, dan lintas tahun', () => {
    assert.deepEqual(presetPeriod('today', '2026-10-23'), { from: '2026-10-23', to: '2026-10-23' });
    assert.deepEqual(presetPeriod('yesterday', '2026-10-23'), { from: '2026-10-22', to: '2026-10-22' });
    assert.deepEqual(presetPeriod('week', '2026-10-23'), { from: '2026-10-19', to: '2026-10-23' }, 'Jumat: Senin-Jumat');
    assert.deepEqual(presetPeriod('week', '2026-10-19'), { from: '2026-10-19', to: '2026-10-19' }, 'Senin: hanya hari ini');
    assert.deepEqual(presetPeriod('week', '2026-10-25'), { from: '2026-10-19', to: '2026-10-25' }, 'Minggu: tujuh hari');
    assert.deepEqual(presetPeriod('last7', '2026-10-23'), { from: '2026-10-17', to: '2026-10-23' });
    assert.deepEqual(presetPeriod('month', '2026-10-23'), { from: '2026-10-01', to: '2026-10-23' });
    assert.deepEqual(presetPeriod('lastMonth', '2026-10-23'), { from: '2026-09-01', to: '2026-09-30' });
    assert.deepEqual(presetPeriod('lastMonth', '2027-01-05'), { from: '2026-12-01', to: '2026-12-31' });
    assert.deepEqual(presetPeriod('lastMonth', '2028-03-10'), { from: '2028-02-01', to: '2028-02-29' }, 'tahun kabisat');
  });

  it('validasi rentang tanggal', () => {
    assert.equal(periodError({ from: '2026-10-01', to: '2026-10-31' }), null);
    assert.match(periodError({ from: '', to: '2026-10-31' }) ?? '', /Isi tanggal/);
    assert.match(periodError({ from: '2026-10-31', to: '2026-10-01' }) ?? '', /tidak boleh setelah/);
    assert.match(periodError({ from: '2025-01-01', to: '2026-10-31' }) ?? '', /maksimal 366/);
    assert.equal(periodError({ from: '2025-10-31', to: '2026-10-30' }), null, '365 hari boleh');
  });

  async function week() {
    // Senin 12.00 WIB dan beberapa hari berikutnya
    const day = (n: number) => new Date(NOW.getTime() + n * 86_400_000);
    await saveSettings(c.store, { taxEnabled: true, taxPercent: 10 });
    const t1 = await checkout(c.store, { lines: [line(c.mie.id, 4), line(c.air.id, 2, 'botol')], cartDiscount: { type: 'nominal', value: 1000 }, payments: [cash(20900)] }, day(0)); // 14000+6000-1000=19000, pajak 10% = 20900
    const t2 = await checkout(c.store, { lines: [line(c.beras.id, 2, 'kg')], payments: [{ method: 'qris', amount: 34100, reference: 'QR-2' }] }, day(1));
    const t3 = await checkout(c.store, { lines: [line(c.mie.id, 3)], payments: [{ method: 'kasbon', amount: 11550, customerId: c.budi.id }] }, day(2));
    return { t1, t2, t3, day };
  }

  it('ringkasan sama dengan jumlah ringkasan harian, dan retur memotong omzet, HPP, serta uang kembali pada tanggalnya', async () => {
    const { t1, day } = await week();
    assert.equal(t1.total, 20900);
    // total sudah termasuk pajak, jadi bayar sesuai total
    const period = { from: TODAY, to: '2026-10-21' };
    const before = salesSummary(c.store.getState(), period);
    assert.equal(before.count, 3);
    assert.equal(before.grossSales, 4 * 3500 + 2 * 3000 + 2 * 15500 + 3 * 3500);
    assert.equal(before.cartDiscounts, 1000);
    assert.equal(before.revenue, before.grossSales - 1000);
    assert.equal(before.cogs, 4 * 2800 + 2 * 2000 + 2 * 12000 + 3 * 2800);
    assert.equal(before.profit, before.revenue - before.cogs);

    await returnItems(c.store, { txId: t1.id, lines: [{ itemIndex: 0, unitQty: 2 }], refundMethod: 'cash', restock: true, reason: 'x' }, day(1));
    const after = salesSummary(c.store.getState(), period);
    assert.ok(after.returnsRevenue > 0);
    assert.equal(after.revenue, before.revenue - after.returnsRevenue);
    assert.equal(after.cogs, before.cogs - 2 * 2800);
    assert.ok(after.refunds >= after.returnsRevenue, 'uang kembali termasuk pajaknya');
    assert.equal(after.returnCount, 1);

    // ringkasan periode = jumlah ringkasan harian
    const days = dailyRows(c.store.getState(), period);
    assert.equal(days.reduce((s, d) => s + d.revenue, 0), after.revenue);
    assert.equal(days.reduce((s, d) => s + d.cogs, 0), after.cogs);
    assert.equal(days.reduce((s, d) => s + d.profit, 0), after.profit);
    // retur tercatat di hari Selasa, bukan Senin saat transaksi aslinya
    assert.equal(days[1].returnCount, 1);
    assert.equal(days[0].returnCount, 0);
    // rentang yang tidak memuat tanggal retur tidak ikut terpotong
    assert.equal(salesSummary(c.store.getState(), { from: TODAY, to: TODAY }).returnCount, 0);
  });

  it('per produk dan kategori: jumlah produk dikurangi diskon transaksi sama dengan penjualan bersih', async () => {
    const { t1, day } = await week();
    await returnItems(c.store, { txId: t1.id, lines: [{ itemIndex: 1, unitQty: 1 }], refundMethod: 'cash', restock: true, reason: 'x' }, day(1));
    const state = c.store.getState();
    const period = { from: TODAY, to: '2026-10-21' };
    const s = salesSummary(state, period);
    const rows = productRows(state, period);
    const sumRev = rows.reduce((a, r) => a + r.revenue, 0);
    assert.equal(sumRev - s.cartDiscountsKept, s.revenue, 'penjualan per produk + diskon transaksi = ringkasan');
    assert.equal(rows.reduce((a, r) => a + r.cogs, 0), s.cogs);
    const mie = rows.find((r) => r.name === 'Indomie Goreng');
    assert.equal(mie?.qty, 7);
    assert.equal(mie?.revenue, 7 * 3500);
    const air = rows.find((r) => r.name === 'Air Mineral');
    assert.equal(air?.qty, 1, 'dua terjual, satu diretur');
    assert.equal(air?.revenue, 3000);
    assert.equal(rows[0].name, 'Beras Premium', 'urut dari penjualan terbesar');
    const cats = categoryRows(rows);
    assert.equal(cats.reduce((a, r) => a + r.revenue, 0), sumRev);
    assert.deepEqual(cats.map((r) => r.category), ['Sembako', 'Makanan', 'Minuman']);
    const csv = tableCsv(productTable(rows, s));
    assert.match(csv, /^Produk,Kategori,Terjual,Penjualan,HPP,Laba\r\n/);
    assert.match(csv, /Beras Premium,Sembako,2 kg,"?Rp 31\.000"?/);
  });

  it('per metode: tunai, QRIS, kasbon baru, cicilan, dan uang kembali', async () => {
    const { t1, day } = await week();
    await receiveDebtPayment(c.store, { customerId: c.budi.id, amount: 5000, method: 'cash' }, day(3));
    await returnItems(c.store, { txId: t1.id, lines: [{ itemIndex: 0, unitQty: 1 }], refundMethod: 'cash', restock: true, reason: 'x' }, day(3));
    await checkout(c.store, { lines: [line(c.mie.id, 1)], payments: [{ method: 'transfer', amount: 3850, status: 'pending', reference: 'T' }] }, day(3));
    const m = methodReport(c.store.getState(), { from: TODAY, to: '2026-10-22' });
    const row = (k: string) => m.rows.find((r) => r.method === k);
    assert.equal(row('cash')?.sales, 20900, 'penjualan tunai t1');
    assert.equal(row('cash')?.debtPayments, 5000);
    assert.ok((row('cash')?.refunds ?? 0) > 0);
    assert.equal(row('qris')?.sales, 34100);
    assert.equal(m.kasbonNew, 11550);
    assert.equal(m.pending, 3850);
    assert.equal(m.received, m.rows.reduce((s, r) => s + r.net, 0));
    assert.equal(row('transfer'), undefined, 'yang masih menunggu tidak dihitung diterima');
  });

  it('nilai stok per sekarang dan rekap kasbon', async () => {
    await week();
    await addManualDebt(c.store, { customerId: c.budi.id, amount: 20000, note: 'lama' }, at(5));
    const state = c.store.getState();
    const rows = stockValueRows(state);
    const mie = rows.find((r) => r.name === 'Indomie Goreng');
    assert.equal(mie?.stock, 193);
    assert.equal(mie?.value, 193 * 2800);
    assert.equal(mie?.retail, 193 * 3500);
    const cats = stockValueByCategory(rows);
    assert.equal(cats.reduce((s, r) => s + r.value, 0), rows.reduce((s, r) => s + r.value, 0));
    const k = kasbonReport(state, { from: TODAY, to: '2026-10-25' }, '2026-10-25');
    assert.equal(k.outstanding, 11550 + 20000);
    assert.equal(k.debtors.length, 1);
    assert.equal(k.debtors[0].name, 'Pak Budi');
    assert.equal(k.newDebt, 11550 + 20000);
    assert.equal(k.paid, 0);
  });

  it('CSV memberi tanda kutip pada sel yang memuat koma', () => {
    const csv = tableCsv({ title: 't', columns: ['A', 'B'], numeric: [1], rows: [['x, y', 'Rp 1.000']] });
    assert.equal(csv, 'A,B\r\n"x, y",Rp 1.000');
  });
});

describe('penyimpanan Fase 2', () => {
  it('shift, uang masuk/keluar, retur, dan opname tersimpan dan dimuat ulang', async () => {
    const c = await setup();
    const shift = await openShift(c.store, { openingCash: 1000 }, NOW);
    await addCashMove(c.store, { type: 'in', amount: 500, note: 'x' }, NOW);
    const t = await checkout(c.store, { lines: [line(c.mie.id, 2)], payments: [cash(7000)] }, at(1));
    await returnItems(c.store, { txId: t.id, lines: [{ itemIndex: 0, unitQty: 1 }], refundMethod: 'cash', restock: true, reason: 'x' }, at(2));
    await startOpname(c.store, { scope: 'Semua' }, at(3));
    const reopened = new Store(c.persistence);
    await reopened.init();
    const s = reopened.getState();
    assert.equal(s.openShift?.id, shift.id);
    assert.equal(s.cashMoves.length, 1);
    assert.equal(s.returns.length, 1);
    assert.equal(s.returnsByTx.get(t.id)?.length, 1);
    assert.equal(s.opnames[0].status, 'draft');
    assert.equal(s.txById.get(t.id)?.shiftId, shift.id);
  });

  it('commit yang gagal tidak meninggalkan retur setengah jadi', async () => {
    const c = await setup();
    const t = await checkout(c.store, { lines: [line(c.mie.id, 2)], payments: [cash(7000)] }, NOW);
    c.persistence.failNextCommit = true;
    await assert.rejects(returnItems(c.store, { txId: t.id, lines: [{ itemIndex: 0, unitQty: 1 }], refundMethod: 'cash', restock: true, reason: 'x' }, at(1)), /Penyimpanan gagal/);
    assert.equal(c.store.getState().returns.length, 0);
    assert.equal(stockOf(c, c.mie.id), 198);
  });
});

describe('tahan (hold)', () => {
  it('menahan keranjang tanpa memotong stok atau mencatat penjualan, lalu melanjutkan', async () => {
    const c = await setup();
    const h = await holdCart(c.store, { label: ' Bu Ani ', lines: [{ productId: c.mie.id, unitName: 'pcs', unitQty: 3, note: 'tanpa kantong' }], discount: { type: 'nominal', value: 500 } }, NOW);
    assert.equal(h.label, 'Bu Ani');
    assert.equal(stockOf(c, c.mie.id), 200);
    assert.equal(c.store.getState().transactions.length, 0);
    assert.equal(c.store.getState().holds.length, 1);
    const back = await resumeHold(c.store, h.id, undefined, at(5));
    assert.equal(back.lines[0].unitQty, 3);
    assert.equal(back.lines[0].note, 'tanpa kantong');
    assert.deepEqual(back.discount, { type: 'nominal', value: 500 });
    assert.equal(c.store.getState().holds.length, 0);
    await assert.rejects(resumeHold(c.store, h.id), /tidak ditemukan/);
  });

  it('melanjutkan saat keranjang masih terisi: keranjang sekarang ikut ditahan (tukar), tidak ada yang hilang', async () => {
    const c = await setup();
    const a = await holdCart(c.store, { label: 'A', lines: [{ productId: c.mie.id, unitName: 'pcs', unitQty: 1 }] }, NOW);
    const back = await resumeHold(c.store, a.id, { label: 'B', lines: [{ productId: c.air.id, unitName: 'botol', unitQty: 2 }] }, at(1));
    assert.equal(back.label, 'A');
    const holds = c.store.getState().holds;
    assert.equal(holds.length, 1);
    assert.equal(holds[0].label, 'B');
    assert.equal(holds[0].lines[0].unitQty, 2);
  });

  it('keranjang kosong ditolak, batas jumlah, hapus, dan tersimpan permanen', async () => {
    const c = await setup();
    await assert.rejects(holdCart(c.store, { lines: [] }, NOW), /masih kosong/);
    for (let i = 0; i < MAX_HOLDS; i++) await holdCart(c.store, { lines: [{ productId: c.mie.id, unitName: 'pcs', unitQty: 1 }] }, at(i));
    await assert.rejects(holdCart(c.store, { lines: [{ productId: c.mie.id, unitName: 'pcs', unitQty: 1 }] }, NOW), /Maksimal 10/);
    const first = c.store.getState().holds[0];
    assert.equal(first.createdAt, NOW.toISOString(), 'yang paling lama di depan');
    await deleteHold(c.store, first.id);
    assert.equal(c.store.getState().holds.length, MAX_HOLDS - 1);
    const reopened = new Store(c.persistence);
    await reopened.init();
    assert.equal(reopened.getState().holds.length, MAX_HOLDS - 1);
    await assert.rejects(deleteHold(c.store, first.id), /tidak ditemukan/);
  });
});
