import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { neutralizeFormula, toCsv } from '../src/core/export';

describe('CSV: teks yang bisa dibaca sebagai rumus dinetralkan', () => {
  it('teks berawalan = + - @ tab diberi apostrof, angka dan teks biasa tidak berubah', () => {
    assert.equal(neutralizeFormula('=HYPERLINK("http://x","klik")'), `'=HYPERLINK("http://x","klik")`);
    assert.equal(neutralizeFormula('+62812'), `'+62812`);
    assert.equal(neutralizeFormula('-1+2'), `'-1+2`);
    assert.equal(neutralizeFormula('@SUM(A1)'), `'@SUM(A1)`);
    assert.equal(neutralizeFormula('\tx'), `'\tx`);
    assert.equal(neutralizeFormula('Indomie'), 'Indomie');
    assert.equal(neutralizeFormula('-'), '-');
    assert.equal(neutralizeFormula('-5'), '-5');
    assert.equal(neutralizeFormula(-5), '-5');
    assert.equal(neutralizeFormula(12000), '12000');
  });
  it('toCsv menerapkannya dan tetap mengutip koma dan tanda kutip', () => {
    assert.equal(toCsv([['=1+1', 'a,b', -3]]), `'=1+1,"a,b",-3`);
    assert.equal(toCsv([['say "hi"']]), '"say ""hi"""');
  });
});
