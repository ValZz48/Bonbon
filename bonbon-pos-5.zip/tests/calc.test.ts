import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import {
  calcTotals,
  changeOf,
  costPerBase,
  discountAmount,
  isDecimalUnit,
  lineAmounts,
  nextCost,
  roundQty,
  roundToStep,
  stockStatus,
  suggestedPurchase,
  toBaseQty,
  validatePayments,
} from '../src/core/calc';
import { addDaysKey, dateKeyOf, formatCompactRupiah, formatQty, formatRupiah } from '../src/core/format';
import type { Payment } from '../src/core/types';

const OFF = { taxEnabled: false, taxPercent: 11, roundingMode: 'none' as const };

describe('perhitungan total transaksi', () => {
  it('menjumlahkan item dengan harga x jumlah', () => {
    const t = calcTotals(
      [
        { unitQty: 2, unitPrice: 3500 },
        { unitQty: 1, unitPrice: 15000 },
      ],
      undefined,
      OFF,
    );
    assert.equal(t.subtotal, 22000);
    assert.equal(t.total, 22000);
    assert.equal(t.tax, 0);
    assert.equal(t.rounding, 0);
  });

  it('diskon item nominal dan persen', () => {
    assert.deepEqual(lineAmounts({ unitQty: 2, unitPrice: 10000, discount: { type: 'nominal', value: 3000 } }), {
      gross: 20000,
      discount: 3000,
      net: 17000,
    });
    assert.deepEqual(lineAmounts({ unitQty: 2, unitPrice: 10000, discount: { type: 'percent', value: 15 } }), {
      gross: 20000,
      discount: 3000,
      net: 17000,
    });
  });

  it('diskon tidak pernah membuat total negatif', () => {
    assert.equal(discountAmount(5000, { type: 'nominal', value: 9000 }), 5000);
    assert.equal(discountAmount(5000, { type: 'percent', value: 250 }), 5000);
    assert.equal(discountAmount(5000, { type: 'nominal', value: -100 }), 0);
    const t = calcTotals([{ unitQty: 1, unitPrice: 5000 }], { type: 'nominal', value: 99999 }, { ...OFF, taxEnabled: true });
    assert.equal(t.total, 0);
    assert.equal(t.tax, 0);
  });

  it('urutan: subtotal, diskon, pajak, pembulatan', () => {
    // 3 x 12.500 = 37.500; diskon 10% = 3.750 -> 33.750; PPN 11% = 3.712,5 -> 3.713 ; 37.463 -> bulat 500 = 37.500
    const t = calcTotals(
      [{ unitQty: 3, unitPrice: 12500 }],
      { type: 'percent', value: 10 },
      { taxEnabled: true, taxPercent: 11, roundingMode: '500' },
    );
    assert.equal(t.subtotal, 37500);
    assert.equal(t.discount, 3750);
    assert.equal(t.tax, 3713);
    assert.equal(t.rounding, 37500 - 37463);
    assert.equal(t.total, 37500);
  });

  it('pajak mati berarti tax = 0', () => {
    const t = calcTotals([{ unitQty: 1, unitPrice: 10000 }], undefined, { ...OFF, taxPercent: 11 });
    assert.equal(t.tax, 0);
  });
});

describe('pembulatan', () => {
  it('tanpa pembulatan', () => assert.equal(roundToStep(12349, 'none'), 12349));
  it('ke 100 terdekat', () => {
    assert.equal(roundToStep(12349, '100'), 12300);
    assert.equal(roundToStep(12350, '100'), 12400);
    assert.equal(roundToStep(12351, '100'), 12400);
  });
  it('ke 500 terdekat', () => {
    assert.equal(roundToStep(12249, '500'), 12000);
    assert.equal(roundToStep(12250, '500'), 12500);
    assert.equal(roundToStep(12749, '500'), 12500);
    assert.equal(roundToStep(12750, '500'), 13000);
  });
  it('selisih pembulatan tercatat bertanda', () => {
    const up = calcTotals([{ unitQty: 1, unitPrice: 12350 }], undefined, { ...OFF, roundingMode: '100' });
    assert.equal(up.rounding, 50);
    assert.equal(up.total, 12400);
    const down = calcTotals([{ unitQty: 1, unitPrice: 12349 }], undefined, { ...OFF, roundingMode: '100' });
    assert.equal(down.rounding, -49);
    assert.equal(down.total, 12300);
  });
});

describe('konversi satuan', () => {
  it('dus ke satuan dasar', () => {
    assert.equal(toBaseQty(2, 24), 48);
    assert.equal(toBaseQty(1, 12), 12);
  });
  it('kg memakai 3 desimal tanpa error floating point', () => {
    assert.equal(roundQty(0.1 + 0.2), 0.3);
    assert.equal(toBaseQty(1.5, 1), 1.5);
    assert.equal(roundQty(2.0004), 2);
    assert.equal(roundQty(2.0006), 2.001);
  });
  it('HPP per satuan dasar dari harga beli per dus', () => {
    assert.equal(costPerBase(48000, 24), 2000);
    assert.equal(costPerBase(100, 3), 33);
  });
  it('satuan berat boleh desimal, satuan hitung tidak', () => {
    assert.ok(isDecimalUnit('kg'));
    assert.ok(isDecimalUnit('Liter'));
    assert.ok(!isDecimalUnit('pcs'));
    assert.ok(!isDecimalUnit('dus'));
  });
  it('HPP rata-rata tertimbang dan harga terakhir', () => {
    assert.equal(nextCost('average', 10, 1000, 10, 2000), 1500);
    assert.equal(nextCost('average', 0, 999, 5, 2000), 2000);
    assert.equal(nextCost('average', -3, 999, 5, 2000), 2000);
    assert.equal(nextCost('last', 10, 1000, 10, 2000), 2000);
  });
});

describe('status peringatan stok', () => {
  it('Aman, Menipis, Habis', () => {
    assert.equal(stockStatus(21, 20), 'ok');
    assert.equal(stockStatus(20, 20), 'low');
    assert.equal(stockStatus(1, 20), 'low');
    assert.equal(stockStatus(0, 20), 'out');
    assert.equal(stockStatus(-2, 20), 'out');
    assert.equal(stockStatus(0.5, 0), 'ok');
  });
  it('saran beli = (min x 2) - stok', () => {
    assert.equal(suggestedPurchase(15, 20), 25);
    assert.equal(suggestedPurchase(0, 24), 48);
    assert.equal(suggestedPurchase(5.5, 6), 6.5);
    assert.equal(suggestedPurchase(0, 0), 1);
  });
});

describe('validasi pembayaran', () => {
  const cash = (amount: number, tendered?: number): Payment => ({ method: 'cash', amount, tendered, status: 'success' });
  const qris = (amount: number): Payment => ({ method: 'qris', amount, status: 'success' });

  it('harus pas dengan total', () => {
    assert.equal(validatePayments(50000, [cash(50000, 100000)]), null);
    assert.match(validatePayments(50000, [cash(30000)]) ?? '', /kurang/);
    assert.match(validatePayments(50000, [cash(30000), qris(30000)]) ?? '', /lebih/);
  });
  it('split payment tunai + QRIS', () => {
    assert.equal(validatePayments(50000, [cash(30000, 50000), qris(20000)]), null);
  });
  it('uang diterima tidak boleh kurang dari jumlah tunai', () => {
    assert.match(validatePayments(50000, [cash(50000, 20000)]) ?? '', /kurang/);
  });
  it('kasbon wajib punya pelanggan, hanya satu kali, dan tidak boleh menunggu konfirmasi', () => {
    const kasbon = (amount: number, extra: object = {}) => ({ method: 'kasbon' as const, amount, status: 'success' as const, ...extra });
    assert.match(validatePayments(1000, [kasbon(1000)]) ?? '', /Pilih pelanggan/);
    assert.equal(validatePayments(1000, [kasbon(1000, { customerId: 'c1' })]), null);
    assert.match(validatePayments(2000, [kasbon(1000, { customerId: 'c1' }), kasbon(1000, { customerId: 'c1' })]) ?? '', /satu kali/);
    assert.match(validatePayments(1000, [kasbon(1000, { customerId: 'c1', status: 'pending' })]) ?? '', /menunggu/);
  });
  it('tunai ditambah kasbon harus pas dengan total', () => {
    const k = { method: 'kasbon' as const, amount: 4000, status: 'success' as const, customerId: 'c1' };
    assert.equal(validatePayments(10000, [cash(6000, 10000), k]), null);
    assert.match(validatePayments(10000, [cash(5000), k]) ?? '', /kurang/);
  });
  it('total 0 tidak butuh pembayaran', () => {
    assert.equal(validatePayments(0, []), null);
  });
  it('kembalian hanya dari tunai', () => {
    assert.equal(changeOf([cash(30000, 50000), qris(20000)]), 20000);
    assert.equal(changeOf([qris(20000)]), 0);
  });
});

describe('format & zona waktu WIB', () => {
  it('rupiah', () => {
    assert.equal(formatRupiah(15000), 'Rp 15.000');
    assert.equal(formatRupiah(1234567), 'Rp 1.234.567');
    assert.equal(formatRupiah(0), 'Rp 0');
    assert.equal(formatRupiah(-2500), '-Rp 2.500');
  });
  it('qty & ringkas', () => {
    assert.equal(formatQty(1.5), '1,5');
    assert.equal(formatQty(1234), '1.234');
    assert.equal(formatCompactRupiah(1250000), '1,25 jt');
    assert.equal(formatCompactRupiah(480000), '480 rb');
    assert.equal(formatCompactRupiah(162750), '162,8 rb');
    assert.equal(formatCompactRupiah(950), '950');
  });
  it('tanggal berganti pukul 00.00 WIB (17.00 UTC)', () => {
    assert.equal(dateKeyOf(new Date('2026-10-19T16:59:00Z')), '2026-10-19');
    assert.equal(dateKeyOf(new Date('2026-10-19T17:00:00Z')), '2026-10-20');
    assert.equal(addDaysKey('2026-10-31', 1), '2026-11-01');
    assert.equal(addDaysKey('2026-10-19', -6), '2026-10-13');
  });
});
