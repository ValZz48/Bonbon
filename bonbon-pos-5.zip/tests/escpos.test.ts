import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { bytesToBase64, chunkBytes, encodeEscPos, rawbtUrl, toAscii } from '../src/core/escpos';
import { receiptLayout, receiptText } from '../src/core/export';
import { MemoryPersistence } from '../src/core/persistence';
import { checkout, receiveStock, saveCustomer, saveProduct, saveSettings } from '../src/core/services';
import { Store } from '../src/core/store';

const NOW = new Date('2026-10-19T05:00:00Z');

async function receipt(paperWidth: 58 | 80 = 58, storeName = 'Warung Manop') {
  const store = new Store(new MemoryPersistence());
  await store.init();
  await saveSettings(store, { storeName, address: 'Jl. Merdeka No. 10, Kota Contoh', receiptFooter: 'Terima kasih!', paperWidth });
  const p = await saveProduct(store, { name: 'Indomie Goreng Spesial Pedas', category: 'Mi', baseUnit: 'pcs', costPrice: 2800, sellPrice: 3500, minStock: 5 }, NOW);
  await receiveStock(store, { productId: p.id, unitQty: 200, unitCost: 2800 }, NOW);
  const budi = await saveCustomer(store, { name: 'Pak Budi' }, NOW);
  const t = await checkout(
    store,
    { lines: [{ productId: p.id, unitName: 'pcs', unitQty: 20 }], payments: [{ method: 'cash', amount: 20000, tendered: 20000 }, { method: 'kasbon', amount: 50000, customerId: budi.id }] },
    NOW,
  );
  return { tx: t, settings: store.getState().settings, debtAfter: store.getState().debtEntryByTx.get(t.id)?.balanceAfter };
}

describe('tata letak struk', () => {
  it('semua baris muat di lebar kertas: 32 karakter untuk 58 mm, 48 untuk 80 mm', async () => {
    for (const [paper, width] of [[58, 32], [80, 48]] as const) {
      const { tx, settings, debtAfter } = await receipt(paper);
      const layout = receiptLayout(tx, settings, { debtAfter });
      assert.equal(layout.width, width);
      for (const line of layout.lines) assert.ok(line.length <= width, `"${line}" lebih dari ${width}`);
    }
  });

  it('receiptText sama persis dengan baris tata letak, dan yang tebal adalah nama toko, TOTAL, dan total kasbon', async () => {
    const { tx, settings, debtAfter } = await receipt(58);
    const layout = receiptLayout(tx, settings, { debtAfter });
    assert.equal(receiptText(tx, settings, { debtAfter }), layout.lines.join('\n'));
    const boldText = layout.bold.map((i) => layout.lines[i].trim());
    assert.deepEqual(boldText.map((t) => t.split(/\s{2,}/)[0]), ['Warung Manop', 'TOTAL', 'Total kasbon']);
  });
});

describe('ESC/POS', () => {
  it('toAscii membuang aksen dan mengganti simbol yang tidak ada di tabel karakter printer', () => {
    assert.equal(toAscii('Café Crème – 2×'), 'Cafe Creme - 2x');
    assert.equal(toAscii('Rp 5.000 • “ok”'), 'Rp 5.000 * "ok"');
    assert.equal(toAscii('日本'), '??');
    assert.equal(toAscii('a\tb'), 'a b');
  });

  it('diawali reset printer, memuat teks per baris, menyalakan dan mematikan tebal, lalu mengumpan kertas', async () => {
    const { tx, settings, debtAfter } = await receipt(58);
    const layout = receiptLayout(tx, settings, { debtAfter });
    const bytes = encodeEscPos(layout);
    assert.deepEqual([...bytes.slice(0, 2)], [0x1b, 0x40]);
    const text = Buffer.from(bytes).toString('latin1');
    assert.ok(text.includes('Warung Manop'));
    assert.ok(text.includes('TOTAL'));
    assert.equal(text.split('\n').length - 1, layout.lines.length, 'satu LF per baris');
    // tebal: ESC E 1 sebelum nama toko, ESC E 0 sesudahnya, dan tidak ada yang tertinggal menyala di akhir
    const on = [...bytes].reduce((n, b, i, a) => n + (a[i - 2] === 0x1b && a[i - 1] === 0x45 && b === 1 ? 1 : 0), 0);
    const off = [...bytes].reduce((n, b, i, a) => n + (a[i - 2] === 0x1b && a[i - 1] === 0x45 && b === 0 ? 1 : 0), 0);
    assert.equal(on, 3);
    assert.equal(off, 3);
    assert.deepEqual([...bytes.slice(-3)], [0x1b, 0x64, 4], 'ESC d 4: umpan 4 baris');
    for (const b of bytes) assert.ok(b < 0x80, 'hanya ASCII');
  });

  it('printer dengan pemotong menerima perintah potong, bukan umpan biasa', async () => {
    const { tx, settings } = await receipt(80);
    const bytes = encodeEscPos(receiptLayout(tx, settings), { cut: true });
    assert.deepEqual([...bytes.slice(-4)], [0x1d, 0x56, 0x42, 0x00]);
  });

  it('nama toko dengan simbol Unicode tetap tercetak sebagai ASCII yang aman', async () => {
    const { tx, settings } = await receipt(58, 'Warung “Manop” – Ibu Yéni');
    const text = Buffer.from(encodeEscPos(receiptLayout(tx, settings))).toString('latin1');
    assert.ok(text.includes('Warung "Manop" - Ibu Yeni'));
  });

  it('chunkBytes memecah tanpa kehilangan satu byte pun', () => {
    const data = Uint8Array.from({ length: 53 }, (_, i) => i);
    const parts = chunkBytes(data, 20);
    assert.deepEqual(parts.map((p) => p.length), [20, 20, 13]);
    assert.deepEqual([...Buffer.concat(parts)], [...data]);
    assert.deepEqual(chunkBytes(new Uint8Array(0), 20), []);
  });

  it('tautan RawBT berisi base64 dari byte yang sama', () => {
    const data = Uint8Array.from([0x1b, 0x40, 0x41, 0x0a]);
    assert.equal(bytesToBase64(data), 'G0BBCg==');
    const url = rawbtUrl(data);
    assert.ok(url.startsWith('intent:base64,G0BBCg==#Intent;scheme=rawbt;'));
    assert.ok(url.includes('package=ru.a402d.rawbtprinter'));
    assert.ok(url.endsWith(';end;'));
  });
});
