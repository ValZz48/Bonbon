// Build script: esbuild (TypeScript/React bundle) + Tailwind v4 compile API -> single-file HTML.
//
//   node scripts/build.mjs            -> public/index.html (full page) and dist/artifact.html (page fragment)
//   node scripts/build.mjs --serve    -> build, serve public/ on http://localhost:5173, rebuild on change
//
// Flags compiled into the bundle:
//   __ARTIFACT__  true in the sandboxed artifact build, where window.print() and file downloads are blocked.

import { createServer } from 'node:http';
import { createRequire } from 'node:module';
import { mkdirSync, readFileSync, readdirSync, statSync, watch, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { build as esbuild, transform } from 'esbuild';
import { compile } from 'tailwindcss';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(join(root, 'package.json'));
const TITLE = 'Bonbon';
// favicon: the candy-b, white on an indigo tile (the traced path lives in src/app/brandPaths.ts)
function faviconHref() {
  const src = readFileSync(join(root, 'src/app/brandPaths.ts'), 'utf8');
  const d = src.match(/SYMBOL_D =\s*'([^']+)'/)[1];
  const w = Number(src.match(/SYMBOL_W = ([\d.]+)/)[1]);
  const h = Number(src.match(/SYMBOL_H = ([\d.]+)/)[1]);
  const k = 40 / w;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#4540d8"/><path transform="translate(12 ${((64 - h * k) / 2).toFixed(2)}) scale(${k.toFixed(4)})" fill="#fff" fill-rule="evenodd" d="${d}"/></svg>`;
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}
const FONTS =
  'https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap';

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) walk(p, out);
    else if (/\.(tsx?|css)$/.test(name)) out.push(p);
  }
  return out;
}

async function bundleJs(artifact) {
  const result = await esbuild({
    entryPoints: [join(root, 'src/main.tsx')],
    bundle: true,
    write: false,
    format: 'iife',
    target: 'es2020',
    minify: true,
    jsx: 'automatic',
    legalComments: 'none',
    define: { 'process.env.NODE_ENV': '"production"', __ARTIFACT__: String(artifact) },
    logLevel: 'warning',
  });
  return result.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
}

async function buildCss() {
  const source = readFileSync(join(root, 'src/styles.css'), 'utf8');
  const compiler = await compile(source, {
    base: root,
    loadStylesheet: async (id, base) => {
      const file = id.endsWith('.css') ? id : `${id}.css`;
      const path = file.startsWith('.') ? resolve(base, file) : require.resolve(file);
      return { path, base: dirname(path), content: readFileSync(path, 'utf8') };
    },
  });
  // Tailwind only needs the tokens that could be class names; invalid ones are ignored.
  // Do NOT split on commas: arbitrary values such as grid-cols-[72px_minmax(0,1fr)] contain them.
  const candidates = new Set();
  for (const file of walk(join(root, 'src')).filter((f) => f.endsWith('.tsx') || f.endsWith('.ts'))) {
    for (const token of readFileSync(file, 'utf8').split(/[\s"'`{}<>;|]+/)) {
      if (!token) continue;
      candidates.add(token);
      // a class glued to code punctuation, e.g. `cx(foo,'a')` or `x?'a':'b'`
      for (const part of token.split(/,(?![^[]*\])/)) if (part && part !== token) candidates.add(part);
    }
  }
  const css = compiler.build([...candidates]);
  return (await transform(css, { loader: 'css', minify: true })).code;
}

// Nothing in the app talks to a server, so the page may not either: scripts and data stay on this device even if some
// piece of text were ever mistaken for code. (Fonts are the only outside request: Google Fonts, styles and files only.)
export const CSP = "default-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com data:; img-src 'self' data: blob:; connect-src 'self'; base-uri 'none'; form-action 'none'; object-src 'none'; frame-src 'none'";

export async function buildAll() {
  const started = Date.now();
  const [css, jsFull, jsArtifact] = await Promise.all([buildCss(), bundleJs(false), bundleJs(true)]);
  mkdirSync(join(root, 'dist'), { recursive: true });

  const head = `<title>${TITLE}</title>`;
  const body = `<div id="root"></div>`;

  const page = `<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#4540d8">
<meta http-equiv="Content-Security-Policy" content="${CSP}">
<meta name="referrer" content="no-referrer">
<link rel="icon" href="${faviconHref()}">
${head}
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="${FONTS}">
<style>${css}</style>
</head>
<body>
${body}
<script>${jsFull}</script>
</body>
</html>
`;

  // Artifact fragment: the host wraps it in <!doctype html><head><body>.
  const fragment = `${head}
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="stylesheet" href="${FONTS}">
<style>${css}</style>
${body}
<script>${jsArtifact}</script>
`;

  // the web app goes to public/ (the folder Vercel and most static hosts serve without any config)
  mkdirSync(join(root, 'public'), { recursive: true });
  writeFileSync(join(root, 'public/index.html'), page);
  // the artifact fragment is only for publishing as a Claude artifact; don't ship it with a web deploy
  if (!process.env.VERCEL) {
    mkdirSync(join(root, 'dist'), { recursive: true });
    writeFileSync(join(root, 'dist/artifact.html'), fragment);
  }
  const kb = (s) => (Buffer.byteLength(s) / 1024).toFixed(0);
  console.log(`built in ${Date.now() - started} ms: public/index.html ${kb(page)} KB${process.env.VERCEL ? '' : `, dist/artifact.html ${kb(fragment)} KB`} (css ${kb(css)} KB)`);
}

async function serve() {
  const port = Number(process.env.PORT) || 5173;
  createServer((req, res) => {
    try {
      const html = readFileSync(join(root, 'public/index.html'));
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
      res.end(html);
    } catch {
      res.writeHead(500).end('build belum selesai');
    }
  }).listen(port, () => console.log(`Bonbon: http://localhost:${port}  (perubahan kode otomatis di-build ulang, muat ulang halaman)`));
  let timer;
  watch(join(root, 'src'), { recursive: true }, () => {
    clearTimeout(timer);
    timer = setTimeout(() => buildAll().catch((e) => console.error(e.message)), 150);
  });
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  await buildAll();
  if (process.argv.includes('--serve')) await serve();
}
