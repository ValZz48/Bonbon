# Bonbon (aplikasi kasir)

*Jualan Jalan, Bonbon Andalan!*

Aplikasi kasir berbasis web untuk warung atau toko: transaksi cepat (tunai dan non-tunai), stok yang selalu tercatat, peringatan sebelum barang habis, **catatan kasbon (utang) pelanggan**, **struk yang bisa dicetak atau dikirim lewat WhatsApp**, **scan barcode dengan kamera HP**, serta **kas laci, retur, opname stok, laporan, dan tahan keranjang**. Semua data tersimpan di peramban (IndexedDB), jadi tetap jalan tanpa internet.

Cara tercepat mencoba: buka `public/index.html` di Chrome, Edge, atau Safari. Tidak perlu instal apa pun. Saat pertama dibuka, aplikasi mengisi produk contoh, pelanggan contoh dengan kasbon, dan transaksi seminggu supaya langsung ada isinya (hapus lewat Pengaturan > Hapus semua data).

## Tampilan

Desain "Bonbon Clean": biru dan putih, minimalis dan profesional, mengikuti logo Bonbon (`src/app/brand.tsx`, jalur vektor hasil trace di `src/app/brandPaths.ts`). Warna utama indigo `#4540D8` (versi lebih terang `#928EFF` di tema gelap) di atas latar putih kebiruan. Kartu bersudut membulat dengan bayangan lembut, huruf Plus Jakarta Sans, satu blok biru bergradasi (hero) sebagai pusat perhatian di Beranda dan Kas Laci, badge inisial berwarna per kategori di daftar produk, ikon metode bayar di Riwayat, dan gerakan singkat untuk setiap tindakan (pindah layar, tambah ke keranjang, buka dialog, total berubah). Semua gerakan mati otomatis bila HP diatur "kurangi animasi". Daftar panjang (pilih produk di Stok, pilih pelanggan, riwayat) selalu bisa digulir dan tidak dipotong. Tema terang dan gelap bisa dipilih di Pengaturan (Otomatis mengikuti HP). Warna dan kontras (AA) diperiksa otomatis di tema terang dan gelap.

## Menjalankan

```bash
npm install
npm run dev        # build lalu serve di http://localhost:5173 (muat ulang halaman setelah mengubah kode)
npm run build      # hasil: public/index.html (satu file, siap dibuka atau di-hosting)
npm test           # 176 unit test
npm run typecheck  # pengecekan tipe untuk src/core dan tests
npm run e2e        # uji alur lengkap di Chromium (butuh: npx playwright install chromium)
```

## Deploy ke Vercel (tanpa `vercel.json`)

Tidak perlu pengaturan khusus. Unggah proyek ini ke GitHub (atau impor zip-nya), pilih Framework Preset **Other**, lalu Deploy. Vercel menjalankan `npm run build` dan membaca folder `public`, yang memang dibuat oleh build ini. Situs ini statis, jadi cocok juga di Netlify atau Cloudflare Pages dengan Output Directory `public`.

Jika build gagal karena alasan apa pun, `public/index.html` sudah ikut di dalam zip dalam keadaan jadi. Kosongkan Build Command, atur Output Directory ke `public`, dan deploy ulang.

Kamera hanya bisa dipakai lewat alamat **https** atau `localhost`. Vercel otomatis memakai https.

## Fitur

- **Kasir**: grid produk, keranjang, diskon item dan transaksi, PPN, pembulatan, F2 untuk bayar dan Esc untuk batal. Di HP, keranjang muncul sebagai lembar dari bawah: daftar barang bisa digeser dan tombol Bayar selalu terlihat.
- **Scan barcode** (tombol Scan di Kasir dan di form Produk): arahkan kamera, kode terbaca otomatis dan produk masuk keranjang. Scan beberapa barang berturut-turut tanpa menutup kamera. Ada tombol senter (jika HP mendukung), bunyi dan getar saat terbaca, serta ketik kode manual bila kamera tidak bisa dipakai. Scanner USB juga tetap bisa: ketik atau scan ke kolom cari lalu Enter.
- **Pembayaran**: tunai dengan kembalian, QRIS, transfer, e-wallet, debit, kredit, pembayaran terpisah (split), status menunggu konfirmasi, dan **Kasbon**.
- **Kasbon**: daftar pelanggan dengan buku utang per orang. Catat kasbon dari kasir (penuh atau sebagian, sisanya dibayar tunai), terima cicilan, catat utang lama secara manual, hapus utang (hapus buku, alasan wajib diisi), atur batas kasbon per pelanggan, dan lihat sejak kapan seseorang berutang. Membatalkan (void) transaksi kasbon ikut menurunkan utang. Kartu ringkasan utang ada di Beranda.
- **Struk**: 58 mm dan 80 mm, **cetak ke printer struk kecil** (Bluetooth langsung, aplikasi RawBT, atau dialog cetak peramban), salin teks, dan **kirim lewat WhatsApp** (nomor pelanggan terisi otomatis bila ada; pesan bisa diubah sebelum dikirim). Bukti cicilan kasbon dan pengingat utang juga bisa dikirim lewat WhatsApp.
- **Stok**: stok masuk (HPP rata-rata atau pembelian terakhir), penyesuaian dengan alasan wajib, log pergerakan, satuan konversi (dus ke pcs), peringatan Aman / Menipis / Habis, dan halaman Perlu Belanja (salin teks dan CSV).
- **Retur** (Riwayat > buka transaksi > Retur): sebagian atau seluruh barang, uang kembali tunai, non-tunai, atau memotong kasbon pelanggan. Pilih apakah barang masuk lagi ke stok (barang rusak atau kadaluarsa tidak). Jumlah sebagian dibagi adil, termasuk diskon, pajak, dan pembulatan, sehingga retur bertahap selalu pas dengan nilai transaksi aslinya. Omzet dan laba pada hari retur dikurangi. Transaksi yang sudah diretur tidak bisa di-void.
- **Kas Laci** (opsional): buka dengan uang receh di laci, catat uang masuk dan keluar (mis. beli galon), lalu tutup dengan menghitung uang. Aplikasi menunjukkan uang tunai yang seharusnya ada (modal awal, penjualan tunai, cicilan kasbon tunai, void dan retur tunai, uang masuk dan keluar), selisihnya, rekap per metode bayar, dan riwayat. Bisa disalin sebagai teks. Pengaturan "Wajib buka kas sebelum berjualan" bersifat opsional (mati secara bawaan).
- **Opname stok** (Stok > Opname): hitung semua produk atau satu kategori. Stok baru berubah saat Selesai, dan hanya selisihnya yang diterapkan sehingga penjualan saat menghitung tidak hilang. Ada kemajuan, filter Belum/Selisih, nilai selisih menurut harga modal, dan riwayat.
- **Laporan**: periode (hari ini, kemarin, minggu ini, 7 hari, bulan ini, bulan lalu, atau tanggal bebas) dengan tab Ringkasan, Produk (plus kategori), Pembayaran, Stok (nilai stok), dan Kasbon. Salin atau unduh CSV, dan Cetak / Simpan PDF (A4) di versi web.
- **Tahan keranjang** (Kasir): simpan keranjang saat melayani pelanggan lain, lanjutkan kapan saja. Stok belum berkurang dan belum tercatat sebagai penjualan. Menukar ke keranjang lain otomatis menahan keranjang yang sedang dibuka. Tersimpan permanen, maksimal 10.
- **Cadangan data** (Pengaturan > Cadangan data): unduh seluruh data sebagai satu berkas `.json`, bagikan (di HP yang mendukung), atau salin sebagai teks. **Pulihkan** dari berkas atau teks tempelan: isinya diperiksa dulu, ditampilkan ringkasannya (jumlah produk, transaksi, dst.), dan data baru diganti hanya setelah konfirmasi, dalam satu langkah atomik (kalau gagal, data lama tidak berubah). Berkas rusak, terpotong, atau dari versi aplikasi yang lebih baru ditolak dengan alasan yang jelas. Di Beranda muncul pengingat bila data belum pernah atau sudah 7 hari lebih tidak dicadangkan (tidak muncul untuk data contoh).
- **Riwayat** dengan void, **Beranda** dengan ringkasan dan grafik, **Pengaturan** (toko, pajak, stok, struk, metode bayar, kasbon).

### Aplikasi Android (APK)

Bundel web yang sama dibungkus Capacitor menjadi APK. Langkah dari HP ada di `PANDUAN-APK.md`: unggah satu zip ke repo GitHub pribadi, workflow `.github/workflows/android.yml` membangun APK, dan hasilnya diunduh dari Releases. Paket Capacitor dipasang hanya oleh workflow (tidak ada di `package.json`, jadi build Vercel tidak berubah).

- `capacitor.config.json`: nama, ID aplikasi (`id.warungmanop.kasir`), folder web.
- `scripts/android-patch.mjs`: dijalankan setelah `cap add android`; menambah izin (notifikasi, kamera), target SDK 34 (WebView tidak tertutup status bar), nomor versi dari nomor build, kunci tanda tangan rilis dari GitHub Secrets (tidak disimpan di repo; kunci yang tetap membuat APK baru bisa dipasang di atas yang lama tanpa kehilangan data), manifest tanpa backup otomatis dan tanpa lalu lintas HTTP polos, serta ikon aplikasi, ikon notifikasi, layar pembuka, dan warna tema Bonbon (gambar sudah jadi di `scripts/android-icons/`; dibuat ulang dengan `node scripts/make-icons.mjs` bila logo berubah).
- **Notifikasi stok** (Pengaturan, hanya di APK): satu pengingat harian pada jam pilihan berisi jumlah dan nama produk yang habis atau menipis. Stok hanya berubah di dalam aplikasi, sehingga isi pengingat selalu sama dengan keadaan terakhir; dijadwalkan ulang setiap stok berubah dan dihapus bila semua stok aman. Di semua versi (web dan APK), toast muncul saat sebuah produk baru menjadi menipis atau habis.
- Di dalam APK: cadangan dan CSV dibagikan lewat menu bagikan Android, cetak struk lewat RawBT (skema `rawbt:`), dan tombol cetak peramban disembunyikan karena WebView tidak punya `window.print` dan Web Bluetooth.
- Aplikasi memakai objek `window.Capacitor` yang disuntikkan Android (`src/app/runtime.ts`), bukan impor paket, sehingga bundel web tidak berubah ukurannya.

### Catatan WhatsApp

Tombol WhatsApp membuka WhatsApp (aplikasi di HP, atau WhatsApp Web di komputer) dengan pesan yang sudah terisi, lalu pengguna menekan kirim sendiri. Tidak ada WhatsApp Business API, jadi tidak ada biaya dan tidak ada server. Akibatnya, aplikasi tidak bisa tahu apakah pesan benar-benar terkirim. Di pratinjau yang di-embed (misalnya di dalam Claude) tautan WhatsApp bisa diblokir; pakai tombol Salin pesan di sana, atau buka aplikasi yang sudah di-deploy.

### Catatan cetak struk

Tombol **Cetak** di struk membuka dialog dengan tiga jalur. Pilih lebar kertas printer dulu (58 mm atau 80 mm).

- **Printer struk Bluetooth** (Chrome di Android, atau Chrome/Edge di komputer): nyalakan printer, tekan tombol, pilih namanya. Aplikasi mengirim perintah ESC/POS langsung lewat Bluetooth LE, jadi tanpa aplikasi tambahan. Printer yang sudah dipilih diingat selama halaman terbuka. Tidak semua printer murah mendukung Bluetooth LE (sebagian hanya Bluetooth klasik); bila tidak muncul atau gagal, pakai RawBT.
- **Aplikasi RawBT** (Android): pasang RawBT (gratis di Play Store), pasangkan printer Bluetooth atau USB di aplikasi itu satu kali, lalu tekan Cetak lewat RawBT. Cocok untuk printer klasik.
- **Dialog cetak peramban**: untuk printer yang sudah terpasang di komputer atau HP, termasuk printer kantor. Struk dicetak sebagai satu lembar sempit (58 atau 80 mm, tinggi mengikuti isi), bukan kertas A4.

Dulu cetak hanya cocok untuk printer besar karena ukuran kertas ditulis `58mm auto`, yang tidak valid, sehingga peramban memakai kertas Letter. Sekarang tingginya dihitung dari jumlah baris, dan bagian aplikasi lain disembunyikan saat cetak.

Cetak dan Bluetooth tidak tersedia di pratinjau yang di-embed (misalnya di dalam Claude); pakai Salin teks atau Kirim WhatsApp di sana, dan aplikasi yang sudah di-deploy untuk mencetak. Bluetooth butuh alamat https (Vercel sudah https) dan tidak ada di Safari/iPhone; di iPhone pakai dialog cetak peramban (AirPrint).

### Catatan scan barcode

- Peramban yang punya `BarcodeDetector` bawaan (Chrome di Android dan beberapa desktop) memakainya. Selain itu (misalnya iPhone) aplikasi memakai pembaca sendiri yang mendukung **EAN-13, EAN-8, UPC-A, dan Code 128**. Pembacaan selalu divalidasi dengan digit cek, dan di jalur pembaca sendiri harus dikonfirmasi dua kali sebelum dihitung, supaya barang yang salah tidak masuk diam-diam.
- Kode yang tetap berada di depan kamera hanya dihitung sekali. Untuk menambah barang yang sama, jauhkan sebentar lalu arahkan lagi (atau ubah jumlahnya di keranjang).
- UPC-A (12 digit) dan EAN-13 dengan angka 0 di depan dianggap kode yang sama.
- Barcode di data contoh adalah kode fiktif dengan digit cek yang sah. Barcode produk asli harus diisi di form Produk (tombol Scan di sebelah kolom barcode).
- Tips: cahaya cukup, dekatkan sampai barcode memenuhi kotak, dan tahan stabil sebentar. Barcode yang kusut atau tertutup plastik mengilap kadang perlu diputar sedikit.

## Struktur folder

```
src/
  core/                  logika murni, tanpa React (semua diuji)
    types.ts             tipe data (Product, Transaction, Customer, DebtEntry, Settings, ...)
    calc.ts              total, diskon, pajak, pembulatan, konversi satuan, HPP, status stok, validasi pembayaran
    format.ts            Rupiah, tanggal WIB, nomor
    persistence.ts       penyimpanan: IndexedDB (versi 3, satu transaksi per operasi) dan memori (fallback/tes)
    store.ts             database in-memory dengan operasi atomik (mutate) dan antrean serial
    services.ts          operasi bisnis: produk, stok, checkout, void, pelanggan, kasbon, pengaturan
    queries.ts           ringkasan, peringatan stok, pencarian, piutang
    returns.ts           retur: pembagian nilai yang tepat sampai rupiah, stok, uang kembali, potong kasbon
    shifts.ts            kas laci: buka/tutup, uang masuk/keluar, hitungan uang tunai, rekap
    opname.ts            opname stok (hitung lalu terapkan selisih)
    holds.ts             tahan dan lanjutkan keranjang
    backup.ts            cadangan dan pemulihan: buat, periksa (validasi ketat), ganti seluruh data secara atomik
    stockNotify.ts       teks toast dan ringkasan harian untuk stok habis/menipis, deteksi yang baru memburuk
    reports.ts           periode, ringkasan, per produk/kategori/metode, nilai stok, rekap kasbon, tabel dan CSV
    barcode.ts           pembaca barcode (EAN/UPC/Code 128), penahan scan ganda, pencocokan kode
    whatsapp.ts          nomor telepon Indonesia, tautan wa.me, teks struk/bukti/pengingat
    export.ts            tata letak struk berbaris tetap (teks, WhatsApp, cetak), daftar belanja (teks dan CSV)
    escpos.ts            byte ESC/POS untuk printer thermal, pemecah potongan Bluetooth, tautan RawBT
    demo.ts              data contoh (produk, pelanggan dan kasbon, transaksi seminggu)
  app/                   kerangka UI: App, navigasi, keranjang, komponen dasar, struk, dialog cetak (print.ts), kirim WhatsApp, pemindai kamera
  screens/               Dashboard, Pos, Holds, PaymentModal, Products, Stock, Opname, Shopping, History, ReturnDialog, Kasbon, Cash, Reports, Backup, Settings
  styles.css             token warna (terang/gelap), Tailwind, gaya struk dan cetak
tests/                   calc, services, kasbon, barcode, escpos, phase2 (retur, kas laci, opname, laporan, tahan), backup (cadangan dan pemulihan), notify (notifikasi stok, pengaturan, RawBT di APK)
scripts/                 build.mjs (esbuild + Tailwind), e2e.mjs (uji peramban), fake-camera.mjs (video barcode untuk uji kamera)
public/index.html        hasil build (satu file)
```

## Perbedaan dari stack di prompt

Paket dari npm registry tidak bisa diunduh saat aplikasi ini dibuat, jadi beberapa bagian ditulis sendiri:

| Prompt | Dipakai di sini |
|---|---|
| Vite | skrip `scripts/build.mjs` (esbuild + Tailwind v4 compile API) |
| Dexie.js | lapisan IndexedDB sendiri (`persistence.ts`), tetap atomik per operasi |
| Recharts | grafik batang SVG sendiri (`Dashboard.tsx`) |
| React Router | navigasi hash sederhana (`app/nav.tsx`) |
| date-fns | `Intl.DateTimeFormat` dengan zona Asia/Jakarta |
| Vitest | `node:test` lewat `tsx` |
| lucide-react | ikon Lucide lewat `react-icons/lu` |
| (pustaka scan barcode) | pembaca EAN/UPC/Code 128 sendiri (`core/barcode.ts`) sebagai cadangan `BarcodeDetector` |

Sama dengan prompt: React, TypeScript, Tailwind CSS.

Nama aplikasi adalah Bonbon; nama toko bawaan "Warung Manop" (tampil di header, struk, dan pesan WhatsApp, bisa diganti di Pengaturan). Berkas cadangan bernama `bonbon-cadangan-TANGGAL.json`; cadangan dari versi sebelum Bonbon (kode internal `warung-manop`) tetap bisa dipulihkan. ID database internal tetap `kasirku-pos` supaya data lama tidak hilang. Data dari versi sebelumnya (database v1 atau v2) otomatis ditingkatkan ke v3 tanpa kehilangan produk, transaksi, atau pengaturan. Jika ada tab lama yang masih terbuka saat peningkatan, aplikasi menampilkan petunjuk untuk menutupnya.

## Asumsi

- Satu pengguna lokal bernama "Kasir" (nama bisa diubah di Pengaturan). Tidak ada login dan peran, karena aplikasi dipakai satu orang (disengaja).
- Harga jual dianggap belum termasuk pajak. PPN dihitung dari subtotal setelah diskon. Urutan: subtotal, diskon, pajak, pembulatan.
- Kasbon: satu transaksi hanya boleh satu pembayaran kasbon, dan pelanggan wajib dipilih. Pembayaran cicilan yang melebihi sisa utang ditolak. Saldo baru bisa negatif ("kelebihan bayar") bila transaksi kasbon yang sudah dicicil dibatalkan (void). Pelanggan dengan saldo tidak nol tidak bisa dinonaktifkan. Penjualan kasbon dihitung sebagai penjualan pada hari transaksinya; cicilan dicatat di buku kasbon pelanggan, bukan sebagai penjualan baru.
- Void hanya untuk transaksi pada hari yang sama (WIB) dan hanya bila belum pernah diretur. Retur bisa kapan saja selama pembayaran sudah dikonfirmasi.
- Retur ke kas tunai mengurangi hitungan laci pada kas yang sedang berjalan saat retur dilakukan, bukan kas tempat transaksi aslinya (kas yang sudah ditutup tidak berubah).
- Kas laci tidak bisa ditutup selama masih ada pembayaran yang menunggu konfirmasi.
- Omzet dan laba di Beranda dan Laporan dikurangi retur pada tanggal retur. Barang rusak yang tidak masuk stok tidak mengembalikan modalnya, sehingga laba turun sebesar modal itu.
- PDF laporan dibuat lewat dialog cetak peramban (pilih "Simpan sebagai PDF"). Di pratinjau Claude tombol cetak dan unduh tidak tersedia, tersedia Salin CSV.
- Stok tidak boleh minus kecuali pengaturan "Izinkan stok minus" aktif.
- Satuan hitung (pcs, botol, dus) hanya menerima bilangan bulat. Kg, liter, dan sejenisnya boleh sampai 3 desimal.
- Saran jumlah beli = (stok minimum x 2) dikurangi stok. Untuk produk habis dengan stok minimum 0, sarannya 1.
- Tanggal kadaluarsa hanya ditampilkan sebagai penanda di daftar produk (belum memengaruhi stok).
- Nomor struk INV-YYYYMMDD-0001 berurutan per hari WIB dan tetap berlanjut setelah muat ulang.
- Keranjang disimpan di memori, hilang jika halaman dimuat ulang. Transaksi yang sudah selesai tersimpan permanen.
- Cetak struk lewat dialog peramban memakai `window.print()` dengan CSS khusus cetak, atau langsung ESC/POS lewat Bluetooth atau RawBT (lihat Catatan cetak struk). Di lingkungan yang memblokir cetak (mis. pratinjau yang di-embed), tombolnya disembunyikan dan tersedia Salin teks. Teks struk dikirim sebagai ASCII (aksen dibuang) karena printer thermal bawaan tidak punya huruf Unicode.
- Data hanya ada di peramban yang dipakai. Menghapus data situs atau berganti HP berarti data tidak ikut. Belum ada sinkronisasi atau cadangan otomatis: cadangan dibuat dengan tombol di Pengaturan, dan Beranda mengingatkan setelah 7 hari. Saat dipulihkan, data sekarang diganti seluruhnya (bukan digabung).

## Yang sudah dan belum terverifikasi

Sudah lolos di lingkungan pembuatan: 176 unit test (termasuk 24.000 pola acak untuk memastikan pembaca barcode tidak membaca kode palsu; retur bertahap juga diuji acak pada ratusan transaksi dengan diskon, pajak, pembulatan, dan satuan desimal sampai jumlahnya pas), pengecekan tipe `src/core` dan `tests`, dan 75 pengecekan end-to-end di Chromium (alur kasir, kasbon, WhatsApp, migrasi database lama, tata letak HP 360 dan 390 px, geser dengan sentuhan, scan kamera dengan video barcode palsu, cetak struk (halaman PDF 58 dan 80 mm, Bluetooth dan RawBT dengan tiruan), cetak laporan A4, kas laci, opname, retur, tahan keranjang, cadangan dan pemulihan, notifikasi dan fitur khusus aplikasi Android (dengan jembatan Android tiruan), serta tampilan terang dan gelap di dalam bungkus halaman Claude lengkap dengan pemeriksaan kontras semua teks).

Belum bisa diuji di sana: `npm install` dan deploy Vercel sungguhan, pembangunan APK sungguhan (registry npm, Android SDK, dan Gradle tidak terjangkau; skrip penyesuaian hanya diuji pada tiruan template Android, dan jembatan Capacitor, notifikasi, dan share diuji dengan jembatan tiruan), pengecekan tipe seluruh `src` (paket tipe React tidak tersedia), kamera fisik dan fokus otomatis HP asli, printer thermal sungguhan (Bluetooth LE dan RawBT hanya diuji dengan tiruan, jadi urutan dan isi byte terbukti benar tetapi kecocokan dengan merek printer tertentu belum), dialog cetak peramban di perangkat asli, serta membuka aplikasi WhatsApp sungguhan.
