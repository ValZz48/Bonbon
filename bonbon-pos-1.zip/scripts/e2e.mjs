// End-to-end smoke test in a real headless Chromium (Playwright).
//   node scripts/build.mjs && node scripts/e2e.mjs [outDir]
// Exercises the whole Fase 1 flow against public/index.html and writes screenshots to outDir.

import { createRequire } from 'node:module';
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { createServer } from 'node:http';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { withCheckDigit, writeBarcodeVideo } from './fake-camera.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(join(root, 'package.json'));
const { chromium } = require('playwright');

const out = resolve(process.argv[2] ?? join(root, 'shots'));
mkdirSync(out, { recursive: true });
const url = pathToFileURL(join(root, 'public/index.html')).href;

const results = [];
const errors = [];
let step = 'start';
let shotSeq = 0;
let activePage; // the page used for failure screenshots (set below, switched per section)
async function check(name, fn) {
  step = name;
  try {
    await fn();
    results.push(['PASS', name]);
  } catch (e) {
    results.push(['FAIL', name, String(e.message).split('\n')[0]]);
    await (activePage ?? page).screenshot({ path: join(out, `gagal-${++shotSeq}.png`) }).catch(() => undefined);
  }
}

function report() {
  const failed = results.filter((r) => r[0] === 'FAIL');
  for (const r of results) console.log(r[0], '-', r[1], r[2] ? `\n      ${r[2]}` : '');
  console.log(`\n${results.length - failed.length}/${results.length} lolos`);
  if (errors.length) console.log('\nError di browser:\n' + errors.map((e) => '  ' + e).join('\n'));
  return failed.length || errors.length ? 1 : 0;
}
process.on('uncaughtException', async (e) => {
  console.log(`\nBERHENTI di langkah "${step}": ${String(e.message).split('\n')[0]}\n`);
  await page.screenshot({ path: join(out, 'berhenti.png') }).catch(() => undefined);
  process.exit(report() || 1);
});
const eq = (a, b, msg) => {
  if (a !== b) throw new Error(`${msg ?? 'nilai'}: harapan ${JSON.stringify(b)}, dapat ${JSON.stringify(a)}`);
};
const ok = (v, msg) => {
  if (!v) throw new Error(msg ?? 'kondisi tidak terpenuhi');
};

const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 1280, height: 860 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
await context.grantPermissions(['clipboard-read', 'clipboard-write']);
const page = await context.newPage();
activePage = page;
page.on('pageerror', (e) => errors.push(`[${step}] pageerror: ${e.message}`));
page.on('console', (m) => {
  if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_(INTERNET|NAME|CONNECTION|BLOCKED|FAILED|PROXY|TUNNEL)/i.test(m.text())) errors.push(`[${step}] console: ${m.text()}`);
});

async function until(fn, msg, ms = 4000) {
  const t0 = Date.now();
  for (;;) {
    if (await fn()) return;
    if (Date.now() - t0 > ms) throw new Error(msg ?? 'kondisi tidak tercapai');
    await page.waitForTimeout(60);
  }
}
const num = (s) => Number(String(s).replace(/[^\d,-]/g, '').replace(',', '.'));
const rupiah = (s) => Number(String(s).replace(/[^\d]/g, ''));
const nav = (label) => page.locator('aside').getByRole('button', { name: new RegExp(`^${label}`) });

// Menu bawah di ponsel: lima menu harian + "Lainnya" (Produk, Perlu Belanja, Kas Laci, Laporan).
const MORE_ITEMS = { Produk: 'Produk', Belanja: 'Perlu Belanja', 'Kas Laci': 'Kas Laci', Laporan: 'Laporan' };
async function phoneGo(p, name) {
  const bar = p.locator('nav[aria-label="Menu utama"]').last();
  if (name in MORE_ITEMS) {
    await bar.getByRole('button', { name: 'Lainnya' }).click();
    await p.getByRole('dialog', { name: 'Menu lainnya' }).getByRole('button', { name: new RegExp(`^${MORE_ITEMS[name]}`) }).click();
  } else {
    await bar.getByRole('button', { name: new RegExp(`^${name}`) }).click();
  }
}

await page.goto(url);
await page.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
await page.waitForTimeout(300);

await check('Beranda: data contoh, kartu ringkasan, grafik, peringatan stok', async () => {
  ok(await page.getByText('Ini data contoh').isVisible(), 'banner data contoh');
  ok(await page.getByText('Omzet hari ini').first().isVisible(), 'kartu omzet');
  ok((await page.locator('svg[role="img"] path').count()) >= 5, 'batang grafik');
  ok((await page.getByRole('region', { name: 'Stok perlu perhatian' }).locator('li').count()) >= 3, 'daftar stok menipis');
});
await page.screenshot({ path: join(out, '01-beranda.png') });

// ---- Kasir ----
await nav('Kasir').click();
await page.getByRole('textbox', { name: 'Cari produk atau scan barcode' }).waitFor();

await check('Kasir: tambah produk lewat grid dan tombol +/−', async () => {
  await page.getByRole('button', { name: /^Tambah Indomie Goreng,/ }).click();
  const cart = page.getByRole('region', { name: 'Keranjang' });
  ok(await cart.getByText('Indomie Goreng').isVisible());
  await cart.getByRole('button', { name: 'Tambah Indomie Goreng', exact: true }).click();
  await until(async () => (await cart.getByLabel('Jumlah Indomie Goreng').inputValue()) === '2', 'jumlah harus menjadi 2');
  eq(rupiah(await cart.locator('span[aria-live="polite"]').innerText()), 7000, 'total');
});

await check('Kasir: scan barcode (Enter) menambah produk dan mengosongkan kolom cari', async () => {
  const search = page.getByRole('textbox', { name: 'Cari produk atau scan barcode' });
  await search.fill('8993000600016'); // Air Mineral 600 ml
  await search.press('Enter');
  eq(await search.inputValue(), '', 'kolom cari');
  const cart = page.getByRole('region', { name: 'Keranjang' });
  ok(await cart.getByText('Air Mineral 600 ml').isVisible());
  eq(rupiah(await cart.locator('span[aria-live="polite"]').innerText()), 10000, 'total');
});

await check('Kasir: satuan dus dan produk kg desimal', async () => {
  const cart = page.getByRole('region', { name: 'Keranjang' });
  await page.getByRole('button', { name: /^Tambah Gula Pasir,/ }).click();
  const qty = cart.getByLabel('Jumlah Gula Pasir');
  await qty.fill('1,5');
  eq(rupiah(await cart.locator('span[aria-live="polite"]').innerText()), 10000 + 27000, 'total dengan 1,5 kg');
  await cart.getByLabel('Satuan Air Mineral 600 ml').selectOption({ label: 'dus (isi 24)' });
  eq(rupiah(await cart.locator('span[aria-live="polite"]').innerText()), 7000 + 45000 + 27000, 'total dengan 1 dus');
  await cart.getByLabel('Satuan Air Mineral 600 ml').selectOption({ label: 'botol' });
});

await check('Kasir: jumlah di atas stok ditolak dan tombol bayar nonaktif', async () => {
  const cart = page.getByRole('region', { name: 'Keranjang' });
  const qty = cart.getByLabel('Jumlah Air Mineral 600 ml');
  await qty.fill('9999');
  ok(await cart.getByText(/Melebihi stok/).isVisible(), 'peringatan stok');
  ok(await cart.getByRole('button', { name: /^Bayar/ }).isDisabled(), 'tombol bayar');
  await qty.fill('1');
  ok(await cart.getByRole('button', { name: /^Bayar/ }).isEnabled(), 'tombol bayar aktif lagi');
});

await check('Kasir: diskon item dan diskon transaksi', async () => {
  const cart = page.getByRole('region', { name: 'Keranjang' });
  // total sekarang: 7.000 + 3.000 + 27.000 = 37.000
  await cart.getByRole('button', { name: 'Diskon dan catatan' }).first().click();
  await cart.getByLabel('Diskon Indomie Goreng', { exact: true }).fill('1000');
  eq(rupiah(await cart.locator('span[aria-live="polite"]').innerText()), 36000, 'setelah diskon item');
  await cart.getByRole('button', { name: /Diskon transaksi/ }).click();
  await cart.getByRole('group', { name: 'Jenis Diskon transaksi' }).getByRole('button', { name: '%' }).click();
  await cart.getByLabel('Diskon transaksi', { exact: true }).fill('10');
  eq(rupiah(await cart.locator('span[aria-live="polite"]').innerText()), 32400, 'setelah diskon 10%');
});
await page.screenshot({ path: join(out, '02-kasir-keranjang.png') });

// ---- Pembayaran: split tunai + QRIS ----
let receiptNo1 = '';
await check('Pembayaran: split tunai + QRIS, struk muncul', async () => {
  await page.keyboard.press('F2');
  const dlg = page.getByRole('dialog', { name: 'Pembayaran' });
  await dlg.waitFor();
  eq(rupiah(await dlg.getByText('Total tagihan').locator('xpath=following-sibling::span').innerText()), 32400, 'total tagihan');
  await dlg.getByLabel('Uang diterima').fill('20000');
  await dlg.getByRole('button', { name: /^Tambah tunai/ }).click();
  ok(await dlg.getByText('Sisa').isVisible(), 'sisa tampil');
  await dlg.getByRole('radio', { name: 'QRIS' }).click();
  await dlg.getByPlaceholder('Mis. 4 digit akhir atau kode transaksi').fill('QR-998');
  await page.screenshot({ path: join(out, '03-pembayaran.png') });
  await dlg.getByRole('button', { name: 'Bayar QRIS' }).click();
  const receipt = page.getByRole('dialog', { name: /^Struk INV-/ });
  await receipt.waitFor();
  receiptNo1 = (await receipt.getByRole('heading').innerText()).replace('Struk ', '');
  ok(/^INV-\d{8}-\d{4}$/.test(receiptNo1), `format nomor struk: ${receiptNo1}`);
  const text = await receipt.locator('.receipt-sheet').innerText();
  ok(text.includes('QR-998') && text.includes('TOTAL'), 'isi struk');
});
await page.screenshot({ path: join(out, '04-struk.png') });

await check('Struk: salin teks ke clipboard', async () => {
  await page.getByRole('button', { name: 'Salin teks' }).click();
  const clip = await page.evaluate(() => navigator.clipboard.readText());
  ok(clip.includes(receiptNo1) && clip.includes('QRIS'), 'teks struk di clipboard');
});
await page.getByRole('button', { name: 'Transaksi baru' }).click();

await check('Keranjang kosong setelah transaksi selesai', async () => {
  const cart = page.getByRole('region', { name: 'Keranjang' });
  ok(await cart.getByText('Keranjang kosong').isVisible());
});

// ---- Transaksi tunai sederhana + kembalian ----
await check('Pembayaran tunai: uang pas dan kembalian', async () => {
  await page.getByRole('button', { name: /^Tambah Roti Tawar Sari Roti,/ }).click();
  await page.getByRole('button', { name: /^Bayar/ }).click();
  const dlg = page.getByRole('dialog', { name: 'Pembayaran' });
  await dlg.getByRole('button', { name: '20rb' }).click();
  eq(rupiah(await dlg.getByText('Kembalian').locator('xpath=following-sibling::span').innerText()), 5000, 'kembalian');
  await dlg.getByRole('button', { name: 'Bayar Tunai' }).click();
  await page.getByRole('dialog', { name: /^Struk INV-/ }).waitFor();
  await page.getByRole('button', { name: 'Transaksi baru' }).click();
});

// ---- Produk & stok ----
await nav('Produk').click();
await check('Produk: stok berkurang setelah penjualan (Indomie 140 -> 138)', async () => {
  await page.getByLabel('Cari produk').fill('Indomie Goreng');
  const row = page.locator('li', { hasText: 'Indomie Goreng' }).first();
  ok((await row.innerText()).includes('13'), 'stok indomie');
});

await check('Produk: tambah produk baru dengan satuan konversi dan stok awal', async () => {
  await page.getByRole('button', { name: 'Tambah produk' }).click();
  const dlg = page.getByRole('dialog', { name: 'Tambah produk' });
  await dlg.getByPlaceholder('Mis. Indomie Goreng').fill('Kerupuk Uli');
  await dlg.getByPlaceholder('Mis. Minuman').fill('Roti & Snack');
  await dlg.getByLabel('HPP per pcs').fill('1500');
  await dlg.getByLabel('Harga jual per pcs').fill('2500');
  await dlg.getByLabel('Stok awal (opsional)').fill('10');
  await dlg.getByRole('button', { name: 'Tambah satuan' }).click();
  await dlg.getByPlaceholder('dus').fill('slop');
  await dlg.getByPlaceholder('24').fill('10');
  await dlg.locator('fieldset input[inputmode="numeric"]').last().fill('24000');
  await dlg.getByRole('button', { name: 'Simpan produk' }).click();
  await dlg.waitFor({ state: 'hidden' });
  await page.getByLabel('Cari produk').fill('Kerupuk Uli');
  ok(await page.getByText('Kerupuk Uli').first().isVisible(), 'produk baru tampil');
  ok((await page.locator('main li').first().innerText()).includes('slop'), 'satuan tambahan slop tampil');
  await page.getByLabel('Cari produk').fill('');
});

await check('Produk: barcode duplikat ditolak dengan pesan jelas', async () => {
  await page.getByRole('button', { name: 'Tambah produk' }).click();
  const dlg = page.getByRole('dialog', { name: 'Tambah produk' });
  await dlg.getByPlaceholder('Mis. Indomie Goreng').fill('Duplikat');
  await dlg.getByPlaceholder('Scan atau ketik').fill('8998866200301');
  await dlg.getByLabel('Harga jual per pcs').fill('1000');
  await dlg.getByRole('button', { name: 'Simpan produk' }).click();
  await dlg.getByRole('alert').getByText(/Barcode 8998866200301 sudah dipakai Indomie Goreng/).waitFor({ timeout: 4000 });
  await dlg.getByRole('button', { name: 'Batal' }).click();
});

await nav('Stok').click();
await check('Stok: daftar produk memuat semua produk (lebih dari 7), bisa digulir tanpa mencari, dan bisa disaring per kategori', async () => {
  const list = page.getByTestId('picker-list');
  await list.waitFor();
  const info = await list.evaluate((el) => ({ items: el.querySelectorAll('li button').length, scrolls: el.scrollHeight > el.clientHeight + 4, canScroll: getComputedStyle(el).overflowY === 'auto' }));
  ok(info.items > 7, `daftar memuat ${info.items} produk tanpa mengetik apa pun`);
  ok(info.canScroll, 'daftar punya overflow-y: auto');
  ok(info.scrolls, 'isi daftar lebih tinggi dari kotaknya, jadi bisa digulir');
  await list.evaluate((el) => { el.scrollTop = el.scrollHeight; });
  const last = list.locator('li button').last();
  await last.scrollIntoViewIfNeeded();
  ok(await last.isVisible(), 'produk paling bawah bisa dicapai dengan menggulir');
  const chip = page.getByRole('group', { name: 'Kategori produk' }).getByRole('button').nth(1);
  const label = (await chip.innerText()).trim();
  await chip.click();
  const filtered = await list.locator('li button').count();
  ok(filtered > 0 && filtered < info.items, `filter kategori ${label} menyisakan ${filtered} dari ${info.items}`);
  await page.getByRole('group', { name: 'Kategori produk' }).getByRole('button', { name: 'Semua' }).click();
});
await check('Stok masuk: per dus, HPP rata-rata, stok bertambah', async () => {
  await page.getByPlaceholder('Cari nama, SKU, atau barcode').fill('Teh Botol');
  await page.getByRole('button', { name: /Teh Botol 450 ml/ }).click();
  await page.getByLabel('Satuan').selectOption({ label: 'dus (isi 12)' });
  const form = page.locator('form');
  await form.locator('input[inputmode="decimal"]').first().fill('2');
  await form.getByRole('button', { name: 'Catat stok masuk' }).click();
  await page.getByText(/Stok Teh Botol 450 ml bertambah 24 botol/).waitFor({ timeout: 4000 });
});

await check('Stok: penyesuaian wajib alasan', async () => {
  await page.getByRole('tab', { name: 'Penyesuaian' }).click();
  await page.getByPlaceholder('Cari nama, SKU, atau barcode').fill('Sprite');
  await page.getByRole('button', { name: /Sprite 390 ml/ }).click();
  const form = page.locator('form');
  await form.locator('input[inputmode="decimal"]').first().fill('2');
  await form.getByRole('button', { name: 'Simpan penyesuaian' }).click();
  await form.getByText('Alasan penyesuaian wajib diisi.').waitFor({ timeout: 4000 });
  await form.getByRole('button', { name: 'Rusak' }).click();
  await form.getByRole('button', { name: 'Simpan penyesuaian' }).click();
  await page.getByText(/Stok Sprite 390 ml disesuaikan menjadi \d+/).waitFor({ timeout: 4000 });
});

await check('Stok: log pergerakan memuat penjualan, stok masuk, dan penyesuaian', async () => {
  await page.getByRole('tab', { name: 'Pergerakan stok' }).click();
  const rows = page.locator('main ul li');
  await rows.first().waitFor();
  ok((await rows.filter({ hasText: 'Penjualan' }).count()) > 0, 'ada baris Penjualan');
  ok((await rows.filter({ hasText: 'Stok masuk' }).count()) > 0, 'ada baris Stok masuk');
  await page.getByLabel('Filter tipe').selectOption({ label: 'Penyesuaian' });
  ok((await rows.filter({ hasText: 'Rusak' }).count()) > 0, 'alasan penyesuaian tercatat');
});

// ---- Perlu belanja ----
await nav('Perlu Belanja').click();
await check('Perlu Belanja: daftar, saran jumlah, salin teks', async () => {
  await page.getByRole('heading', { name: 'Perlu Belanja' }).waitFor();
  const rows = page.locator('main li');
  ok((await rows.count()) >= 4, 'jumlah baris');
  const first = (await rows.first().innerText());
  ok(/Habis/.test(first), 'yang habis ada di paling atas');
  await page.getByRole('button', { name: 'Salin daftar' }).click();
  const clip = await page.evaluate(() => navigator.clipboard.readText());
  ok(clip.startsWith('Daftar belanja') && /- .+: .+/.test(clip), 'format teks daftar belanja');
});
await page.screenshot({ path: join(out, '05-perlu-belanja.png') });

// ---- Riwayat + void ----
await nav('Riwayat').click();
await check('Riwayat: transaksi hari ini tampil, void mengembalikan stok', async () => {
  const row = page.locator('main li button', { hasText: receiptNo1 });
  await row.waitFor();
  await row.click();
  const dlg = page.getByRole('dialog', { name: `Struk ${receiptNo1}` });
  ok(await dlg.getByText('Selesai').isVisible(), 'status selesai');
  await dlg.getByRole('button', { name: 'Void' }).click();
  const v = page.getByRole('dialog', { name: `Void ${receiptNo1}` });
  await v.getByRole('button', { name: 'Void transaksi' }).click();
  await v.getByText('Alasan void wajib diisi.').waitFor({ timeout: 4000 });
  await v.getByRole('button', { name: 'Salah input' }).click();
  await v.getByRole('button', { name: 'Void transaksi' }).click();
  await v.waitFor({ state: 'hidden' });
  await page.locator('main li button', { hasText: receiptNo1 }).getByText('Dibatalkan').waitFor({ timeout: 4000 });
});

await check('Riwayat: konfirmasi pembayaran yang menunggu', async () => {
  await page.getByLabel('Filter status').selectOption({ label: 'Menunggu konfirmasi' });
  await page.getByRole('combobox', { name: 'Filter metode' }).waitFor();
  await page.getByRole('button', { name: 'Semua' }).click();
  const rows = page.locator('main li button');
  ok((await rows.count()) >= 1, 'ada transaksi menunggu dari data demo');
  await rows.first().click();
  await page.getByRole('button', { name: 'Sudah diterima' }).click();
  await page.getByText('Pembayaran dikonfirmasi.').waitFor({ timeout: 4000 });
  await page.keyboard.press('Escape');
});

// ---- Fase 2: retur, kas laci, opname, laporan, tahan ----
await nav('Riwayat').click();
await check('Retur: sebagian barang diretur dari Riwayat, uang kembali tercatat, Void tidak lagi tersedia, filter Ada retur', async () => {
  await page.getByLabel('Filter status').selectOption({ label: 'Selesai' });
  const row = page.locator('main li button', { hasText: 'Tunai' }).first();
  await row.waitFor();
  await row.click();
  const receipt = page.getByRole('dialog', { name: /^Struk INV-/ });
  await receipt.getByRole('button', { name: 'Retur', exact: true }).click();
  const dlg = page.getByRole('dialog', { name: /^Retur INV-/ });
  await dlg.waitFor();
  await dlg.getByRole('button', { name: /^Tambah retur/ }).first().click();
  await dlg.getByRole('button', { name: 'Salah beli' }).click();
  const submit = dlg.getByRole('button', { name: /^Retur, kembalikan/ });
  ok(rupiah(await submit.innerText()) > 0, 'jumlah uang kembali tampil di tombol');
  await submit.click();
  await page.getByText('Retur dicatat.').waitFor({ timeout: 4000 });
  await receipt.getByText(/uang kembali/).waitFor();
  eq(await receipt.getByRole('button', { name: 'Void' }).count(), 0, 'transaksi yang diretur tidak bisa di-void');
  await page.keyboard.press('Escape');
  await page.getByLabel('Filter status').selectOption({ label: 'Ada retur' });
  const hit = page.locator('main li button').filter({ hasText: /Diretur|Retur sebagian/ });
  ok((await hit.count()) >= 1, 'transaksi yang diretur ditandai di daftar');
});

await nav('Kas Laci').click();
let lastCounted = 0;
await check('Kas laci: uang keluar mengurangi hitungan laci, tutup kas menghitung selisih dan menyimpan riwayat', async () => {
  await page.getByRole('heading', { name: 'Kas Laci' }).waitFor();
  const live = page.getByRole('region', { name: 'Kas berjalan' });
  const expected = async () => rupiah(await live.locator('p[aria-live="polite"]').innerText());
  const before = await expected();
  ok(before > 0, 'kas hari ini dari data contoh sedang berjalan');
  await live.getByRole('button', { name: 'Uang keluar' }).click();
  const out = page.getByRole('dialog', { name: 'Uang keluar dari laci' });
  await out.getByLabel('Jumlah uang').fill('15000');
  await out.getByRole('button', { name: 'Catat' }).click();
  ok(await out.getByText('Keterangan wajib').isVisible().catch(() => false) || (await page.getByText('Keterangan wajib diisi', { exact: false }).count()) > 0, 'keterangan wajib diisi');
  await out.getByRole('button', { name: 'Beli barang' }).click();
  await out.getByRole('button', { name: 'Catat' }).click();
  await page.getByText('Uang keluar dicatat.').waitFor({ timeout: 4000 });
  await until(async () => (await expected()) === before - 15000, `hitungan laci harus turun 15.000 dari ${before}`);
  const exp = await expected();
  await live.getByRole('button', { name: 'Tutup kas' }).click();
  const close = page.getByRole('dialog', { name: 'Tutup kas laci' });
  await close.getByLabel('Uang yang dihitung').fill(String(exp - 500));
  await close.getByText(/Kurang Rp\s*500/).waitFor();
  await close.getByRole('button', { name: 'Tutup kas' }).click();
  await page.getByText('Kas laci ditutup.').waitFor({ timeout: 4000 });
  lastCounted = exp - 500;
  await page.getByText('Kas laci belum dibuka').waitFor();
  const hist = page.getByRole('region', { name: 'Riwayat kas' });
  await hist.locator('li button').first().getByText(/Kurang Rp\s*500/).waitFor();
  await hist.locator('li button').first().click();
  const detail = page.getByRole('dialog').filter({ has: page.getByRole('button', { name: 'Salin rekap' }) });
  await detail.getByRole('button', { name: 'Salin rekap' }).click();
  const clip = await page.evaluate(() => navigator.clipboard.readText());
  ok(/Rekap shift/.test(clip) && /Selisih: kurang Rp\s*500/.test(clip), `isi rekap: ${clip}`);
  await page.keyboard.press('Escape');
});
await page.screenshot({ path: join(out, '24-kas-laci.png') });

await check('Kas laci: wajib buka kas menahan pembayaran di Kasir, buka kas mengisi uang awal dari hitungan terakhir', async () => {
  await nav('Pengaturan').click();
  await page.getByRole('switch', { name: 'Wajib buka kas sebelum berjualan' }).click();
  await page.getByRole('button', { name: 'Simpan pengaturan' }).click();
  await page.getByText('Pengaturan disimpan.').waitFor({ timeout: 4000 });
  await nav('Kasir').click();
  await page.getByText(/Kas laci belum dibuka\. Buka dulu/).waitFor();
  await page.getByRole('button', { name: /^Tambah Indomie Goreng,/ }).click();
  await page.getByRole('region', { name: 'Keranjang' }).getByRole('button', { name: /^Bayar/ }).click();
  await page.getByRole('heading', { name: 'Kas Laci' }).waitFor();
  await page.getByRole('button', { name: 'Buka kas' }).first().click();
  const dlg = page.getByRole('dialog', { name: 'Buka kas laci' });
  eq(rupiah(await dlg.getByLabel('Uang awal di laci').inputValue()), lastCounted, 'uang awal terisi dari hitungan terakhir');
  await dlg.getByRole('button', { name: 'Buka kas' }).click();
  await page.getByText('Kas laci dibuka.').waitFor({ timeout: 4000 });
  await nav('Pengaturan').click();
  await page.getByRole('switch', { name: 'Wajib buka kas sebelum berjualan' }).click();
  await page.getByRole('button', { name: 'Simpan pengaturan' }).click();
  await page.getByText('Pengaturan disimpan.').waitFor({ timeout: 4000 });
  await nav('Kasir').click();
  const cart = page.getByRole('region', { name: 'Keranjang' });
  await cart.getByRole('button', { name: 'Kosongkan' }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Kosongkan' }).click();
});

await check('Kasir: Tahan menyimpan keranjang tanpa mengurangi stok, Lanjutkan mengembalikannya, keranjang yang terisi ikut ditahan saat bertukar', async () => {
  await nav('Kasir').click();
  const cart = page.getByRole('region', { name: 'Keranjang' });
  await page.getByRole('button', { name: 'Keranjang tertahan, 1' }).waitFor();
  await page.getByRole('button', { name: /^Tambah Indomie Goreng,/ }).click();
  await cart.getByRole('button', { name: 'Tahan', exact: true }).click();
  const hold = page.getByRole('dialog', { name: 'Tahan keranjang' });
  await hold.getByLabel(/Nama atau ciri/).fill('Pak Tono');
  await hold.getByRole('button', { name: 'Tahan', exact: true }).click();
  await page.getByText(/Keranjang ditahan/).waitFor({ timeout: 4000 });
  await cart.getByText('Keranjang kosong').waitFor();
  await page.getByRole('button', { name: 'Keranjang tertahan, 2' }).click();
  const list = page.getByRole('dialog', { name: 'Keranjang tertahan (2)' });
  await list.getByText('Pak Tono').waitFor();
  await list.getByText('Bu Ani').waitFor();
  await list.locator('li', { hasText: 'Pak Tono' }).getByRole('button', { name: 'Lanjutkan' }).click();
  await cart.getByText('Indomie Goreng').waitFor();
  await page.getByRole('button', { name: 'Keranjang tertahan, 1' }).click();
  const list2 = page.getByRole('dialog', { name: 'Keranjang tertahan (1)' });
  await list2.getByText(/ikut ditahan otomatis/).waitFor();
  await list2.locator('li', { hasText: 'Bu Ani' }).getByRole('button', { name: 'Lanjutkan' }).click();
  await page.getByRole('button', { name: 'Keranjang tertahan, 1' }).click();
  const list3 = page.getByRole('dialog', { name: 'Keranjang tertahan (1)' });
  await list3.getByText('Keranjang sebelumnya').waitFor();
  await list3.locator('li', { hasText: 'Keranjang sebelumnya' }).getByRole('button', { name: /^Hapus/ }).click();
  await list3.getByRole('button', { name: 'Ya, hapus' }).click();
  await page.getByText('Keranjang tertahan dihapus.').waitFor({ timeout: 4000 });
  await page.keyboard.press('Escape');
  eq(await page.getByRole('button', { name: /^Keranjang tertahan/ }).count(), 0, 'tombol Tertahan hilang saat kosong');
  await cart.getByRole('button', { name: 'Kosongkan' }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Kosongkan' }).click();
});

await nav('Stok').click();
await check('Opname: mulai, hitung (tersimpan saat pindah kolom), selisih tampil, selesai menerapkan ke stok dan masuk riwayat', async () => {
  await page.getByRole('tab', { name: 'Opname' }).click();
  await page.getByRole('button', { name: /^Mulai opname/ }).click();
  const field = page.getByRole('textbox', { name: /^Jumlah dihitung/ }).first();
  await field.waitFor();
  await field.fill('777');
  await field.press('Tab');
  await page.getByText(/^Selisih \+/).first().waitFor({ timeout: 4000 });
  eq(await page.getByRole('progressbar', { name: 'Kemajuan menghitung' }).getAttribute('aria-valuenow'), '1', 'jumlah yang sudah dihitung');
  await page.getByRole('button', { name: 'Selesai dan terapkan' }).click();
  const dlg = page.getByRole('dialog', { name: 'Selesaikan opname?' });
  await dlg.getByText(/1 produk dihitung/).waitFor();
  await dlg.getByRole('button', { name: 'Terapkan ke stok' }).click();
  await page.getByText(/Opname selesai/).waitFor({ timeout: 4000 });
  await page.getByRole('region', { name: 'Riwayat opname' }).waitFor();
  ok((await page.getByRole('region', { name: 'Riwayat opname' }).locator('li button').count()) >= 2, 'riwayat opname memuat yang demo dan yang baru');
  await page.getByRole('tab', { name: 'Pergerakan stok' }).click();
  await page.getByText('Opname', { exact: true }).first().waitFor();
});
await page.screenshot({ path: join(out, '25-opname.png') });

await nav('Laporan').click();
await check('Laporan: ringkasan, tab Produk, salin CSV, rentang tanggal terbalik ditolak', async () => {
  await page.getByRole('heading', { name: 'Laporan' }).waitFor();
  await page.getByText('Penjualan bersih').first().waitFor();
  await page.getByRole('tab', { name: 'Produk' }).click();
  const tbl = page.getByRole('region', { name: 'Per produk' });
  await tbl.waitFor();
  ok((await tbl.locator('tbody tr').count()) >= 5, 'baris produk');
  await page.getByRole('button', { name: 'Salin CSV' }).click();
  const clip = await page.evaluate(() => navigator.clipboard.readText());
  ok(clip.startsWith('Per produk\r\nProduk,Kategori,Terjual,Penjualan,HPP,Laba'), `awal CSV: ${clip.slice(0, 80)}`);
  await page.getByRole('tab', { name: 'Pembayaran' }).click();
  await page.getByRole('region', { name: 'Per metode pembayaran' }).waitFor();
  await page.getByRole('button', { name: 'Pilih tanggal' }).click();
  await page.getByLabel('Dari tanggal').fill('2099-01-01');
  await page.getByText(/tidak boleh setelah/).waitFor();
  await page.getByRole('button', { name: 'Bulan ini' }).click();
  await page.getByRole('tab', { name: 'Stok' }).click();
  await page.getByRole('region', { name: 'Nilai stok (per sekarang)' }).waitFor();
  await page.getByRole('tab', { name: 'Kasbon' }).click();
  await page.getByRole('region', { name: 'Pelanggan yang masih berutang' }).waitFor();
});
await page.screenshot({ path: join(out, '26-laporan.png') });

// ---- Pengaturan ----
await nav('Pengaturan').click();
await check('Pengaturan: aktifkan PPN 11% + pembulatan, tersimpan dan terpakai di kasir', async () => {
  await page.getByRole('switch', { name: 'Tambahkan PPN ke transaksi' }).click();
  await page.getByLabel('Pembulatan total').selectOption('500');
  await page.getByRole('button', { name: 'Simpan pengaturan' }).click();
  await page.getByText('Pengaturan disimpan.').waitFor({ timeout: 4000 });
  await nav('Kasir').click();
  await page.getByRole('button', { name: /^Tambah Indomie Goreng,/ }).click(); // 3.500 + 11% = 3.885 -> 4.000
  const cart = page.getByRole('region', { name: 'Keranjang' });
  eq(rupiah(await cart.locator('span[aria-live="polite"]').innerText()), 4000, 'total dengan PPN dibulatkan 500');
  ok(await cart.getByText('PPN 11%').isVisible(), 'baris PPN');
  await cart.getByRole('button', { name: 'Kosongkan' }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Kosongkan' }).click();
});
await nav('Pengaturan').click();
await page.screenshot({ path: join(out, '06-pengaturan.png') });
await check('Pengaturan: hapus semua data (konfirmasi di halaman) mengosongkan aplikasi', async () => {
  await page.getByRole('switch', { name: 'Tambahkan PPN ke transaksi' }).click();
  await page.getByLabel('Pembulatan total').selectOption('none');
  await page.getByRole('button', { name: 'Simpan pengaturan' }).click();
  await page.getByRole('button', { name: 'Hapus semua data' }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Hapus semua' }).click();
  await page.getByText('Semua data dihapus.').waitFor({ timeout: 4000 });
  await nav('Kasir').click();
  ok(await page.getByText('Belum ada produk').isVisible(), 'keadaan kosong di kasir');
  await nav('Beranda').click();
  await page.getByText('Belum ada transaksi').first().waitFor();
});

await check('Muat ulang: data tetap ada (IndexedDB) dan data contoh tidak diisi ulang', async () => {
  await page.reload();
  await page.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
  await nav('Produk').click();
  ok(await page.getByText('Belum ada produk').first().isVisible().catch(() => false) || (await page.locator('main li').count()) === 0, 'tetap kosong setelah reload');
});

await check('Hapus semua data juga mengosongkan pelanggan dan kasbon', async () => {
  await nav('Kasbon').click();
  await page.getByRole('heading', { name: 'Kasbon' }).waitFor();
  await page.getByText('Belum ada pelanggan').first().waitFor({ timeout: 4000 });
});

// ---- Isi ulang data demo untuk tangkapan layar ponsel & mode gelap ----
await nav('Pengaturan').click();
await page.getByRole('button', { name: 'Isi data demo' }).click();
await page.getByText(/Data demo terisi/).waitFor({ timeout: 60000 });


// ---- Kasbon ----
const budiBalance = async (dlg) => rupiah(await dlg.getByText(/^Kasbon saat ini$/).locator('xpath=following-sibling::span').innerText());
await nav('Kasbon').click();
await page.getByRole('heading', { name: 'Kasbon' }).waitFor();

await check('Kasbon: ringkasan dan daftar yang berutang dari data contoh (yang lunas tidak tampil)', async () => {
  ok(await page.getByText('Total kasbon').first().isVisible(), 'kartu total kasbon');
  const list = page.locator('main li button');
  for (const n of ['Pak Budi', 'Bu Siti', 'Mas Andi']) ok((await list.filter({ hasText: n }).count()) === 1, `${n} berutang`);
  eq(await list.filter({ hasText: 'Bu Rina' }).count(), 0, 'Bu Rina sudah lunas, tidak di tab Berutang');
  await page.getByRole('tab', { name: /^Semua/ }).click();
  eq(await list.filter({ hasText: 'Bu Rina' }).count(), 1, 'Bu Rina ada di tab Semua');
  await page.getByRole('tab', { name: /^Berutang/ }).click();
});
await page.screenshot({ path: join(out, '10-kasbon.png') });

let budiBefore = 0;
await check('Kasbon: detail menampilkan buku kasbon, saldo kepala sama dengan saldo baris terakhir', async () => {
  await page.locator('main li button', { hasText: 'Pak Budi' }).click();
  const dlg = page.getByRole('dialog', { name: 'Pak Budi' });
  await dlg.waitFor();
  const text = await dlg.innerText();
  ok(text.includes('Kasbon manual') && text.includes('Cicilan pertama') && text.includes('Pembayaran Tunai'), 'baris buku kasbon');
  budiBefore = await budiBalance(dlg);
  eq(rupiah(await dlg.locator('ul li').first().getByText(/^Sisa/).innerText()), budiBefore, 'saldo baris terakhir');
  ok(budiBefore > 0, 'Pak Budi masih berutang');
});
await page.screenshot({ path: join(out, '11-kasbon-detail.png') });

await check('Kasbon: bayar melebihi utang ditolak, jumlah sebagian diterima, bukti WhatsApp berisi data yang benar', async () => {
  const dlg = page.getByRole('dialog', { name: 'Pak Budi' });
  await dlg.getByRole('button', { name: /Terima pembayaran/ }).click();
  const pay = page.getByRole('dialog', { name: 'Terima pembayaran Pak Budi' });
  await pay.getByLabel('Jumlah dibayar').fill('99999999');
  await pay.getByText(/Melebihi kasbon/).waitFor();
  ok(await pay.getByRole('button', { name: /^(Lunasi kasbon|Catat pembayaran)/ }).isDisabled(), 'tombol nonaktif saat melebihi utang');
  await pay.getByLabel('Jumlah dibayar').fill('10000');
  await pay.getByRole('button', { name: 'Catat pembayaran' }).click();
  const done = page.getByRole('dialog', { name: 'Pembayaran dicatat' });
  await done.waitFor();
  ok((await done.innerText()).includes(`Rp ${(budiBefore - 10000).toLocaleString('id-ID')}`), 'sisa kasbon setelah cicilan');
  await done.getByRole('button', { name: /Kirim bukti via WhatsApp/ }).click();
  const wa = page.getByRole('dialog', { name: 'Kirim bukti pembayaran' });
  const href = await wa.getByRole('link', { name: /Buka WhatsApp/ }).getAttribute('href');
  ok(href.startsWith('https://wa.me/6281234567890?text='), `tautan WhatsApp: ${href.slice(0, 40)}`);
  const msg = decodeURIComponent(href.split('?text=')[1]);
  ok(msg.includes('Bukti pembayaran kasbon') && msg.includes('Rp 10.000') && msg.includes('Pak Budi'), 'isi pesan bukti bayar');
  await page.keyboard.press('Escape');
  await done.getByRole('button', { name: 'Selesai' }).click();
  eq(await budiBalance(dlg), budiBefore - 10000, 'saldo kepala berkurang 10.000');
  ok((await dlg.locator('ul li').first().innerText()).includes('Pembayaran Tunai'), 'baris pembayaran paling atas');
  await page.keyboard.press('Escape');
});

await check('Kasbon: pengingat WhatsApp berisi total dan lama utang', async () => {
  await page.locator('main li button', { hasText: 'Bu Siti' }).click();
  const dlg = page.getByRole('dialog', { name: 'Bu Siti' });
  await dlg.getByRole('button', { name: /Ingatkan via WhatsApp/ }).click();
  const wa = page.getByRole('dialog', { name: 'Ingatkan Bu Siti' });
  const href = await wa.getByRole('link', { name: /Buka WhatsApp/ }).getAttribute('href');
  ok(href.startsWith('https://wa.me/6285711223344?text='), 'nomor Bu Siti');
  const msg = decodeURIComponent(href.split('?text=')[1]);
  ok(/Halo Bu Siti/.test(msg) && /Kasbon Anda saat ini \*Rp [\d.]+\*/.test(msg), `isi pengingat: ${msg.slice(0, 80)}`);
  await page.keyboard.press('Escape');
  await page.keyboard.press('Escape');
});

// ---- Kasir: kasbon dengan pelanggan baru, batas kasbon, dan split tunai ----
let kasbonReceipt = '';
await nav('Kasir').click();
await check('Kasir: kasbon butuh pelanggan, batas kasbon dijaga, sisanya dibayar tunai', async () => {
  await page.getByRole('button', { name: /^Tambah Indomie Goreng,/ }).click();
  const cart = page.getByRole('region', { name: 'Keranjang' });
  await cart.getByRole('button', { name: 'Tambah Indomie Goreng', exact: true }).click(); // 2 x 3.500 = 7.000
  await page.keyboard.press('F2');
  const dlg = page.getByRole('dialog', { name: 'Pembayaran' });
  await dlg.getByRole('radio', { name: 'Kasbon' }).click();
  ok(await dlg.getByRole('button', { name: 'Catat sebagai kasbon' }).isDisabled(), 'tombol nonaktif tanpa pelanggan');
  await dlg.getByRole('button', { name: 'Pelanggan baru' }).click();
  const form = page.getByRole('dialog', { name: 'Pelanggan baru' });
  await form.getByLabel('Nama', { exact: true }).fill('Bu Dewi');
  await form.getByLabel('Nomor WhatsApp (opsional)').fill('0856 7777 8888');
  await form.getByLabel('Batas kasbon').fill('5000');
  await form.getByRole('button', { name: 'Simpan' }).click();
  await dlg.getByText('Bu Dewi').first().waitFor();
  await dlg.getByText(/Melebihi batas kasbon Bu Dewi/).first().waitFor();
  ok(await dlg.getByRole('button', { name: 'Catat sebagai kasbon' }).isDisabled(), 'tombol nonaktif saat melewati batas');
  await dlg.getByLabel('Jumlah kasbon').fill('5000');
  await dlg.getByRole('button', { name: 'Tambah kasbon Rp 5.000' }).click();
  ok(await dlg.getByRole('radio', { name: 'Kasbon' }).count() === 0, 'kasbon hanya sekali per transaksi');
  await dlg.getByRole('button', { name: 'Uang pas' }).click();
  await dlg.getByRole('button', { name: 'Bayar Tunai' }).click();
  const receipt = page.getByRole('dialog', { name: /^Struk INV-/ });
  await receipt.waitFor();
  kasbonReceipt = (await receipt.getByRole('heading').innerText()).replace('Struk ', '');
  const paper = await receipt.locator('.receipt-sheet').innerText();
  ok(paper.includes('Bu Dewi') && /Kasbon\s+Rp 5\.000/.test(paper) && /Total kasbon\s+Rp 5\.000/.test(paper), `isi struk kasbon: ${paper.slice(-160)}`);
});
await page.screenshot({ path: join(out, '12-struk-kasbon.png') });

await check('Struk: kirim WhatsApp ke pelanggan, nomor salah ditolak, tanpa nomor memakai pemilih kontak', async () => {
  const receipt = page.getByRole('dialog', { name: /^Struk INV-/ });
  await receipt.getByRole('button', { name: 'Kirim WhatsApp' }).click();
  const wa = page.getByRole('dialog', { name: /^Kirim struk INV-/ });
  const number = wa.getByLabel('Nomor WhatsApp');
  eq(await number.inputValue(), '0856 7777 8888', 'nomor pelanggan terisi otomatis');
  const link = wa.getByRole('link', { name: /Buka WhatsApp/ });
  const href = await link.getAttribute('href');
  ok(href.startsWith('https://wa.me/6285677778888?text='), 'tautan memakai nomor pelanggan');
  const msg = decodeURIComponent(href.split('?text=')[1]);
  ok(msg.startsWith('*Warung Manop*') && msg.includes(`Struk *${kasbonReceipt}*`) && msg.includes('*Total kasbon Bu Dewi: Rp 5.000*') && msg.includes('Tunai: Rp 2.000'), 'isi pesan struk');
  await number.fill('abc');
  await wa.getByText(/Nomor tidak valid/).waitFor();
  eq(await wa.getByRole('link', { name: /Buka WhatsApp/ }).count(), 0, 'tidak ada tautan saat nomor tidak valid');
  ok(await wa.getByRole('button', { name: /Buka WhatsApp/ }).isDisabled(), 'tombol nonaktif saat nomor tidak valid');
  await number.fill('');
  ok((await wa.getByRole('link', { name: /Buka WhatsApp/ }).getAttribute('href')).startsWith('https://wa.me/?text='), 'tanpa nomor: pemilih kontak WhatsApp');
  await page.keyboard.press('Escape');
  await receipt.waitFor();
  await page.getByRole('button', { name: 'Transaksi baru' }).click();
});

await check('Riwayat: transaksi kasbon berlabel pelanggan; void membatalkan kasbon dan buku kasbon ikut turun', async () => {
  await nav('Riwayat').click();
  const row = page.locator('main li button', { hasText: 'Kasbon · Bu Dewi' });
  await row.first().click();
  await page.getByRole('button', { name: 'Void', exact: true }).click();
  const v = page.getByRole('dialog', { name: /^Void INV-/ });
  ok((await v.innerText()).includes('Bu Dewi sebesar Rp 5.000'), 'peringatan kasbon ikut dibatalkan');
  await v.getByPlaceholder('Tulis alasan void').fill('Salah input');
  await v.getByRole('button', { name: 'Void transaksi' }).click();
  await v.waitFor({ state: 'hidden' });
  await nav('Kasbon').click();
  await page.getByRole('tab', { name: /^Semua/ }).click();
  await page.locator('main li button', { hasText: 'Bu Dewi' }).click();
  const dlg = page.getByRole('dialog', { name: 'Bu Dewi' });
  const text = await dlg.innerText();
  ok(text.includes('Tidak ada kasbon.') && /Void INV-/.test(text), 'saldo 0 dan baris void di buku kasbon');
  await page.keyboard.press('Escape');
});

await check('Pengaturan: mematikan kasbon menghilangkannya dari layar bayar, lalu dinyalakan lagi', async () => {
  await nav('Pengaturan').click();
  await page.getByRole('switch', { name: /Tawarkan Kasbon/ }).click();
  await page.getByRole('button', { name: 'Simpan pengaturan' }).click();
  await page.getByText('Pengaturan disimpan.').waitFor({ timeout: 4000 });
  await nav('Kasir').click();
  await page.getByRole('button', { name: /^Tambah Indomie Goreng,/ }).click();
  await page.getByRole('button', { name: /^Bayar/ }).first().click();
  const dlg = page.getByRole('dialog', { name: 'Pembayaran' });
  await dlg.getByRole('radio', { name: 'QRIS' }).waitFor();
  eq(await dlg.getByRole('radio', { name: 'Kasbon' }).count(), 0, 'metode Kasbon tidak ada');
  await page.keyboard.press('Escape');
  const cart = page.getByRole('region', { name: 'Keranjang' });
  await cart.getByRole('button', { name: 'Kosongkan' }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Kosongkan' }).click();
  await nav('Pengaturan').click();
  await page.getByRole('switch', { name: /Tawarkan Kasbon/ }).click();
  await page.getByRole('button', { name: 'Simpan pengaturan' }).click();
  await page.getByText('Pengaturan disimpan.').waitFor({ timeout: 4000 });
});

await check('Beranda: kartu Kasbon pelanggan menampilkan total dan yang terbesar', async () => {
  await nav('Beranda').click();
  const card = page.getByRole('region', { name: 'Kasbon pelanggan' });
  await card.waitFor();
  const text = await card.innerText();
  ok(/pelanggan berutang/.test(text) && /Rp [\d.]+/.test(text) && text.includes('Pak Budi'), `kartu kasbon: ${text.slice(0, 120)}`);
});
await page.screenshot({ path: join(out, '13-beranda-kasbon.png') });

// ---- Migrasi: database versi lama (v1, sebelum ada kasbon) harus tetap utuh ----
const legacyServer = createServer((req, res) => {
  res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
  res.end(req.url?.startsWith('/blank') ? '<!doctype html><title>blank</title>' : readFileSync(join(root, 'public/index.html')));
}).listen(0);
const legacyBase = `http://localhost:${legacyServer.address().port}`;
const createLegacyDb = (p, keepOpen) =>
  p.evaluate(async (keep) => {
    await new Promise((resolve, reject) => {
      const req = indexedDB.open('kasirku-pos', 1);
      req.onupgradeneeded = () => {
        for (const t of ['products', 'productUnits', 'stockMovements', 'transactions', 'settings']) req.result.createObjectStore(t, { keyPath: 'id' });
      };
      req.onerror = () => reject(req.error);
      req.onsuccess = () => {
        const db = req.result;
        const tx = db.transaction(['products', 'transactions', 'settings'], 'readwrite');
        tx.objectStore('products').put({ id: 'p1', sku: 'SKU-0001', name: 'Kopi Lama', category: 'Umum', baseUnit: 'pcs', costPrice: 1000, sellPrice: 2000, stock: 10, minStock: 2, active: true, createdAt: '2026-10-01T00:00:00.000Z', updatedAt: '2026-10-01T00:00:00.000Z' });
        tx.objectStore('transactions').put({ id: 't1', receiptNo: 'INV-20261001-0001', dateKey: '2026-10-01', cashierId: 'kasir', cashierName: 'Kasir', items: [{ productId: 'p1', name: 'Kopi Lama', unitName: 'pcs', unitQty: 2, conversion: 1, qty: 2, unitPrice: 2000, costPrice: 1000, discount: 0 }], subtotal: 4000, discount: 0, taxPercent: 0, tax: 0, rounding: 0, total: 4000, payments: [{ method: 'cash', amount: 4000, status: 'success', tendered: 4000 }], change: 0, status: 'completed', createdAt: '2026-10-01T03:00:00.000Z' });
        tx.objectStore('settings').put({ id: 'main', storeName: 'Toko Contoh', address: 'Jl. Lama 1', phone: '', cashierName: 'Kasir', taxEnabled: false, taxPercent: 11, roundingMode: 'none', allowNegativeStock: false, defaultMinStock: 5, expiryWarnDays: 7, costMethod: 'average', receiptFooter: 'Terima kasih!', paperWidth: 58, enabledMethods: ['cash', 'qris'], demoOffered: true });
        tx.oncomplete = () => {
          if (keep) window.__legacyDb = db; // an old tab that never lets go of the database
          else db.close();
          resolve();
        };
        tx.onerror = () => reject(tx.error);
      };
    });
  }, keepOpen);

const legacyCtx = await browser.newContext({ viewport: { width: 1280, height: 860 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
const lp = await legacyCtx.newPage();
activePage = lp;
lp.on('pageerror', (e) => errors.push(`[migrasi] pageerror: ${e.message}`));
await lp.goto(`${legacyBase}/blank`);
await createLegacyDb(lp, false);
await lp.goto(`${legacyBase}/`);
await lp.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
const lnav = (label) => lp.locator('aside').getByRole('button', { name: new RegExp(`^${label}`) });

await check('Migrasi v1: produk, transaksi, dan pengaturan lama utuh; nama bawaan lama jadi Warung Manop', async () => {
  ok((await lp.locator('aside').innerText()).includes('Warung Manop'), 'nama toko baru di sidebar');
  await lnav('Produk').click();
  await lp.getByText('Kopi Lama').first().waitFor();
  await lnav('Riwayat').click();
  await lp.getByRole('button', { name: 'Semua' }).click();
  await lp.locator('main li button', { hasText: 'INV-20261001-0001' }).waitFor();
});
await check('Migrasi v1: pengaturan metode lama dipakai, Kasbon tersedia, dan data kasbon baru tersimpan setelah muat ulang', async () => {
  await lnav('Kasir').click();
  await lp.getByRole('button', { name: /^Tambah Kopi Lama,/ }).click();
  await lp.keyboard.press('F2');
  const dlg = lp.getByRole('dialog', { name: 'Pembayaran' });
  await dlg.getByRole('radio', { name: 'QRIS' }).waitFor();
  eq(await dlg.getByRole('radio', { name: 'Debit' }).count(), 0, 'metode yang dimatikan tetap mati');
  await dlg.getByRole('radio', { name: 'Kasbon' }).click();
  await dlg.getByRole('button', { name: 'Pelanggan baru' }).click();
  const form = lp.getByRole('dialog', { name: 'Pelanggan baru' });
  await form.getByLabel('Nama', { exact: true }).fill('Pak Tono');
  await form.getByRole('button', { name: 'Simpan' }).click();
  await dlg.getByRole('button', { name: 'Catat sebagai kasbon' }).click();
  await lp.getByRole('dialog', { name: /^Struk INV-/ }).waitFor();
  await lp.reload(); // the URL hash (#kasir) is kept, so the app reopens on Kasir, not Beranda
  await lnav('Kasbon').waitFor({ timeout: 20000 });
  await lnav('Kasbon').click();
  await lp.locator('main li button', { hasText: 'Pak Tono' }).waitFor({ timeout: 4000 });
});
await legacyCtx.close();

const blockedCtx = await browser.newContext({ viewport: { width: 1280, height: 860 } });
const holder = await blockedCtx.newPage();
await holder.goto(`${legacyBase}/blank`);
await createLegacyDb(holder, true);
const blocked = await blockedCtx.newPage();
activePage = blocked;
await blocked.goto(`${legacyBase}/`);
await check('Migrasi v1: tab lama yang masih terbuka tidak membuat aplikasi macet, muncul petunjuk jelas', async () => {
  await blocked.getByText(/Tutup tab Bonbon lain/).waitFor({ timeout: 8000 });
});
await blockedCtx.close();
legacyServer.close();

const phone = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, locale: 'id-ID', timezoneId: 'Asia/Jakarta', colorScheme: 'dark' });
const mp = await phone.newPage();
activePage = mp;
mp.on('pageerror', (e) => errors.push(`[ponsel] pageerror: ${e.message}`));
await mp.goto(url);
await mp.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
await mp.waitForTimeout(400);
await check('Ponsel 390px: tidak ada scroll horizontal di semua halaman', async () => {
  for (const name of ['Beranda', 'Kasir', 'Stok', 'Kasbon', 'Riwayat', 'Produk', 'Belanja', 'Kas Laci', 'Laporan']) {
    await phoneGo(mp, name);
    await mp.waitForTimeout(250);
    const w = await mp.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
    ok(w.sw <= w.cw, `${name}: scrollWidth ${w.sw} > ${w.cw}`);
  }
});
await mp.locator('nav[aria-label="Menu utama"]').last().getByRole('button', { name: 'Beranda' }).click();
await mp.waitForTimeout(300);
await mp.screenshot({ path: join(out, '07-ponsel-gelap-beranda.png') });
await mp.locator('nav[aria-label="Menu utama"]').last().getByRole('button', { name: 'Kasir' }).click();
await mp.getByRole('button', { name: /^Tambah Indomie Goreng,/ }).click();
await mp.getByRole('button', { name: /^Tambah Air Mineral 600 ml,/ }).click();
await mp.waitForTimeout(200);
await mp.screenshot({ path: join(out, '08-ponsel-gelap-kasir.png') });
await check('Ponsel: ringkasan keranjang membuka lembar keranjang dan pembayaran', async () => {
  await mp.getByRole('button', { name: 'Buka keranjang' }).click();
  const sheet = mp.getByRole('dialog', { name: 'Keranjang' });
  await sheet.getByRole('button', { name: /^Bayar/ }).click();
  await mp.getByRole('dialog', { name: 'Pembayaran' }).waitFor();
  await mp.screenshot({ path: join(out, '09-ponsel-gelap-bayar.png') });
  await mp.keyboard.press('Escape');
});
await check('Ponsel: halaman Kasbon, detail pelanggan, dan dialog WhatsApp muat di layar', async () => {
  const bar = () => mp.locator('nav[aria-label="Menu utama"]').last();
  await bar().getByRole('button', { name: 'Kasbon' }).click();
  await mp.getByRole('heading', { name: 'Kasbon' }).waitFor();
  await mp.waitForTimeout(250);
  await mp.screenshot({ path: join(out, '14-ponsel-gelap-kasbon.png') });
  await mp.locator('main li button', { hasText: 'Pak Budi' }).click();
  const dlg = mp.getByRole('dialog', { name: 'Pak Budi' });
  await dlg.waitFor();
  await mp.waitForTimeout(250);
  await mp.screenshot({ path: join(out, '15-ponsel-gelap-kasbon-detail.png') });
  await dlg.getByRole('button', { name: /Ingatkan via WhatsApp/ }).click();
  const wa = mp.getByRole('dialog', { name: 'Ingatkan Pak Budi' });
  await wa.waitFor();
  await mp.waitForTimeout(250);
  await mp.screenshot({ path: join(out, '16-ponsel-gelap-wa.png') });
  const w = await mp.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  ok(w.sw <= w.cw, `scroll horizontal: ${w.sw} > ${w.cw}`);
  await mp.keyboard.press('Escape');
  await mp.keyboard.press('Escape');
});

await check('Ponsel: Kas Laci, Opname, Laporan, Retur, dan daftar Tertahan muat di layar tanpa scroll samping', async () => {
  const noOverflow = async (label) => {
    await mp.waitForTimeout(250);
    const w = await mp.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
    ok(w.sw <= w.cw, `${label}: scrollWidth ${w.sw} > ${w.cw}`);
  };
  await phoneGo(mp, 'Kas Laci');
  await mp.getByRole('heading', { name: 'Kas Laci' }).waitFor();
  await mp.getByRole('button', { name: 'Uang masuk' }).click();
  await mp.getByRole('dialog', { name: 'Uang masuk ke laci' }).waitFor();
  await noOverflow('dialog uang masuk');
  await mp.screenshot({ path: join(out, '27-ponsel-kas.png') });
  await mp.keyboard.press('Escape');
  await phoneGo(mp, 'Stok');
  await mp.getByRole('tab', { name: 'Opname' }).click();
  await mp.getByRole('button', { name: /^Mulai opname/ }).click();
  await mp.getByRole('textbox', { name: /^Jumlah dihitung/ }).first().waitFor();
  await noOverflow('opname');
  await mp.screenshot({ path: join(out, '28-ponsel-opname.png') });
  await mp.getByRole('button', { name: 'Batalkan', exact: true }).click();
  await mp.getByRole('dialog', { name: 'Batalkan opname?' }).getByRole('button', { name: 'Batalkan opname' }).click();
  await phoneGo(mp, 'Laporan');
  await mp.getByRole('heading', { name: 'Laporan' }).waitFor();
  for (const tab of ['Ringkasan', 'Produk', 'Pembayaran', 'Stok', 'Kasbon']) {
    await mp.getByRole('tab', { name: tab }).click();
    await noOverflow(`laporan ${tab}`);
  }
  await mp.screenshot({ path: join(out, '29-ponsel-laporan.png') });
  await phoneGo(mp, 'Riwayat');
  await mp.getByLabel('Filter status').selectOption({ label: 'Selesai' });
  await mp.locator('main li button', { hasText: 'Tunai' }).first().click();
  await mp.getByRole('dialog', { name: /^Struk INV-/ }).getByRole('button', { name: 'Retur', exact: true }).click();
  const ret = mp.getByRole('dialog', { name: /^Retur INV-/ });
  await ret.waitFor();
  const box = await ret.boundingBox();
  ok(box && box.x >= 0 && box.x + box.width <= 390, `dialog retur keluar layar: ${JSON.stringify(box)}`);
  await mp.screenshot({ path: join(out, '30-ponsel-retur.png') });
  await mp.keyboard.press('Escape');
  await mp.keyboard.press('Escape');
  await phoneGo(mp, 'Kasir');
  await mp.getByRole('button', { name: /^Keranjang tertahan/ }).click();
  await mp.getByRole('dialog', { name: /^Keranjang tertahan/ }).waitFor();
  await noOverflow('daftar tertahan');
  await mp.screenshot({ path: join(out, '31-ponsel-tertahan.png') });
  await mp.keyboard.press('Escape');
});

await check('Tema: pilihan Otomatis, Terang, Gelap di Pengaturan; Otomatis mengikuti HP, pilihan bertahan setelah muat ulang', async () => {
  const tctx = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta', colorScheme: 'dark' });
  const tp = await tctx.newPage();
  try {
    await tp.goto(url + '#pengaturan');
    await tp.locator('main').waitFor({ timeout: 20000 });
    const bg = () => tp.evaluate(() => getComputedStyle(document.body).backgroundColor);
    const DARK = 'rgb(11, 13, 31)';
    const LIGHT = 'rgb(245, 247, 252)';
    ok((await bg()) === DARK, 'Otomatis + HP mode gelap = gelap');
    await tp.getByRole('button', { name: 'Terang' }).click();
    ok((await bg()) === LIGHT, 'Terang memaksa terang walau HP gelap');
    await tp.reload();
    await tp.locator('main').waitFor();
    ok((await bg()) === LIGHT, 'pilihan Terang bertahan setelah muat ulang');
    ok((await tp.getByRole('button', { name: 'Terang' }).getAttribute('aria-pressed')) === 'true', 'tombol Terang tampak terpilih');
    await tp.getByRole('button', { name: 'Gelap' }).click();
    ok((await bg()) === DARK, 'Gelap');
    await tp.getByRole('button', { name: 'Otomatis' }).click();
    ok((await bg()) === DARK && (await tp.evaluate(() => document.documentElement.hasAttribute('data-theme'))) === false, 'Otomatis kembali mengikuti HP');
  } finally {
    await tctx.close();
  }
});

const narrow = await browser.newContext({ viewport: { width: 360, height: 740 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
const np = await narrow.newPage();
activePage = np;
await np.goto(url);
await np.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
await check('Ponsel 360px: enam menu bawah tidak terpotong dan halaman tidak bergeser menyamping', async () => {
  const bar = np.locator('nav[aria-label="Menu utama"]').last();
  const sizes = await bar.getByRole('button').evaluateAll((els) => els.map((b) => ({ t: b.innerText.trim(), sw: b.scrollWidth, cw: b.clientWidth })));
  eq(sizes.length, 6, 'jumlah menu');
  for (const s of sizes) ok(s.sw <= s.cw, `menu "${s.t}" terpotong (${s.sw} > ${s.cw})`);
  for (const name of ['Kasbon', 'Kasir', 'Riwayat']) {
    await bar.getByRole('button', { name }).click();
    await np.waitForTimeout(200);
    const w = await np.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
    ok(w.sw <= w.cw, `${name}: scrollWidth ${w.sw} > ${w.cw}`);
  }
  await np.screenshot({ path: join(out, '17-ponsel-360.png') });
});
await narrow.close();

// Regresi: keranjang berisi banyak item di ponsel. Tombol Bayar harus tetap terlihat dan daftar bergeser dengan sentuhan.
const touch = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
for (const [w, h] of [[390, 844], [360, 640], [360, 480]]) {
  await check(`Ponsel ${w}x${h}: keranjang penuh (banyak item), tombol Bayar tetap terlihat dan daftar bisa digeser dengan sentuhan`, async () => {
    const q = await touch.newPage();
    activePage = q;
    try {
      await q.setViewportSize({ width: w, height: h });
      await q.goto(url);
      await q.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
      await q.locator('nav[aria-label="Menu utama"]').last().getByRole('button', { name: 'Kasir' }).click();
      const tiles = q.locator('button[aria-label^="Tambah "]:not([disabled])').filter({ hasText: /Rp/ });
      const n = await tiles.count();
      ok(n >= 12, `butuh banyak produk untuk uji ini, hanya ${n}`);
      for (let i = 0; i < n; i++) await tiles.nth(i).click();
      await q.getByRole('button', { name: 'Buka keranjang' }).click();
      const sheet = q.getByRole('dialog', { name: 'Keranjang' });
      await sheet.waitFor();
      await q.waitForTimeout(300);
      const focused = await q.evaluate(() => document.activeElement?.tagName);
      ok(focused !== 'INPUT' && focused !== 'SELECT' && focused !== 'TEXTAREA', `membuka keranjang tidak boleh memfokuskan kolom isian (keyboard ponsel menutupi tombol Bayar): ${focused}`);
      const geo = await q.evaluate(() => {
        const d = document.querySelector('[role=dialog]');
        const pay = [...d.querySelectorAll('button')].find((x) => x.textContent.trim().startsWith('Bayar'));
        const list = [...d.querySelectorAll('.scroll-y')].filter((e) => e.querySelector('li')).pop();
        const pb = pay.getBoundingClientRect();
        const lb = list.getBoundingClientRect();
        return { payTop: pb.top, payBottom: pb.bottom, vh: innerHeight, listH: lb.height, listScrollable: list.scrollHeight > list.clientHeight + 1, listX: lb.left + lb.width * 0.05, listY: lb.top + lb.height / 2 };
      });
      ok(geo.payTop >= 0 && geo.payBottom <= geo.vh, `tombol Bayar di luar layar: ${Math.round(geo.payTop)}-${Math.round(geo.payBottom)} dari tinggi ${geo.vh}`);
      ok(geo.listScrollable, 'daftar harus punya area gulir sendiri');
      const cdp = await touch.newCDPSession(q);
      const readTop = () => q.evaluate(() => [...document.querySelectorAll('[role=dialog] .scroll-y')].filter((e) => e.querySelector('li')).pop().scrollTop);
      const t0 = await readTop();
      const x = geo.listX;
      let y = geo.listY;
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y }] });
      for (let i = 1; i <= 12; i++) {
        await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x, y: y - (i * Math.min(200, geo.listH * 0.6)) / 12 }] });
        await q.waitForTimeout(16);
      }
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
      await q.waitForTimeout(500);
      const t1 = await readTop();
      ok(t1 > t0 + 20, `daftar tidak bergeser oleh sentuhan (${t0} -> ${t1})`);
      // Bayar tetap di tempatnya dan bisa ditekan
      await sheet.getByRole('button', { name: /^Bayar/ }).click({ timeout: 4000 });
      await q.getByRole('dialog', { name: 'Pembayaran' }).waitFor();
      if (w === 390) await q.screenshot({ path: join(out, '18-ponsel-keranjang-penuh.png') });
    } finally {
      await q.close();
    }
  });
}
await check('Ponsel layar pendek (lanskap 800x360): Bayar langsung terlihat di keranjang penuh', async () => {
  const q = await touch.newPage();
  activePage = q;
  try {
    await q.setViewportSize({ width: 800, height: 360 });
    await q.goto(url);
    await q.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
    await q.locator('nav[aria-label="Menu utama"]:visible').getByRole('button', { name: /^Kasir/ }).click(); // di 800px yang tampil sidebar
    const tiles = q.locator('button[aria-label^="Tambah "]:not([disabled])').filter({ hasText: /Rp/ });
    // di layar 360px tinggi, bilah ringkasan dan menu bawah menutupi sebagian kartu: isi keranjang lewat klik DOM
    for (let i = 0, n = await tiles.count(); i < n; i++) await tiles.nth(i).evaluate((el) => el.click());
    await q.getByRole('button', { name: 'Buka keranjang' }).click();
    const sheet = q.getByRole('dialog', { name: 'Keranjang' });
    await sheet.waitFor();
    await q.waitForTimeout(300);
    const box = await sheet.getByRole('button', { name: /^Bayar/ }).boundingBox();
    ok(box && box.y >= 0 && box.y + box.height <= 360, `Bayar harus terlihat tanpa menggulir di layar lanskap 360px: y ${box?.y} tinggi ${box?.height}`);
    await sheet.getByRole('button', { name: /^Bayar/ }).click({ timeout: 4000 });
    await q.getByRole('dialog', { name: 'Pembayaran' }).waitFor();
  } finally {
    await q.close();
  }
});
await touch.close();

// ---- Scan barcode dengan kamera. Chromium memutar video palsu berisi barcode EAN-13 sungguhan. ----
const INDOMIE = '8998866200301';
const TIDAK_ADA = withCheckDigit('899123456789'); // kode sah, tetapi tidak ada di katalog
const camFile = join(tmpdir(), `warung-manop-kamera-${process.pid}.y4m`);
writeBarcodeVideo(camFile, [
  { code: null, frames: 6 },
  { code: INDOMIE, frames: 12 },
  { code: null, frames: 6 },
  { code: INDOMIE, frames: 12 },
  { code: null, frames: 6 },
  { code: TIDAK_ADA, frames: 12 },
  { code: null, frames: 6 },
]);
const camBrowser = await chromium.launch({
  args: ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream', `--use-file-for-fake-video-capture=${camFile}`],
});
const camPhone = { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2, permissions: ['camera'], locale: 'id-ID', timezoneId: 'Asia/Jakarta' };
const openKasir = async (q) => {
  await q.goto(url);
  await q.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
  await q.locator('nav[aria-label="Menu utama"]').last().getByRole('button', { name: 'Kasir' }).click();
};
const cartQty = async (q, name) => {
  await q.getByRole('button', { name: 'Buka keranjang' }).click();
  const v = await q.getByRole('dialog', { name: 'Keranjang' }).getByLabel(`Jumlah ${name}`).inputValue();
  await q.keyboard.press('Escape');
  return Number(v);
};
const scannedCount = async (dlg) => Number(/\((\d+) dipindai\)/.exec(await dlg.getByRole('button', { name: /^Selesai/ }).innerText())?.[1] ?? 0);

await check('Scan kamera (pemindai bawaan aplikasi): barcode terbaca, produk masuk keranjang, kode tak dikenal ditolak jelas', async () => {
  const ctx = await camBrowser.newContext(camPhone);
  await ctx.addInitScript(() => { delete window.BarcodeDetector; }); // paksa jalur decoder aplikasi
  const q = await ctx.newPage();
  activePage = q;
  q.on('pageerror', (e) => errors.push(`[kamera] pageerror: ${e.message}`));
  try {
    await openKasir(q);
    await q.getByRole('button', { name: 'Scan barcode dengan kamera' }).click();
    const dlg = q.getByRole('dialog', { name: 'Scan barang' });
    await dlg.waitFor();
    await dlg.getByText('Indomie Goreng ditambahkan').waitFor({ timeout: 25000 });
    await q.screenshot({ path: join(out, '19-scan-kamera.png') });
    await dlg.getByRole('button', { name: /\(2 dipindai\)/ }).waitFor({ timeout: 25000 }); // dilepas dari pandangan lalu dipindai lagi = tambah lagi
    await dlg.getByText(/Barcode \d+ belum terdaftar/).waitFor({ timeout: 25000 });
    await q.screenshot({ path: join(out, '20-scan-kamera-tak-dikenal.png') });
    const n = await scannedCount(dlg);
    ok(n >= 2 && n <= 4, `kode yang terus terlihat tidak boleh ditambah berulang kali (jumlah ${n})`);
    await dlg.getByRole('button', { name: /^Selesai/ }).click();
    await dlg.waitFor({ state: 'detached' });
    const qty = await cartQty(q, 'Indomie Goreng');
    ok(qty >= n && qty <= n + 1, `jumlah di keranjang ${qty} tidak cocok dengan hasil pindai ${n}`);
  } finally {
    await ctx.close();
  }
});

await check('Scan kamera (BarcodeDetector bawaan peramban): dipakai bila ada, tidak menghitung ganda, kode asing ditolak', async () => {
  const ctx = await camBrowser.newContext(camPhone);
  await ctx.addInitScript(() => {
    window.__code = '';
    window.BarcodeDetector = class {
      static async getSupportedFormats() { return ['ean_13', 'ean_8', 'upc_a', 'code_128']; }
      async detect() { return window.__code ? [{ rawValue: window.__code, format: 'ean_13' }] : []; }
    };
  });
  const q = await ctx.newPage();
  activePage = q;
  q.on('pageerror', (e) => errors.push(`[kamera-bawaan] pageerror: ${e.message}`));
  try {
    await openKasir(q);
    await q.getByRole('button', { name: 'Scan barcode dengan kamera' }).click();
    const dlg = q.getByRole('dialog', { name: 'Scan barang' });
    await dlg.waitFor();
    await q.waitForTimeout(800); // kamera siap
    await q.evaluate(() => { window.__code = '8998866200318'; });
    await dlg.getByText('Indomie Soto ditambahkan').waitFor({ timeout: 8000 });
    await q.waitForTimeout(1200); // tetap terlihat: tidak boleh bertambah
    eq(await scannedCount(dlg), 1, 'kode yang tetap di depan kamera hanya dihitung sekali');
    await q.evaluate(() => { window.__code = ''; });
    await q.waitForTimeout(900);
    await q.evaluate(() => { window.__code = '8998866200318'; });
    await dlg.getByRole('button', { name: /\(2 dipindai\)/ }).waitFor({ timeout: 8000 });
    await q.evaluate(() => { window.__code = ''; });
    await q.waitForTimeout(900);
    await q.evaluate(() => { window.__code = '8998866200301'; }); // Indomie Goreng
    await dlg.getByRole('button', { name: /\(3 dipindai\)/ }).waitFor({ timeout: 8000 });
    await q.evaluate(() => { window.__code = ''; });
    await q.waitForTimeout(900);
    await q.evaluate(() => { window.__code = '1234567890128'; });
    await dlg.getByText('Barcode 1234567890128 belum terdaftar. Tambahkan lewat menu Produk.').waitFor({ timeout: 8000 });
    await q.evaluate(() => { window.__code = ''; });
    await dlg.getByRole('button', { name: /^Selesai/ }).click();
    eq(await cartQty(q, 'Indomie Soto'), 2, 'Indomie Soto');
    eq(await cartQty(q, 'Indomie Goreng'), 1, 'Indomie Goreng');
  } finally {
    await ctx.close();
  }
});

await check('Scan kamera: stok habis ditolak dengan pesan di pemindai, bukan menambah diam-diam', async () => {
  const ctx = await camBrowser.newContext(camPhone);
  await ctx.addInitScript(() => {
    window.__code = '';
    window.BarcodeDetector = class {
      static async getSupportedFormats() { return ['ean_13']; }
      async detect() { return window.__code ? [{ rawValue: window.__code, format: 'ean_13' }] : []; }
    };
  });
  const q = await ctx.newPage();
  activePage = q;
  try {
    await openKasir(q);
    await q.getByRole('button', { name: 'Scan barcode dengan kamera' }).click();
    const dlg = q.getByRole('dialog', { name: 'Scan barang' });
    await dlg.waitFor();
    await q.waitForTimeout(800);
    await q.evaluate(() => { window.__code = '8996001600146'; }); // Teh Botol 450 ml: stok 0 di data contoh
    await dlg.getByText(/Teh Botol 450 ml habis/).waitFor({ timeout: 8000 });
    eq(await scannedCount(dlg), 0, 'tidak ada yang dihitung');
  } finally {
    await ctx.close();
  }
});

await check('Form Produk: tombol Scan mengisi kolom barcode, kode yang sudah dipakai produk lain ditolak', async () => {
  const ctx = await camBrowser.newContext(camPhone);
  await ctx.addInitScript(() => { delete window.BarcodeDetector; });
  const q = await ctx.newPage();
  activePage = q;
  try {
    await q.goto(url);
    await q.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
    await phoneGo(q, 'Produk');
    await q.getByRole('button', { name: /Tambah produk/ }).first().click();
    const form = q.getByRole('dialog', { name: 'Tambah produk' });
    await form.waitFor();
    await form.getByRole('button', { name: 'Scan barcode dengan kamera' }).click();
    const dlg = q.getByRole('dialog', { name: 'Scan barcode produk' });
    await dlg.waitFor();
    // video memutar Indomie Goreng (sudah ada, ditolak) lalu kode baru (mengisi dan menutup)
    await dlg.waitFor({ state: 'detached', timeout: 40000 });
    eq(await form.getByLabel('Barcode (opsional)').inputValue(), TIDAK_ADA, 'isi kolom barcode');
    await q.screenshot({ path: join(out, '21-produk-scan-barcode.png') });
  } finally {
    await ctx.close();
  }
});

await check('Kamera ditolak atau tidak ada: pesan jelas, tombol Coba lagi, dan ketik kode manual tetap berfungsi', async () => {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
  await ctx.addInitScript(() => {
    Object.defineProperty(navigator, 'mediaDevices', {
      configurable: true,
      value: { getUserMedia: () => Promise.reject(Object.assign(new Error('denied'), { name: 'NotAllowedError' })) },
    });
  });
  const q = await ctx.newPage();
  activePage = q;
  try {
    await openKasir(q);
    await q.getByRole('button', { name: 'Scan barcode dengan kamera' }).click();
    const dlg = q.getByRole('dialog', { name: 'Scan barang' });
    await dlg.getByText(/Izin kamera ditolak/).waitFor({ timeout: 8000 });
    await dlg.getByRole('button', { name: 'Coba lagi' }).waitFor();
    await q.screenshot({ path: join(out, '22-scan-kamera-ditolak.png') });
    await dlg.getByLabel('Kode barcode atau SKU').fill('MKN-001'); // SKU juga dikenali
    await dlg.getByRole('button', { name: 'OK' }).click();
    await dlg.getByText('Indomie Goreng ditambahkan').waitFor({ timeout: 5000 });
    await dlg.getByLabel('Kode barcode atau SKU').fill('000');
    await dlg.getByRole('button', { name: 'OK' }).click();
    await dlg.getByText(/Barcode 000 belum terdaftar/).waitFor({ timeout: 5000 });
  } finally {
    await ctx.close();
  }
});
await camBrowser.close();
rmSync(camFile, { force: true });


// ---- Cetak struk di printer kecil (thermal 58/80 mm) ----
// Penyebab "hanya bisa di printer besar": `@page { size: 58mm auto }` tidak valid, jadi Chromium memakai kertas Letter.
// Di sini halaman cetak diuji lewat PDF sungguhan (page.pdf), dan jalur Bluetooth/RawBT lewat tiruan.
const pdfPages = (buf) => {
  const t = buf.toString('latin1');
  const boxes = [...t.matchAll(/\/MediaBox\s*\[([^\]]+)\]/g)].map((m) => m[1].trim().split(/\s+/).slice(2).map((n) => (Number(n) / 72) * 25.4));
  return { pages: (t.match(/\/Type\s*\/Page[^s]/g) ?? []).length, boxes };
};
const decodeAscii = (arr) => Buffer.from(arr).toString('latin1');
async function bayarTunaiDesktop(q, banyak) {
  await q.goto(url);
  await q.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
  await q.locator('aside').getByRole('button', { name: /^Kasir/ }).click();
  const tiles = q.locator('button[aria-label^="Tambah "]:not([disabled])').filter({ hasText: /Rp/ });
  const n = Math.min(banyak, await tiles.count());
  for (let i = 0; i < n; i++) await tiles.nth(i).click();
  await q.keyboard.press('F2');
  const dlg = q.getByRole('dialog', { name: 'Pembayaran' });
  await dlg.waitFor();
  await dlg.getByRole('button', { name: 'Uang pas' }).click();
  await dlg.getByRole('button', { name: 'Bayar Tunai' }).click();
  const receipt = q.getByRole('dialog', { name: /^Struk INV-/ });
  await receipt.waitFor();
  return receipt;
}

await check('Cetak struk (peramban): satu lembar sempit 58 mm lalu 80 mm, hanya struk yang tercetak, tidak ada kertas kosong', async () => {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 860 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
  await ctx.addInitScript(() => {
    Object.defineProperty(navigator, 'bluetooth', { value: undefined, configurable: true });
    window.__prints = 0;
    window.print = () => { window.__prints++; };
  });
  const q = await ctx.newPage();
  activePage = q;
  try {
    const receipt = await bayarTunaiDesktop(q, 14); // struk panjang: 14 produk berbeda
    await receipt.getByRole('button', { name: 'Cetak' }).click();
    const dlg = q.getByRole('dialog', { name: 'Cetak struk' });
    await dlg.waitFor();
    eq(await dlg.getByRole('button', { name: '58 mm' }).getAttribute('aria-pressed'), 'true', 'lebar bawaan dari Pengaturan');
    eq(await dlg.getByRole('button', { name: /Pilih printer dan cetak/ }).count(), 0, 'tanpa Bluetooth, tombolnya tidak ada');
    await dlg.getByText(/tidak punya Bluetooth langsung/).waitFor();
    await q.screenshot({ path: join(out, '23-dialog-cetak.png') });

    for (const [paper, wantMm, chars] of [[58, 58, 32], [80, 80, 48]]) {
      await dlg.getByRole('button', { name: `${paper} mm`, exact: true }).click();
      const before = await q.evaluate(() => window.__prints);
      await dlg.getByRole('button', { name: 'Buka dialog cetak' }).click();
      eq(await q.evaluate(() => window.__prints), before + 1, 'window.print dipanggil sekali');
      const info = await q.evaluate(() => {
        const root = document.getElementById('print-root');
        const rows = [...root.children];
        return { paper: root.dataset.paper, n: rows.length, longest: Math.max(...rows.map((r) => r.textContent.length)), printing: document.body.classList.contains('printing'), pageRule: document.querySelector('style[data-print-page]').textContent };
      });
      eq(info.paper, String(paper), 'lebar kertas');
      ok(info.printing, 'body harus bertanda printing');
      ok(info.n > 30, `struk panjang harus punya banyak baris, dapat ${info.n}`);
      ok(info.longest <= chars, `baris terpanjang ${info.longest} > ${chars} karakter`);
      ok(new RegExp(`size: ${paper}mm \\d+mm`).test(info.pageRule) && !/auto/.test(info.pageRule), `aturan @page harus punya tinggi pasti: ${info.pageRule}`);

      await q.emulateMedia({ media: 'print' });
      const layout = await q.evaluate(() => {
        const visible = [...document.body.children].filter((e) => !['SCRIPT', 'STYLE', 'LINK'].includes(e.tagName) && getComputedStyle(e).display !== 'none').map((e) => e.id || e.tagName);
        const root = document.getElementById('print-root');
        const clipped = [...root.children].filter((r) => r.scrollWidth > r.clientWidth + 1).length;
        const cs = getComputedStyle(document.body);
        return { visible, clipped, bg: cs.backgroundColor, pad: cs.paddingTop, color: getComputedStyle(root).color };
      });
      eq(layout.visible.join(','), 'print-root', 'yang tampil saat cetak');
      eq(layout.clipped, 0, 'baris yang terpotong');
      eq(layout.color, 'rgb(0, 0, 0)', 'teks cetak harus hitam');
      eq(layout.pad, '0px', 'jarak atas halaman saat cetak');
      const pdf = pdfPages(await q.pdf({ preferCSSPageSize: true, printBackground: true }));
      eq(pdf.pages, 1, `jumlah halaman (${paper} mm)`);
      ok(Math.abs(pdf.boxes[0][0] - wantMm) < 0.6, `lebar kertas ${pdf.boxes[0][0].toFixed(1)} mm, harusnya ${wantMm} mm (bukan Letter 215,9 mm)`);
      ok(pdf.boxes[0][1] > 80 && pdf.boxes[0][1] < 400, `tinggi kertas ${pdf.boxes[0][1].toFixed(1)} mm tidak wajar`);
      await q.emulateMedia({ media: 'screen' });

      await q.evaluate(() => window.dispatchEvent(new Event('afterprint')));
      eq(await q.evaluate(() => !!document.getElementById('print-root') || document.body.classList.contains('printing') || !!document.querySelector('style[data-print-page]')), false, 'dibersihkan setelah cetak');
    }
  } finally {
    await ctx.close();
  }
});

const fakeBluetooth = (mode) => `(() => {
  const mode = ${JSON.stringify(mode)};
  window.__bt = { requests: 0, writes: [], connects: 0 };
  const writable = { properties: { write: false, writeWithoutResponse: true }, writeValueWithoutResponse: async (v) => { window.__bt.writes.push(Array.from(new Uint8Array(v))); } };
  const readOnly = { properties: { write: false, writeWithoutResponse: false } };
  const device = { name: 'MPT-II', gatt: { connected: false, connect: async function () { window.__bt.connects++; this.connected = true; return { connected: true, disconnect: () => { device.gatt.connected = false; }, getPrimaryServices: async () => [{ getCharacteristics: async () => (mode === 'nowrite' ? [readOnly] : [readOnly, writable]) }] }; } } };
  Object.defineProperty(navigator, 'bluetooth', { configurable: true, value: { requestDevice: async (opts) => {
    window.__bt.requests++; window.__bt.opts = opts;
    if (mode === 'cancel') { const e = new Error('cancelled'); e.name = 'NotFoundError'; throw e; }
    return device;
  } } });
})();`;

await check('Cetak struk (Bluetooth): hanya tersedia bila didukung, byte ESC/POS terkirim utuh per potongan kecil, printer diingat', async () => {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 860 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
  await ctx.addInitScript(fakeBluetooth('ok'));
  const q = await ctx.newPage();
  activePage = q;
  try {
    const receipt = await bayarTunaiDesktop(q, 3);
    const struk = await receipt.locator('.receipt-sheet').innerText();
    await receipt.getByRole('button', { name: 'Cetak' }).click();
    const dlg = q.getByRole('dialog', { name: 'Cetak struk' });
    await dlg.getByRole('button', { name: 'Pilih printer dan cetak' }).click();
    await dlg.getByText(/Struk dikirim ke MPT-II/).waitFor({ timeout: 10000 });
    const bt = await q.evaluate(() => window.__bt);
    eq(bt.requests, 1, 'pemilih printer dibuka sekali');
    ok(bt.opts.acceptAllDevices === true && bt.opts.optionalServices.includes('000018f0-0000-1000-8000-00805f9b34fb'), 'layanan printer didaftarkan');
    ok(bt.writes.length > 5 && bt.writes.every((w) => w.length <= 20), `potongan harus kecil, dapat ${bt.writes.map((w) => w.length).join(',')}`);
    const all = bt.writes.flat();
    eq(all.slice(0, 2).join(','), '27,64', 'diawali ESC @');
    eq(all.slice(-3).join(','), '27,100,4', 'diakhiri umpan kertas');
    const text = decodeAscii(all);
    ok(text.includes('Warung Manop') && text.includes('TOTAL') && text.includes('INV-'), 'isi struk di byte yang terkirim');
    ok(all.every((b) => b < 128), 'hanya ASCII');
    ok(struk.includes('TOTAL'), 'struk di layar ada');
    await dlg.getByRole('button', { name: 'Cetak ke MPT-II' }).waitFor();
    await q.screenshot({ path: join(out, '24-cetak-bluetooth.png') });
    await dlg.getByRole('button', { name: 'Cetak ke MPT-II' }).click();
    await until(async () => (await q.evaluate(() => window.__bt.writes.length)) > bt.writes.length * 1.9, 'cetak kedua', 10000);
    const bt2 = await q.evaluate(() => ({ requests: window.__bt.requests }));
    eq(bt2.requests, 1, 'printer yang sama dipakai lagi tanpa membuka pemilih');
  } finally {
    await ctx.close();
  }
});

await check('Cetak struk (Bluetooth): dibatalkan, atau printer tanpa jalur tulis, menampilkan pesan jelas dan tidak macet', async () => {
  for (const [mode, want] of [['cancel', /Tidak ada printer yang dipilih/], ['nowrite', /tidak membuka jalur cetak Bluetooth LE/]]) {
    const ctx = await browser.newContext({ viewport: { width: 1280, height: 860 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
    await ctx.addInitScript(fakeBluetooth(mode));
    const q = await ctx.newPage();
    activePage = q;
    try {
      const receipt = await bayarTunaiDesktop(q, 1);
      await receipt.getByRole('button', { name: 'Cetak' }).click();
      const dlg = q.getByRole('dialog', { name: 'Cetak struk' });
      await dlg.getByRole('button', { name: 'Pilih printer dan cetak' }).click();
      await dlg.getByText(want).waitFor({ timeout: 8000 });
      ok(await dlg.getByRole('button', { name: 'Pilih printer dan cetak' }).isEnabled(), 'tombol bisa dicoba lagi');
    } finally {
      await ctx.close();
    }
  }
});

await check('Cetak struk (Android): tombol RawBT mengirim byte ESC/POS lewat tautan intent, dan tidak muncul di desktop', async () => {
  const ctx = await browser.newContext({
    viewport: { width: 390, height: 844 },
    isMobile: true,
    hasTouch: true,
    locale: 'id-ID',
    timezoneId: 'Asia/Jakarta',
    userAgent: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36',
  });
  await ctx.addInitScript(() => {
    Object.defineProperty(navigator, 'bluetooth', { value: undefined, configurable: true });
    window.__links = [];
    const click = HTMLAnchorElement.prototype.click;
    HTMLAnchorElement.prototype.click = function () {
      if (this.href.startsWith('intent:')) window.__links.push(this.href);
      else click.call(this);
    };
  });
  const q = await ctx.newPage();
  activePage = q;
  try {
    await openKasir(q);
    await q.getByRole('button', { name: /^Tambah Indomie Goreng,/ }).click();
    await q.getByRole('button', { name: 'Buka keranjang' }).click();
    await q.getByRole('dialog', { name: 'Keranjang' }).getByRole('button', { name: /^Bayar/ }).click();
    const pay = q.getByRole('dialog', { name: 'Pembayaran' });
    await pay.getByRole('button', { name: 'Uang pas' }).click();
    await pay.getByRole('button', { name: 'Bayar Tunai' }).click();
    const receipt = q.getByRole('dialog', { name: /^Struk INV-/ });
    await receipt.waitFor();
    await receipt.getByRole('button', { name: 'Cetak' }).click();
    const dlg = q.getByRole('dialog', { name: 'Cetak struk' });
    await dlg.getByRole('button', { name: 'Cetak lewat RawBT' }).waitFor();
    await q.screenshot({ path: join(out, '25-cetak-ponsel.png') });
    await dlg.getByRole('button', { name: 'Cetak lewat RawBT' }).click();
    const links = await q.evaluate(() => window.__links);
    eq(links.length, 1, 'tautan RawBT dibuka sekali');
    const m = links[0].match(/^intent:base64,([A-Za-z0-9+/=]+)#Intent;scheme=rawbt;.*package=ru\.a402d\.rawbtprinter;end;$/);
    ok(m, `bentuk tautan: ${links[0].slice(0, 80)}`);
    const bytes = [...Buffer.from(m[1], 'base64')];
    eq(bytes.slice(0, 2).join(','), '27,64', 'diawali ESC @');
    ok(decodeAscii(bytes).includes('TOTAL'), 'isi struk ada di tautan');
  } finally {
    await ctx.close();
  }
});

// ---- Laporan dicetak / disimpan sebagai PDF (A4) ----
await check('Cetak laporan (peramban): satu dokumen A4 berisi judul, periode, dan tabel; hanya laporan yang tercetak', async () => {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 860 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
  await ctx.addInitScript(() => {
    window.__prints = 0;
    window.print = () => { window.__prints++; };
  });
  const q = await ctx.newPage();
  activePage = q;
  try {
    await q.goto(url);
    await q.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
    await q.locator('aside').getByRole('button', { name: /^Laporan/ }).click();
    await q.getByRole('button', { name: 'Bulan ini' }).click();
    await q.getByRole('tab', { name: 'Produk' }).click();
    await q.getByRole('button', { name: 'Cetak / Simpan PDF' }).click();
    eq(await q.evaluate(() => window.__prints), 1, 'window.print dipanggil sekali');
    const info = await q.evaluate(() => {
      const r = document.getElementById('print-report');
      return {
        title: r.querySelector('h1').textContent,
        store: r.querySelector('.pr-store').textContent,
        tables: r.querySelectorAll('table').length,
        rows: r.querySelectorAll('tbody tr').length,
        printing: document.body.classList.contains('printing-report'),
        pageRule: document.querySelector('style[data-print-page]').textContent,
      };
    });
    eq(info.title, 'Laporan Produk', 'judul');
    eq(info.store, 'Warung Manop', 'nama toko');
    eq(info.tables, 2, 'tabel produk dan kategori');
    ok(info.rows >= 6, `baris tabel: ${info.rows}`);
    ok(info.printing && /A4/.test(info.pageRule), `aturan halaman: ${info.pageRule}`);
    await q.emulateMedia({ media: 'print' });
    const visible = await q.evaluate(() => [...document.body.children].filter((e) => !['SCRIPT', 'STYLE', 'LINK'].includes(e.tagName) && getComputedStyle(e).display !== 'none').map((e) => e.id || e.tagName));
    eq(visible.join(','), 'print-report', 'hanya laporan yang terlihat saat mencetak');
    const pdf = await q.pdf({ preferCSSPageSize: true, printBackground: true });
    const { pages, boxes } = pdfPages(pdf);
    ok(pages >= 1 && pages <= 4, `jumlah halaman ${pages}`);
    for (const [w, h] of boxes) ok(Math.abs(w - 210) < 1.5 && Math.abs(h - 297) < 1.5, `ukuran halaman harus A4, dapat ${w.toFixed(0)}x${h.toFixed(0)} mm`);
    await q.emulateMedia({ media: 'screen' });
    await q.evaluate(() => window.dispatchEvent(new Event('afterprint')));
    eq(await q.evaluate(() => document.getElementById('print-report') === null && !document.body.classList.contains('printing-report')), true, 'dibersihkan setelah cetak');
  } finally {
    await ctx.close();
  }
});

// ---- Cadangan dan pemulihan ----
await check('Cadangan: salin, hapus semua data, pulihkan dari teks tempelan; berkas diunduh; data tetap setelah muat ulang', async () => {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 860 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta', acceptDownloads: true });
  await ctx.grantPermissions(['clipboard-read', 'clipboard-write']);
  const q = await ctx.newPage();
  activePage = q;
  const side = (label) => q.locator('aside').getByRole('button', { name: new RegExp(`^${label}`) });
  try {
    await q.goto(url);
    await q.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
    eq(await q.getByTestId('backup-reminder').count(), 0, 'data contoh tidak perlu diingatkan');
    await side('Pengaturan').click();
    await q.getByRole('heading', { name: 'Pengaturan' }).waitFor();
    const status = q.getByTestId('backup-status');
    ok((await status.innerText()).includes('Belum pernah dicadangkan'), 'status awal');
    const storeName = await q.getByLabel('Nama toko').inputValue();

    // Salin cadangan: teks di clipboard adalah cadangan yang utuh
    await q.getByRole('button', { name: 'Salin cadangan' }).click();
    await q.getByText(/^Cadangan disalin/).waitFor({ timeout: 4000 });
    const text = await q.evaluate(() => navigator.clipboard.readText());
    const data = JSON.parse(text);
    eq(data.app, 'warung-manop', 'penanda aplikasi');
    ok(data.counts.products >= 10 && data.counts.transactions >= 10, `isi cadangan: ${JSON.stringify(data.counts)}`);
    ok(/Cadangan terakhir .*hari ini/.test(await status.innerText()), 'status setelah cadangan');

    // Menyimpan pengaturan tidak boleh menimpa catatan waktu cadangan (draft form dibuka sebelum cadangan dibuat)
    await q.getByLabel('Nama toko').fill('Toko Uji');
    await q.getByRole('button', { name: 'Simpan pengaturan' }).click();
    await q.getByText('Pengaturan disimpan.').waitFor({ timeout: 4000 });
    ok(/Cadangan terakhir/.test(await status.innerText()), 'catatan cadangan tertimpa saat menyimpan pengaturan');
    await q.reload(); // alamat #pengaturan ikut dimuat ulang
    await q.getByRole('heading', { name: 'Pengaturan' }).waitFor({ timeout: 60000 });
    ok(/Cadangan terakhir/.test(await q.getByTestId('backup-status').innerText()), 'catatan cadangan hilang setelah muat ulang');

    // Unduh cadangan: berkas JSON polos (tanpa BOM) bernama tanggal
    const [dl] = await Promise.all([q.waitForEvent('download'), q.getByRole('button', { name: 'Unduh cadangan' }).click()]);
    ok(/^bonbon-cadangan-\d{4}-\d{2}-\d{2}\.json$/.test(dl.suggestedFilename()), `nama berkas ${dl.suggestedFilename()}`);
    const raw = readFileSync(await dl.path(), 'utf8');
    ok(!raw.startsWith('﻿'), 'berkas JSON tidak boleh berawalan BOM');
    eq(JSON.parse(raw).counts.products, data.counts.products, 'isi berkas unduhan');
    await q.getByRole('button', { name: 'Bagikan' }).count().then((n) => eq(n, 0, 'Bagikan hanya muncul kalau peramban bisa membagikan berkas'));

    // Hapus semua data
    await q.getByRole('button', { name: 'Hapus semua data' }).click();
    await q.getByRole('dialog').getByRole('button', { name: 'Hapus semua' }).click();
    await q.getByText('Semua data dihapus.').waitFor({ timeout: 4000 });
    await side('Kasir').click();
    await q.getByText('Belum ada produk').waitFor();

    // Pulihkan: teks yang salah ditolak dengan alasan jelas
    await side('Pengaturan').click();
    await q.getByRole('button', { name: 'Pulihkan dari cadangan' }).click();
    const dlg = q.getByRole('dialog', { name: 'Pulihkan dari cadangan' });
    const box = dlg.getByLabel('Teks cadangan');
    const tryText = async (t, re) => {
      await box.fill(t);
      await dlg.getByRole('button', { name: 'Periksa teks' }).click();
      await dlg.getByRole('alert').filter({ hasText: re }).waitFor({ timeout: 3000 });
    };
    await tryText('halo', /bukan cadangan yang utuh/);
    await tryText(text.slice(0, text.length - 50), /bukan cadangan yang utuh/);
    await tryText('{"app":"lain","format":1,"tables":{}}', /bukan berkas cadangan Bonbon/);
    await tryText(JSON.stringify({ ...data, format: 99 }), /versi aplikasi yang lebih baru/);
    // toko masih kosong: tidak ada yang berubah
    eq(await dlg.getByRole('button', { name: 'Periksa teks' }).isEnabled(), true, 'tombol periksa');

    // Teks yang benar: pratinjau, lalu konfirmasi
    await box.fill(text);
    await dlg.getByRole('button', { name: 'Periksa teks' }).click();
    const confirm = q.getByRole('dialog', { name: 'Ganti data dengan cadangan ini?' });
    await confirm.waitFor();
    ok((await confirm.innerText()).includes(`${data.counts.products} produk`), 'jumlah produk di pratinjau');
    ok((await confirm.innerText()).includes('akan DIGANTI'), 'peringatan mengganti data');
    await q.screenshot({ path: join(out, '31-pulihkan-konfirmasi.png') });
    await confirm.getByRole('button', { name: 'Ya, ganti semua data' }).click();
    await q.getByText(/^Data dipulihkan:/).waitFor({ timeout: 6000 });
    await q.getByRole('heading', { name: 'Beranda' }).waitFor();

    // Semuanya kembali, termasuk pengaturan dan kasbon
    await side('Kasir').click();
    await q.getByRole('button', { name: /^Tambah Indomie Goreng,/ }).waitFor({ timeout: 4000 });
    await side('Kasbon').click();
    await q.locator('main li button', { hasText: 'Pak Budi' }).first().waitFor({ timeout: 4000 });
    await side('Pengaturan').click();
    eq(await q.getByLabel('Nama toko').inputValue(), storeName, 'nama toko kembali ke yang dicadangkan');

    // ... dan tetap ada setelah muat ulang
    await q.reload();
    await q.getByRole('heading', { name: 'Pengaturan' }).waitFor({ timeout: 60000 });
    await side('Kasir').click();
    await q.getByRole('button', { name: /^Tambah Indomie Goreng,/ }).waitFor({ timeout: 4000 });
  } finally {
    await ctx.close();
  }
});

await check('Cadangan: pulihkan dari berkas .json, peringatan transaksi yang akan hilang, tombol Kembali dan Batal tidak mengubah data', async () => {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 860 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
  await ctx.grantPermissions(['clipboard-read', 'clipboard-write']);
  const q = await ctx.newPage();
  activePage = q;
  try {
    await q.goto(url);
    await q.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
    await q.locator('aside').getByRole('button', { name: /^Pengaturan/ }).click();
    await q.getByRole('button', { name: 'Salin cadangan' }).click();
    await q.getByText(/^Cadangan disalin/).waitFor();
    const data = JSON.parse(await q.evaluate(() => navigator.clipboard.readText()));
    data.exportedAt = '2020-01-01T00:00:00.000Z'; // semua transaksi sekarang lebih baru dari cadangan ini
    await q.getByRole('button', { name: 'Pulihkan dari cadangan' }).click();
    const dlg = q.getByRole('dialog', { name: 'Pulihkan dari cadangan' });
    await dlg.locator('input[type=file]').setInputFiles({ name: 'cadangan-lama.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(data)) });
    const confirm = q.getByRole('dialog', { name: 'Ganti data dengan cadangan ini?' });
    await confirm.waitFor();
    ok(/\d+ transaksi yang dibuat setelah cadangan ini akan hilang/.test(await confirm.innerText()), 'peringatan transaksi yang hilang');
    await confirm.getByRole('button', { name: 'Kembali' }).click();
    await dlg.waitFor();
    await dlg.getByRole('button', { name: 'Batal' }).click();
    await dlg.waitFor({ state: 'detached' });
    // berkas yang bukan cadangan
    await q.getByRole('button', { name: 'Pulihkan dari cadangan' }).click();
    await dlg.locator('input[type=file]').setInputFiles({ name: 'foto.json', mimeType: 'application/json', buffer: Buffer.from('{"nama":"bukan cadangan"}') });
    await dlg.getByRole('alert').filter({ hasText: 'bukan berkas cadangan Bonbon' }).waitFor();
    await dlg.getByRole('button', { name: 'Batal' }).click();
    await q.locator('aside').getByRole('button', { name: /^Kasir/ }).click();
    await q.getByRole('button', { name: /^Tambah Indomie Goreng,/ }).waitFor();
  } finally {
    await ctx.close();
  }
});

await check('Cadangan: pengingat di Beranda muncul bila belum pernah atau sudah lama, hilang setelah mencadangkan, dan bisa ditutup', async () => {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 860 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
  await ctx.grantPermissions(['clipboard-read', 'clipboard-write']);
  const q = await ctx.newPage();
  activePage = q;
  const side = (label) => q.locator('aside').getByRole('button', { name: new RegExp(`^${label}`) });
  const restoreCrafted = async (edit) => {
    await side('Pengaturan').click();
    await q.getByRole('button', { name: 'Salin cadangan' }).click();
    await q.getByText(/^Cadangan disalin/).waitFor();
    const f = JSON.parse(await q.evaluate(() => navigator.clipboard.readText()));
    for (const pr of f.tables.products) pr.sku = `X${pr.sku}`; // bukan data contoh lagi
    edit(f);
    await q.getByRole('button', { name: 'Pulihkan dari cadangan' }).click();
    const dlg = q.getByRole('dialog', { name: 'Pulihkan dari cadangan' });
    await dlg.getByLabel('Teks cadangan').fill(JSON.stringify(f));
    await dlg.getByRole('button', { name: 'Periksa teks' }).click();
    await q.getByRole('dialog', { name: 'Ganti data dengan cadangan ini?' }).getByRole('button', { name: 'Ya, ganti semua data' }).click();
    await q.getByRole('heading', { name: 'Beranda' }).waitFor();
  };
  try {
    await q.goto(url);
    await q.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });

    // cadangan 10 hari lalu
    await restoreCrafted((f) => { f.tables.settings[0].lastBackupAt = new Date(Date.now() - 10 * 86_400_000).toISOString(); });
    const card = q.getByTestId('backup-reminder');
    await card.waitFor({ timeout: 4000 });
    ok((await card.innerText()).includes('Sudah 10 hari tidak dicadangkan'), 'teks pengingat');
    await q.screenshot({ path: join(out, '32-pengingat-cadangan.png') });
    // mencadangkan menghilangkan pengingat
    await card.getByRole('button', { name: 'Cadangkan sekarang' }).click();
    await q.getByRole('heading', { name: 'Pengaturan' }).waitFor();
    ok(/Cadangan terakhir .*10 hari lalu/.test(await q.getByTestId('backup-status').innerText()), 'status 10 hari lalu');
    await q.getByRole('button', { name: 'Salin cadangan' }).click();
    await q.getByText(/^Cadangan disalin/).waitFor();
    await side('Beranda').click();
    await q.getByRole('heading', { name: 'Beranda' }).waitFor();
    eq(await q.getByTestId('backup-reminder').count(), 0, 'pengingat hilang setelah mencadangkan');

    // belum pernah dicadangkan, lalu ditutup untuk sesi ini
    await restoreCrafted((f) => { delete f.tables.settings[0].lastBackupAt; });
    await card.waitFor({ timeout: 4000 });
    ok((await card.innerText()).includes('Data belum pernah dicadangkan'), 'teks belum pernah');
    await card.getByRole('button', { name: 'Tutup pengingat cadangan' }).click();
    eq(await q.getByTestId('backup-reminder').count(), 0, 'pengingat ditutup');
    await side('Kasir').click();
    await side('Beranda').click();
    await q.getByRole('heading', { name: 'Beranda' }).waitFor();
    eq(await q.getByTestId('backup-reminder').count(), 0, 'tetap tertutup saat kembali ke Beranda');
    // setelah dimuat ulang pengingat muncul lagi (belum ada cadangan)
    await q.reload();
    await q.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
    await q.getByTestId('backup-reminder').waitFor({ timeout: 4000 });
  } finally {
    await ctx.close();
  }
});

// ---- Aplikasi Android (Capacitor): jembatan palsu menggantikan WebView asli ----
const fakeNative = () => {
  window.__native = { calls: [], clicked: [] };
  window.Capacitor = {
    isNativePlatform: () => true,
    nativePromise: async (plugin, method, options) => {
      window.__native.calls.push({ plugin, method, options });
      if (method === 'checkPermissions' || method === 'requestPermissions') return { display: 'granted' };
      if (plugin === 'Filesystem' && method === 'writeFile') return { uri: `file:///cache/${options.path}` };
      return {};
    },
  };
  const click = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (/^rawbt:/.test(this.href)) { window.__native.clicked.push(this.href); return; }
    return click.call(this);
  };
};

await check('Aplikasi Android: notifikasi stok harian (izin, jadwal, ganti jam, tes, matikan) dan toast stok habis', async () => {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 860 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta', userAgent: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36' });
  await ctx.addInitScript(fakeNative);
  const q = await ctx.newPage();
  activePage = q;
  const side = (label) => q.locator('aside').getByRole('button', { name: new RegExp(`^${label}`) });
  const calls = (plugin, method) => q.evaluate(([pl, m]) => window.__native.calls.filter((c) => c.plugin === pl && (!m || c.method === m)), [plugin, method]);
  const lastSchedule = async () => (await calls('LocalNotifications', 'schedule')).filter((c) => c.options.notifications[0].id === 7001).at(-1)?.options.notifications[0];
  const waitUntil = async (fn, msg) => {
    for (let i = 0; i < 60; i++) {
      if (await fn()) return;
      await q.waitForTimeout(100);
    }
    throw new Error(msg);
  };
  try {
    await q.goto(url);
    await q.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
    await side('Pengaturan').click();
    await q.getByRole('heading', { name: 'Notifikasi stok' }).waitFor();
    eq((await calls('LocalNotifications', 'schedule')).length, 0, 'belum aktif: tidak ada jadwal');

    // nyalakan: minta izin, simpan, jadwal harian jam 08.00 berisi ringkasan stok
    await q.getByRole('switch', { name: 'Ingatkan stok setiap hari' }).click();
    await q.getByLabel('Jam pengingat').waitFor();
    ok((await calls('LocalNotifications', 'checkPermissions')).length >= 1, 'izin ditanyakan');
    await q.getByText('Pengingat stok dinyalakan.').waitFor();
    ok(await q.getByRole('button', { name: 'Tersimpan' }).isVisible(), 'berlaku langsung: tidak ada perubahan yang menunggu tombol Simpan');
    await waitUntil(async () => !!(await lastSchedule()), 'jadwal harian dibuat');
    let n = await lastSchedule();
    eq(n.schedule.on.hour, 8, 'jam bawaan');
    eq(n.schedule.on.minute, 0, 'menit');
    eq(n.schedule.allowWhileIdle, true, 'tetap berbunyi saat HP idle');
    eq(n.title, 'Stok perlu perhatian', 'judul');
    ok(/\d+ habis/.test(n.body) && /menipis/.test(n.body), `isi ringkasan: ${n.body}`);
    ok(n.largeBody.includes('Habis: Telur Ayam') && n.largeBody.includes('Menipis: '), 'rincian per produk');
    eq(n.channelId, 'stok', 'kanal notifikasi');
    ok((await calls('LocalNotifications', 'createChannel')).length >= 1, 'kanal dibuat');

    // ganti jam
    await q.getByLabel('Jam pengingat').selectOption('18');
    await q.getByText('Jam pengingat diganti.').waitFor();
    await waitUntil(async () => (await lastSchedule())?.schedule.on.hour === 18, 'jadwal jam 18');

    // tes notifikasi: langsung tampil, tanpa jadwal
    await q.getByRole('button', { name: 'Kirim tes notifikasi' }).click();
    await q.getByText(/^Tes terkirim/).waitFor();
    const test = (await calls('LocalNotifications', 'schedule')).find((c) => c.options.notifications[0].id === 7002);
    ok(test && !test.options.notifications[0].schedule, 'tes tampil sekarang juga');

    // stok berubah di dalam aplikasi: toast, dan isi pengingat ikut berubah
    await side('Stok').click();
    await q.getByRole('tab', { name: 'Penyesuaian' }).click();
    await q.getByPlaceholder('Cari nama, SKU, atau barcode').fill('Pocari');
    await q.getByRole('button', { name: /Pocari Sweat/ }).click();
    const form = q.locator('form');
    const have = /Stok sekarang (\d+)/.exec(await form.innerText())[1]; // kurangi sebanyak itu: stok jadi 0
    await form.locator('input[inputmode="decimal"]').first().fill(have);
    await form.getByRole('button', { name: 'Rusak' }).click();
    await form.getByRole('button', { name: 'Simpan penyesuaian' }).click();
    await q.getByText('Stok habis: Pocari Sweat 500 ml.').waitFor({ timeout: 4000 });
    await waitUntil(async () => (await lastSchedule())?.largeBody.includes('Habis: Pocari Sweat 500 ml'), 'pengingat ikut diperbarui');
    await q.screenshot({ path: join(out, '33-notifikasi-stok.png') });

    // matikan: jadwal dibatalkan dan tidak dibuat lagi
    await side('Pengaturan').click();
    await q.getByRole('switch', { name: 'Ingatkan stok setiap hari' }).click();
    await q.getByText('Pengingat stok dimatikan.').waitFor();
    await waitUntil(async () => {
      const all = (await calls('LocalNotifications')).filter((c) => (c.method === 'cancel' || c.method === 'schedule') && (c.options.notifications?.[0]?.id === 7001));
      return all.at(-1)?.method === 'cancel';
    }, 'jadwal dibatalkan');
  } finally {
    await ctx.close();
  }
});

await check('Aplikasi Android: izin notifikasi ditolak tidak menyalakan saklar; versi web tidak menampilkan bagian notifikasi', async () => {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 860 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
  await ctx.addInitScript(() => {
    fakeNativeDenied();
    function fakeNativeDenied() {
      window.Capacitor = { isNativePlatform: () => true, nativePromise: async (plugin, method) => (method === 'checkPermissions' || method === 'requestPermissions' ? { display: 'denied' } : {}) };
    }
  });
  const q = await ctx.newPage();
  activePage = q;
  try {
    await q.goto(url);
    await q.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
    await q.locator('aside').getByRole('button', { name: /^Pengaturan/ }).click();
    const sw = q.getByRole('switch', { name: 'Ingatkan stok setiap hari' });
    await sw.click();
    await q.getByText(/Izin notifikasi ditolak/).waitFor();
    eq(await sw.getAttribute('aria-checked'), 'false', 'saklar tetap mati');
    eq(await q.getByLabel('Jam pengingat').count(), 0, 'pilihan jam tidak muncul');
    await q.getByRole('button', { name: 'Kirim tes notifikasi' }).click();
    await q.getByText(/Notifikasi tidak bisa ditampilkan/).waitFor();
  } finally {
    await ctx.close();
  }
  // APK dibangun tanpa plugin notifikasi: pesannya harus jujur, bukan "izin ditolak"
  const bare = await browser.newContext({ viewport: { width: 1280, height: 860 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
  await bare.addInitScript(() => {
    window.Capacitor = { isNativePlatform: () => true, nativePromise: async () => { throw new Error('"LocalNotifications" plugin is not implemented on android'); } };
  });
  const b = await bare.newPage();
  activePage = b;
  try {
    await b.goto(url);
    await b.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
    await b.locator('aside').getByRole('button', { name: /^Pengaturan/ }).click();
    const sw2 = b.getByRole('switch', { name: 'Ingatkan stok setiap hari' });
    await sw2.click();
    await b.getByText(/Fitur notifikasi tidak ada di APK ini/).waitFor();
    eq(await sw2.getAttribute('aria-checked'), 'false', 'saklar tetap mati');
    await b.getByRole('button', { name: 'Kirim tes notifikasi' }).click();
    await b.getByText(/Fitur notifikasi tidak ada di APK ini/).first().waitFor();
  } finally {
    await bare.close();
  }
  const web = await browser.newContext({ viewport: { width: 1280, height: 860 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
  const w = await web.newPage();
  activePage = w;
  try {
    await w.goto(url);
    await w.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
    await w.locator('aside').getByRole('button', { name: /^Pengaturan/ }).click();
    await w.getByRole('heading', { name: 'Pengaturan' }).waitFor();
    eq(await w.getByRole('heading', { name: 'Notifikasi stok' }).count(), 0, 'bagian notifikasi hanya untuk aplikasi Android');
  } finally {
    await web.close();
  }
});

await check('Aplikasi Android: cadangan lewat menu bagikan, CSV lewat menu bagikan, struk lewat RawBT, tanpa tombol cetak peramban', async () => {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 860 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta', userAgent: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36' });
  await ctx.addInitScript(fakeNative);
  const q = await ctx.newPage();
  activePage = q;
  const side = (label) => q.locator('aside').getByRole('button', { name: new RegExp(`^${label}`) });
  const calls = (plugin, method) => q.evaluate(([pl, m]) => window.__native.calls.filter((c) => c.plugin === pl && c.method === m), [plugin, method]);
  try {
    await q.goto(url);
    await q.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });

    await side('Pengaturan').click();
    eq(await q.getByRole('button', { name: 'Unduh cadangan' }).count(), 0, 'di aplikasi tombolnya bernama lain');
    eq(await q.getByRole('button', { name: 'Bagikan', exact: true }).count(), 0, 'tombol Bagikan peramban tidak dipakai');
    await q.getByRole('button', { name: 'Simpan / kirim cadangan' }).click();
    await q.getByText(/^Cadangan disiapkan/).waitFor();
    const w = (await calls('Filesystem', 'writeFile')).at(-1).options;
    ok(/^bonbon-cadangan-\d{4}-\d{2}-\d{2}\.json$/.test(w.path) && w.directory === 'CACHE' && w.encoding === 'utf8', `writeFile ${JSON.stringify({ ...w, data: '...' })}`);
    ok(!w.data.startsWith('﻿') && JSON.parse(w.data).app === 'warung-manop', 'isi cadangan JSON polos');
    const sh = (await calls('Share', 'share')).at(-1).options;
    eq(sh.url, `file:///cache/${w.path}`, 'berkas diserahkan ke menu bagikan');
    ok(/Cadangan terakhir .*hari ini/.test(await q.getByTestId('backup-status').innerText()), 'status cadangan');

    // laporan: CSV lewat menu bagikan, tanpa cetak PDF
    await side('Laporan').click();
    await q.getByRole('button', { name: 'Unduh CSV' }).click();
    await q.waitForTimeout(300);
    const csv = (await calls('Filesystem', 'writeFile')).at(-1).options;
    ok(csv.path.endsWith('.csv') && csv.data.startsWith('﻿'), 'CSV berawalan BOM untuk Excel');
    eq(await q.getByRole('button', { name: /Cetak/ }).count(), 0, 'tanpa cetak PDF peramban');
    await q.getByText(/Cetak PDF belum tersedia di aplikasi/).waitFor();

    // struk: RawBT lewat skema rawbt:, tanpa dialog cetak peramban
    await side('Riwayat').click();
    await q.locator('main li button').first().click();
    await q.getByRole('dialog', { name: /^Struk INV-/ }).getByRole('button', { name: 'Cetak' }).click();
    const dlg = q.getByRole('dialog', { name: 'Cetak struk' });
    await dlg.waitFor();
    eq(await dlg.getByRole('button', { name: 'Buka dialog cetak' }).count(), 0, 'dialog cetak peramban tidak ada di aplikasi');
    await dlg.getByRole('button', { name: /Cetak lewat RawBT/ }).click();
    const links = await q.evaluate(() => window.__native.clicked);
    eq(links.length, 1, 'RawBT dipanggil sekali');
    ok(/^rawbt:base64,[A-Za-z0-9+/=]+$/.test(links[0]), `tautan RawBT ${links[0].slice(0, 30)}`);
  } finally {
    await ctx.close();
  }
});

// ---- Tampilan di dalam bungkus halaman Claude (artifact). ----
// Penampil membungkus halaman dengan `body{margin:0;padding:0;background:#fff;color:#000;font:14px ...}` di luar layer CSS manapun.
// Aturan body di dalam @layer kalah dari itu (halaman putih, teks hitam di atas kartu gelap), jadi diuji di sini dengan bungkus yang sama.
if (existsSync(join(root, 'dist/artifact.html'))) {
  const HOST_HEAD =
    '<!doctype html><html><head><meta charset=utf8><meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover"><style>:root{color-scheme:light;box-sizing:border-box;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}html{scroll-padding-top:env(safe-area-inset-top,0px)}body{margin:0;padding:0;font:14px -apple-system,BlinkMacSystemFont,sans-serif;background:#fff;color:#000}img{max-width:100%}[hidden]:not([hidden=until-found i]){display:none!important}</style></head><body>\n';
  const wrapped = join(tmpdir(), `warung-manop-bungkus-${process.pid}.html`);
  writeFileSync(wrapped, HOST_HEAD + readFileSync(join(root, 'dist/artifact.html'), 'utf8') + '\n</body></html>');

  const sweepContrast = () => {
    const parse = (c) => { const m = c.match(/rgba?\(([^)]+)\)/); if (!m) return null; const [r, g, b, a = 1] = m[1].split(/[ ,\/]+/).filter(Boolean).map(Number); return { r, g, b, a }; };
    const lum = ({ r, g, b }) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
    const mix = (top, bot) => ({ r: top.r * top.a + bot.r * (1 - top.a), g: top.g * top.a + bot.g * (1 - top.a), b: top.b * top.a + bot.b * (1 - top.a), a: 1 });
    const bgOf = (el) => { const chain = []; for (let e = el; e; e = e.parentElement) chain.push(e); let bg = { r: 255, g: 255, b: 255, a: 1 }; for (const e of chain.reverse()) { const c = parse(getComputedStyle(e).backgroundColor); if (c && c.a > 0) bg = c.a >= 1 ? c : mix(c, bg); } return bg; };
    const bad = [];
    const seen = new Set();
    for (const el of document.querySelectorAll('body *')) {
      const own = [...el.childNodes].filter((n) => n.nodeType === 3 && n.textContent.trim()).map((n) => n.textContent.trim()).join(' ');
      if (!own || el.closest('.receipt-sheet') || el.closest('[disabled]')) continue;
      const r = el.getBoundingClientRect();
      const cs = getComputedStyle(el);
      if (r.width === 0 || r.height === 0 || cs.visibility === 'hidden') continue;
      let fg = parse(cs.color);
      if (!fg) continue;
      const bg = bgOf(el);
      if (fg.a < 1) fg = mix(fg, bg);
      const ratio = (Math.max(lum(fg), lum(bg)) + 0.05) / (Math.min(lum(fg), lum(bg)) + 0.05);
      const size = parseFloat(cs.fontSize);
      const need = size >= 18 || (size >= 14 && Number(cs.fontWeight) >= 700) ? 3 : 4.5;
      const key = el.tagName + own.slice(0, 30);
      if (ratio < need && !seen.has(key)) { seen.add(key); bad.push(`${ratio.toFixed(2)} < ${need}: "${own.slice(0, 36)}"`); }
    }
    return bad;
  };

  for (const scheme of ['dark', 'light']) {
    await check(`Di bungkus halaman Claude (${scheme === 'dark' ? 'tema gelap' : 'tema terang'}): latar, warna teks, font, jarak pinggir, dan kontras semua teks di semua halaman dan dialog`, async () => {
      const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, colorScheme: scheme, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
      await ctx.grantPermissions(['clipboard-read', 'clipboard-write']);
      const q = await ctx.newPage();
      activePage = q;
      try {
        await q.goto(pathToFileURL(wrapped).href);
        await q.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
        const g = await q.evaluate(() => {
          const tok = (n, prop) => { const d = document.createElement('i'); d.style[prop] = `var(${n})`; document.body.appendChild(d); const c = getComputedStyle(d)[prop]; d.remove(); return c; };
          const b = getComputedStyle(document.body);
          return { bg: b.backgroundColor, canvas: tok('--canvas', 'backgroundColor'), color: b.color, ink: tok('--ink', 'color'), padL: parseFloat(b.paddingLeft), padR: parseFloat(b.paddingRight), font: b.fontFamily };
        });
        eq(g.bg, g.canvas, 'warna latar halaman');
        eq(g.color, g.ink, 'warna teks halaman');
        ok(g.padL >= 16 && g.padR >= 16, `jarak pinggir kiri/kanan harus minimal 16px, dapat ${g.padL}/${g.padR}`);
        ok(/Plus Jakarta Sans/.test(g.font), `font aplikasi tidak terpakai: ${g.font}`);

        const nav = q.locator('nav[aria-label="Menu utama"]').last();
        const problems = [];
        const sweep = async (label) => {
          await q.waitForTimeout(300);
          for (const p of await q.evaluate(sweepContrast)) problems.push(`${label}: ${p}`);
        };
        for (const name of ['Beranda', 'Kasir', 'Stok', 'Kasbon', 'Riwayat', 'Produk', 'Belanja', 'Kas Laci', 'Laporan']) {
          await phoneGo(q, name);
          await sweep(name);
        }
        await q.getByRole('button', { name: 'Lainnya' }).click();
        await q.getByRole('dialog', { name: 'Menu lainnya' }).waitFor();
        await sweep('Menu Lainnya');
        await q.keyboard.press('Escape');
        await phoneGo(q, 'Kas Laci');
        await q.getByRole('button', { name: 'Uang keluar' }).click();
        await q.getByRole('dialog', { name: 'Uang keluar dari laci' }).waitFor();
        await sweep('Dialog uang keluar');
        await q.keyboard.press('Escape');
        await q.getByRole('button', { name: 'Tutup kas' }).click();
        await q.getByRole('dialog', { name: 'Tutup kas laci' }).waitFor();
        await q.getByLabel('Uang yang dihitung').fill('1');
        await sweep('Dialog tutup kas');
        await q.keyboard.press('Escape');
        await q.getByRole('region', { name: 'Riwayat kas' }).locator('li button').first().click();
        await q.getByRole('button', { name: 'Salin rekap' }).waitFor();
        await sweep('Detail kas');
        await q.keyboard.press('Escape');
        await phoneGo(q, 'Stok');
        await q.getByRole('tab', { name: 'Opname' }).click();
        await sweep('Opname mulai');
        await q.getByRole('button', { name: /^Mulai opname/ }).click();
        const cnt = q.getByRole('textbox', { name: /^Jumlah dihitung/ }).first();
        await cnt.fill('777');
        await cnt.press('Tab');
        await sweep('Opname berjalan');
        await q.getByRole('button', { name: 'Batalkan', exact: true }).click();
        await q.getByRole('dialog', { name: 'Batalkan opname?' }).getByRole('button', { name: 'Batalkan opname' }).click();
        await phoneGo(q, 'Riwayat');
        await q.getByLabel('Filter status').selectOption({ label: 'Selesai' });
        await q.locator('main li button', { hasText: 'Tunai' }).first().click();
        await q.getByRole('dialog', { name: /^Struk INV-/ }).getByRole('button', { name: 'Retur', exact: true }).click();
        const retur = q.getByRole('dialog', { name: /^Retur INV-/ });
        await retur.getByRole('button', { name: /^Tambah retur/ }).first().click();
        await sweep('Dialog retur');
        await q.keyboard.press('Escape');
        await q.keyboard.press('Escape');
        await phoneGo(q, 'Laporan');
        for (const tab of ['Ringkasan', 'Produk', 'Pembayaran', 'Stok', 'Kasbon']) {
          await q.getByRole('tab', { name: tab }).click();
          await sweep(`Laporan ${tab}`);
        }
        await phoneGo(q, 'Kasir');
        await q.getByRole('button', { name: /^Keranjang tertahan/ }).click();
        await q.getByRole('dialog', { name: /^Keranjang tertahan/ }).waitFor();
        await sweep('Daftar tertahan');
        await q.keyboard.press('Escape');
        await nav.getByRole('button', { name: /^Kasbon/ }).click();
        await q.locator('main li button', { hasText: 'Pak Budi' }).click();
        await q.getByRole('dialog', { name: 'Pak Budi' }).waitFor();
        await sweep('Detail kasbon');
        await q.keyboard.press('Escape');
        await phoneGo(q, 'Produk');
        await q.getByRole('button', { name: /Tambah produk/ }).first().click();
        await q.getByRole('dialog', { name: 'Tambah produk' }).waitFor();
        await sweep('Form produk');
        await q.keyboard.press('Escape');
        await q.getByRole('button', { name: 'Pengaturan' }).first().click();
        await q.getByRole('heading', { name: 'Pengaturan' }).waitFor();
        await sweep('Pengaturan');
        await nav.getByRole('button', { name: /^Kasir/ }).click();
        await q.locator('button[aria-label^="Tambah "]:not([disabled])').first().click();
        await q.getByRole('button', { name: 'Buka keranjang' }).click();
        const sheet = q.getByRole('dialog', { name: 'Keranjang' });
        await sheet.waitFor();
        await sweep('Keranjang');
        await sheet.getByRole('button', { name: 'Kosongkan' }).click();
        await q.getByRole('dialog', { name: 'Kosongkan keranjang?' }).waitFor();
        await sweep('Dialog hapus (tombol merah)');
        await q.keyboard.press('Escape');
        await sheet.getByRole('button', { name: /^Bayar/ }).click();
        await q.getByRole('dialog', { name: 'Pembayaran' }).waitFor();
        await sweep('Pembayaran');
        await q.keyboard.press('Escape');
        await q.getByRole('button', { name: 'Scan barcode dengan kamera' }).click();
        await q.getByRole('dialog', { name: 'Scan barang' }).waitFor();
        await sweep('Scan barcode');
        await q.keyboard.press('Escape');

        // Cadangan: di bungkus halaman tidak ada unduhan atau bagikan; salin dan pulihkan tetap ada
        await q.getByRole('button', { name: 'Pengaturan' }).first().click();
        await q.getByRole('heading', { name: 'Pengaturan' }).waitFor();
        eq(await q.getByRole('button', { name: 'Unduh cadangan' }).count(), 0, 'unduhan tidak boleh ada di bungkus halaman');
        eq(await q.getByRole('button', { name: 'Bagikan' }).count(), 0, 'bagikan tidak boleh ada di bungkus halaman');
        await q.getByRole('button', { name: 'Salin cadangan' }).click();
        await q.getByText(/^Cadangan disalin/).waitFor();
        const backupFile = JSON.parse(await q.evaluate(() => navigator.clipboard.readText()));
        await sweep('Pengaturan setelah cadangan');
        await q.getByRole('button', { name: 'Pulihkan dari cadangan' }).click();
        const rd = q.getByRole('dialog', { name: 'Pulihkan dari cadangan' });
        await rd.waitFor();
        await sweep('Dialog pulihkan');
        await rd.getByLabel('Teks cadangan').fill('halo');
        await rd.getByRole('button', { name: 'Periksa teks' }).click();
        await rd.getByRole('alert').waitFor();
        await sweep('Dialog pulihkan, teks salah');
        backupFile.exportedAt = '2020-01-01T00:00:00.000Z';
        for (const pr of backupFile.tables.products) pr.sku = `X${pr.sku}`;
        backupFile.tables.settings[0].lastBackupAt = new Date(Date.now() - 10 * 86_400_000).toISOString();
        await rd.getByLabel('Teks cadangan').fill(JSON.stringify(backupFile));
        await rd.getByRole('button', { name: 'Periksa teks' }).click();
        const rc = q.getByRole('dialog', { name: 'Ganti data dengan cadangan ini?' });
        await rc.waitFor();
        await sweep('Dialog ganti data');
        await rc.getByRole('button', { name: 'Ya, ganti semua data' }).click();
        await q.getByRole('heading', { name: 'Beranda' }).waitFor();
        await q.getByTestId('backup-reminder').waitFor();
        await sweep('Pengingat cadangan di Beranda');
        await q.getByRole('button', { name: 'Pengaturan' }).first().click();
        await q.getByRole('heading', { name: 'Pengaturan' }).waitFor();
        await sweep('Pengaturan, cadangan sudah lama');
        eq(problems.join('\n'), '', 'teks yang sulit dibaca');
      } finally {
        await ctx.close();
      }
    });
  }
  rmSync(wrapped, { force: true });
}


// Regresi: halaman tidak boleh tetap terkunci (overflow: hidden) setelah modal bertumpuk ditutup
await check('Ponsel: logo Bonbon dan nama toko tampil, judul halaman benar', async () => {
  eq(await mp.title(), 'Bonbon', 'judul halaman');
  ok(await mp.getByRole('img', { name: 'Bonbon' }).first().isVisible(), 'logo Bonbon tidak tampil');
  ok((await mp.locator('header').first().innerText()).includes('Warung Manop'), 'nama toko tidak tampil di header');
});
const lockScenarios = {
  'keranjang -> kosongkan -> konfirmasi': async (q) => {
    await q.getByRole('dialog', { name: 'Keranjang' }).getByRole('button', { name: /Kosongkan/ }).click();
    await q.getByRole('dialog', { name: 'Kosongkan keranjang?' }).getByRole('button', { name: 'Kosongkan' }).click();
  },
  'keranjang + konfirmasi -> pindah halaman': async (q) => {
    await q.getByRole('dialog', { name: 'Keranjang' }).getByRole('button', { name: /Kosongkan/ }).click();
    await q.evaluate(() => { location.hash = '#produk'; });
  },
  'keranjang -> bayar -> pindah halaman': async (q) => {
    await q.getByRole('dialog', { name: 'Keranjang' }).getByRole('button', { name: /^Bayar/ }).click();
    await q.getByRole('dialog', { name: 'Pembayaran' }).waitFor();
    await q.evaluate(() => { location.hash = '#produk'; });
  },
  'keranjang -> bayar -> Esc': async (q) => {
    await q.getByRole('dialog', { name: 'Keranjang' }).getByRole('button', { name: /^Bayar/ }).click();
    await q.getByRole('dialog', { name: 'Pembayaran' }).waitFor();
    await q.keyboard.press('Escape');
  },
};
for (const [name, act] of Object.entries(lockScenarios)) {
  await check(`Ponsel: halaman tetap bisa digeser setelah ${name}`, async () => {
    const q = await phone.newPage();
    try {
      await q.goto(url);
      await q.getByRole('heading', { name: 'Beranda' }).waitFor({ timeout: 60000 });
      await q.locator('nav[aria-label="Menu utama"]').last().getByRole('button', { name: 'Kasir' }).click();
      await q.getByRole('button', { name: /^Tambah Indomie Goreng,/ }).click();
      await q.getByRole('button', { name: 'Buka keranjang' }).click();
      await act(q);
      await q.waitForTimeout(250);
      eq(await q.evaluate(() => document.body.style.overflow), '', 'body.style.overflow');
      eq(await q.evaluate(() => getComputedStyle(document.documentElement).overflowY === 'hidden' || getComputedStyle(document.body).overflowY === 'hidden'), false, 'overflow terhitung hidden');
    } finally {
      await q.close();
    }
  });
}
await phone.close();

await browser.close();

process.exit(report());
