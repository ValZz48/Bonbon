import { useRef, useState } from 'react';
import { LuClipboardCopy, LuDownload, LuFileUp, LuShare2, LuShieldCheck, LuTriangleAlert } from 'react-icons/lu';
import { BACKUP_REMIND_DAYS, type BackupInfo, type ParsedBackup, backupAgeDays, backupFileName, backupText, createBackup, markBackedUp, parseBackup, restoreBackup } from '../core/backup';
import { DEMO_SKUS } from '../core/demo';
import { formatDateTime } from '../core/format';
import { useCart } from '../app/cart';
import { useNav } from '../app/nav';
import { CAN_DOWNLOAD, IS_ARTIFACT, IS_NATIVE, downloadText } from '../app/runtime';
import { useAppState, useStore } from '../app/state';
import { Modal, cx, errorMessage, useAction, useCopy, useToast } from '../app/ui';

const num = (n: number) => n.toLocaleString('id-ID');

/** One line saying how fresh the last backup is. `stale` is true when it is time to make a new one. */
export function useBackupStatus() {
  const state = useAppState();
  const last = state.settings.lastBackupAt;
  const days = backupAgeDays(last);
  // sample data is not worth backing up, so no nagging until it has been cleared
  const hasDemo = state.products.some((p) => DEMO_SKUS.includes(p.sku));
  const hasData = state.products.length > 0 && state.transactions.length > 0 && !hasDemo;
  const stale = hasData && (days === null || days >= BACKUP_REMIND_DAYS);
  const text = !last || days === null ? 'Belum pernah dicadangkan.' : `Cadangan terakhir ${formatDateTime(last)} (${days === 0 ? 'hari ini' : `${days} hari lalu`}).`;
  return { text, stale, never: days === null, days };
}

function canShareFiles(): boolean {
  if (IS_ARTIFACT || IS_NATIVE) return false; // the app's share sheet is reached through the save button
  try {
    return typeof navigator.canShare === 'function' && navigator.canShare({ files: [new File(['{}'], 'a.json', { type: 'application/json' })] });
  } catch {
    return false;
  }
}

export function BackupPanel() {
  const store = useStore();
  const toast = useToast();
  const copy = useCopy();
  const status = useBackupStatus();
  const { busy, run } = useAction();
  const [restoring, setRestoring] = useState(false);

  const make = () => {
    const now = new Date();
    return { now, text: backupText(createBackup(store, now)), name: backupFileName(now) };
  };

  const download = () =>
    run(async () => {
      const b = make();
      if (!(await downloadText(b.name, b.text, 'application/json'))) throw new Error('Berkas tidak bisa disimpan. Coba tombol Salin cadangan.');
      await markBackedUp(store, b.now);
      toast(IS_NATIVE ? 'Cadangan disiapkan. Pilih tujuan penyimpanannya di menu yang muncul.' : `Cadangan diunduh: ${b.name}`);
    });

  const share = () =>
    run(async () => {
      const b = make();
      const file = new File([b.text], b.name, { type: 'application/json' });
      try {
        await navigator.share({ files: [file], title: 'Cadangan Bonbon' });
      } catch (e) {
        if (e instanceof DOMException && e.name === 'AbortError') return; // closed the share sheet: nothing was saved
        throw e;
      }
      await markBackedUp(store, b.now);
      toast('Cadangan dibagikan.');
    });

  const copyText = () =>
    run(async () => {
      const b = make();
      await copy(b.text, 'Cadangan disalin. Tempel dan simpan di tempat aman (catatan, WhatsApp ke diri sendiri, atau email).');
      await markBackedUp(store, b.now);
    });

  return (
    <>
      <div className={cx('flex items-start gap-2.5 rounded-md px-3 py-2.5 text-sm', status.stale ? 'bg-warnsoft text-warn' : 'bg-sunken text-muted')} role="status" data-testid="backup-status">
        {status.stale ? <LuTriangleAlert className="mt-0.5 shrink-0" size={17} /> : <LuShieldCheck className="mt-0.5 shrink-0" size={17} />}
        <span>{status.text}</span>
      </div>
      <p className="hint -mt-2">Data hanya ada di peramban ini. Kalau HP hilang, rusak, atau datanya terhapus, cadangan inilah satu-satunya jalan kembali. Simpan berkasnya di luar HP (Google Drive, email, atau kirim ke diri sendiri).</p>
      <div className="flex flex-wrap gap-2">
        {CAN_DOWNLOAD && (
          <button type="button" className="btn btn-primary" onClick={download} disabled={busy}>
            <LuDownload size={17} /> {IS_NATIVE ? 'Simpan / kirim cadangan' : 'Unduh cadangan'}
          </button>
        )}
        {canShareFiles() && (
          <button type="button" className="btn btn-soft" onClick={share} disabled={busy}>
            <LuShare2 size={17} /> Bagikan
          </button>
        )}
        <button type="button" className={cx('btn', CAN_DOWNLOAD ? 'btn-ghost' : 'btn-primary')} onClick={copyText} disabled={busy}>
          <LuClipboardCopy size={17} /> Salin cadangan
        </button>
        <button type="button" className="btn btn-ghost" onClick={() => setRestoring(true)}>
          <LuFileUp size={17} /> Pulihkan dari cadangan
        </button>
      </div>
      {restoring && <RestoreDialog onClose={() => setRestoring(false)} />}
    </>
  );
}

function Counts({ info }: { info: BackupInfo }) {
  const c = info.counts;
  return (
    <ul className="grid gap-0.5 text-sm" aria-label="Isi cadangan">
      <li>{num(c.products)} produk</li>
      <li>{num(c.transactions)} transaksi</li>
      <li>{num(c.customers)} pelanggan, {num(c.debtEntries)} catatan kasbon</li>
      {(c.returns > 0 || c.shifts > 0) && (
        <li>
          {num(c.returns)} retur, {num(c.shifts)} kas laci
        </li>
      )}
    </ul>
  );
}

function RestoreDialog({ onClose }: { onClose: () => void }) {
  const state = useAppState();
  const store = useStore();
  const toast = useToast();
  const nav = useNav();
  const { dispatch } = useCart();
  const { busy, run } = useAction();
  const fileRef = useRef<HTMLInputElement>(null);
  const [text, setText] = useState('');
  const [fileName, setFileName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [parsed, setParsed] = useState<ParsedBackup | null>(null);

  const check = (raw: string) => {
    setError(null);
    try {
      setParsed(parseBackup(raw));
    } catch (e) {
      setParsed(null);
      setError(errorMessage(e));
    }
  };

  const onFile = async (f: File | undefined) => {
    if (!f) return;
    setFileName(f.name);
    try {
      const raw = await f.text();
      setText('');
      check(raw);
    } catch {
      setParsed(null);
      setError('Berkas tidak bisa dibaca. Coba pilih ulang.');
    }
  };

  const doRestore = async () => {
    if (!parsed) return;
    const ok = await run(async () => {
      await restoreBackup(store, parsed);
      return true;
    });
    if (!ok) return;
    dispatch({ type: 'clear' });
    toast(`Data dipulihkan: ${num(parsed.info.counts.products)} produk dan ${num(parsed.info.counts.transactions)} transaksi.`);
    onClose();
    nav.go('beranda');
  };

  // sales made after the backup was taken would be lost: say so plainly
  const after = parsed && parsed.info.exportedAt ? state.transactions.filter((t) => t.createdAt > parsed.info.exportedAt).length : 0;

  if (parsed) {
    return (
      <Modal
        title="Ganti data dengan cadangan ini?"
        onClose={onClose}
        footer={
          <>
            <button type="button" className="btn btn-ghost" onClick={() => setParsed(null)} disabled={busy}>
              Kembali
            </button>
            <button type="button" className="btn btn-danger" onClick={doRestore} disabled={busy} data-autofocus>
              {busy ? 'Memulihkan...' : 'Ya, ganti semua data'}
            </button>
          </>
        }
      >
        <div className="grid gap-3">
          <div className="rounded-md bg-sunken px-3 py-2.5">
            <p className="text-sm font-semibold">{parsed.info.storeName}</p>
            {parsed.info.exportedAt && <p className="mb-1.5 text-xs text-muted">Dibuat {formatDateTime(parsed.info.exportedAt)}</p>}
            <Counts info={parsed.info} />
          </div>
          <p role="alert" className="rounded-md bg-warnsoft px-3 py-2.5 text-sm font-medium text-warn">
            Data sekarang ({num(state.products.length)} produk, {num(state.transactions.length)} transaksi) akan DIGANTI seluruhnya dan tidak bisa dikembalikan.
          </p>
          {after > 0 && (
            <p className="err !mt-0">
              {num(after)} transaksi yang dibuat setelah cadangan ini akan hilang. Buat cadangan data sekarang dulu kalau masih ingin menyimpannya.
            </p>
          )}
        </div>
      </Modal>
    );
  }

  return (
    <Modal
      title="Pulihkan dari cadangan"
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Batal
          </button>
          <button type="button" className="btn btn-primary" onClick={() => check(text)} disabled={!text.trim()}>
            Periksa teks
          </button>
        </>
      }
    >
      <p className="mb-3 text-sm text-muted">Pilih berkas cadangan (.json), atau tempel teks cadangan di bawah. Isinya diperiksa dulu, data baru diganti setelah Anda setuju.</p>
      <input ref={fileRef} type="file" accept=".json,application/json" className="sr-only" aria-label="Berkas cadangan" onChange={(e) => void onFile(e.target.files?.[0])} />
      <button type="button" className="btn btn-soft mb-1 w-full" onClick={() => fileRef.current?.click()}>
        <LuFileUp size={17} /> {fileName ? `Berkas: ${fileName}` : 'Pilih berkas cadangan'}
      </button>
      <p className="my-2 text-center text-xs text-muted">atau</p>
      <textarea
        className="input font-mono text-xs"
        rows={6}
        placeholder="Tempel teks cadangan di sini"
        aria-label="Teks cadangan"
        value={text}
        onChange={(e) => {
          setText(e.target.value);
          setError(null);
        }}
      />
      {error && (
        <p role="alert" className="err mt-3">
          {error}
        </p>
      )}
    </Modal>
  );
}
