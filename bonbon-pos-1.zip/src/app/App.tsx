import { useState } from 'react';
import {
  LuChartColumn,
  LuClipboardList,
  LuEllipsis,
  LuHandCoins,
  LuHistory,
  LuLayoutDashboard,
  LuPackage,
  LuScanBarcode,
  LuSettings,
  LuTriangleAlert,
  LuWallet,
  LuWarehouse,
} from 'react-icons/lu';
import type { IconType } from 'react-icons';
import { alertCounts } from '../core/queries';
import { CashScreen } from '../screens/Cash';
import { DashboardScreen } from '../screens/Dashboard';
import { HistoryScreen } from '../screens/History';
import { KasbonScreen } from '../screens/Kasbon';
import { PosScreen } from '../screens/Pos';
import { ProductsScreen } from '../screens/Products';
import { ReportsScreen } from '../screens/Reports';
import { SettingsScreen } from '../screens/Settings';
import { ShoppingScreen } from '../screens/Shopping';
import { StockScreen } from '../screens/Stock';
import { BonbonMark, BonbonWord } from './brand';
import { CartProvider, useCartView } from './cart';
import { type Route, NavProvider, useNav } from './nav';
import { StockWatcher } from './StockWatcher';
import { useAppState } from './state';
import { Modal, OverlayProvider, cx } from './ui';

const NAV: { route: Route; label: string; icon: IconType }[] = [
  { route: 'beranda', label: 'Beranda', icon: LuLayoutDashboard },
  { route: 'kasir', label: 'Kasir', icon: LuScanBarcode },
  { route: 'produk', label: 'Produk', icon: LuPackage },
  { route: 'stok', label: 'Stok', icon: LuWarehouse },
  { route: 'belanja', label: 'Perlu Belanja', icon: LuClipboardList },
  { route: 'kasbon', label: 'Kasbon', icon: LuHandCoins },
  { route: 'riwayat', label: 'Riwayat', icon: LuHistory },
  { route: 'kas', label: 'Kas Laci', icon: LuWallet },
  { route: 'laporan', label: 'Laporan', icon: LuChartColumn },
  { route: 'pengaturan', label: 'Pengaturan', icon: LuSettings },
];

/** Phone bottom bar: the daily five. Everything else lives under "Lainnya". */
const PHONE_MAIN: Route[] = ['beranda', 'kasir', 'stok', 'kasbon', 'riwayat'];
const PHONE_MORE: Route[] = ['produk', 'belanja', 'kas', 'laporan'];

function Brand({ compact }: { compact?: boolean }) {
  const state = useAppState();
  return (
    <div className={cx('flex min-w-0 items-center gap-2.5', compact && 'md:justify-center xl:justify-start')}>
      {/* the app icon: the candy-b on an indigo tile */}
      <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-accent text-onaccent shadow-[0_3px_10px_rgb(69_64_216/0.35)]">
        <BonbonMark className="h-[19px] w-auto" />
      </span>
      <span className={cx('min-w-0 leading-none', compact && 'md:hidden xl:block')}>
        <BonbonWord className="h-[18px] w-auto text-accent" />
        <span className="mt-1.5 block max-w-36 truncate text-xs font-medium text-muted">{state.settings.storeName}</span>
      </span>
    </div>
  );
}

function RouteView({ route }: { route: Route }) {
  switch (route) {
    case 'beranda':
      return <DashboardScreen />;
    case 'kasir':
      return <PosScreen />;
    case 'produk':
      return <ProductsScreen />;
    case 'stok':
      return <StockScreen />;
    case 'belanja':
      return <ShoppingScreen />;
    case 'kasbon':
      return <KasbonScreen />;
    case 'riwayat':
      return <HistoryScreen />;
    case 'kas':
      return <CashScreen />;
    case 'laporan':
      return <ReportsScreen />;
    case 'pengaturan':
      return <SettingsScreen />;
  }
}

/** A fresh wrapper per screen, so every navigation (also a change of parameters) plays the short entrance. */
function Screen() {
  const { route, params } = useNav();
  return (
    <div key={route + JSON.stringify(params)} className="anim-page">
      <RouteView route={route} />
    </div>
  );
}

function Shell() {
  const state = useAppState();
  const { route, go } = useNav();
  const cart = useCartView();
  const counts = alertCounts(state);
  const alertTotal = counts.low + counts.out;
  const [more, setMore] = useState(false);
  const moreActive = PHONE_MORE.includes(route);

  const badge = (r: Route) => {
    if (r === 'belanja' && alertTotal > 0) return { n: alertTotal, bad: counts.out > 0 };
    if (r === 'kasir' && cart.itemCount > 0) return { n: cart.itemCount, bad: false };
    return null;
  };

  return (
    <div className="mx-auto grid max-w-[1480px] gap-4 md:grid-cols-[72px_minmax(0,1fr)] xl:grid-cols-[216px_minmax(0,1fr)] xl:gap-6">
      {/* sidebar: icon rail on tablets, full labels on wide screens */}
      <aside className="sticky top-4 hidden h-[calc(100dvh-2rem)] flex-col gap-4 md:flex">
        <div className="card flex h-full flex-col gap-4 p-3 xl:p-4">
          <Brand compact />
          <nav aria-label="Menu utama" className="flex flex-col gap-1">
            {NAV.filter((n) => n.route !== 'pengaturan').map(({ route: r, label, icon: Icon }) => {
              const b = badge(r);
              const active = route === r;
              return (
                <button
                  key={r}
                  type="button"
                  aria-current={active ? 'page' : undefined}
                  title={label}
                  onClick={() => go(r)}
                  className={cx(
                    'relative flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-semibold transition-colors md:justify-center xl:justify-start',
                    active ? 'bg-accentsoft text-accent' : 'text-muted hover:bg-sunken hover:text-ink',
                  )}
                >
                  <Icon size={19} aria-hidden="true" className="shrink-0" />
                  <span className="hidden xl:inline">{label}</span>
                  {b && (
                    <span className={cx('money min-w-5 rounded-full px-1.5 text-center text-[11px] leading-5 font-bold md:absolute md:top-1 md:right-1 xl:static xl:ml-auto', b.bad ? 'bg-bad text-onbad' : 'bg-warn text-canvas')}>
                      {b.n}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
          <div className="mt-auto">
            {(() => {
              const active = route === 'pengaturan';
              return (
                <button
                  type="button"
                  aria-current={active ? 'page' : undefined}
                  title="Pengaturan"
                  onClick={() => go('pengaturan')}
                  className={cx('flex min-h-11 w-full items-center gap-3 rounded-xl px-3 text-sm font-semibold transition-colors md:justify-center xl:justify-start', active ? 'bg-accentsoft text-accent' : 'text-muted hover:bg-sunken hover:text-ink')}
                >
                  <LuSettings size={19} aria-hidden="true" className="shrink-0" />
                  <span className="hidden xl:inline">Pengaturan</span>
                </button>
              );
            })()}
          </div>
        </div>
      </aside>

      <div className="min-w-0 pb-24 md:pb-4">
        {/* phone header */}
        <header className="mb-4 flex items-center justify-between md:hidden">
          <Brand />
          <button type="button" className="btn-icon" aria-label="Pengaturan" aria-current={route === 'pengaturan' ? 'page' : undefined} onClick={() => go('pengaturan')}>
            <LuSettings size={19} />
          </button>
        </header>

        {state.volatile && (
          <div role="alert" className="mb-4 flex items-start gap-2.5 rounded-lg bg-warnsoft px-4 py-3 text-sm font-medium text-warn">
            <LuTriangleAlert className="mt-0.5 shrink-0" size={17} />
            Penyimpanan peramban tidak tersedia di sini (mode pratinjau atau privat). Data hanya bertahan selama halaman terbuka.
          </div>
        )}

        <main>
          <Screen />
        </main>
      </div>

      {/* phone bottom bar */}
      <nav
        aria-label="Menu utama"
        className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-6 border-t border-line bg-panel pl-[max(4px,env(safe-area-inset-left,0px))] pr-[max(4px,env(safe-area-inset-right,0px))] pt-1.5 pb-[calc(0.375rem+env(safe-area-inset-bottom,0px))] md:hidden"
      >
        {PHONE_MAIN.map((r) => {
          const { label, icon: Icon } = NAV.find((n) => n.route === r) as (typeof NAV)[number];
          const active = route === r;
          return (
            <button
              key={r}
              type="button"
              aria-current={active ? 'page' : undefined}
              onClick={() => go(r)}
              className={cx('relative flex min-h-12 min-w-0 flex-col items-center justify-center gap-0.5 rounded-md text-[11px] font-semibold', active ? 'text-accent' : 'text-muted')}
            >
              <span className={cx('grid h-7 place-items-center rounded-full transition-[width,background-color] duration-300 ease-out', active ? 'w-14 bg-accentsoft' : 'w-9 bg-transparent')}>
                <Icon size={20} aria-hidden="true" className={cx('transition-transform duration-300', active && '-translate-y-px scale-110')} />
              </span>
              {/* very narrow phones (< 320px) keep the icon and the active colour; the name stays for screen readers */}
              <span className="tracking-tight max-[319px]:sr-only">{label}</span>
            </button>
          );
        })}
        <button
          type="button"
          aria-haspopup="dialog"
          aria-current={moreActive ? 'page' : undefined}
          onClick={() => setMore(true)}
          className={cx('relative flex min-h-12 min-w-0 flex-col items-center justify-center gap-0.5 rounded-md text-[11px] font-semibold', moreActive ? 'text-accent' : 'text-muted')}
        >
          <span className={cx('grid h-7 place-items-center rounded-full transition-[width,background-color] duration-300 ease-out', moreActive ? 'w-14 bg-accentsoft' : 'w-9 bg-transparent')}>
            <LuEllipsis size={20} aria-hidden="true" />
          </span>
          <span className="tracking-tight max-[319px]:sr-only">Lainnya</span>
          {alertTotal > 0 && (
            <span className={cx('money absolute top-0 right-1/2 -mr-5 min-w-4 rounded-full px-1 text-center text-[10px] leading-4 font-bold', counts.out > 0 ? 'bg-bad text-onbad' : 'bg-warn text-canvas')}>{alertTotal}</span>
          )}
        </button>
      </nav>

      {more && (
        <Modal title="Menu lainnya" size="sm" focusFirstField={false} onClose={() => setMore(false)}>
          <ul className="-my-1 divide-y divide-line">
            {PHONE_MORE.map((r) => {
              const { label, icon: Icon } = NAV.find((n) => n.route === r) as (typeof NAV)[number];
              const b = badge(r);
              return (
                <li key={r}>
                  <button
                    type="button"
                    onClick={() => {
                      setMore(false);
                      go(r);
                    }}
                    className={cx('flex min-h-12 w-full items-center gap-3 text-left text-[15px] font-semibold', route === r ? 'text-accent' : 'text-ink')}
                  >
                    <Icon size={20} aria-hidden="true" className="shrink-0" />
                    <span className="flex-1">{label}</span>
                    {b && r === 'belanja' && <span className={cx('money min-w-5 rounded-full px-1.5 text-center text-[11px] leading-5 font-bold', b.bad ? 'bg-bad text-onbad' : 'bg-warn text-canvas')}>{b.n}</span>}
                  </button>
                </li>
              );
            })}
          </ul>
        </Modal>
      )}
    </div>
  );
}

export function App() {
  return (
    <OverlayProvider>
      <CartProvider>
        <NavProvider>
          <StockWatcher />
          <Shell />
        </NavProvider>
      </CartProvider>
    </OverlayProvider>
  );
}
