// In-memory database with atomic, serialized mutations.
//
// Every business operation runs inside `store.mutate(tx => ...)`. The operation reads
// the current state, stages its writes on `tx`, and only when the callback finishes
// without throwing are ALL staged writes committed in one storage transaction and then
// applied to memory. A thrown error leaves the database untouched.

import type { Changes, Persistence, Snapshot, TableName, TableRow } from './persistence';
import { TABLES } from './persistence';
import type { CashMove, Customer, DebtEntry, HeldCart, OpnameSession, Product, ProductUnit, ReturnRecord, Settings, Shift, StockMovement, Transaction } from './types';
import { debtDelta } from './types';
import { DEFAULT_SETTINGS } from './types';

export interface State {
  version: number;
  volatile: boolean;
  settings: Settings;
  products: Product[];
  productsById: Map<string, Product>;
  unitsByProduct: Map<string, ProductUnit[]>;
  movements: StockMovement[]; // newest first
  transactions: Transaction[]; // newest first
  txById: Map<string, Transaction>;
  txByDate: Map<string, Transaction[]>; // newest first within a day
  customers: Customer[]; // by name
  customersById: Map<string, Customer>;
  debtByCustomer: Map<string, DebtEntry[]>; // oldest first (notebook order)
  balanceByCustomer: Map<string, number>; // outstanding kasbon; missing = 0
  debtEntryByTx: Map<string, DebtEntry>; // the kasbon line a sale created
  shifts: Shift[]; // newest first
  shiftsById: Map<string, Shift>;
  openShift: Shift | null; // the running shift, if any
  cashMoves: CashMove[]; // newest first
  returns: ReturnRecord[]; // newest first
  returnsByTx: Map<string, ReturnRecord[]>; // oldest first within a sale
  returnsByDate: Map<string, ReturnRecord[]>;
  opnames: OpnameSession[]; // newest first
  holds: HeldCart[]; // carts put on hold, oldest first
}

type TableMaps = { [K in TableName]: Map<string, TableRow<K>> };

function newTables(): TableMaps {
  const t = {} as Record<TableName, Map<string, unknown>>;
  for (const name of TABLES) t[name] = new Map();
  return t as TableMaps;
}

function newDeletes(): { [K in TableName]: Set<string> } {
  const t = {} as Record<TableName, Set<string>>;
  for (const name of TABLES) t[name] = new Set();
  return t;
}

const RECEIPT_RE = /^INV-(\d{4})(\d{2})(\d{2})-(\d+)$/;

export class Tx {
  private puts: { [K in TableName]: Map<string, TableRow<K>> } = newTables();
  private dels = newDeletes();
  private receiptSeq = new Map<string, number>();

  constructor(private readonly store: Store) {}

  get<K extends TableName>(table: K, id: string): TableRow<K> | undefined {
    if (this.dels[table].has(id)) return undefined;
    return (this.puts[table].get(id) as TableRow<K> | undefined) ?? (this.store.tables[table].get(id) as TableRow<K> | undefined);
  }

  list<K extends TableName>(table: K): TableRow<K>[] {
    const out: TableRow<K>[] = [];
    for (const [id, row] of this.store.tables[table]) {
      if (this.dels[table].has(id) || this.puts[table].has(id)) continue;
      out.push(row as TableRow<K>);
    }
    for (const row of this.puts[table].values()) out.push(row as TableRow<K>);
    return out;
  }

  put<K extends TableName>(table: K, row: TableRow<K>): void {
    const id = (row as { id: string }).id;
    this.dels[table].delete(id);
    (this.puts[table] as Map<string, unknown>).set(id, row);
  }

  del<K extends TableName>(table: K, id: string): void {
    this.puts[table].delete(id);
    this.dels[table].add(id);
  }

  get settings(): Settings {
    return this.get('settings', 'main') ?? DEFAULT_SETTINGS;
  }

  /** Next receipt number for a WIB date key: INV-YYYYMMDD-0001, per-day sequence. */
  nextReceiptNo(dateKey: string): string {
    const seq = Math.max(this.store.receiptSeq.get(dateKey) ?? 0, this.receiptSeq.get(dateKey) ?? 0) + 1;
    this.receiptSeq.set(dateKey, seq);
    return `INV-${dateKey.replace(/-/g, '')}-${String(seq).padStart(4, '0')}`;
  }

  /** @internal */
  changes(): Changes {
    const c: Changes = { put: {}, del: {} };
    for (const t of TABLES) {
      if (this.puts[t].size) (c.put[t] as unknown[]) = [...this.puts[t].values()];
      if (this.dels[t].size) c.del[t] = [...this.dels[t]];
    }
    return c;
  }
}

export class Store {
  /** @internal */
  tables: TableMaps = newTables();
  /** @internal */
  receiptSeq = new Map<string, number>();

  private version = 0;
  private cached: State | null = null;
  private listeners = new Set<() => void>();
  private queue: Promise<unknown> = Promise.resolve();

  constructor(private readonly persistence: Persistence) {}

  get volatile(): boolean {
    return this.persistence.volatile;
  }

  async init(): Promise<void> {
    const snap = await this.persistence.load();
    this.fill(snap);
    if (!this.tables.settings.has('main')) {
      this.tables.settings.set('main', { ...DEFAULT_SETTINGS });
      try {
        await this.persistence.commit({ put: { settings: [{ ...DEFAULT_SETTINGS }] }, del: {} });
      } catch {
        /* settings will be saved on the next successful commit */
      }
    }
    this.touch();
  }

  private fill(snap: Snapshot): void {
    this.tables = newTables();
    this.receiptSeq = new Map();
    for (const t of TABLES) {
      for (const row of snap[t] as { id: string }[]) (this.tables[t] as Map<string, unknown>).set(row.id, row);
    }
    // merge defaults so older saved settings gain new fields
    const s = this.tables.settings.get('main');
    // 'Toko Contoh' was the old untouched default name; carry it over to the current default
    if (s) this.tables.settings.set('main', { ...DEFAULT_SETTINGS, ...s, storeName: s.storeName === 'Toko Contoh' ? DEFAULT_SETTINGS.storeName : s.storeName });
    for (const t of this.tables.transactions.values()) this.trackReceipt(t);
  }

  private trackReceipt(t: Transaction): void {
    const m = RECEIPT_RE.exec(t.receiptNo);
    if (!m) return;
    const key = `${m[1]}-${m[2]}-${m[3]}`;
    const n = Number(m[4]);
    if (n > (this.receiptSeq.get(key) ?? 0)) this.receiptSeq.set(key, n);
  }

  subscribe = (fn: () => void): (() => void) => {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  };

  private touch(): void {
    this.version += 1;
    this.cached = null;
    for (const fn of this.listeners) fn();
  }

  /** Stable between commits, so it is safe for useSyncExternalStore. */
  getState = (): State => {
    if (this.cached) return this.cached;
    const products = [...this.tables.products.values()].sort((a, b) => a.name.localeCompare(b.name, 'id'));
    const unitsByProduct = new Map<string, ProductUnit[]>();
    for (const u of this.tables.productUnits.values()) {
      const arr = unitsByProduct.get(u.productId);
      if (arr) arr.push(u);
      else unitsByProduct.set(u.productId, [u]);
    }
    for (const arr of unitsByProduct.values()) arr.sort((a, b) => a.conversion - b.conversion);
    const byNewest = <T extends { createdAt: string }>(a: T, b: T) => (a.createdAt < b.createdAt ? 1 : a.createdAt > b.createdAt ? -1 : 0);
    const movements = [...this.tables.stockMovements.values()].reverse().sort(byNewest);
    const transactions = [...this.tables.transactions.values()].reverse().sort(byNewest);
    const txByDate = new Map<string, Transaction[]>();
    for (const t of transactions) {
      const arr = txByDate.get(t.dateKey);
      if (arr) arr.push(t);
      else txByDate.set(t.dateKey, [t]);
    }
    const customers = [...this.tables.customers.values()].sort((a, b) => a.name.localeCompare(b.name, 'id'));
    const debtByCustomer = new Map<string, DebtEntry[]>();
    for (const e of this.tables.debtEntries.values()) {
      const arr = debtByCustomer.get(e.customerId);
      if (arr) arr.push(e);
      else debtByCustomer.set(e.customerId, [e]);
    }
    const balanceByCustomer = new Map<string, number>();
    const debtEntryByTx = new Map<string, DebtEntry>();
    for (const [id, arr] of debtByCustomer) {
      arr.sort((a, b) => a.seq - b.seq);
      balanceByCustomer.set(id, arr.reduce((s, e) => s + debtDelta(e), 0));
      for (const e of arr) if (e.type === 'kasbon' && e.txId) debtEntryByTx.set(e.txId, e);
    }
    const shifts = [...this.tables.shifts.values()].sort((a, b) => (a.openedAt < b.openedAt ? 1 : a.openedAt > b.openedAt ? -1 : 0));
    const cashMoves = [...this.tables.cashMoves.values()].sort(byNewest);
    const returns = [...this.tables.returns.values()].sort(byNewest);
    const returnsByTx = new Map<string, ReturnRecord[]>();
    const returnsByDate = new Map<string, ReturnRecord[]>();
    for (const r of [...returns].reverse()) {
      const a = returnsByTx.get(r.txId);
      if (a) a.push(r);
      else returnsByTx.set(r.txId, [r]);
    }
    for (const r of returns) {
      const a = returnsByDate.get(r.dateKey);
      if (a) a.push(r);
      else returnsByDate.set(r.dateKey, [r]);
    }
    const opnames = [...this.tables.opnames.values()].sort((a, b) => (a.startedAt < b.startedAt ? 1 : a.startedAt > b.startedAt ? -1 : 0));
    const holds = [...this.tables.holds.values()].sort((a, b) => (a.createdAt < b.createdAt ? -1 : a.createdAt > b.createdAt ? 1 : 0));
    this.cached = {
      version: this.version,
      volatile: this.persistence.volatile,
      settings: this.tables.settings.get('main') ?? DEFAULT_SETTINGS,
      products,
      productsById: new Map(products.map((p) => [p.id, p])),
      unitsByProduct,
      movements,
      transactions,
      txById: new Map(transactions.map((t) => [t.id, t])),
      txByDate,
      customers,
      customersById: new Map(customers.map((c) => [c.id, c])),
      debtByCustomer,
      balanceByCustomer,
      debtEntryByTx,
      shifts,
      shiftsById: new Map(shifts.map((x) => [x.id, x])),
      openShift: shifts.find((x) => x.status === 'open') ?? null,
      cashMoves,
      returns,
      returnsByTx,
      returnsByDate,
      opnames,
      holds,
    };
    return this.cached;
  };

  /** Run an operation atomically. Operations never interleave. */
  mutate<T>(fn: (tx: Tx) => T | Promise<T>): Promise<T> {
    const run = async (): Promise<T> => {
      const tx = new Tx(this);
      const result = await fn(tx);
      const changes = tx.changes();
      const touched = TABLES.some((t) => (changes.put[t]?.length ?? 0) > 0 || (changes.del[t]?.length ?? 0) > 0);
      if (touched) {
        await this.persistence.commit(changes);
        this.apply(changes);
      }
      return result;
    };
    const p = this.queue.then(run);
    this.queue = p.catch(() => undefined);
    return p;
  }

  private apply(changes: Changes): void {
    for (const t of TABLES) {
      for (const row of (changes.put[t] ?? []) as { id: string }[]) {
        (this.tables[t] as Map<string, unknown>).set(row.id, row);
        if (t === 'transactions') this.trackReceipt(row as unknown as Transaction);
      }
      for (const id of changes.del[t] ?? []) this.tables[t].delete(id);
    }
    this.touch();
  }

  /** Every table as plain arrays (for backups). Safe to serialise. */
  snapshot(): Snapshot {
    const snap = {} as Record<TableName, unknown[]>;
    for (const t of TABLES) snap[t] = [...this.tables[t].values()];
    return snap as unknown as Snapshot;
  }

  /** Replace ALL data with `snap` (already validated). Atomic: on failure the current data is untouched. */
  restore(snap: Snapshot): Promise<void> {
    const run = async () => {
      await this.persistence.replaceAll(snap);
      this.fill(snap);
      if (!this.tables.settings.has('main')) this.tables.settings.set('main', { ...DEFAULT_SETTINGS });
      this.touch();
    };
    const p = this.queue.then(run);
    this.queue = p.catch(() => undefined);
    return p;
  }

  /** Wipe every table and restore default settings (sample data is not offered again). */
  async resetAll(): Promise<void> {
    const run = async () => {
      const fresh = { ...DEFAULT_SETTINGS, demoOffered: true };
      await this.persistence.clear();
      this.tables = newTables();
      this.receiptSeq = new Map();
      this.tables.settings.set('main', fresh);
      await this.persistence.commit({ put: { settings: [fresh] }, del: {} });
      this.touch();
    };
    const p = this.queue.then(run);
    this.queue = p.catch(() => undefined);
    return p;
  }
}
