// Text exports: receipt (monospace), shopping list (text + CSV).

import { formatDateKey, formatDateTime, formatNumber, formatQty, formatRupiah } from './format';
import type { Settings, Transaction } from './types';
import type { ReceiptExtra } from './whatsapp';
import { METHOD_LABEL } from './types';

export function toCsv(rows: (string | number)[][]): string {
  const cell = (v: string | number) => {
    const s = String(v);
    return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return rows.map((r) => r.map(cell).join(',')).join('\r\n');
}

export interface ShoppingRow {
  name: string;
  sku: string;
  unit: string;
  stock: number;
  minStock: number;
  qty: number;
  status: string;
}

export function shoppingText(storeName: string, dateKey: string, rows: ShoppingRow[]): string {
  const lines = [`Daftar belanja - ${storeName}`, formatDateKey(dateKey), ''];
  for (const r of rows) {
    if (r.qty > 0) lines.push(`- ${r.name}: ${formatQty(r.qty)} ${r.unit}`);
  }
  return lines.join('\n');
}

export function shoppingCsv(rows: ShoppingRow[]): string {
  return toCsv([
    ['Produk', 'SKU', 'Status', 'Stok', 'Stok minimum', 'Jumlah beli', 'Satuan'],
    ...rows.map((r) => [r.name, r.sku, r.status, r.stock, r.minStock, r.qty, r.unit]),
  ]);
}

// ---- Receipt as plain text (copy / WhatsApp / fallback for printing) ----------

function wrap(text: string, width: number): string[] {
  const out: string[] = [];
  let line = '';
  for (const word of text.split(/\s+/).filter(Boolean)) {
    if (!line) line = word;
    else if ((line + ' ' + word).length <= width) line += ' ' + word;
    else {
      out.push(line);
      line = word;
    }
  }
  if (line) out.push(line);
  return out.length ? out : [''];
}

export interface ReceiptLayout {
  /** monospace lines, already padded to the paper's character width */
  lines: string[];
  /** indexes of lines printed bold (store name, TOTAL) */
  bold: number[];
  /** characters per line: 32 for 58 mm, 48 for 80 mm paper */
  width: number;
}

/** The receipt as fixed-width lines. Copy, WhatsApp, browser print and ESC/POS all come from this one layout. */
export function receiptLayout(t: Transaction, s: Settings, extra: ReceiptExtra = {}): ReceiptLayout {
  const W = s.paperWidth === 80 ? 48 : 32;
  const rule = '-'.repeat(W);
  const center = (x: string) => (x.length >= W ? x : ' '.repeat(Math.floor((W - x.length) / 2)) + x);
  const row = (l: string, r: string) => {
    const room = W - r.length - 1;
    const left = l.length > room ? l.slice(0, Math.max(0, room)) : l;
    return left + ' '.repeat(Math.max(1, W - left.length - r.length)) + r;
  };
  const signed = (n: number) => (n > 0 ? '+' : n < 0 ? '-' : '') + formatNumber(Math.abs(n));

  const out: string[] = [];
  const bold: number[] = [];
  for (const l of wrap(s.storeName, W)) {
    bold.push(out.length);
    out.push(center(l));
  }
  for (const l of wrap(s.address, W)) out.push(center(l));
  if (s.phone) out.push(center(s.phone));
  out.push(rule);
  out.push(row('No', t.receiptNo));
  out.push(row('Tanggal', formatDateTime(t.createdAt)));
  out.push(row('Kasir', t.cashierName));
  if (t.customerName) out.push(row('Pelanggan', t.customerName));
  out.push(rule);
  for (const i of t.items) {
    for (const l of wrap(i.name, W)) out.push(l);
    const gross = Math.round(i.unitQty * i.unitPrice);
    out.push(row(`  ${formatQty(i.unitQty)} ${i.unitName} x ${formatNumber(i.unitPrice)}`, formatNumber(gross)));
    if (i.discount > 0) out.push(row('  Diskon', '-' + formatNumber(i.discount)));
    if (i.note) out.push('  * ' + i.note);
  }
  out.push(rule);
  out.push(row('Subtotal', formatNumber(t.subtotal)));
  if (t.discount > 0) out.push(row('Diskon', '-' + formatNumber(t.discount)));
  if (t.tax > 0) out.push(row(`PPN ${t.taxPercent}%`, formatNumber(t.tax)));
  if (t.rounding !== 0) out.push(row('Pembulatan', signed(t.rounding)));
  bold.push(out.length);
  out.push(row('TOTAL', formatRupiah(t.total)));
  out.push(rule);
  for (const p of t.payments) {
    out.push(row(METHOD_LABEL[p.method] + (p.status === 'pending' ? ' (menunggu)' : ''), formatRupiah(p.amount)));
    if (p.method === 'cash' && (p.tendered ?? p.amount) > p.amount) out.push(row('  Diterima', formatRupiah(p.tendered as number)));
    if (p.reference) out.push('  Ref: ' + p.reference);
  }
  if (t.change > 0) out.push(row('Kembali', formatRupiah(t.change)));
  if (extra.debtAfter !== undefined && t.customerName) {
    bold.push(out.length);
    out.push(row('Total kasbon', formatRupiah(extra.debtAfter)));
  }
  out.push(rule);
  for (const l of wrap(s.receiptFooter, W)) out.push(center(l));
  if (t.status === 'voided') {
    out.push('');
    bold.push(out.length);
    out.push(center('*** DIBATALKAN ***'));
    if (t.voidReason) for (const l of wrap(t.voidReason, W)) out.push(center(l));
  }
  return { lines: out, bold, width: W };
}

export function receiptText(t: Transaction, s: Settings, extra: ReceiptExtra = {}): string {
  return receiptLayout(t, s, extra).lines.join('\n');
}
