import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { BACKUP_FORMAT, backupAgeDays, backupFileName, backupText, createBackup, markBackedUp, parseBackup, restoreBackup } from '../src/core/backup';
import { holdCart } from '../src/core/holds';
import { startOpname } from '../src/core/opname';
import { MemoryPersistence } from '../src/core/persistence';
import { returnItems } from '../src/core/returns';
import { checkout, receiveStock, saveCustomer, saveProduct, saveSettings } from '../src/core/services';
import { addCashMove, openShift } from '../src/core/shifts';
import { Store } from '../src/core/store';

const NOW = new Date('2026-10-24T05:00:00Z'); // Sabtu 24 Okt 2026, 12.00 WIB
const at = (minutes: number) => new Date(NOW.getTime() + minutes * 60_000);

/** A shop with a bit of everything: sales, kasbon, a return, an open shift, a hold and an opname. */
async function busyShop() {
  const persistence = new MemoryPersistence();
  const store = new Store(persistence);
  await store.init();
  await saveSettings(store, { storeName: 'Warung Manop', requireShift: false });
  const mie = await saveProduct(store, { name: 'Indomie Goreng', category: 'Makanan', baseUnit: 'pcs', costPrice: 2800, sellPrice: 3500, minStock: 5 }, NOW);
  const air = await saveProduct(store, { name: 'Air Mineral', category: 'Minuman', baseUnit: 'botol', costPrice: 2000, sellPrice: 3000, minStock: 5 }, NOW);
  await receiveStock(store, { productId: mie.id, unitQty: 100, unitCost: 2800 }, NOW);
  await receiveStock(store, { productId: air.id, unitQty: 50, unitCost: 2000 }, NOW);
  const budi = await saveCustomer(store, { name: 'Pak Budi', phone: '0812-3456-7890' }, NOW);
  await openShift(store, { openingCash: 50_000 }, at(1));
  await addCashMove(store, { type: 'in', amount: 10_000, note: 'Tambah modal' }, at(2));
  const t1 = await checkout(store, { lines: [{ productId: mie.id, unitName: 'pcs', unitQty: 4 }], payments: [{ method: 'cash', amount: 14_000, tendered: 20_000 }] }, at(3));
  await checkout(store, { lines: [{ productId: air.id, unitName: 'botol', unitQty: 2 }], payments: [{ method: 'kasbon', amount: 6000, customerId: budi.id }] }, at(4));
  await returnItems(store, { txId: t1.id, lines: [{ itemIndex: 0, unitQty: 1 }], refundMethod: 'cash', restock: true, reason: 'Salah beli' }, at(5));
  await holdCart(store, { label: 'Bu Ani', lines: [{ productId: mie.id, unitName: 'pcs', unitQty: 3 }] }, at(6));
  await startOpname(store, { scope: 'Semua' }, at(7));
  return { store, persistence, mie, air, budi };
}

/** Plain objects, in a stable order, so two stores can be compared. */
function dump(store: Store) {
  const snap = store.snapshot() as unknown as Record<string, { id: string }[]>;
  const out: Record<string, unknown[]> = {};
  for (const [t, rows] of Object.entries(snap)) out[t] = [...rows].sort((a, b) => a.id.localeCompare(b.id));
  return JSON.parse(JSON.stringify(out));
}

describe('cadangan: buat dan baca', () => {
  it('cadangan lalu pulihkan ke toko kosong mengembalikan semua data persis sama', async () => {
    const a = await busyShop();
    const file = createBackup(a.store, at(10));
    assert.equal(file.app, 'warung-manop');
    assert.equal(file.format, BACKUP_FORMAT);
    assert.equal(file.counts.products, 2);
    assert.equal(file.counts.transactions, 2);
    assert.equal(file.counts.returns, 1);
    assert.equal(file.counts.customers, 1);

    const parsed = parseBackup(backupText(file));
    assert.equal(parsed.info.storeName, 'Warung Manop');
    assert.equal(parsed.info.counts.transactions, 2);

    const b = new Store(new MemoryPersistence());
    await b.init();
    await restoreBackup(b, parsed);

    const want = dump(a.store);
    const got = dump(b);
    // the restored shop remembers its backup time and will not be offered sample data
    assert.equal((got.settings[0] as { lastBackupAt?: string }).lastBackupAt, at(10).toISOString());
    (want.settings[0] as Record<string, unknown>).lastBackupAt = at(10).toISOString();
    (want.settings[0] as Record<string, unknown>).demoOffered = true;
    assert.deepEqual(got, want);

    const s = b.getState();
    assert.equal(s.productsById.get(a.mie.id)?.stock, 97); // 100 - 4 + 1 returned
    assert.equal(s.balanceByCustomer.get(a.budi.id), 6000);
    assert.equal(s.openShift?.openingCash, 50_000);
    assert.equal(s.holds.length, 1);
    assert.equal(s.returnsByTx.size, 1);
  });

  it('nomor struk tetap berlanjut setelah dipulihkan (tidak mengulang nomor)', async () => {
    const a = await busyShop();
    const b = new Store(new MemoryPersistence());
    await b.init();
    await restoreBackup(b, parseBackup(backupText(createBackup(a.store, at(10)))));
    const t = await checkout(b, { lines: [{ productId: a.mie.id, unitName: 'pcs', unitQty: 1 }], payments: [{ method: 'cash', amount: 3500, tendered: 3500 }] }, at(20));
    assert.equal(t.receiptNo, 'INV-20261024-0003');
  });

  it('pemulihan tersimpan permanen (dibuka ulang dari penyimpanan)', async () => {
    const a = await busyShop();
    const persistence = new MemoryPersistence();
    const b = new Store(persistence);
    await b.init();
    await restoreBackup(b, parseBackup(backupText(createBackup(a.store, at(10)))));
    const reopened = new Store(persistence);
    await reopened.init();
    assert.deepEqual(dump(reopened), dump(b));
  });

  it('pemulihan MENGGANTI data yang ada, bukan menambahkan', async () => {
    const a = await busyShop();
    const file = backupText(createBackup(a.store, at(10)));
    const b = new Store(new MemoryPersistence());
    await b.init();
    await saveProduct(b, { name: 'Barang Lain', category: 'X', baseUnit: 'pcs', costPrice: 1, sellPrice: 2, minStock: 0 }, NOW);
    await restoreBackup(b, parseBackup(file));
    assert.equal(b.getState().products.length, 2);
    assert.equal(b.getState().products.some((p) => p.name === 'Barang Lain'), false);
  });

  it('cadangan tidak mengubah data yang sedang berjalan, dan markBackedUp mencatat waktunya', async () => {
    const a = await busyShop();
    const before = dump(a.store);
    createBackup(a.store, at(10));
    assert.deepEqual(dump(a.store), before);
    assert.equal(a.store.getState().settings.lastBackupAt, undefined);
    await markBackedUp(a.store, at(10));
    assert.equal(a.store.getState().settings.lastBackupAt, at(10).toISOString());
    // nothing else was touched
    const after = dump(a.store);
    (after.settings[0] as Record<string, unknown>).lastBackupAt = undefined;
    (before.settings[0] as Record<string, unknown>).lastBackupAt = undefined;
    assert.deepEqual(JSON.parse(JSON.stringify(after)), JSON.parse(JSON.stringify(before)));
  });

  it('berkas dari versi lama tanpa tabel baru dianggap tabel itu kosong', async () => {
    const a = await busyShop();
    const file = createBackup(a.store, at(10)) as unknown as { tables: Record<string, unknown> };
    delete file.tables.holds;
    delete file.tables.opnames;
    delete file.tables.returns;
    const parsed = parseBackup(JSON.stringify(file));
    assert.equal(parsed.snapshot.holds.length, 0);
    assert.equal(parsed.snapshot.opnames.length, 0);
    assert.equal(parsed.info.counts.products, 2);
  });

  it('BOM di awal berkas (dari editor Windows) tidak jadi masalah', async () => {
    const a = await busyShop();
    const parsed = parseBackup('﻿' + backupText(createBackup(a.store, at(10))));
    assert.equal(parsed.info.counts.products, 2);
  });
});

describe('cadangan: berkas rusak ditolak sebelum menyentuh data', () => {
  async function good() {
    const a = await busyShop();
    return JSON.parse(backupText(createBackup(a.store, at(10)))) as { app: string; format: number; tables: Record<string, Record<string, unknown>[]> };
  }
  const bad = (obj: unknown, re: RegExp) => assert.throws(() => parseBackup(JSON.stringify(obj)), re);

  it('kosong, bukan JSON, terpotong, atau bukan cadangan Warung Manop', async () => {
    assert.throws(() => parseBackup(''), /kosong/);
    assert.throws(() => parseBackup('   \n '), /kosong/);
    assert.throws(() => parseBackup('halo'), /bukan cadangan yang utuh/);
    const a = await busyShop();
    const text = backupText(createBackup(a.store, at(10)));
    assert.throws(() => parseBackup(text.slice(0, text.length - 40)), /bukan cadangan yang utuh/);
    bad({ foo: 1 }, /bukan berkas cadangan Bonbon/);
    bad([], /bukan berkas cadangan Bonbon/);
    bad({ app: 'lain', format: 1, tables: {} }, /bukan berkas cadangan Bonbon/);
    bad({ app: 'warung-manop', format: 1 }, /bukan berkas cadangan Bonbon/);
  });

  it('format lebih baru dari aplikasi ini', async () => {
    const g = await good();
    g.format = BACKUP_FORMAT + 1;
    bad(g, /versi aplikasi yang lebih baru/);
    g.format = 'x' as unknown as number;
    bad(g, /versi aplikasi yang lebih baru/);
  });

  it('tabel bukan daftar, baris bukan objek, tanpa ID, atau ID ganda', async () => {
    let g = await good();
    (g.tables as Record<string, unknown>).products = { a: 1 };
    bad(g, /produk di cadangan rusak/);
    g = await good();
    (g.tables.products as unknown[])[0] = 'x';
    bad(g, /produk baris 1.*tanpa ID/);
    g = await good();
    delete g.tables.transactions[0].id;
    bad(g, /transaksi baris 1.*tanpa ID/);
    g = await good();
    g.tables.products[1].id = g.tables.products[0].id;
    bad(g, /produk di cadangan punya ID ganda/);
  });

  it('isi baris yang tidak masuk akal', async () => {
    let g = await good();
    g.tables.products[0].stock = 'banyak';
    bad(g, /produk baris 1.*produk tidak lengkap/);
    g = await good();
    g.tables.products[0].sellPrice = null;
    bad(g, /produk tidak lengkap/);
    g = await good();
    g.tables.transactions[0].status = 'hilang';
    bad(g, /transaksi tidak lengkap/);
    g = await good();
    g.tables.transactions[0].dateKey = '24-10-2026';
    bad(g, /transaksi tidak lengkap/);
    g = await good();
    g.tables.transactions[0].items = 'x';
    bad(g, /transaksi tidak lengkap/);
    g = await good();
    g.tables.debtEntries[0].type = 'hadiah';
    bad(g, /kasbon tidak lengkap/);
    g = await good();
    g.tables.shifts[0].status = 'setengah';
    bad(g, /data kas tidak lengkap/);
    g = await good();
    g.tables.cashMoves[0].type = 'lain';
    bad(g, /uang masuk\/keluar tidak lengkap/);
    g = await good();
    g.tables.returns[0].refund = 'x';
    bad(g, /retur tidak lengkap/);
    g = await good();
    g.tables.holds[0].lines = null;
    bad(g, /keranjang tertahan tidak lengkap/);
    g = await good();
    g.tables.settings[0].storeName = 5;
    bad(g, /pengaturan tidak lengkap/);
  });

  it('pengaturan ganda atau ber-ID lain', async () => {
    const g = await good();
    g.tables.settings.push({ ...g.tables.settings[0], id: 'main2' });
    bad(g, /pengaturan tidak lengkap|pengaturan.*ganda/);
    const h = await good();
    h.tables.settings[0].id = 'lain';
    bad(h, /pengaturan tidak lengkap/);
  });

  it('rujukan yang putus: satuan tanpa produk, kasbon tanpa pelanggan, retur tanpa transaksi, kas tanpa shift, dua shift terbuka', async () => {
    let g = await good();
    g.tables.customers = [];
    bad(g, /kasbon yang pelanggannya tidak ada/);
    g = await good();
    g.tables.transactions = [];
    bad(g, /retur yang transaksinya tidak ada/);
    g = await good();
    g.tables.shifts = [];
    bad(g, /uang masuk\/keluar yang kasnya tidak ada/);
    g = await good();
    g.tables.shifts.push({ ...g.tables.shifts[0], id: 'shift-lain' });
    bad(g, /lebih dari satu kas yang masih terbuka/);
    g = await good();
    g.tables.productUnits = [{ id: 'u-hantu', productId: 'produk-hantu', name: 'dus', conversion: 24 }];
    bad(g, /satuan yang produknya tidak ada/);
    g = await good();
    g.tables.productUnits = [{ id: 'u-nol', productId: g.tables.products[0].id, name: 'dus', conversion: 0 }];
    bad(g, /satuan produk tidak lengkap/);
  });

  it('pemulihan yang gagal menyimpan tidak mengubah data sama sekali', async () => {
    const a = await busyShop();
    const file = parseBackup(backupText(createBackup(a.store, at(10))));
    const persistence = new MemoryPersistence();
    const b = new Store(persistence);
    await b.init();
    await saveProduct(b, { name: 'Punya Saya', category: 'X', baseUnit: 'pcs', costPrice: 1, sellPrice: 2, minStock: 0 }, NOW);
    const before = dump(b);
    persistence.failNextCommit = true;
    await assert.rejects(restoreBackup(b, file), /Penyimpanan gagal/);
    assert.deepEqual(dump(b), before);
    const reopened = new Store(persistence);
    await reopened.init();
    assert.deepEqual(dump(reopened), before);
    // and a retry works
    await restoreBackup(b, file);
    assert.equal(b.getState().products.length, 2);
  });
});

describe('cadangan: pengingat', () => {
  it('umur cadangan dihitung dalam hari utuh; belum pernah atau tanggal rusak = null', () => {
    assert.equal(backupAgeDays(undefined, NOW), null);
    assert.equal(backupAgeDays('', NOW), null);
    assert.equal(backupAgeDays('bukan tanggal', NOW), null);
    assert.equal(backupAgeDays(NOW.toISOString(), NOW), 0);
    assert.equal(backupAgeDays(new Date(NOW.getTime() - 23 * 3_600_000).toISOString(), NOW), 0);
    assert.equal(backupAgeDays(new Date(NOW.getTime() - 25 * 3_600_000).toISOString(), NOW), 1);
    assert.equal(backupAgeDays(new Date(NOW.getTime() - 7 * 86_400_000).toISOString(), NOW), 7);
    // clock set back: never negative
    assert.equal(backupAgeDays(new Date(NOW.getTime() + 86_400_000).toISOString(), NOW), 0);
  });

  it('nama berkas memakai tanggal WIB', () => {
    assert.equal(backupFileName(NOW), 'bonbon-cadangan-2026-10-24.json');
    // 17:30 UTC on the 24th is already the 25th in WIB
    assert.equal(backupFileName(new Date('2026-10-24T17:30:00Z')), 'bonbon-cadangan-2026-10-25.json');
  });
});
