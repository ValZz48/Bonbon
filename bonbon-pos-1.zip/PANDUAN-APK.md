# Membuat APK Bonbon dari HP

Semua langkah di bawah bisa dilakukan dari browser HP. GitHub yang membangun APK-nya di server mereka (gratis, sekitar 10 menit).

## 1. Buat repo khusus APK

1. Buka github.com dan login.
2. Tombol **+** (kanan atas) > **New repository**.
3. Nama bebas, misalnya `bonbon-apk`. Pilih **Private** (penting, lihat catatan di bawah). Tekan **Create repository**.

## 2. Unggah zip kode (jangan diekstrak)

1. Di halaman repo: **Add file** > **Upload files**.
2. Pilih berkas `bonbon-pos.zip` dari HP.
3. Tekan **Commit changes**.

## 3. Buat berkas workflow

GitHub di HP tidak bisa mengunggah folder bernama `.github`, jadi berkas ini dibuat langsung di GitHub:

1. **Add file** > **Create new file**.
2. Di kolom nama, ketik persis: `.github/workflows/android.yml` (garis miring otomatis membuat folder).
3. Buka berkas `android.yml` yang dikirim bersama zip, salin seluruh isinya, tempel di kolom isi.
4. Tekan **Commit changes**. Ini sekaligus memulai build pertama.

## 4. Tunggu build selesai

- Buka tab **Actions** > klik proses **Bangun APK** yang sedang berjalan. Build pertama sekitar 8 sampai 12 menit.
- Centang hijau berarti berhasil. Silang merah berarti gagal: buka langkah yang merah, salin pesan error-nya, dan kirim ke Claude untuk diperbaiki.

## 5. Unduh dan pasang

1. Di halaman utama repo, cari **Releases** (di HP: gulir ke bawah) > pilih rilis terbaru (`apk-1`, dst.).
2. Ketuk **Bonbon.apk** untuk mengunduh.
3. Buka berkasnya. Android akan meminta izin "pasang dari sumber ini" untuk Chrome atau Files: izinkan, lalu ketuk **Pasang**.
4. Kalau muncul peringatan Play Protect ("aplikasi tidak dikenal"), pilih **Tetap pasang**. Itu normal karena aplikasi tidak dari Play Store.

## 6. Setelah terpasang

- **Notifikasi stok**: buka Pengaturan > Notifikasi stok > nyalakan > izinkan notifikasi > pilih jam > **Simpan pengaturan**. Tekan **Kirim tes notifikasi** untuk memastikan muncul di bilah notifikasi HP.
- **Scan barcode**: izin kamera diminta saat pertama dipakai.
- **Pindah data dari versi web**: data di APK terpisah dari data di Vercel. Di versi web buka Pengaturan > Cadangan data > Salin cadangan, lalu di APK Pengaturan > Cadangan data > Pulihkan dari cadangan > tempel.
- **Cadangkan rutin**. Kalau aplikasi di-uninstall, datanya ikut hilang. Tombol Simpan / kirim cadangan membuka menu bagikan Android (simpan ke Drive atau kirim ke diri sendiri lewat WhatsApp).

## 7. Memperbarui aplikasi

Unggah zip baru dengan **nama berkas yang sama**, `bonbon-pos.zip` (Add file > Upload files; berkas lama tertimpa). Kalau di repo masih ada zip lama bernama `warung-manop-pos.zip`, biarkan saja: build selalu memakai `bonbon-pos.zip`. Build berjalan otomatis dan rilis baru muncul. Pasang APK baru **di atas** yang lama: data tetap aman karena tanda tangan aplikasinya tetap.

## Catatan

- **Pernah memasang APK "Warung Manop" versi lama?** Bonbon punya ID aplikasi baru, jadi terpasang sebagai aplikasi terpisah. Pindahkan datanya lewat Cadangan data (salin di yang lama, pulihkan di Bonbon), lalu hapus yang lama.

- **Repo harus Private.** Kunci tanda tangan aplikasi (`warung-manop.keystore`, namanya tetap dari versi awal) ada di dalamnya. Untuk aplikasi pribadi yang dipasang manual ini aman selama repo tidak dipublikasikan.
- **Cetak struk**: di APK, cetak lewat aplikasi **RawBT** (gratis di Play Store). Cetak Bluetooth langsung dari aplikasi dan cetak PDF laporan belum ada di APK. Salin, kirim WhatsApp, dan bagikan CSV tetap jalan.
- **Notifikasi** adalah pengingat harian dengan isi sesuai stok terakhir di aplikasi. Karena stok hanya berubah di dalam aplikasi, isinya selalu akurat. Tidak ada notifikasi kalau semua stok aman.
- Konfigurasi APK ini belum bisa diuji di HP sungguhan dari lingkungan pembuatannya. Kalau ada yang tidak jalan (build merah, notifikasi tidak muncul, kamera tidak terbuka), kirim pesan error atau ceritakan yang terjadi.

## Notifikasi stok tidak muncul atau selalu "ditolak"

APK dari versi sebelum 27 Oktober 2026 dibangun tanpa plugin notifikasi (plugin harus tercatat di package.json, dan langkah pemasangnya dulu memakai `--no-save`). Gejalanya: izin selalu dianggap ditolak dan tes notifikasi gagal. Sudah diperbaiki di workflow, dan workflow sekarang berhenti dengan pesan jelas kalau plugin notifikasi, berkas, atau berbagi tidak ikut terpasang. Bangun ulang APK dengan kode terbaru, pasang di atas yang lama (data tetap), lalu nyalakan lagi saklar di Pengaturan > Notifikasi stok. Saklar dan jam pengingat berlaku langsung tanpa tombol Simpan.
